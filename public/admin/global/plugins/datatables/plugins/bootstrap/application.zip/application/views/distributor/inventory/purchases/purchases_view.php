
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li >Inventory Transaction</li>
                <li class="active">Purchases View</li>
            </ul>
            <ul class="breadcrumb pull-right">

                <?php if ($companyInfo->invoice_format_type == 1): ?>
                    <li>
                        <a class="inventoryAddPermission" href="<?php echo site_url($this->project . '/purchases_add'); ?>">
                            <i class="ace-icon fa fa-plus"></i>
                            Add
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url($this->project . '/purchases_list'); ?>">
                            <i class="ace-icon fa fa-list"></i>
                            List
                        </a>
                    </li>
                    <li>
                        <a class="inventoryEditPermission" href="<?php echo site_url($this->project . '/purchases_edit/' . $purchasesList->generals_id); ?>">
                            <i class="ace-icon fa fa-pencil bigger-130"></i> Edit
                        </a>
                    </li>

                <?php else: ?>

                    <li>
                        <a  onclick="window.print();" style="cursor:pointer;">
                            <i class="ace-icon fa fa-print"></i> Print
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url($this->project . '/purchases_list'); ?>">
                            <i class="ace-icon 	fa fa-list"></i> List
                        </a>
                    </li>

                <?php endif; ?>


            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1">

                    <?php if ($companyInfo->invoice_format_type == 1): ?>

                        <div class="widget-box transparent">
                            <div class="widget-header widget-header-large">
                                <h3 class="widget-title grey lighter">
                                    <i class="ace-icon fa fa-file-invoice green"></i>
                                    Purchases Voucher
                                </h3>
                                <div class="widget-toolbar no-border invoice-info">
                                    <span class="invoice-info-label">Payment Type:</span>
                                    <span class="red"><?php
                    if ($purchasesList->payType == 1) {
                        echo " Cash";
                    } elseif ($purchasesList->payType == 4) {
                        echo "Cash";
                    } elseif ($purchasesList->payType == 3) {
                        echo "Cheque";
                    } else {
                        echo "Credit";
                    }
                        ?></span>
                                    <br />
                                    <?php if ($purchasesList->payType == 2) { ?>
                                        <span class="invoice-info-label"> Due Date:</span>
                                        <span class="red"><?php echo date('d-m-Y', strtotime($purchasesList->dueDate)); ?></span>
                                    <?php } ?>
                                </div>
                                <div class="widget-toolbar no-border invoice-info">
                                    <span class="invoice-info-label">Voucher ID:</span>
                                    <span class="red"><?php echo $purchasesList->voucher_no; ?>  <?php echo str_replace("PUID#-", "", $purchasesList->mainInvoiceId); ?></span>
                                    <br />
                                    <span class="invoice-info-label"> Date:</span>
                                    <span class="red"><?php echo date('d-m-Y', strtotime($purchasesList->date)); ?></span>
                                </div>
                                <div class="widget-toolbar hidden-480"  class="hidden-xs">
                                    <a  onclick="window.print();" style="cursor:pointer;">
                                        <i class="ace-icon fa fa-print"></i>
                                    </a>
                                </div>
                            </div>

                        <?php endif; ?>

                        <div class="widget-body">
                            <div class="widget-main padding-24">

                                <?php if ($companyInfo->invoice_format_type == 1): ?>

                                    <div class="row"  >
                                        <div class="col-xs-4">
                                            <div class="row">
                                                <div class="col-xs-11 label label-lg label-default arrowed-in arrowed-right">
                                                    Company Info
                                                </div>
                                            </div>
                                            <div>
                                                <ul class="list-unstyled spaced">
                                                    <li>
                                                        <?php echo $companyInfo->companyName; ?>
                                                    </li>
                                                    <li>
                                                        <?php echo $companyInfo->email; ?>
                                                    </li>
                                                    <li>
                                                        <?php echo $companyInfo->phone; ?>
                                                    </li>
                                                    <li>
                                                        <?php echo $companyInfo->address; ?>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- /.col -->
                                        <div class="col-xs-4">
                                            <div class="row">
                                                <div class="col-xs-11 label label-lg label-default arrowed-in arrowed-right">
                                                    Supplier Info
                                                </div>
                                            </div>
                                            <div>
                                                <ul class="list-unstyled  spaced">
                                                    <li>
                                                        <?php echo $supplierInfo->supID . '[' . $supplierInfo->supName . ']' ?>
                                                    </li>
                                                    <li>
                                                        <?php echo $supplierInfo->supEmail; ?>
                                                    </li>
                                                    <li>
                                                        <?php echo $supplierInfo->supPhone; ?>
                                                    </li>
                                                    <li>
                                                        <?php echo $supplierInfo->supAddress; ?>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- /.col -->
                                        <div class="col-xs-4">
                                            <div class="row">
                                                <div class="col-xs-11 label label-lg label-default arrowed-in arrowed-right">
                                                    Invoice  Info
                                                </div>
                                            </div>
                                            <div>
                                                <ul class="list-unstyled  spaced">
                                                    <li>
                                                        Current Due: <span id="customerCurrentDue"></span>
                                                    </li>
                                                    <li>
                                                        Transportation: <?php
                                                    if (!empty($purchasesList->transportation) && $purchasesList->transportation > 0):
                                                        $transporation = $this->Common_model->tableRow('vehicle', 'id', $purchasesList->transportation);
                                                        echo $transporation->vehicleName . ' [ ' . $transporation->vehicleModel . ' ] ';
                                                    else:
                                                        echo "N/A";
                                                    endif;
                                                        ?>
                                                    </li>
                                                    <li>
                                                        Loader:
                                                        <?php
                                                        if (!empty($purchasesList->loader) && $purchasesList->loader > 0):
                                                            $loaderInfo = $this->Common_model->tableRow('employee', 'id', $purchasesList->loader);
                                                            echo $loaderInfo->personalMobile . ' [ ' . $loaderInfo->name . ' ] ';
                                                        else:
                                                            echo "N/A";
                                                        endif;
                                                        ?>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div><!-- /.col -->
                                    </div><!-- /.row -->
                                <?php else: ?>
                                    <div>
                                        <?php echo $companyInfo->report_header; ?>
                                    </div>
                                    <div class="row" style="height:10px">
                                        <div class="col-xs-9">
                                            <div>
                                                <ul class="list-unstyled  spaced">
                                                    <li style="margin: 0px;padding: 0px;">
                                                        <strong style="text-align: right !important; "> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;Name&nbsp;:&nbsp;</strong> <?php echo $supplierInfo->supName . ' [ ' . $supplierInfo->supID . ' ] ' ?>
                                                    </li>

                                                    <li style="margin: 0px;padding: 0px;">
                                                        <strong style="text-align: right !important; "> &nbsp;Address &nbsp;: &nbsp;</strong>  <?php echo $supplierInfo->supAddress; ?>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-xs-3 text-left">
                                            <div>
                                                <ul class="list-unstyled  spaced">
                                                    <li style="white-space: nowrap;margin: 0px;padding: 0px;">
                                                        <strong>Invoice ID &nbsp;&nbsp;:&nbsp;</strong>  <?php echo $purchasesList->voucher_no; ?>
                                                    </li>

                                                    <li style="white-space: nowrap;margin: 0px;padding: 0px;">
                                                        <strong style="text-align: right">    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;&nbsp; : &nbsp;</strong> <?php echo date('M d, Y', strtotime($purchasesList->date)); ?>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- /.col -->
                                    </div>
                                <?php endif; ?>
                                <div class="space"></div>
                                <div style="min-height:400px;" >
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <td class="center">#</td>
                                                <td><strong>Product</strong></td>
                                                <td class="text-right"><strong>Bundle</strong></td>
                                                <td class="text-right"><strong>Quantity</strong></td>
                                                <td><strong>Unit</strong></td>
                                                <td class="text-right"><strong>Unit Price</strong></td>
                                                <td class="text-right"><strong>Total Price</strong></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $tqty = 0;
                                            $trate = 0;
                                            $tprice = 0;
                                            foreach ($stockList as $key => $each_info):
                                                if ($each_info->type == 'In') {
                                                    $tqty += $each_info->quantity;
                                                    $trate += $each_info->rate;
                                                    $tprice += $each_info->rate * $each_info->quantity;
                                                    ?>
                                                    <tr>
                                                        <td class="center"><?php echo $key + 1; ?></td>
                                                        <td>
                                                            <?php
                                                            echo $this->Common_model->tableRow('productcategory', 'category_id', $each_info->category_id)->title;
                                                            ?>

                                                            <?php
                                                            $productInfo = $this->Common_model->tableRow('product', 'product_id', $each_info->product_id);
                                                            echo $productInfo->productName;
                                                            echo ' [ ' . $this->Common_model->tableRow('brand', 'brandId', $productInfo->brand_id)->brandName . ' ] ';
                                                            ?>
                                                        </td>

                                                        <td align="right"><?php
                                                    if ($each_info->bundle > 0) {
                                                        echo $each_info->bundle;
                                                    }
                                                            ?></td>
                                                        <td align='right'><?php echo $each_info->quantity; ?> </td>
                                                        <td>
                                                            <?php
                                                            if (!empty($each_info->unit)):
                                                                echo $this->Common_model->tableRow('unit', 'unit_id', $each_info->unit)->unitTtile;
                                                            endif;
                                                            ?>
                                                        </td>
                                                        <td align='right'><?php echo $each_info->rate; ?> </td>
                                                        <td align='right'><?php echo number_format($each_info->rate * $each_info->quantity, 2); ?> </td>
                                                    </tr>
                                                <?php }endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Sub-Total</strong></td>
                                                <td align='right'><?php echo number_format((float) $tprice, 2, '.', ','); ?></td>
                                            </tr>
                                            <?php if (!empty($purchasesList->discount) && $purchasesList->discount > 0): ?>

                                                <tr>
                                                    <td colspan="6" align="right"><strong>Discount ( - )</strong></td>
                                                    <td align='right'><?php echo number_format((float) $purchasesList->discount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if (!empty($purchasesList->loaderAmount) && $purchasesList->loaderAmount > 0): ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Loader ( + )</strong></td>
                                                    <td align='right'><?php echo number_format((float) $purchasesList->loaderAmount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if (!empty($purchasesList->transportationAmount) && $purchasesList->transportationAmount > 0): ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Transportation ( + )</strong></td>
                                                    <td align='right'><?php echo number_format((float) $purchasesList->transportationAmount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>

                                            <?php
                                            $netAmount = ($tprice + $purchasesList->transportationAmount + $purchasesList->loaderAmount) - $purchasesList->discount;
                                            ?>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Net Total</strong></td>
                                                <td align='right'><?php echo number_format((float) $netAmount, 2, '.', ','); ?></td>
                                            </tr>

                                            <?php if (!empty($creditAmount->credit) && $creditAmount->credit > 0): ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Payment</strong></td>
                                                    <td align='right'><?php echo number_format((float) $creditAmount->credit, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php
                                            if (!empty($creditAmount->credit)):
                                                $dueAmount = $netAmount - $creditAmount->credit;
                                            else:
                                                $dueAmount = $netAmount;
                                            endif;

                                            if (!empty($dueAmount) && $dueAmount > 0) :
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Due Amount</strong></td>
                                                    <td align='right'><?php echo number_format((float) $dueAmount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <td colspan="7" >
                                                    <strong>  <span>In Words : &nbsp;</span> <?php echo $this->Common_model->get_bd_amount_in_text($netAmount); ?></strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="7" >
                                                    <span>Narration : &nbsp;</span> <?php echo $purchasesList->narration; ?>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div class="hr hr8 hr-double hr-dotted"></div>

                                <?php if ($companyInfo->invoice_format_type == 1): ?>

                                    <div class="row">
                                        <div class="col-xs-4 text-center">
                                            <p>Prepared By:_____________<br />
                                                Date:____________________
                                            </p>
                                        </div>
                                        <div class="col-xs-4 text-center">
                                        </div>
                                        <div class="col-xs-4 text-center">
                                            <p>Approved By:________________<br />
                                                Date:_________________</p>
                                        </div>
                                    </div>
                                    <hr />

                                <?php else: ?>

                                    <div><?php echo $companyInfo->report_footer; ?></div>


                                <?php endif; ?>

                                
                                <hr />
                                <p class="text-center"><?php //echo $this->mtcb->table_row('system_config', 'option', 'ADDRESS')->value;                                                                   ?></p>
                                <!--                                <div class="space-6"></div>
                                                                <div class="well">
                                                                    Thank you for choosing Ace Company products.
                                                                    We believe you will be satisfied by our services.
                                                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>

<script>
    var url = baseUrl + "SalesController/getSupplierClosingBalance";

    $.ajax({
        type: 'POST',
        url:baseUrl + "InventoryController/getSupplierClosingBalance",
        data:{
            supplierid: '<?php echo $purchasesList->supplier_id; ?>'
        },
        success: function (data)
        {
            data=parseFloat(data);
            if(isNaN(data)){
                data=0;
            }
            $('#customerCurrentDue').text(parseFloat(data).toFixed(2));
        }
    });


</script>

