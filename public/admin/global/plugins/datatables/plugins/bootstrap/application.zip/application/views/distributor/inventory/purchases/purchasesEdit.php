
<div class="main-content" >
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li >Inventory Transaction</li>
                <li class="active">Purchases Edit</li>
                <li class="active"> <span style="color:red;"> * </span> <span style="color:red">Mark field must be fill up</span></li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a class="inventoryAddPermission" href="<?php echo site_url($this->project . '/purchases_add'); ?>">
                        <i class="ace-icon fa fa-plus"></i>
                        Add
                    </a>
                </li>
                <li>
                    <a href="<?php echo site_url($this->project . '/purchases_list'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
                <li>
                    <a class="inventoryEditPermission" href="<?php echo site_url($this->project . '/viewPurchases/' . $editPurchases->generals_id); ?>">
                        <i class="ace-icon fa fa-search-plus bigger-130"></i> View
                    </a>
                </li>

            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <form id="publicForm" action=""  method="post" class="form-horizontal">
                    <table class="mytable  table table-bordered">
                        <tr>
                            <td  style="padding: 10px!important;">
                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Supplier ID <span style="color:red;">*</span></label>
                                            <div class="col-sm-6">
                                                <select  id="supplierid" name="supplierID" onchange="getSupplierClosingBalance(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Supplier ID or Name" required>
                                                    <option></option>
                                                    <?php foreach ($supplierList as $key => $each_info): ?>
                                                        <option <?php
                                                    if ($editPurchases->supplier_id == $each_info->sup_id) {
                                                        echo "selected";
                                                    }
                                                        ?> value="<?php echo $each_info->sup_id; ?>"><?php echo $each_info->supID . ' [ ' . $each_info->supName . ' ] ' . ' [ ' . $each_info->supPhone . ' ] '; ?></option>
                                                        <?php endforeach; ?>
                                                </select>
                                                <div class="clearfix"></div>
                                                <span id="loadCusSup"></span>

                                            </div>
                                            <div class="col-sm-2" id="hideNewSup">
                                                <a  data-toggle="modal" data-target="#myModal" class="btn btn-xs btn-success"><i class="fa fa-plus"></i>&nbsp;New</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Reference</label>
                                            <div class="col-sm-6">
                                                <input type="text" id="form-field-1" name="reference"  value="<?php echo $editPurchases->reference; ?>" class="form-control" placeholder="Reference" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Payment Type<span style="color:red;"> *</span></label>
                                            <div class="col-sm-6">
                                                <select onchange="showBankinfo(this.value)"  name="paymentType"  class="chosen-select form-control" id="paymentType" data-placeholder="Select Payment Type" required>
                                                    <option></option>
                                                    <!--<option value="1" selected >Full Cash</option>-->
                                                    <option <?php
                                                        if ($editPurchases->payType == 4) {
                                                            echo "selected";
                                                        }
                                                        ?> value="4">Cash</option>
                                                    <option <?php
                                                        if ($editPurchases->payType == 2) {
                                                            echo "selected";
                                                        }
                                                        ?>  value="2" >Credit</option>
                                                    <option <?php
                                                        if ($editPurchases->payType == 3) {
                                                            echo "selected";
                                                        }
                                                        ?>  value="3">Cheque/ DD / PO </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12" id="showBankInfo" style="display:none;">
                                        <div class="form-group">
                                            <div class="col-sm-10">
                                                <div class="col-sm-3">
                                                    <input type="text" value="<?php echo isset($bank_check_details->bankName) ? $bank_check_details->bankName : '' ?>" name="bankName" id="bankName" class="form-control" placeholder="Bank Name"/>
                                                </div>
                                                <div class="col-sm-3">
                                                    <input type="text" value="<?php echo isset($bank_check_details->branchName) ? $bank_check_details->branchName : '' ?>" name="branchName" id="branchName" class="form-control" placeholder="Branch Name"/>
                                                </div>
                                                <div class="col-sm-3">
                                                    <input type="text" value="<?php echo isset($bank_check_details->checkNo) ? $bank_check_details->checkNo : '' ?>" class="form-control" id="checkNo" name="checkNo" placeholder="Cheque NO"/>
                                                </div>
                                                <div class="col-sm-3">
                                                    <input class="form-control date-picker" id="checkDate" name="checkDate" name="purchasesDate" type="text" value="<?php echo isset($bank_check_details->checkDate) ? $bank_check_details->checkDate : '' ?>" data-date-format="dd-mm-yyyy" />
                                                </div>
                                            </div>
                                            <div class="col-sm-2"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Voucher ID</label>
                                            <div class="col-sm-4">
                                                <input type="text" id="form-field-1" name="userInvoiceId"  value="<?php echo str_replace("PUID#-","",$editPurchases->mainInvoiceId); ?>" class="form-control" placeholder="Voucher ID "/>
                                            </div>
                                            <div class="col-sm-3">
                                                <input type="text" id="form-field-1" name="voucherid" readonly value="<?php echo $editPurchases->voucher_no; ?>" class="form-control" placeholder="Product Code" required/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Purchases Date<span style="color:red;"> *</span></label>
                                            <div class="col-sm-7">
                                                <div class="input-group">
                                                    <input class="form-control date-picker" name="purchasesDate" id="purchasesDate" type="text" value="<?php echo date('d-m-Y', strtotime($editPurchases->date)); ?>" data-date-format="dd-mm-yyyy" required/>
                                                    <span class="input-group-addon">
                                                        <i class="fa fa-calendar bigger-110"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Loader</label>
                                            <div class="col-sm-7">
                                                <select  name="loader"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Loader">
                                                    <option></option>
                                                    <?php foreach ($employeeList as $key => $eachEmp): ?>
                                                        <option <?php
                                                    if ($editPurchases->loader == $eachEmp->id): echo "selected";
                                                    endif;
                                                        ?> value="<?php echo $eachEmp->id; ?>"><?php echo $eachEmp->personalMobile . ' [ ' . $eachEmp->name . ']'; ?></option>
                                                        <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Transportation</label>
                                            <div class="col-sm-7">
                                                <select  name="transportation"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Transportation">
                                                    <option></option>
                                                    <?php foreach ($vehicleList as $key => $eachVehicle): ?>
                                                        <option <?php
                                                    if ($editPurchases->transportation == $eachVehicle->id) {
                                                        echo "selected";
                                                    }
                                                        ?> value="<?php echo $eachVehicle->id; ?>"><?php echo $eachVehicle->vehicleName . ' [ ' . $eachVehicle->vehicleModel . ' ]'; ?></option>
                                                        <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12" id="showAccount">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Due Date <span style="color:red;">*</span> </label>
                                            <div class="col-sm-7">
                                                <div class="input-group">
                                                    <input class="form-control date-picker" name="dueDate" id="dueDate" type="text" value="<?php echo date('d-m-Y', strtotime($editPurchases->dueDate)); ?>" data-date-format="dd-mm-yyyy" />
                                                    <span class="input-group-addon">
                                                        <i class="fa fa-calendar bigger-110"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="clearfix"></div>
                                <div class="clearfix"></div>
                                <div class="col-md-6" id="hideAccount"  style="display: none;">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Pay. From( CR ) <span style="color:red;">*</span></label>
                                        <div class="col-sm-7">
                                            <select  name="accountCr" class="chosen-select form-control  checkAccountBalance" id="form-field-select-3" data-placeholder="Search by Account Head"  onchange="check_pretty_cash(this.value)">
                                                <option value=""></option>
                                                <?php
                                                foreach ($accountHeadList as $key => $head) {
                                                    ?>
                                                    <optgroup label="<?php echo $head['parentName']; ?>">
                                                        <?php
                                                        foreach ($head['Accountledger'] as $eachLedger) :
                                                            ?>
                                                            <option value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                        <?php endforeach; ?>
                                                    </optgroup>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-2">
                                            <input type="text" id="accountBalance" readonly name="balance"  value="" class="form-control" placeholder="Balance" />
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </td>
                        </tr>
                        <tr>
                            <td  style="padding: 10px!important;">
                                <div class="col-md-12">
                                    <div class="col-md-9">
                                        <div class="panel panel-default">
                                            <div class="panel-body">
                                                <div class="table-header">
                                                    Purchases Item
                                                </div>
                                                <table class="table table-bordered table-hover" id="show_item">
                                                    <thead>
                                                        <tr>
                                                            <td style="width:20%" align="center"><strong>Product Category<span style="color:red;"> *</span></strong></td>
                                                            <td style="width:25%" align="center"><strong>Product<span style="color:red;"> *</span></strong></td>
                                                            <td style="width:15%" align="center"><strong>Bundle<span style="color:red;"> *</span></strong></td>
                                                            <td style="width:10%" align="center"><strong>Quantity<span style="color:red;"> *</span></strong></td>
                                                            <td nowrap style="width:12%;" align="center"><strong>Unit Price(BDT)<span style="color:red;"> *</span> </strong></td>
                                                            <td nowrap style="width:13%;" align="center"><strong>Total Price(BDT)</strong></td>
                                                            <td style="width:5%" align="center"><strong>Action</strong></td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <select id="productID" onchange="getProductList2(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Product">
                                                                    <option value=""></option>
                                                                    <?php foreach ($productCat as $key => $eachCat):
                                                                        ?>
                                                                        <option categoryName="<?php echo $eachCat->title; ?>"  value="<?php echo $eachCat->category_id; ?>"><?php echo $eachCat->title; ?></option>
                                                                        <?php
                                                                    endforeach;
                                                                    ?>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <select id="productID2" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Product">
                                                                    <option value=""></option>
                                                                </select>
                                                            </td>
                                                            <td><input type="text" id="bundleValue" class="form-control text-right bundle decimal"  placeholder="0"></td>
                                                            <td><input type="text" class="form-control text-right quantity decimal"  placeholder="0"></td>
                                                            <td><input type="text" class="form-control text-right rate decimal" placeholder="0.00"  ></td>
                                                            <td><input type="text" class="form-control text-right price decimal" placeholder="0.00" readonly="readonly"></td>
                                                            <td><a id="add_item" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add</a></td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <?php
                                                        $totalQty = 0;
                                                        $totalReturn = 0;
                                                        $totalRate = 0;
                                                        $totalprice = 0;
                                                        foreach ($editStock as $key => $eachStock) :
                                                            if ($eachStock->type == 'In') {
                                                                $totalQty+=$eachStock->quantity;
                                                                $totalRate+=$eachStock->rate;
                                                                $totalprice+=$eachStock->price;
                                                                $returnQtyedit = $this->Inventory_Model->getReturnAbleCylinder2($this->dist_id, $eachStock->generals_id, $eachStock->product_id);
                                                                $totalReturn+=$returnQtyedit->quantity;
                                                                ?>
                                                                <tr class="new_item<?php echo $key + 767; ?>">
                                                            <input type="hidden" name="category_id[]" value="<?php echo $eachStock->category_id; ?>">
                                                            <td style="padding-left:15px;">
                                                                <?php
                                                                $cateogry = $this->Common_model->tableRow('productcategory', 'category_id', $eachStock->category_id)->title;
                                                                $productInfo = $this->Common_model->tableRow('product', 'product_id', $eachStock->product_id);
                                                                $brandInfo = $this->Common_model->tableRow('brand', 'brandId', $productInfo->brand_id);
                                                                echo $cateogry;
                                                                ?>
                                                                <input type="hidden" name="product_id[]" value="<?php echo $eachStock->product_id; ?>">
                                                            </td>
                                                            <td>
                                                                <?php
                                                                echo $productInfo->productName . ' [ ' . $brandInfo->brandName . ' ] ';
                                                                ?>
                                                            </td>
                                                            <td align="right"><input <?php
                                                        if ($eachStock->category_id != 1) {
                                                            echo "readonly";
                                                        }
                                                                ?> type="text" class="add_bundle form-control text-right decimal" id="bundle_<?php echo $key + 767 ?>" name="bundle[]" value="<?php echo $eachStock->bundle; ?>">
                                                            </td>
                                                            <td align="right"><input type="text" class="add_quantity form-control text-right decimal" id="qty_<?php echo $key + 767 ?>" name="quantity[]" value="<?php echo $eachStock->quantity; ?>"></td>

                                                            <td align="right"><input type="text" class="add_rate decimal text-right form-control" id="rate_<?php echo $key + 767 ?>" name="rate[]" value="<?php echo $eachStock->rate; ?>"></td>
                                                            <td align="right"><?php
                                                            $totalEditPrice+=$eachStock->price;
                                                                ?><input type="text" readonly class="add_price text-right form-control" id="tprice_<?php echo $key + 767 ?>" name="price[]" value="<?php echo $eachStock->price; ?>"></td>
                                                            <td><a del_id="<?php echo $key + 767; ?>" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    endforeach;
                                                    ?>
                                                    <tr>
                                                        <td align="right" colspan="3"><strong>Total(BDT)</strong></td>
                                                        <td align="right"><strong class="total_quantity"><?php echo $totalQty; ?></strong></td>
                                                        <td align="right"><strong class="total_rate"><?php echo $totalRate; ?></strong></td>
                                                        <td align="right"><strong class="total_price1"><?php echo $totalprice; ?></strong></td>
                                                    </tr>
                                                    </tfoot>
                                                </table>
                                                <table class="table table-bordered table-hover table-success">
                                                    <tr>
                                                        <td>
                                                            <textarea style="border:none;" cols="120"  class="form-control" name="narration" placeholder="Narration......" type="text"><?php echo $editPurchases->narration; ?></textarea>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="panel panel-default">
                                            <div class="panel-body">
                                                <div class="table-header">
                                                    Payment Calculation
                                                </div>
                                                <table  class="table table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <td nowrap align="right"><strong>Total (BDT)</strong></td>
                                                            <td align="right"><input type="text" value="<?php echo $totalEditPrice . '.00'; ?>" class="text-right form-control total_price" readonly /></td>
                                                        </tr>
<!--                                                        <tr>
                                                            <td nowrap  align="right"><strong>Discount ( - )</strong></td>
                                                            <td><input type="text" readonly id="discount" onkeyup="calcutateFinal()"   style="text-align: right" name="discount" value="<?php echo $editPurchases->discount; ?>"  class="form-control"  placeholder="0.00"/></td>
                                                        </tr>-->



                                                    <input type="hidden" readonly id="discount" onkeyup="calcutateFinal()"   style="text-align: right" name="discount" value="<?php echo $editPurchases->discount; ?>"  class="form-control"  placeholder="0.00"/>



                                                    <tr>
                                                        <td nowrap  align="right"><strong>Loader ( + )</strong></td>
                                                        <td><input type="text" id="loader" onkeyup="calcutateFinal()"   style="text-align: right" name="loaderAmount" value="<?php echo $editPurchases->loaderAmount; ?>"  class="form-control"  placeholder="0.00"/></td>
                                                    </tr>
                                                    <tr>
                                                        <td nowrap  align="right"><strong>Transportation ( + )</strong></td>
                                                        <td><input type="text" id="transportation" onkeyup="calcutateFinal()"   style="text-align: right" name="transportationAmount"  value="<?php echo $editPurchases->transportationAmount; ?>"  class="form-control"  placeholder="0.00"/></td>
                                                    </tr>
                                                    <tr>
                                                        <td nowrap  align="right"><strong>Net Total</strong></td>
                                                        <td><input type="text" id="netAmount"  style="text-align: right" name="netTotal" value="<?php echo ($editPurchases->loaderAmount + $totalEditPrice + $editPurchases->transportationAmount); ?>" readonly class="form-control"  placeholder="0.00"/></td>
                                                    </tr>

                                                    <tr id="chaque_amount_class" style="display:none">
                                                        <td nowrap  align="right"><strong>Chaque Amount</strong></td>
                                                        <td><input type="text" id="chaque_amount"  style="text-align: right" name="chaque_amount" value="<?php echo isset($bank_check_details->totalPayment) ? $bank_check_details->totalPayment : '' ?>"  class="form-control"  placeholder="0.00"/></td>
                                                    </tr>

                                                    <tr class="partialPayment" >
                                                        <td nowrap align="right"><strong><span style="color:red;">*</span>Add Account</strong></td>
                                                        <td>
                                                            <select style="width:100%!important"  name="accountCrPartial" class="chosen-select  checkAccountBalance" id="partialHead2" data-placeholder="Search by Account Head"  onchange="check_pretty_cash(this.value)">
                                                                <option value=""></option>
                                                                <?php
                                                                foreach ($accountHeadList as $key => $head) {
                                                                    // if ($key == 42 || $key == 45 || $key == 55) {
                                                                    ?>
                                                                    <optgroup label="<?php echo $head['parentName']; ?>">
                                                                        <?php
                                                                        foreach ($head['Accountledger'] as $eachLedger) :
                                                                            ?>
                                                                            <option <?php
                                                                    if (!empty($accountIdForEdit) && $accountIdForEdit == $eachLedger->chartId) {
                                                                        echo "selected";
                                                                    } else {
                                                                        if ($eachLedger->chartId == '54') {
                                                                            echo "selected";
                                                                        }
                                                                    }
                                                                            ?> value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                                            <?php endforeach; ?>
                                                                    </optgroup>
                                                                    <?php
                                                                    //}
                                                                }
                                                                ?>
                                                            </select>
                                                        </td>
                                                        <!--<td><input type="text" name="dueAllotment" class="form-control text-right dueAmount" placeholder="0.00" readonly="readonly"></td>-->
                                                    </tr>

                                                    <tr class="partialPayment">
                                                        <td nowrap align="right"><strong> <span style="color:red;"> * </span>Account Balance</strong></td>
                                                        <td align="right"><input name="accountBalance" readonly id="accountLastBalance" type="text" class="form-control text-right" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" placeholder="0.00"></td>
                                                    </tr>

                                                    <tr  class="partialPayment">
                                                        <td nowrap  align="right"><strong><span style="color:red;">*</span>Payment ( - ) </strong></td>
                                                        <td  align="right"><input name="thisAllotment" id="thisAllotment" type="text" onkeyup="calcutateFinal(this.value)" value="<?php echo $creditAmount2->credit; ?>" class="form-control text-right payment" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" placeholder="0.00"></td>
                                                    </tr>
                                                    <tr>
                                                        <td nowrap align="right"><strong>Due Amount</strong></td>
                                                        <td  align="right"><input id="currentDue" type="text" onkeyup="calculateDueAmount(this.value)" readonly value="" class="form-control text-right payment" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" placeholder="0.00"></td>
                                                    </tr>
                                                    <tr>
                                                        <td nowrap  align="right"><strong>Previous Due</strong></td>
                                                        <td align="right"><input readonly id="customerPreviousDue" readonly type="text" onkeyup="calculateDueAmount(this.value)" value="" class="form-control text-right payment" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" placeholder="0.00"></td>
                                                    </tr>
                                                    <tr>
                                                        <td nowrap  align="right"><strong>Total Due</strong></td>
                                                        <td align="right"><input id="totalDue" type="text" readonly onkeyup="calculateDueAmount(this.value)" value="" class="form-control text-right payment" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" placeholder="0.00"></td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td  style="padding: 10px!important;">
                                <div class="clearfix"></div>
                                <div class="clearfix form-actions" >
                                    <div class="col-md-offset-3 col-md-9">
                                        <button onclick="return isconfirm2()" id="subBtn" class="btn btn-info" type="button">
                                            <i class="ace-icon fa fa-check bigger-110"></i>
                                            Update
                                        </button>
                                        &nbsp; &nbsp; &nbsp;
                                        <!--                                        <button class="btn" onclick="showCylinder()" type="button">
                                                                                    <i class="ace-icon fa fa-shopping-cart bigger-110"></i>
                                                                                    Returned Cylinder
                                                                                </button>-->
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>

        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

<script>


    $(document).ready(function(){
        $('.payment').keyup(function(){
            var accountAmount=parseFloat($("#accountLastBalance").val());
            var thisAllotment=parseFloat($("#thisAllotment").val());
            if(accountAmount < thisAllotment){
                swal("Payment amount cannot greater than from account balance", "Validation Error!", "error");
                $("#thisAllotment").val('');
                calcutateFinal();
            }

        });
    });












    var accountId = $('#partialHead2').val();
    $.ajax({
        type: 'POST',
        data: {account: accountId},
        url: '<?php echo site_url('FinaneController/accountBalanceWithOutDate'); ?>',
        success: function(result){
            $('#accountLastBalance').val(result);
        }
    });



    $(document).ready(function(){
        $('.checkAccountBalance').change(function(){
            var accountId = $('#partialHead2').val();
            $.ajax({
                type: 'POST',
                data: {account: accountId},
                url: '<?php echo site_url('FinaneController/accountBalanceWithOutDate'); ?>',
                success: function(result){
                    $('#accountLastBalance').val(result);
                }
            });
        });
    });




    $(document).ready(function () {
        calcutateFinal();

        var payType = $('#paymentType').val();
        showBankinfo(payType);
    });


    function isconfirm2(){
        var supplierid=$("#supplierid").val();
        var purchasesDate=$("#purchasesDate").val();
        var paymentType=$("#paymentType").val();
        var paymentType=$("#paymentType").val();
        var dueDate=$("#dueDate").val();
        var partialHead=$("#partialHead2").val();
        var thisAllotment=$("#thisAllotment").val();
        var bankName=$("#bankName").val();
        var branchName=$("#branchName").val();
        var checkNo=$("#checkNo").val();
        var checkDate=$("#checkDate").val();
        var chaque_amount=parseFloat($("#chaque_amount").val());
        if(isNaN(chaque_amount)){
            chaque_amount=0;
        }

        var cylinder=0;
        if ($("#culinderReceive").css('display') == 'none') {
            cylinder=0;
        }else{
            var cylinderItem=parseFloat($(".total_quantity2").text());
            if(isNaN(cylinderItem)){
                cylinderItem=0;
            }else{
                cylinder=1;
            }


        }
        var totalPrice=parseFloat($(".total_price").val());
        if(isNaN(totalPrice)){
            totalPrice=0;
        }
        if(supplierid == ''){
            swal("Select Supplier Name!", "Validation Error!", "error");
        }else if(purchasesDate == ''){
            swal("Select Purchases Date!", "Validation Error!", "error");
        }else if(paymentType == ''){
            swal("Select Payment Type", "Validation Error!", "error");
        }else if(paymentType == 2 && dueDate == ''){
            swal("Select Due Date!", "Validation Error!", "error");
        }else if(paymentType == 3 && bankName == ''){
            swal("Type Bank Name!", "Validation Error!", "error");
        }else if(paymentType == 3 && branchName == ''){
            swal("Type Branch Name!", "Validation Error!", "error");
        }else if(paymentType == 3 && checkNo == ''){
            swal("Type Cheque No!", "Validation Error!", "error");
        }else if(paymentType == 3 && checkDate == ''){
            swal("Select Cheque Date!", "Validation Error!", "error");
        }else if(paymentType == 3 && chaque_amount == ''){
            swal("Given Cheque Payment!", "Validation Error!", "error");
        }else if(totalPrice == '' || totalPrice < 0){
            swal("Add Purcahses Item!", "Validation Error!", "error");
        }else if(paymentType == 4 && partialHead == ''){
            swal("Select Account Head!", "Validation Error!", "error");
        }else if(paymentType == 4 && thisAllotment == ''){
            swal("Given Cash Amount!", "Validation Error!", "error");
        }else{
            swal({
                title: "Are you sure ?",
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#73AE28',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true,
                type: 'success'
            },
            function (isConfirm) {
                if (isConfirm) {
                    $("#publicForm").submit();
                }else{
                    return false;
                }
            });
        }
    }
</script>




<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add New Supplier</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <form id="publicForm2" action=""  method="post" class="form-horizontal">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Supplier ID </label>
                                <div class="col-sm-6">
                                    <input type="text" id="form-field-1" name="supplierId" readonly value="<?php echo isset($supplierID) ? $supplierID : ''; ?>" class="form-control supplierId" placeholder="SupplierID" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Supplier Name </label>

                                <div class="col-sm-6">
                                    <input type="text" id="form-field-1" name="supName" class="form-control required supName" placeholder="Name" required/>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Phone</label>
                                <div class="col-sm-6">
                                    <input type="text" maxlength="11" id="form-field-1" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" onblur="checkDuplicatePhone(this.value)" name="supPhone" placeholder="Phone" class="form-control" />
                                    <span id="errorMsg"  style="color:red;display: none;"><i class="ace-icon fa fa-spinner fa-spin orange bigger-120"></i> &nbsp;&nbsp;Phone Number already Exits!!</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email</label>
                                <div class="col-sm-6">
                                    <input type="email" id="form-field-1" name="supEmail" placeholder="Email" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address</label>
                                <div class="col-sm-6">
                                    <!--<textarea id="editor1" cols="10" rows="5" name="comp_add"></textarea>-->
                                    <textarea  cols="6" rows="3" placeholder="Type Address.." class="form-control" name="supAddress"></textarea>
                                </div>
                            </div>



                            <div class="clearfix form-actions" >
                                <div class="col-md-offset-3 col-md-9">
                                    <button onclick="saveNewSupplier()" id="subBtn2" class="btn btn-info" type="button" >
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        Save
                                    </button>
                                    &nbsp; &nbsp; &nbsp;
                                    <button class="btn" type="reset" data-dismiss="modal">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            </div>
        </div>

    </div>
</div>

<!--<script type="text/javascript" src="<?php echo base_url('assets/purchases/purchasesEdit.js'); ?>"></script>-->
<script>



    $.ajax({
        type: "POST",
        url: baseUrl + "InventoryController/loadCusSupDetails",
        data: {
            supCusId:<?php echo $editPurchases->supplier_id; ?>,
            type:2
        },
        success: function (data) {

            $("#loadCusSup").html(data);
        }
    });



<?php if (!empty($cylinserOut)): ?>
        setTimeout(function() {
            $('#culinderReceive').show();
        }, 2000);
<?php else:
    ?>
            setTimeout(function() {
                $('#culinderReceive').hide();
            }, 2000);

<?php endif; ?>


<?php if ($editPurchases->payType == 4) { ?>

        setTimeout(function() {
            $(".partialPayment").show(10);

        }, 2000);
<?php } elseif ($editPurchases->payType == 3) { ?>

        $("#showBankInfo").show(10);
<?php } elseif ($editPurchases->payType == 2) { ?>

        setTimeout(function() {
            $(".partialPayment").hide(10);
        }, 2000);

        $("#showAccount").show(10);
<?php } ?>


</script>

<script>


    function calculateDueAmount() {
        calculateSupplierDue();
    }
    $(document).ready(function () {
        calculateSupplierDue();
    });
    function getSupplierClosingBalance(supCusId){
        calculateSupplierDue();

        $.ajax({
            type: "POST",
            url: baseUrl + "InventoryController/loadCusSupDetails",
            data: {
                supCusId:supCusId,
                type:2
            },
            success: function (data) {

                $("#loadCusSup").html(data);
            }
        });

    }
    $(document).on("keyup", ".add_quantity", function () {
        var id_arr = $(this).attr('id');
        var id = id_arr.split("_");
        var element_id = id[id.length - 1];

        var quantity = parseFloat($("#qty_" + element_id).val());
        if(isNaN(quantity)){
            quantity=0;
        }
        var rate= parseFloat($("#rate_" + element_id).val());
        if(isNaN(rate)){
            rate=0;
        }
        var totalAmount = quantity * rate;
        $("#tprice_"+ element_id).val(parseFloat(totalAmount).toFixed(2));

        var row_total = 0;
        $.each($('.add_price'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            row_total += quantity;
        });
        $('.total_price').val(parseFloat(row_total).toFixed(2));

        findTotalCal();
        setTimeout(function() {
            calcutateFinal();
        }, 100);


    });

    $(document).on("keyup", ".add_return", function () {
        findTotalCal();
    });


    $(document).on("keyup", ".add_rate", function () {
        var id_arr = $(this).attr('id');
        var id = id_arr.split("_");
        var element_id = id[id.length - 1];

        var quantity = parseFloat($("#qty_" + element_id).val());
        if(isNaN(quantity)){
            quantity=0;
        }
        var rate= parseFloat($("#rate_" + element_id).val());
        if(isNaN(rate)){
            rate=0;
        }
        var totalAmount = quantity * rate;
        $("#tprice_"+ element_id).val(parseFloat(totalAmount).toFixed(2));

        var row_total = 0;
        $.each($('.add_price'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            row_total += quantity;
        });
        $('.total_price').val(parseFloat(row_total).toFixed(2));

        findTotalCal();
        setTimeout(function() {
            calcutateFinal();
        }, 100);


    });

    var calculateSupplierDue = function () {
        var supplierid=parseFloat($('#supplierid').val());
        $.ajax({
            type: 'POST',
            url: baseUrl + "InventoryController/getSupplierClosingBalance",
            data:{
                supplierid: supplierid
            },
            success: function (data)
            {
                data=parseFloat(data);
                if(isNaN(data)){
                    data=0;
                }
                $('#supplierCurrentBal').val(parseFloat(data).toFixed(2));
            }
        });
    };



    function calcutateFinal(){

        var total_price = parseFloat($(".total_price").val());
        if(isNaN(total_price)){
            total_price=0;
        }

        var discount = parseFloat($("#discount").val());
        if(isNaN(discount)){
            discount=0;
        }
        var loader = parseFloat($("#loader").val());
        if(isNaN(loader)){
            loader=0;
        }
        var transportation = parseFloat($("#transportation").val());
        if(isNaN(transportation)){
            transportation=0;
        }

        var total_price = (total_price + transportation +  loader) - discount;
        $("#netAmount").val(parseFloat(total_price).toFixed(2));
        var payment = parseFloat($("#thisAllotment").val());//payment
        if(isNaN(payment)){
            payment=0;
        }
        var previousDue = parseFloat($("#customerPreviousDue").val());


        if(isNaN(previousDue)){
            previousDue=0;
        }
        if(payment > total_price ){
            $("#currentDue").val(parseFloat(0.00).toFixed(2));
        }else{
            $("#currentDue").val(parseFloat(total_price - payment).toFixed(2));
        }
        $("#totalDue").val(parseFloat((total_price+previousDue) - payment).toFixed(2));
    }





    function getProductList2(cat_id) {
        $.ajax({
            type: "POST",
            url: baseUrl + "InventoryController/getProductList",
            data: 'cat_id=' + cat_id,
            success: function (data) {
                $('#productID2').chosen();
                $('#productID2 option').remove();
                $('#productID2').append($(data));
                $("#productID2").trigger("chosen:updated");
            }
        });


        if(cat_id ==1){
            $(".bundle").attr('readonly',false);
        }else{
            $(".bundle").attr('readonly',true);
        }



    }



    $('#accountBalance').hide();
    $(document).ready(function () {
        $('.checkAccountBalance').change(function () {
            var accountId = $(this).val();
            $.ajax({
                type: 'POST',
                data: {
                    account: accountId
                },
                url: baseUrl + "FinaneController/checkOnlyBalanceForPayment",
                success: function (result) {
                    $('#accountBalance').show();
                    $('#accountBalance').val('');
                    $('#accountBalance').val(result);
                }
            });
        });
    });
    function showBankinfo(id) {
        $('#accountBalance').hide();
        $("#chaque_amount_class").hide(10);
        if (id != 4) {
            $('.payment').val('');
        }
        calcutateFinal();


        if (id == 4) {
            $("#hideAccount").hide();
            $("#showAccount").hide();
            $("#showBankInfo").hide();
            $(".partialPayment").show();
            //$("#partialHead").css({"width":"30%!important"});
            $(".chosen-select").chosen();
            $(".chosen-select").css({
                width: "100%!important"
            });
            $('#partialHead').val('').trigger('chosen:updated');
        } else {
            $("#hideAccount").hide();
            $("#showAccount").hide();
            $("#showBankInfo").hide();
            setTimeout(function() {
                $(".partialPayment").hide();
            }, 1000);



        }
        if (id == 3) {
            $("#hideAccount").hide();
            $("#showAccount").hide();
            $("#showBankInfo").show();
            $("#chaque_amount_class").show(10);
        } else {
            $("#hideAccount").hide();
            $("#showAccount").hide();
            $("#showBankInfo").hide();
            // $(".partialPayment").hide(1000);
        }
        if (id == 1) {
            $("#hideAccount").show();
            $("#showAccount").hide();
        } else if (id == 2) {
            $("#hideAccount").hide();
            $("#showAccount").show();
        }

    }

    function saveNewSupplier() {
        var supplierId = $(".supplierId").val();
        var supName = $(".supName").val();
        if (supplierId != '' && supName != '') {
            $.ajax({
                type: 'POST',
                url: baseUrl + "SetupController/saveNewSupplier",
                data: $("#publicForm2").serializeArray(),
                success: function (data)
                {
                    $('#myModal').modal('toggle');
                    $('#hideNewSup').hide();
                    $('#supplierid').chosen();
                    $('#supplierid').append($(data));
                    $("#supplierid").trigger("chosen:updated");
                }
            });
        } else {
            alert("Supplier ID AND supplier name can't be empty.");
            return false;
            //$('#myModal').modal('hide');

        }
    }

    function checkDuplicatePhone(phone) {

        $.ajax({
            type: 'POST',
            url: baseUrl + "SetupController/checkDuplicateEmail",
            data: {
                'phone': phone
            },
            success: function (data)
            {
                if (data == 1) {
                    $("#subBtn2").attr('disabled', true);
                    $("#errorMsg").show();
                } else {
                    $("#subBtn2").attr('disabled', false);
                    $("#errorMsg").hide();
                }
            }
        });
    }
    $(document).ready(function () {
        $('.rate').blur(function () {
            var rate = parseFloat($(this).val());
            if(isNaN(rate)){
                rate=0;
            }
            $(this).val(parseFloat(rate).toFixed(2));
        });


        $('.quantity').keyup(function () {
            priceCal();
        });
        $('.rate').keyup(function () {
            priceCal();
        });
    });
    function priceCal() {
        var quantity = $('.quantity').val();
        if (isNaN(quantity)) {
            quantity = 0;
        }
        var rate = $('.rate').val();
        if (isNaN(rate)) {
            rate = 0;
        }
        $('.price').val(parseFloat(rate * quantity).toFixed(2));
    }

    var findTotalCal2 = function () {
        var total_quantity = 0;
        $.each($('.add_quantity2'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            total_quantity += quantity;
        });
        $('.total_quantity2').html(parseFloat(total_quantity));
    };
    var findTotalQty = function () {
        var total_quantity = 0;
        $.each($('.add_quantity'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            total_quantity += quantity;
        });
        $('.total_quantity').html(parseFloat(total_quantity));
    };

    var findTotalRate = function () {
        var total_rate = 0;
        $.each($('.add_rate'), function () {
            rate = $(this).val();
            rate = Number(rate);
            total_rate += rate;
        });
        $('.total_rate').html(parseFloat(total_rate).toFixed(2));
    };
    var findTotalPrice = function () {
        var total_price = 0;
        $.each($('.add_price'), function () {
            price = $(this).val();
            price = Number(price);
            total_price += price;
        });
        $('.total_price').val(parseFloat(total_price).toFixed(2));
        $('.total_price1').text((total_price).toFixed(2));
    };
    var returnQty = function () {
        var returnqty = 0;
        $.each($('.add_return'), function () {
            returnq = $(this).val();
            returnq = Number(returnq);
            returnqty += returnq;
        });
        $('.totalReturnQty').html(parseFloat(returnqty));
    };
    var findTotalCal = function () {
        findTotalQty();
        findTotalRate();
        findTotalPrice();
        returnQty();
        calculateDueAmount();
    };

    $(document).ready(function () {
        var j = 0;
        $("#add_item").click(function () {
            var productCatID = $('#productID').val();
            var productCatName = $('#productID').find('option:selected').attr('categoryName');
            var productID = $('#productID2').val();
            var productName = $('#productID2').find('option:selected').attr('productName');
            var quantity = $('.quantity').val();
            var bundle = $('.bundle').val();
            var bundleValue = $('#bundleValue').val();
            var rate = $('.rate').val();
            var price = $('.price').val();
            if (quantity == '') {
                swal("Qty can't be empty!", "Validation Error!", "error");
                return false;
            } else if (price == '' || price =='0.00') {
                swal("Price can't be empty!", "Validation Error!", "error");
                return false;
            }else if (productCatID == 1 && (bundleValue == '' || bundleValue <= 0)) {
                swal("Bundle qty can't be empty.!", "Validation Error!", "error");
                return false;
            } else if (productID == '') {
                swal("Product id can't be empty!", "Validation Error!", "error");
                return false;
            } else {
                if(productCatID == 1){
                    $("#show_item tfoot").prepend('<tr class="new_item' + j + '"><input type="hidden" name="category_id[]" value="' + productCatID + '"><td style="padding-left:15px;"> ' + productCatName +'</td><td style="padding-left:15px;"> ' + productName + ' <input type="hidden"  name="product_id[]" value="' + productID + '"></td><td align="right"><input type="text" class="add_bundle decimal form-control text-right" id="bundle_'+ j +'" name="bundle[]" value="' + bundle + '"></td><td align="right"><input type="text" class="add_quantity decimal form-control text-right" id="qty_'+ j +'" name="quantity[]" value="' + quantity + '"></td><td align="right"><input type="text" id="rate_'+ j +'" class="add_rate form-control decimal text-right" name="rate[]" value="' + rate + '"></td><td align="right"><input type="text" class="add_price  text-right form-control" id="tprice_'+ j +'" readonly name="price[]" value="' + price + '"></td><td><a del_id="' + j + '" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');
                }else{
                    $("#show_item tfoot").prepend('<tr class="new_item' + j + '"><input type="hidden" name="category_id[]" value="' + productCatID + '"><td style="padding-left:15px;"> ' + productCatName +'</td><td style="padding-left:15px;"> ' + productName + ' <input type="hidden"  name="product_id[]" value="' + productID + '"></td><td align="right"><input type="text" readonly class="add_bundle decimal form-control text-right" id="bundle_'+ j +'" name="bundle[]" value="' + bundle + '"></td><td align="right"><input type="text" class="add_quantity decimal form-control text-right" id="qty_'+ j +'" name="quantity[]" value="' + quantity + '"></td><td align="right"><input type="text" id="rate_'+ j +'" class="add_rate form-control decimal text-right" name="rate[]" value="' + rate + '"></td><td align="right"><input type="text" class="add_price  text-right form-control" id="tprice_'+ j +'" readonly name="price[]" value="' + price + '"></td><td><a del_id="' + j + '" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');
                }
                j++;
            }
            $('.quantity').val('');
            $('.rate').val('');
            $('.price').val('');
            $('.bundle').val('');
            $('#productID').val('').trigger('chosen:updated');
            $('#productID2').val('').trigger('chosen:updated');
            $('#category_product').val('').trigger('chosen:updated');
            //$('#productUnit').val('').trigger('chosen:updated');
            findTotalCal();
            setTimeout(function() {
                calcutateFinal();
            }, 100);

        });
        $(document).on('click', '.delete_item', function () {
            var id = $(this).attr("del_id");
            swal({
                title: "Are you sure ?",
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#73AE28',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true,
                type: 'success'
            },
            function (isConfirm) {
                if (isConfirm) {
                    $('.new_item' + id).remove();
                    findTotalCal();
                    setTimeout(function() {
                        calcutateFinal();
                    }, 100);
                }else{
                    return false;
                }
            });

        });
    });
    //get product purchases price
    function getProductPrice(product_id) {

        var productCatID = $('#productID').find('option:selected').attr('categoryId');
        if(productCatID ==2){
            $(".returnAble").attr('readonly',false);
        }else{
            $(".returnAble").attr('readonly',true);
        }

        $.ajax({
            type: "POST",
            url: baseUrl + "FinaneController/getProductPrice",
            data: 'product_id=' + product_id,
            success: function (data) {
                if (data != '0.00' && data >=1) {
                    $('.rate').val(data);
                } else {
                    $('.rate').val('');
                }

            }
        });
    }
    function getProductList(cat_id) {
        if(cat_id ==2){
            $(".returnAble").attr('readonly',false);
        }else{
            $(".returnAble").attr('readonly',true);
        }
        $.ajax({
            type: "POST",
            url: baseUrl + "InventoryController/getProductList",
            data: 'cat_id=' + cat_id,
            success: function (data) {
                $('#productID').chosen();
                $('#productID option').remove();
                $('#productID').append($(data));
                $("#productID").trigger("chosen:updated");
            }
        });
    }
    function checkDuplicateCategory(catName) {
        $.ajax({
            type: 'POST',

            url: baseUrl + "SetupController/checkDuplicateCategory",
            data: {
                'catName': catName
            },
            success: function (data)
            {
                if (data == 1) {
                    $("#subBtn").attr('disabled', true);
                    $("#errorMsg").show();
                } else {
                    $("#subBtn").attr('disabled', false);
                    $("#errorMsg").hide();
                }
            }
        });
    }





</script>

