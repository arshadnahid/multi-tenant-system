<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CommonModel extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
    }

    // add new data into a database table
    function insert_data($table_name, $data) {
        $this->db->insert($table_name, $data);
        return $this->db->insert_id();
    }

// update data by id of a database table
    function update_data($table_name, $data, $column_name, $column_value) {
        $this->db->where($column_name, $column_value);
        $this->db->update($table_name, $data);
        return $this->db->affected_rows();
    }

    function getSubCatList($condition) {
        $this->db->select("*");
        $this->db->from("subCategory");
        $this->db->where($condition);
        $return = $this->db->get()->result();
        return $return;
    }

    function getSubCatListById($id) {
        $this->db->select("*");
        $this->db->from("subCategory");
        $this->db->where('id', $id);
        $return = $this->db->get()->row();
        return $return;
    }

    public function checkPublicProductCat($distId) {
        $this->db->select("category_id,dist_id,title");
        $this->db->from("productcategory");
        $this->db->group_start();
        $this->db->where('dist_id', $distId);
        $this->db->or_where('dist_id', 1);
        $this->db->group_end();
        $getProductList = $this->db->get()->result();
        return $getProductList;
    }


    function getCatName($catId) {
        $this->db->select("title");
        $this->db->from("productcategory");
        $this->db->where('category_id', $catId);
        $return = $this->db->get()->row()->title;
        return $return;
    }

}
