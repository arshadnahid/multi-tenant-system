
<?php if ($loadValue == 1): ?>

    <table class="customerInfo" >
        <tr>
            <td><b>Address</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span> <?php
    echo $customerList->customerAddress;
    ;
    ?></span></td>
        </tr>
        <tr>
            <td><b> Phone</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span> <?php
                echo $customerList->customerPhone;
                ;
    ?></span></td>
        </tr>
        <tr>
            <td><b> Name</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span><?php
                echo $customerList->customerName;
                ;
    ?> </span></td>
        </tr>
        <tr>
            <td><b> ID</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span> <?php
                echo $customerList->customerID;
                ;
    ?></span></td>
        </tr>
    </table>
<?php else: ?>

    <table class="customerInfo" >
        <tr>
            <td><b>Address</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span> <?php
    echo $supplierList->supAddress;
    ;
    ?></span></td>
        </tr>
        <tr>
            <td><b> Phone</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span> <?php
                echo $supplierList->supPhone;
                ;
    ?></span></td>
        </tr>
        <tr>
            <td><b> Name</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span><?php
                echo $supplierList->supName;
                ;
    ?> </span></td>
        </tr>
        <tr>
            <td><b> ID</b> &nbsp; </td>
            <td> &nbsp;:&nbsp;&nbsp; </td>
            <td>&nbsp;&nbsp;&nbsp;<span> <?php
                echo $supplierList->supID;
                ;
    ?></span></td>
        </tr>
    </table>




<?php endif; ?>

