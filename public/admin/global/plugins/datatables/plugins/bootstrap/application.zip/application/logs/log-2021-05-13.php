<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-13 01:10:34 --> Config Class Initialized
INFO - 2021-05-13 01:10:34 --> Hooks Class Initialized
DEBUG - 2021-05-13 01:10:34 --> UTF-8 Support Enabled
INFO - 2021-05-13 01:10:34 --> Utf8 Class Initialized
INFO - 2021-05-13 01:10:34 --> URI Class Initialized
DEBUG - 2021-05-13 01:10:34 --> No URI present. Default controller set.
INFO - 2021-05-13 01:10:34 --> Router Class Initialized
INFO - 2021-05-13 01:10:34 --> Output Class Initialized
INFO - 2021-05-13 01:10:34 --> Security Class Initialized
DEBUG - 2021-05-13 01:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 01:10:34 --> Input Class Initialized
INFO - 2021-05-13 01:10:34 --> Language Class Initialized
INFO - 2021-05-13 01:10:34 --> Loader Class Initialized
INFO - 2021-05-13 01:10:34 --> Helper loaded: url_helper
INFO - 2021-05-13 01:10:34 --> Helper loaded: file_helper
INFO - 2021-05-13 01:10:34 --> Helper loaded: utility_helper
INFO - 2021-05-13 01:10:34 --> Helper loaded: unit_helper
INFO - 2021-05-13 01:10:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 01:10:34 --> Database Driver Class Initialized
INFO - 2021-05-13 01:10:34 --> Email Class Initialized
DEBUG - 2021-05-13 01:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 01:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 01:10:34 --> Helper loaded: form_helper
INFO - 2021-05-13 01:10:34 --> Form Validation Class Initialized
INFO - 2021-05-13 01:10:34 --> Controller Class Initialized
INFO - 2021-05-13 01:10:34 --> Model "Common_model" initialized
INFO - 2021-05-13 01:10:34 --> Model "Finane_Model" initialized
INFO - 2021-05-13 01:10:34 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 01:10:34 --> Model "Sales_Model" initialized
INFO - 2021-05-13 01:10:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 01:10:34 --> Final output sent to browser
DEBUG - 2021-05-13 01:10:34 --> Total execution time: 0.0681
INFO - 2021-05-13 01:10:37 --> Config Class Initialized
INFO - 2021-05-13 01:10:37 --> Hooks Class Initialized
DEBUG - 2021-05-13 01:10:37 --> UTF-8 Support Enabled
INFO - 2021-05-13 01:10:37 --> Utf8 Class Initialized
INFO - 2021-05-13 01:10:37 --> URI Class Initialized
DEBUG - 2021-05-13 01:10:37 --> No URI present. Default controller set.
INFO - 2021-05-13 01:10:37 --> Router Class Initialized
INFO - 2021-05-13 01:10:37 --> Output Class Initialized
INFO - 2021-05-13 01:10:37 --> Security Class Initialized
DEBUG - 2021-05-13 01:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 01:10:37 --> Input Class Initialized
INFO - 2021-05-13 01:10:37 --> Language Class Initialized
INFO - 2021-05-13 01:10:37 --> Loader Class Initialized
INFO - 2021-05-13 01:10:37 --> Helper loaded: url_helper
INFO - 2021-05-13 01:10:37 --> Helper loaded: file_helper
INFO - 2021-05-13 01:10:37 --> Helper loaded: utility_helper
INFO - 2021-05-13 01:10:37 --> Helper loaded: unit_helper
INFO - 2021-05-13 01:10:37 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 01:10:37 --> Database Driver Class Initialized
INFO - 2021-05-13 01:10:37 --> Email Class Initialized
DEBUG - 2021-05-13 01:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 01:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 01:10:37 --> Helper loaded: form_helper
INFO - 2021-05-13 01:10:37 --> Form Validation Class Initialized
INFO - 2021-05-13 01:10:37 --> Controller Class Initialized
INFO - 2021-05-13 01:10:37 --> Model "Common_model" initialized
INFO - 2021-05-13 01:10:37 --> Model "Finane_Model" initialized
INFO - 2021-05-13 01:10:37 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 01:10:37 --> Model "Sales_Model" initialized
INFO - 2021-05-13 01:10:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 01:10:37 --> Final output sent to browser
DEBUG - 2021-05-13 01:10:37 --> Total execution time: 0.0587
INFO - 2021-05-13 01:10:45 --> Config Class Initialized
INFO - 2021-05-13 01:10:45 --> Hooks Class Initialized
DEBUG - 2021-05-13 01:10:45 --> UTF-8 Support Enabled
INFO - 2021-05-13 01:10:45 --> Utf8 Class Initialized
INFO - 2021-05-13 01:10:45 --> URI Class Initialized
INFO - 2021-05-13 01:10:45 --> Router Class Initialized
INFO - 2021-05-13 01:10:45 --> Output Class Initialized
INFO - 2021-05-13 01:10:45 --> Security Class Initialized
DEBUG - 2021-05-13 01:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 01:10:45 --> Input Class Initialized
INFO - 2021-05-13 01:10:45 --> Language Class Initialized
INFO - 2021-05-13 01:10:45 --> Loader Class Initialized
INFO - 2021-05-13 01:10:45 --> Helper loaded: url_helper
INFO - 2021-05-13 01:10:45 --> Helper loaded: file_helper
INFO - 2021-05-13 01:10:45 --> Helper loaded: utility_helper
INFO - 2021-05-13 01:10:45 --> Helper loaded: unit_helper
INFO - 2021-05-13 01:10:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 01:10:45 --> Database Driver Class Initialized
INFO - 2021-05-13 01:10:45 --> Email Class Initialized
DEBUG - 2021-05-13 01:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 01:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 01:10:45 --> Helper loaded: form_helper
INFO - 2021-05-13 01:10:45 --> Form Validation Class Initialized
INFO - 2021-05-13 01:10:45 --> Controller Class Initialized
INFO - 2021-05-13 01:10:45 --> Model "Common_model" initialized
INFO - 2021-05-13 01:10:45 --> Model "Finane_Model" initialized
INFO - 2021-05-13 01:10:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 01:10:45 --> Model "Sales_Model" initialized
INFO - 2021-05-13 01:10:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 01:10:45 --> Final output sent to browser
DEBUG - 2021-05-13 01:10:45 --> Total execution time: 0.0603
INFO - 2021-05-13 01:10:51 --> Config Class Initialized
INFO - 2021-05-13 01:10:51 --> Hooks Class Initialized
DEBUG - 2021-05-13 01:10:51 --> UTF-8 Support Enabled
INFO - 2021-05-13 01:10:51 --> Utf8 Class Initialized
INFO - 2021-05-13 01:10:51 --> URI Class Initialized
INFO - 2021-05-13 01:10:51 --> Router Class Initialized
INFO - 2021-05-13 01:10:51 --> Output Class Initialized
INFO - 2021-05-13 01:10:51 --> Security Class Initialized
DEBUG - 2021-05-13 01:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 01:10:51 --> Input Class Initialized
INFO - 2021-05-13 01:10:51 --> Language Class Initialized
INFO - 2021-05-13 01:10:51 --> Loader Class Initialized
INFO - 2021-05-13 01:10:51 --> Helper loaded: url_helper
INFO - 2021-05-13 01:10:51 --> Helper loaded: file_helper
INFO - 2021-05-13 01:10:51 --> Helper loaded: utility_helper
INFO - 2021-05-13 01:10:51 --> Helper loaded: unit_helper
INFO - 2021-05-13 01:10:51 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 01:10:51 --> Database Driver Class Initialized
INFO - 2021-05-13 01:10:51 --> Email Class Initialized
DEBUG - 2021-05-13 01:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 01:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 01:10:51 --> Helper loaded: form_helper
INFO - 2021-05-13 01:10:51 --> Form Validation Class Initialized
INFO - 2021-05-13 01:10:51 --> Controller Class Initialized
INFO - 2021-05-13 01:10:51 --> Model "Common_model" initialized
INFO - 2021-05-13 01:10:51 --> Model "Finane_Model" initialized
INFO - 2021-05-13 01:10:51 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 01:10:51 --> Model "Sales_Model" initialized
INFO - 2021-05-13 01:10:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 01:10:51 --> Final output sent to browser
DEBUG - 2021-05-13 01:10:51 --> Total execution time: 0.0390
INFO - 2021-05-13 03:38:11 --> Config Class Initialized
INFO - 2021-05-13 03:38:11 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:11 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:11 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:11 --> URI Class Initialized
DEBUG - 2021-05-13 03:38:11 --> No URI present. Default controller set.
INFO - 2021-05-13 03:38:11 --> Router Class Initialized
INFO - 2021-05-13 03:38:11 --> Output Class Initialized
INFO - 2021-05-13 03:38:11 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:11 --> Input Class Initialized
INFO - 2021-05-13 03:38:11 --> Language Class Initialized
INFO - 2021-05-13 03:38:11 --> Loader Class Initialized
INFO - 2021-05-13 03:38:11 --> Helper loaded: url_helper
INFO - 2021-05-13 03:38:11 --> Helper loaded: file_helper
INFO - 2021-05-13 03:38:11 --> Helper loaded: utility_helper
INFO - 2021-05-13 03:38:11 --> Helper loaded: unit_helper
INFO - 2021-05-13 03:38:11 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 03:38:11 --> Database Driver Class Initialized
INFO - 2021-05-13 03:38:11 --> Email Class Initialized
DEBUG - 2021-05-13 03:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 03:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 03:38:11 --> Helper loaded: form_helper
INFO - 2021-05-13 03:38:11 --> Form Validation Class Initialized
INFO - 2021-05-13 03:38:11 --> Controller Class Initialized
INFO - 2021-05-13 03:38:11 --> Model "Common_model" initialized
INFO - 2021-05-13 03:38:11 --> Model "Finane_Model" initialized
INFO - 2021-05-13 03:38:11 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 03:38:11 --> Model "Sales_Model" initialized
INFO - 2021-05-13 03:38:11 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 03:38:11 --> Final output sent to browser
DEBUG - 2021-05-13 03:38:11 --> Total execution time: 0.0782
INFO - 2021-05-13 03:38:13 --> Config Class Initialized
INFO - 2021-05-13 03:38:13 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:13 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:13 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:13 --> URI Class Initialized
DEBUG - 2021-05-13 03:38:13 --> No URI present. Default controller set.
INFO - 2021-05-13 03:38:13 --> Router Class Initialized
INFO - 2021-05-13 03:38:13 --> Output Class Initialized
INFO - 2021-05-13 03:38:13 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:13 --> Input Class Initialized
INFO - 2021-05-13 03:38:13 --> Language Class Initialized
INFO - 2021-05-13 03:38:13 --> Loader Class Initialized
INFO - 2021-05-13 03:38:13 --> Helper loaded: url_helper
INFO - 2021-05-13 03:38:13 --> Helper loaded: file_helper
INFO - 2021-05-13 03:38:13 --> Helper loaded: utility_helper
INFO - 2021-05-13 03:38:13 --> Helper loaded: unit_helper
INFO - 2021-05-13 03:38:13 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 03:38:13 --> Database Driver Class Initialized
INFO - 2021-05-13 03:38:13 --> Email Class Initialized
DEBUG - 2021-05-13 03:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 03:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 03:38:13 --> Helper loaded: form_helper
INFO - 2021-05-13 03:38:13 --> Form Validation Class Initialized
INFO - 2021-05-13 03:38:13 --> Controller Class Initialized
INFO - 2021-05-13 03:38:13 --> Model "Common_model" initialized
INFO - 2021-05-13 03:38:13 --> Model "Finane_Model" initialized
INFO - 2021-05-13 03:38:13 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 03:38:13 --> Model "Sales_Model" initialized
INFO - 2021-05-13 03:38:13 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 03:38:13 --> Final output sent to browser
DEBUG - 2021-05-13 03:38:13 --> Total execution time: 0.1308
INFO - 2021-05-13 03:38:14 --> Config Class Initialized
INFO - 2021-05-13 03:38:14 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:14 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:14 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:14 --> URI Class Initialized
INFO - 2021-05-13 03:38:14 --> Router Class Initialized
INFO - 2021-05-13 03:38:14 --> Output Class Initialized
INFO - 2021-05-13 03:38:14 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:14 --> Input Class Initialized
INFO - 2021-05-13 03:38:14 --> Language Class Initialized
ERROR - 2021-05-13 03:38:14 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2021-05-13 03:38:16 --> Config Class Initialized
INFO - 2021-05-13 03:38:16 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:16 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:16 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:16 --> URI Class Initialized
INFO - 2021-05-13 03:38:16 --> Router Class Initialized
INFO - 2021-05-13 03:38:16 --> Output Class Initialized
INFO - 2021-05-13 03:38:16 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:16 --> Input Class Initialized
INFO - 2021-05-13 03:38:16 --> Language Class Initialized
INFO - 2021-05-13 03:38:16 --> Loader Class Initialized
INFO - 2021-05-13 03:38:16 --> Helper loaded: url_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: file_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: utility_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: unit_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 03:38:16 --> Database Driver Class Initialized
INFO - 2021-05-13 03:38:16 --> Email Class Initialized
DEBUG - 2021-05-13 03:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 03:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 03:38:16 --> Helper loaded: form_helper
INFO - 2021-05-13 03:38:16 --> Form Validation Class Initialized
INFO - 2021-05-13 03:38:16 --> Controller Class Initialized
INFO - 2021-05-13 03:38:16 --> Model "Common_model" initialized
INFO - 2021-05-13 03:38:16 --> Model "Finane_Model" initialized
INFO - 2021-05-13 03:38:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 03:38:16 --> Model "Sales_Model" initialized
INFO - 2021-05-13 03:38:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 03:38:16 --> Final output sent to browser
DEBUG - 2021-05-13 03:38:16 --> Total execution time: 0.1372
INFO - 2021-05-13 03:38:16 --> Config Class Initialized
INFO - 2021-05-13 03:38:16 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:16 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:16 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:16 --> URI Class Initialized
DEBUG - 2021-05-13 03:38:16 --> No URI present. Default controller set.
INFO - 2021-05-13 03:38:16 --> Router Class Initialized
INFO - 2021-05-13 03:38:16 --> Output Class Initialized
INFO - 2021-05-13 03:38:16 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:16 --> Input Class Initialized
INFO - 2021-05-13 03:38:16 --> Language Class Initialized
INFO - 2021-05-13 03:38:16 --> Loader Class Initialized
INFO - 2021-05-13 03:38:16 --> Helper loaded: url_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: file_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: utility_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: unit_helper
INFO - 2021-05-13 03:38:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 03:38:16 --> Database Driver Class Initialized
INFO - 2021-05-13 03:38:16 --> Email Class Initialized
DEBUG - 2021-05-13 03:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 03:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 03:38:16 --> Helper loaded: form_helper
INFO - 2021-05-13 03:38:16 --> Form Validation Class Initialized
INFO - 2021-05-13 03:38:16 --> Controller Class Initialized
INFO - 2021-05-13 03:38:16 --> Model "Common_model" initialized
INFO - 2021-05-13 03:38:16 --> Model "Finane_Model" initialized
INFO - 2021-05-13 03:38:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 03:38:16 --> Model "Sales_Model" initialized
INFO - 2021-05-13 03:38:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 03:38:16 --> Final output sent to browser
DEBUG - 2021-05-13 03:38:16 --> Total execution time: 0.0763
INFO - 2021-05-13 03:38:17 --> Config Class Initialized
INFO - 2021-05-13 03:38:17 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:17 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:17 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:17 --> URI Class Initialized
INFO - 2021-05-13 03:38:17 --> Router Class Initialized
INFO - 2021-05-13 03:38:17 --> Output Class Initialized
INFO - 2021-05-13 03:38:17 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:17 --> Input Class Initialized
INFO - 2021-05-13 03:38:17 --> Language Class Initialized
ERROR - 2021-05-13 03:38:17 --> 404 Page Not Found: Blog/wp-includes
INFO - 2021-05-13 03:38:18 --> Config Class Initialized
INFO - 2021-05-13 03:38:18 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:18 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:18 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:18 --> URI Class Initialized
INFO - 2021-05-13 03:38:18 --> Router Class Initialized
INFO - 2021-05-13 03:38:18 --> Output Class Initialized
INFO - 2021-05-13 03:38:18 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:18 --> Input Class Initialized
INFO - 2021-05-13 03:38:18 --> Language Class Initialized
ERROR - 2021-05-13 03:38:18 --> 404 Page Not Found: Web/wp-includes
INFO - 2021-05-13 03:38:19 --> Config Class Initialized
INFO - 2021-05-13 03:38:19 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:19 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:19 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:19 --> URI Class Initialized
INFO - 2021-05-13 03:38:19 --> Router Class Initialized
INFO - 2021-05-13 03:38:19 --> Output Class Initialized
INFO - 2021-05-13 03:38:19 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:19 --> Input Class Initialized
INFO - 2021-05-13 03:38:19 --> Language Class Initialized
ERROR - 2021-05-13 03:38:19 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2021-05-13 03:38:20 --> Config Class Initialized
INFO - 2021-05-13 03:38:20 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:20 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:20 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:20 --> URI Class Initialized
INFO - 2021-05-13 03:38:20 --> Router Class Initialized
INFO - 2021-05-13 03:38:20 --> Output Class Initialized
INFO - 2021-05-13 03:38:20 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:20 --> Input Class Initialized
INFO - 2021-05-13 03:38:20 --> Language Class Initialized
ERROR - 2021-05-13 03:38:20 --> 404 Page Not Found: Website/wp-includes
INFO - 2021-05-13 03:38:21 --> Config Class Initialized
INFO - 2021-05-13 03:38:21 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:21 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:21 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:21 --> URI Class Initialized
INFO - 2021-05-13 03:38:21 --> Router Class Initialized
INFO - 2021-05-13 03:38:21 --> Output Class Initialized
INFO - 2021-05-13 03:38:21 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:21 --> Input Class Initialized
INFO - 2021-05-13 03:38:21 --> Language Class Initialized
ERROR - 2021-05-13 03:38:21 --> 404 Page Not Found: Wp/wp-includes
INFO - 2021-05-13 03:38:22 --> Config Class Initialized
INFO - 2021-05-13 03:38:22 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:22 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:22 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:22 --> URI Class Initialized
INFO - 2021-05-13 03:38:22 --> Router Class Initialized
INFO - 2021-05-13 03:38:22 --> Output Class Initialized
INFO - 2021-05-13 03:38:22 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:22 --> Input Class Initialized
INFO - 2021-05-13 03:38:22 --> Language Class Initialized
ERROR - 2021-05-13 03:38:22 --> 404 Page Not Found: News/wp-includes
INFO - 2021-05-13 03:38:23 --> Config Class Initialized
INFO - 2021-05-13 03:38:23 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:23 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:23 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:23 --> URI Class Initialized
INFO - 2021-05-13 03:38:23 --> Router Class Initialized
INFO - 2021-05-13 03:38:23 --> Output Class Initialized
INFO - 2021-05-13 03:38:23 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:23 --> Input Class Initialized
INFO - 2021-05-13 03:38:23 --> Language Class Initialized
ERROR - 2021-05-13 03:38:23 --> 404 Page Not Found: 2020/wp-includes
INFO - 2021-05-13 03:38:24 --> Config Class Initialized
INFO - 2021-05-13 03:38:24 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:24 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:24 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:24 --> URI Class Initialized
INFO - 2021-05-13 03:38:24 --> Router Class Initialized
INFO - 2021-05-13 03:38:24 --> Output Class Initialized
INFO - 2021-05-13 03:38:24 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:24 --> Input Class Initialized
INFO - 2021-05-13 03:38:24 --> Language Class Initialized
ERROR - 2021-05-13 03:38:24 --> 404 Page Not Found: 2019/wp-includes
INFO - 2021-05-13 03:38:25 --> Config Class Initialized
INFO - 2021-05-13 03:38:25 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:25 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:25 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:25 --> URI Class Initialized
INFO - 2021-05-13 03:38:25 --> Router Class Initialized
INFO - 2021-05-13 03:38:25 --> Output Class Initialized
INFO - 2021-05-13 03:38:25 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:25 --> Input Class Initialized
INFO - 2021-05-13 03:38:25 --> Language Class Initialized
ERROR - 2021-05-13 03:38:25 --> 404 Page Not Found: Shop/wp-includes
INFO - 2021-05-13 03:38:26 --> Config Class Initialized
INFO - 2021-05-13 03:38:26 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:26 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:26 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:26 --> URI Class Initialized
INFO - 2021-05-13 03:38:26 --> Router Class Initialized
INFO - 2021-05-13 03:38:26 --> Output Class Initialized
INFO - 2021-05-13 03:38:26 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:26 --> Input Class Initialized
INFO - 2021-05-13 03:38:26 --> Language Class Initialized
ERROR - 2021-05-13 03:38:26 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2021-05-13 03:38:27 --> Config Class Initialized
INFO - 2021-05-13 03:38:27 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:27 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:27 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:27 --> URI Class Initialized
INFO - 2021-05-13 03:38:27 --> Router Class Initialized
INFO - 2021-05-13 03:38:27 --> Output Class Initialized
INFO - 2021-05-13 03:38:27 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:27 --> Input Class Initialized
INFO - 2021-05-13 03:38:27 --> Language Class Initialized
ERROR - 2021-05-13 03:38:27 --> 404 Page Not Found: Test/wp-includes
INFO - 2021-05-13 03:38:28 --> Config Class Initialized
INFO - 2021-05-13 03:38:28 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:28 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:28 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:28 --> URI Class Initialized
INFO - 2021-05-13 03:38:28 --> Router Class Initialized
INFO - 2021-05-13 03:38:28 --> Output Class Initialized
INFO - 2021-05-13 03:38:28 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:28 --> Input Class Initialized
INFO - 2021-05-13 03:38:28 --> Language Class Initialized
ERROR - 2021-05-13 03:38:28 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2021-05-13 03:38:29 --> Config Class Initialized
INFO - 2021-05-13 03:38:29 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:29 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:29 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:29 --> URI Class Initialized
INFO - 2021-05-13 03:38:29 --> Router Class Initialized
INFO - 2021-05-13 03:38:29 --> Output Class Initialized
INFO - 2021-05-13 03:38:29 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:29 --> Input Class Initialized
INFO - 2021-05-13 03:38:29 --> Language Class Initialized
ERROR - 2021-05-13 03:38:29 --> 404 Page Not Found: Site/wp-includes
INFO - 2021-05-13 03:38:29 --> Config Class Initialized
INFO - 2021-05-13 03:38:29 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:29 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:29 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:29 --> URI Class Initialized
INFO - 2021-05-13 03:38:29 --> Router Class Initialized
INFO - 2021-05-13 03:38:29 --> Output Class Initialized
INFO - 2021-05-13 03:38:29 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:29 --> Input Class Initialized
INFO - 2021-05-13 03:38:29 --> Language Class Initialized
ERROR - 2021-05-13 03:38:29 --> 404 Page Not Found: Cms/wp-includes
INFO - 2021-05-13 03:38:30 --> Config Class Initialized
INFO - 2021-05-13 03:38:30 --> Hooks Class Initialized
DEBUG - 2021-05-13 03:38:30 --> UTF-8 Support Enabled
INFO - 2021-05-13 03:38:30 --> Utf8 Class Initialized
INFO - 2021-05-13 03:38:30 --> URI Class Initialized
INFO - 2021-05-13 03:38:30 --> Router Class Initialized
INFO - 2021-05-13 03:38:30 --> Output Class Initialized
INFO - 2021-05-13 03:38:30 --> Security Class Initialized
DEBUG - 2021-05-13 03:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 03:38:30 --> Input Class Initialized
INFO - 2021-05-13 03:38:30 --> Language Class Initialized
ERROR - 2021-05-13 03:38:30 --> 404 Page Not Found: Sito/wp-includes
INFO - 2021-05-13 05:57:24 --> Config Class Initialized
INFO - 2021-05-13 05:57:24 --> Hooks Class Initialized
DEBUG - 2021-05-13 05:57:24 --> UTF-8 Support Enabled
INFO - 2021-05-13 05:57:24 --> Utf8 Class Initialized
INFO - 2021-05-13 05:57:24 --> URI Class Initialized
DEBUG - 2021-05-13 05:57:24 --> No URI present. Default controller set.
INFO - 2021-05-13 05:57:24 --> Router Class Initialized
INFO - 2021-05-13 05:57:24 --> Output Class Initialized
INFO - 2021-05-13 05:57:24 --> Security Class Initialized
DEBUG - 2021-05-13 05:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 05:57:24 --> Input Class Initialized
INFO - 2021-05-13 05:57:24 --> Language Class Initialized
INFO - 2021-05-13 05:57:24 --> Loader Class Initialized
INFO - 2021-05-13 05:57:24 --> Helper loaded: url_helper
INFO - 2021-05-13 05:57:24 --> Helper loaded: file_helper
INFO - 2021-05-13 05:57:24 --> Helper loaded: utility_helper
INFO - 2021-05-13 05:57:24 --> Helper loaded: unit_helper
INFO - 2021-05-13 05:57:24 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 05:57:24 --> Database Driver Class Initialized
INFO - 2021-05-13 05:57:24 --> Email Class Initialized
DEBUG - 2021-05-13 05:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 05:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 05:57:24 --> Helper loaded: form_helper
INFO - 2021-05-13 05:57:24 --> Form Validation Class Initialized
INFO - 2021-05-13 05:57:24 --> Controller Class Initialized
INFO - 2021-05-13 05:57:24 --> Model "Common_model" initialized
INFO - 2021-05-13 05:57:24 --> Model "Finane_Model" initialized
INFO - 2021-05-13 05:57:24 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 05:57:24 --> Model "Sales_Model" initialized
INFO - 2021-05-13 05:57:24 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 05:57:24 --> Final output sent to browser
DEBUG - 2021-05-13 05:57:24 --> Total execution time: 0.0538
INFO - 2021-05-13 07:56:56 --> Config Class Initialized
INFO - 2021-05-13 07:56:56 --> Hooks Class Initialized
DEBUG - 2021-05-13 07:56:56 --> UTF-8 Support Enabled
INFO - 2021-05-13 07:56:56 --> Utf8 Class Initialized
INFO - 2021-05-13 07:56:56 --> URI Class Initialized
INFO - 2021-05-13 07:56:56 --> Router Class Initialized
INFO - 2021-05-13 07:56:56 --> Output Class Initialized
INFO - 2021-05-13 07:56:56 --> Security Class Initialized
DEBUG - 2021-05-13 07:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 07:56:56 --> Input Class Initialized
INFO - 2021-05-13 07:56:56 --> Language Class Initialized
ERROR - 2021-05-13 07:56:56 --> 404 Page Not Found: Owa/auth
INFO - 2021-05-13 09:25:33 --> Config Class Initialized
INFO - 2021-05-13 09:25:33 --> Hooks Class Initialized
DEBUG - 2021-05-13 09:25:33 --> UTF-8 Support Enabled
INFO - 2021-05-13 09:25:33 --> Utf8 Class Initialized
INFO - 2021-05-13 09:25:33 --> URI Class Initialized
INFO - 2021-05-13 09:25:33 --> Router Class Initialized
INFO - 2021-05-13 09:25:33 --> Output Class Initialized
INFO - 2021-05-13 09:25:33 --> Security Class Initialized
DEBUG - 2021-05-13 09:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 09:25:33 --> Input Class Initialized
INFO - 2021-05-13 09:25:33 --> Language Class Initialized
INFO - 2021-05-13 09:25:33 --> Loader Class Initialized
INFO - 2021-05-13 09:25:33 --> Helper loaded: url_helper
INFO - 2021-05-13 09:25:33 --> Helper loaded: file_helper
INFO - 2021-05-13 09:25:33 --> Helper loaded: utility_helper
INFO - 2021-05-13 09:25:33 --> Helper loaded: unit_helper
INFO - 2021-05-13 09:25:33 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 09:25:33 --> Database Driver Class Initialized
INFO - 2021-05-13 09:25:33 --> Email Class Initialized
DEBUG - 2021-05-13 09:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 09:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 09:25:33 --> Helper loaded: form_helper
INFO - 2021-05-13 09:25:33 --> Form Validation Class Initialized
INFO - 2021-05-13 09:25:33 --> Controller Class Initialized
INFO - 2021-05-13 09:25:33 --> Model "Common_model" initialized
INFO - 2021-05-13 09:25:33 --> Model "Finane_Model" initialized
INFO - 2021-05-13 09:25:33 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 09:25:33 --> Model "Sales_Model" initialized
INFO - 2021-05-13 09:25:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 09:25:33 --> Final output sent to browser
DEBUG - 2021-05-13 09:25:33 --> Total execution time: 0.0722
INFO - 2021-05-13 11:12:09 --> Config Class Initialized
INFO - 2021-05-13 11:12:09 --> Hooks Class Initialized
DEBUG - 2021-05-13 11:12:09 --> UTF-8 Support Enabled
INFO - 2021-05-13 11:12:09 --> Utf8 Class Initialized
INFO - 2021-05-13 11:12:09 --> URI Class Initialized
INFO - 2021-05-13 11:12:09 --> Router Class Initialized
INFO - 2021-05-13 11:12:09 --> Output Class Initialized
INFO - 2021-05-13 11:12:09 --> Security Class Initialized
DEBUG - 2021-05-13 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 11:12:09 --> Input Class Initialized
INFO - 2021-05-13 11:12:09 --> Language Class Initialized
ERROR - 2021-05-13 11:12:09 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-13 11:12:09 --> Config Class Initialized
INFO - 2021-05-13 11:12:09 --> Hooks Class Initialized
DEBUG - 2021-05-13 11:12:09 --> UTF-8 Support Enabled
INFO - 2021-05-13 11:12:09 --> Utf8 Class Initialized
INFO - 2021-05-13 11:12:09 --> URI Class Initialized
INFO - 2021-05-13 11:12:09 --> Router Class Initialized
INFO - 2021-05-13 11:12:09 --> Output Class Initialized
INFO - 2021-05-13 11:12:09 --> Security Class Initialized
DEBUG - 2021-05-13 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 11:12:09 --> Input Class Initialized
INFO - 2021-05-13 11:12:09 --> Language Class Initialized
ERROR - 2021-05-13 11:12:09 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-13 11:12:09 --> Config Class Initialized
INFO - 2021-05-13 11:12:09 --> Hooks Class Initialized
DEBUG - 2021-05-13 11:12:09 --> UTF-8 Support Enabled
INFO - 2021-05-13 11:12:09 --> Utf8 Class Initialized
INFO - 2021-05-13 11:12:09 --> URI Class Initialized
INFO - 2021-05-13 11:12:09 --> Router Class Initialized
INFO - 2021-05-13 11:12:09 --> Output Class Initialized
INFO - 2021-05-13 11:12:09 --> Security Class Initialized
DEBUG - 2021-05-13 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 11:12:09 --> Input Class Initialized
INFO - 2021-05-13 11:12:09 --> Language Class Initialized
ERROR - 2021-05-13 11:12:09 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-13 12:21:27 --> Config Class Initialized
INFO - 2021-05-13 12:21:27 --> Hooks Class Initialized
DEBUG - 2021-05-13 12:21:27 --> UTF-8 Support Enabled
INFO - 2021-05-13 12:21:27 --> Utf8 Class Initialized
INFO - 2021-05-13 12:21:27 --> URI Class Initialized
INFO - 2021-05-13 12:21:27 --> Router Class Initialized
INFO - 2021-05-13 12:21:27 --> Output Class Initialized
INFO - 2021-05-13 12:21:27 --> Security Class Initialized
DEBUG - 2021-05-13 12:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 12:21:27 --> Input Class Initialized
INFO - 2021-05-13 12:21:27 --> Language Class Initialized
ERROR - 2021-05-13 12:21:27 --> 404 Page Not Found: admin/Assets/fileupload
INFO - 2021-05-13 12:47:45 --> Config Class Initialized
INFO - 2021-05-13 12:47:45 --> Hooks Class Initialized
DEBUG - 2021-05-13 12:47:45 --> UTF-8 Support Enabled
INFO - 2021-05-13 12:47:45 --> Utf8 Class Initialized
INFO - 2021-05-13 12:47:45 --> URI Class Initialized
DEBUG - 2021-05-13 12:47:45 --> No URI present. Default controller set.
INFO - 2021-05-13 12:47:45 --> Router Class Initialized
INFO - 2021-05-13 12:47:45 --> Output Class Initialized
INFO - 2021-05-13 12:47:45 --> Security Class Initialized
DEBUG - 2021-05-13 12:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 12:47:45 --> Input Class Initialized
INFO - 2021-05-13 12:47:45 --> Language Class Initialized
INFO - 2021-05-13 12:47:45 --> Loader Class Initialized
INFO - 2021-05-13 12:47:45 --> Helper loaded: url_helper
INFO - 2021-05-13 12:47:45 --> Helper loaded: file_helper
INFO - 2021-05-13 12:47:45 --> Helper loaded: utility_helper
INFO - 2021-05-13 12:47:45 --> Helper loaded: unit_helper
INFO - 2021-05-13 12:47:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 12:47:45 --> Database Driver Class Initialized
INFO - 2021-05-13 12:47:45 --> Email Class Initialized
DEBUG - 2021-05-13 12:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 12:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 12:47:45 --> Helper loaded: form_helper
INFO - 2021-05-13 12:47:45 --> Form Validation Class Initialized
INFO - 2021-05-13 12:47:45 --> Controller Class Initialized
INFO - 2021-05-13 12:47:45 --> Model "Common_model" initialized
INFO - 2021-05-13 12:47:45 --> Model "Finane_Model" initialized
INFO - 2021-05-13 12:47:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 12:47:45 --> Model "Sales_Model" initialized
INFO - 2021-05-13 12:47:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 12:47:45 --> Final output sent to browser
DEBUG - 2021-05-13 12:47:45 --> Total execution time: 0.0695
INFO - 2021-05-13 13:06:05 --> Config Class Initialized
INFO - 2021-05-13 13:06:05 --> Hooks Class Initialized
DEBUG - 2021-05-13 13:06:05 --> UTF-8 Support Enabled
INFO - 2021-05-13 13:06:05 --> Utf8 Class Initialized
INFO - 2021-05-13 13:06:05 --> URI Class Initialized
INFO - 2021-05-13 13:06:05 --> Router Class Initialized
INFO - 2021-05-13 13:06:05 --> Output Class Initialized
INFO - 2021-05-13 13:06:05 --> Security Class Initialized
DEBUG - 2021-05-13 13:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 13:06:05 --> Input Class Initialized
INFO - 2021-05-13 13:06:05 --> Language Class Initialized
INFO - 2021-05-13 13:06:05 --> Loader Class Initialized
INFO - 2021-05-13 13:06:05 --> Helper loaded: url_helper
INFO - 2021-05-13 13:06:05 --> Helper loaded: file_helper
INFO - 2021-05-13 13:06:05 --> Helper loaded: utility_helper
INFO - 2021-05-13 13:06:05 --> Helper loaded: unit_helper
INFO - 2021-05-13 13:06:05 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 13:06:05 --> Database Driver Class Initialized
INFO - 2021-05-13 13:06:05 --> Email Class Initialized
DEBUG - 2021-05-13 13:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 13:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 13:06:05 --> Helper loaded: form_helper
INFO - 2021-05-13 13:06:05 --> Form Validation Class Initialized
INFO - 2021-05-13 13:06:05 --> Controller Class Initialized
INFO - 2021-05-13 13:06:05 --> Model "Common_model" initialized
INFO - 2021-05-13 13:06:05 --> Model "Finane_Model" initialized
INFO - 2021-05-13 13:06:05 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 13:06:05 --> Model "Sales_Model" initialized
INFO - 2021-05-13 13:06:05 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 13:06:05 --> Final output sent to browser
DEBUG - 2021-05-13 13:06:05 --> Total execution time: 0.0727
INFO - 2021-05-13 13:06:06 --> Config Class Initialized
INFO - 2021-05-13 13:06:06 --> Hooks Class Initialized
DEBUG - 2021-05-13 13:06:06 --> UTF-8 Support Enabled
INFO - 2021-05-13 13:06:06 --> Utf8 Class Initialized
INFO - 2021-05-13 13:06:06 --> URI Class Initialized
DEBUG - 2021-05-13 13:06:06 --> No URI present. Default controller set.
INFO - 2021-05-13 13:06:06 --> Router Class Initialized
INFO - 2021-05-13 13:06:06 --> Output Class Initialized
INFO - 2021-05-13 13:06:06 --> Security Class Initialized
DEBUG - 2021-05-13 13:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 13:06:06 --> Input Class Initialized
INFO - 2021-05-13 13:06:06 --> Language Class Initialized
INFO - 2021-05-13 13:06:06 --> Loader Class Initialized
INFO - 2021-05-13 13:06:06 --> Helper loaded: url_helper
INFO - 2021-05-13 13:06:06 --> Helper loaded: file_helper
INFO - 2021-05-13 13:06:06 --> Helper loaded: utility_helper
INFO - 2021-05-13 13:06:06 --> Helper loaded: unit_helper
INFO - 2021-05-13 13:06:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 13:06:06 --> Database Driver Class Initialized
INFO - 2021-05-13 13:06:06 --> Email Class Initialized
DEBUG - 2021-05-13 13:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 13:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 13:06:06 --> Helper loaded: form_helper
INFO - 2021-05-13 13:06:06 --> Form Validation Class Initialized
INFO - 2021-05-13 13:06:06 --> Controller Class Initialized
INFO - 2021-05-13 13:06:06 --> Model "Common_model" initialized
INFO - 2021-05-13 13:06:06 --> Model "Finane_Model" initialized
INFO - 2021-05-13 13:06:06 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 13:06:06 --> Model "Sales_Model" initialized
INFO - 2021-05-13 16:46:06 --> Config Class Initialized
INFO - 2021-05-13 16:46:06 --> Hooks Class Initialized
DEBUG - 2021-05-13 16:46:06 --> UTF-8 Support Enabled
INFO - 2021-05-13 16:46:06 --> Utf8 Class Initialized
INFO - 2021-05-13 16:46:06 --> URI Class Initialized
INFO - 2021-05-13 16:46:06 --> Router Class Initialized
INFO - 2021-05-13 16:46:06 --> Output Class Initialized
INFO - 2021-05-13 16:46:06 --> Security Class Initialized
DEBUG - 2021-05-13 16:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 16:46:06 --> Input Class Initialized
INFO - 2021-05-13 16:46:06 --> Language Class Initialized
INFO - 2021-05-13 16:46:06 --> Loader Class Initialized
INFO - 2021-05-13 16:46:06 --> Helper loaded: url_helper
INFO - 2021-05-13 16:46:06 --> Helper loaded: file_helper
INFO - 2021-05-13 16:46:06 --> Helper loaded: utility_helper
INFO - 2021-05-13 16:46:06 --> Helper loaded: unit_helper
INFO - 2021-05-13 16:46:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 16:46:06 --> Database Driver Class Initialized
INFO - 2021-05-13 16:46:06 --> Email Class Initialized
DEBUG - 2021-05-13 16:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 16:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 16:46:06 --> Helper loaded: form_helper
INFO - 2021-05-13 16:46:06 --> Form Validation Class Initialized
INFO - 2021-05-13 16:46:06 --> Controller Class Initialized
INFO - 2021-05-13 16:46:06 --> Model "Common_model" initialized
INFO - 2021-05-13 16:46:06 --> Model "Finane_Model" initialized
INFO - 2021-05-13 16:46:06 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 16:46:06 --> Model "Sales_Model" initialized
INFO - 2021-05-13 16:46:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 16:46:06 --> Final output sent to browser
DEBUG - 2021-05-13 16:46:06 --> Total execution time: 0.1102
INFO - 2021-05-13 16:46:19 --> Config Class Initialized
INFO - 2021-05-13 16:46:19 --> Hooks Class Initialized
DEBUG - 2021-05-13 16:46:19 --> UTF-8 Support Enabled
INFO - 2021-05-13 16:46:19 --> Utf8 Class Initialized
INFO - 2021-05-13 16:46:19 --> URI Class Initialized
DEBUG - 2021-05-13 16:46:19 --> No URI present. Default controller set.
INFO - 2021-05-13 16:46:19 --> Router Class Initialized
INFO - 2021-05-13 16:46:19 --> Output Class Initialized
INFO - 2021-05-13 16:46:19 --> Security Class Initialized
DEBUG - 2021-05-13 16:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 16:46:19 --> Input Class Initialized
INFO - 2021-05-13 16:46:19 --> Language Class Initialized
INFO - 2021-05-13 16:46:19 --> Loader Class Initialized
INFO - 2021-05-13 16:46:19 --> Helper loaded: url_helper
INFO - 2021-05-13 16:46:19 --> Helper loaded: file_helper
INFO - 2021-05-13 16:46:19 --> Helper loaded: utility_helper
INFO - 2021-05-13 16:46:19 --> Helper loaded: unit_helper
INFO - 2021-05-13 16:46:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 16:46:19 --> Database Driver Class Initialized
INFO - 2021-05-13 16:46:19 --> Email Class Initialized
DEBUG - 2021-05-13 16:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 16:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 16:46:19 --> Helper loaded: form_helper
INFO - 2021-05-13 16:46:19 --> Form Validation Class Initialized
INFO - 2021-05-13 16:46:19 --> Controller Class Initialized
INFO - 2021-05-13 16:46:19 --> Model "Common_model" initialized
INFO - 2021-05-13 16:46:19 --> Model "Finane_Model" initialized
INFO - 2021-05-13 16:46:19 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 16:46:19 --> Model "Sales_Model" initialized
INFO - 2021-05-13 16:46:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 16:46:19 --> Final output sent to browser
DEBUG - 2021-05-13 16:46:19 --> Total execution time: 0.0406
INFO - 2021-05-13 16:46:34 --> Config Class Initialized
INFO - 2021-05-13 16:46:34 --> Hooks Class Initialized
DEBUG - 2021-05-13 16:46:34 --> UTF-8 Support Enabled
INFO - 2021-05-13 16:46:34 --> Utf8 Class Initialized
INFO - 2021-05-13 16:46:34 --> URI Class Initialized
DEBUG - 2021-05-13 16:46:34 --> No URI present. Default controller set.
INFO - 2021-05-13 16:46:34 --> Router Class Initialized
INFO - 2021-05-13 16:46:34 --> Output Class Initialized
INFO - 2021-05-13 16:46:34 --> Security Class Initialized
DEBUG - 2021-05-13 16:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 16:46:34 --> Input Class Initialized
INFO - 2021-05-13 16:46:34 --> Language Class Initialized
INFO - 2021-05-13 16:46:35 --> Loader Class Initialized
INFO - 2021-05-13 16:46:35 --> Helper loaded: url_helper
INFO - 2021-05-13 16:46:35 --> Helper loaded: file_helper
INFO - 2021-05-13 16:46:35 --> Helper loaded: utility_helper
INFO - 2021-05-13 16:46:35 --> Helper loaded: unit_helper
INFO - 2021-05-13 16:46:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 16:46:35 --> Database Driver Class Initialized
INFO - 2021-05-13 16:46:35 --> Email Class Initialized
DEBUG - 2021-05-13 16:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 16:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 16:46:35 --> Helper loaded: form_helper
INFO - 2021-05-13 16:46:35 --> Form Validation Class Initialized
INFO - 2021-05-13 16:46:35 --> Controller Class Initialized
INFO - 2021-05-13 16:46:35 --> Model "Common_model" initialized
INFO - 2021-05-13 16:46:35 --> Model "Finane_Model" initialized
INFO - 2021-05-13 16:46:35 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 16:46:35 --> Model "Sales_Model" initialized
INFO - 2021-05-13 16:46:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 16:46:35 --> Final output sent to browser
DEBUG - 2021-05-13 16:46:35 --> Total execution time: 0.0386
INFO - 2021-05-13 16:46:40 --> Config Class Initialized
INFO - 2021-05-13 16:46:40 --> Hooks Class Initialized
DEBUG - 2021-05-13 16:46:40 --> UTF-8 Support Enabled
INFO - 2021-05-13 16:46:40 --> Utf8 Class Initialized
INFO - 2021-05-13 16:46:40 --> URI Class Initialized
INFO - 2021-05-13 16:46:40 --> Router Class Initialized
INFO - 2021-05-13 16:46:40 --> Output Class Initialized
INFO - 2021-05-13 16:46:40 --> Security Class Initialized
DEBUG - 2021-05-13 16:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 16:46:40 --> Input Class Initialized
INFO - 2021-05-13 16:46:40 --> Language Class Initialized
INFO - 2021-05-13 16:46:40 --> Loader Class Initialized
INFO - 2021-05-13 16:46:40 --> Helper loaded: url_helper
INFO - 2021-05-13 16:46:40 --> Helper loaded: file_helper
INFO - 2021-05-13 16:46:40 --> Helper loaded: utility_helper
INFO - 2021-05-13 16:46:40 --> Helper loaded: unit_helper
INFO - 2021-05-13 16:46:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 16:46:40 --> Database Driver Class Initialized
INFO - 2021-05-13 16:46:40 --> Email Class Initialized
DEBUG - 2021-05-13 16:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 16:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 16:46:40 --> Helper loaded: form_helper
INFO - 2021-05-13 16:46:40 --> Form Validation Class Initialized
INFO - 2021-05-13 16:46:40 --> Controller Class Initialized
INFO - 2021-05-13 16:46:40 --> Model "Common_model" initialized
INFO - 2021-05-13 16:46:40 --> Model "Finane_Model" initialized
INFO - 2021-05-13 16:46:40 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 16:46:40 --> Model "Sales_Model" initialized
INFO - 2021-05-13 16:46:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 16:46:40 --> Final output sent to browser
DEBUG - 2021-05-13 16:46:40 --> Total execution time: 0.0630
INFO - 2021-05-13 17:06:54 --> Config Class Initialized
INFO - 2021-05-13 17:06:54 --> Hooks Class Initialized
DEBUG - 2021-05-13 17:06:54 --> UTF-8 Support Enabled
INFO - 2021-05-13 17:06:54 --> Utf8 Class Initialized
INFO - 2021-05-13 17:06:54 --> URI Class Initialized
DEBUG - 2021-05-13 17:06:54 --> No URI present. Default controller set.
INFO - 2021-05-13 17:06:54 --> Router Class Initialized
INFO - 2021-05-13 17:06:54 --> Output Class Initialized
INFO - 2021-05-13 17:06:54 --> Security Class Initialized
DEBUG - 2021-05-13 17:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 17:06:54 --> Input Class Initialized
INFO - 2021-05-13 17:06:54 --> Language Class Initialized
INFO - 2021-05-13 17:06:54 --> Loader Class Initialized
INFO - 2021-05-13 17:06:54 --> Helper loaded: url_helper
INFO - 2021-05-13 17:06:54 --> Helper loaded: file_helper
INFO - 2021-05-13 17:06:54 --> Helper loaded: utility_helper
INFO - 2021-05-13 17:06:54 --> Helper loaded: unit_helper
INFO - 2021-05-13 17:06:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 17:06:54 --> Database Driver Class Initialized
INFO - 2021-05-13 17:06:54 --> Email Class Initialized
DEBUG - 2021-05-13 17:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 17:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 17:06:54 --> Helper loaded: form_helper
INFO - 2021-05-13 17:06:54 --> Form Validation Class Initialized
INFO - 2021-05-13 17:06:54 --> Controller Class Initialized
INFO - 2021-05-13 17:06:54 --> Model "Common_model" initialized
INFO - 2021-05-13 17:06:54 --> Model "Finane_Model" initialized
INFO - 2021-05-13 17:06:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 17:06:54 --> Model "Sales_Model" initialized
INFO - 2021-05-13 17:06:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 17:06:54 --> Final output sent to browser
DEBUG - 2021-05-13 17:06:54 --> Total execution time: 0.0637
INFO - 2021-05-13 19:37:16 --> Config Class Initialized
INFO - 2021-05-13 19:37:16 --> Hooks Class Initialized
DEBUG - 2021-05-13 19:37:16 --> UTF-8 Support Enabled
INFO - 2021-05-13 19:37:16 --> Utf8 Class Initialized
INFO - 2021-05-13 19:37:16 --> URI Class Initialized
DEBUG - 2021-05-13 19:37:16 --> No URI present. Default controller set.
INFO - 2021-05-13 19:37:16 --> Router Class Initialized
INFO - 2021-05-13 19:37:16 --> Output Class Initialized
INFO - 2021-05-13 19:37:16 --> Security Class Initialized
DEBUG - 2021-05-13 19:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 19:37:16 --> Input Class Initialized
INFO - 2021-05-13 19:37:16 --> Language Class Initialized
INFO - 2021-05-13 19:37:16 --> Loader Class Initialized
INFO - 2021-05-13 19:37:16 --> Helper loaded: url_helper
INFO - 2021-05-13 19:37:16 --> Helper loaded: file_helper
INFO - 2021-05-13 19:37:16 --> Helper loaded: utility_helper
INFO - 2021-05-13 19:37:16 --> Helper loaded: unit_helper
INFO - 2021-05-13 19:37:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 19:37:16 --> Database Driver Class Initialized
INFO - 2021-05-13 19:37:16 --> Email Class Initialized
DEBUG - 2021-05-13 19:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 19:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 19:37:16 --> Helper loaded: form_helper
INFO - 2021-05-13 19:37:16 --> Form Validation Class Initialized
INFO - 2021-05-13 19:37:16 --> Controller Class Initialized
INFO - 2021-05-13 19:37:16 --> Model "Common_model" initialized
INFO - 2021-05-13 19:37:16 --> Model "Finane_Model" initialized
INFO - 2021-05-13 19:37:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 19:37:16 --> Model "Sales_Model" initialized
INFO - 2021-05-13 19:37:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 19:37:16 --> Final output sent to browser
DEBUG - 2021-05-13 19:37:16 --> Total execution time: 0.0634
INFO - 2021-05-13 20:05:26 --> Config Class Initialized
INFO - 2021-05-13 20:05:26 --> Hooks Class Initialized
DEBUG - 2021-05-13 20:05:26 --> UTF-8 Support Enabled
INFO - 2021-05-13 20:05:26 --> Utf8 Class Initialized
INFO - 2021-05-13 20:05:26 --> URI Class Initialized
DEBUG - 2021-05-13 20:05:26 --> No URI present. Default controller set.
INFO - 2021-05-13 20:05:26 --> Router Class Initialized
INFO - 2021-05-13 20:05:26 --> Output Class Initialized
INFO - 2021-05-13 20:05:26 --> Security Class Initialized
DEBUG - 2021-05-13 20:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 20:05:26 --> Input Class Initialized
INFO - 2021-05-13 20:05:26 --> Language Class Initialized
INFO - 2021-05-13 20:05:26 --> Loader Class Initialized
INFO - 2021-05-13 20:05:26 --> Helper loaded: url_helper
INFO - 2021-05-13 20:05:26 --> Helper loaded: file_helper
INFO - 2021-05-13 20:05:26 --> Helper loaded: utility_helper
INFO - 2021-05-13 20:05:26 --> Helper loaded: unit_helper
INFO - 2021-05-13 20:05:26 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 20:05:26 --> Database Driver Class Initialized
INFO - 2021-05-13 20:05:26 --> Email Class Initialized
DEBUG - 2021-05-13 20:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 20:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 20:05:26 --> Helper loaded: form_helper
INFO - 2021-05-13 20:05:26 --> Form Validation Class Initialized
INFO - 2021-05-13 20:05:26 --> Controller Class Initialized
INFO - 2021-05-13 20:05:26 --> Model "Common_model" initialized
INFO - 2021-05-13 20:05:26 --> Model "Finane_Model" initialized
INFO - 2021-05-13 20:05:26 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 20:05:26 --> Model "Sales_Model" initialized
INFO - 2021-05-13 20:05:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 20:05:26 --> Final output sent to browser
DEBUG - 2021-05-13 20:05:26 --> Total execution time: 0.0751
INFO - 2021-05-13 20:54:02 --> Config Class Initialized
INFO - 2021-05-13 20:54:02 --> Hooks Class Initialized
DEBUG - 2021-05-13 20:54:02 --> UTF-8 Support Enabled
INFO - 2021-05-13 20:54:02 --> Utf8 Class Initialized
INFO - 2021-05-13 20:54:02 --> URI Class Initialized
DEBUG - 2021-05-13 20:54:02 --> No URI present. Default controller set.
INFO - 2021-05-13 20:54:02 --> Router Class Initialized
INFO - 2021-05-13 20:54:02 --> Output Class Initialized
INFO - 2021-05-13 20:54:02 --> Security Class Initialized
DEBUG - 2021-05-13 20:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 20:54:02 --> Input Class Initialized
INFO - 2021-05-13 20:54:02 --> Language Class Initialized
INFO - 2021-05-13 20:54:02 --> Loader Class Initialized
INFO - 2021-05-13 20:54:02 --> Helper loaded: url_helper
INFO - 2021-05-13 20:54:02 --> Helper loaded: file_helper
INFO - 2021-05-13 20:54:02 --> Helper loaded: utility_helper
INFO - 2021-05-13 20:54:02 --> Helper loaded: unit_helper
INFO - 2021-05-13 20:54:02 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 20:54:02 --> Database Driver Class Initialized
INFO - 2021-05-13 20:54:02 --> Email Class Initialized
DEBUG - 2021-05-13 20:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 20:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 20:54:02 --> Helper loaded: form_helper
INFO - 2021-05-13 20:54:02 --> Form Validation Class Initialized
INFO - 2021-05-13 20:54:02 --> Controller Class Initialized
INFO - 2021-05-13 20:54:02 --> Model "Common_model" initialized
INFO - 2021-05-13 20:54:02 --> Model "Finane_Model" initialized
INFO - 2021-05-13 20:54:02 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 20:54:02 --> Model "Sales_Model" initialized
INFO - 2021-05-13 20:54:02 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 20:54:02 --> Final output sent to browser
DEBUG - 2021-05-13 20:54:02 --> Total execution time: 0.0500
INFO - 2021-05-13 22:41:06 --> Config Class Initialized
INFO - 2021-05-13 22:41:06 --> Hooks Class Initialized
DEBUG - 2021-05-13 22:41:06 --> UTF-8 Support Enabled
INFO - 2021-05-13 22:41:06 --> Utf8 Class Initialized
INFO - 2021-05-13 22:41:06 --> URI Class Initialized
DEBUG - 2021-05-13 22:41:06 --> No URI present. Default controller set.
INFO - 2021-05-13 22:41:06 --> Router Class Initialized
INFO - 2021-05-13 22:41:06 --> Output Class Initialized
INFO - 2021-05-13 22:41:06 --> Security Class Initialized
DEBUG - 2021-05-13 22:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 22:41:06 --> Input Class Initialized
INFO - 2021-05-13 22:41:06 --> Language Class Initialized
INFO - 2021-05-13 22:41:06 --> Loader Class Initialized
INFO - 2021-05-13 22:41:06 --> Helper loaded: url_helper
INFO - 2021-05-13 22:41:06 --> Helper loaded: file_helper
INFO - 2021-05-13 22:41:06 --> Helper loaded: utility_helper
INFO - 2021-05-13 22:41:06 --> Helper loaded: unit_helper
INFO - 2021-05-13 22:41:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 22:41:06 --> Database Driver Class Initialized
INFO - 2021-05-13 22:41:06 --> Email Class Initialized
DEBUG - 2021-05-13 22:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 22:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 22:41:06 --> Helper loaded: form_helper
INFO - 2021-05-13 22:41:06 --> Form Validation Class Initialized
INFO - 2021-05-13 22:41:06 --> Controller Class Initialized
INFO - 2021-05-13 22:41:06 --> Model "Common_model" initialized
INFO - 2021-05-13 22:41:06 --> Model "Finane_Model" initialized
INFO - 2021-05-13 22:41:06 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 22:41:06 --> Model "Sales_Model" initialized
INFO - 2021-05-13 22:41:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 22:41:06 --> Final output sent to browser
DEBUG - 2021-05-13 22:41:06 --> Total execution time: 0.0458
INFO - 2021-05-13 22:48:38 --> Config Class Initialized
INFO - 2021-05-13 22:48:38 --> Hooks Class Initialized
DEBUG - 2021-05-13 22:48:38 --> UTF-8 Support Enabled
INFO - 2021-05-13 22:48:38 --> Utf8 Class Initialized
INFO - 2021-05-13 22:48:38 --> URI Class Initialized
DEBUG - 2021-05-13 22:48:38 --> No URI present. Default controller set.
INFO - 2021-05-13 22:48:38 --> Router Class Initialized
INFO - 2021-05-13 22:48:38 --> Output Class Initialized
INFO - 2021-05-13 22:48:38 --> Security Class Initialized
DEBUG - 2021-05-13 22:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 22:48:38 --> Input Class Initialized
INFO - 2021-05-13 22:48:38 --> Language Class Initialized
INFO - 2021-05-13 22:48:38 --> Loader Class Initialized
INFO - 2021-05-13 22:48:38 --> Helper loaded: url_helper
INFO - 2021-05-13 22:48:38 --> Helper loaded: file_helper
INFO - 2021-05-13 22:48:38 --> Helper loaded: utility_helper
INFO - 2021-05-13 22:48:38 --> Helper loaded: unit_helper
INFO - 2021-05-13 22:48:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 22:48:38 --> Database Driver Class Initialized
INFO - 2021-05-13 22:48:38 --> Email Class Initialized
DEBUG - 2021-05-13 22:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 22:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 22:48:38 --> Helper loaded: form_helper
INFO - 2021-05-13 22:48:38 --> Form Validation Class Initialized
INFO - 2021-05-13 22:48:38 --> Controller Class Initialized
INFO - 2021-05-13 22:48:38 --> Model "Common_model" initialized
INFO - 2021-05-13 22:48:38 --> Model "Finane_Model" initialized
INFO - 2021-05-13 22:48:38 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 22:48:38 --> Model "Sales_Model" initialized
INFO - 2021-05-13 22:48:38 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 22:48:38 --> Final output sent to browser
DEBUG - 2021-05-13 22:48:38 --> Total execution time: 0.0471
INFO - 2021-05-13 22:49:54 --> Config Class Initialized
INFO - 2021-05-13 22:49:54 --> Hooks Class Initialized
DEBUG - 2021-05-13 22:49:54 --> UTF-8 Support Enabled
INFO - 2021-05-13 22:49:54 --> Utf8 Class Initialized
INFO - 2021-05-13 22:49:54 --> URI Class Initialized
INFO - 2021-05-13 22:49:54 --> Router Class Initialized
INFO - 2021-05-13 22:49:54 --> Output Class Initialized
INFO - 2021-05-13 22:49:54 --> Security Class Initialized
DEBUG - 2021-05-13 22:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-13 22:49:54 --> Input Class Initialized
INFO - 2021-05-13 22:49:54 --> Language Class Initialized
INFO - 2021-05-13 22:49:54 --> Loader Class Initialized
INFO - 2021-05-13 22:49:54 --> Helper loaded: url_helper
INFO - 2021-05-13 22:49:54 --> Helper loaded: file_helper
INFO - 2021-05-13 22:49:54 --> Helper loaded: utility_helper
INFO - 2021-05-13 22:49:54 --> Helper loaded: unit_helper
INFO - 2021-05-13 22:49:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-13 22:49:54 --> Database Driver Class Initialized
INFO - 2021-05-13 22:49:54 --> Email Class Initialized
DEBUG - 2021-05-13 22:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-13 22:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-13 22:49:54 --> Helper loaded: form_helper
INFO - 2021-05-13 22:49:54 --> Form Validation Class Initialized
INFO - 2021-05-13 22:49:54 --> Controller Class Initialized
INFO - 2021-05-13 22:49:54 --> Model "Common_model" initialized
INFO - 2021-05-13 22:49:54 --> Model "Finane_Model" initialized
INFO - 2021-05-13 22:49:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-13 22:49:54 --> Model "Sales_Model" initialized
INFO - 2021-05-13 22:49:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-13 22:49:54 --> Final output sent to browser
DEBUG - 2021-05-13 22:49:54 --> Total execution time: 0.0408
