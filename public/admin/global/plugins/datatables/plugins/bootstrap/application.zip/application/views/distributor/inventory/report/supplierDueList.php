
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li>Supplier Due List</li>

            </ul>

        </div>
        <br>
        <div class="page-content">



            <div class="row">
                <div class="col-sm-10 col-md-offset-1">
                    <div class="table-header">
                        Supplier Due List <span style="color:greenyellow;"></span>
                    </div>
                    <?php if ($companyInfo->invoice_format_type == 1): ?>


                            <table class="table table-responsive">
                                <tr>
                                    <td style="text-align:center;">
                                        <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                        <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                        <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                        <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                        <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                        <strong><?php echo $pageTitle; ?></strong>
                                    </td>
                                </tr>
                            </table>

                        <?php else: ?>
                            <div>
                                <?php echo $companyInfo->report_header; ?>
                            </div>
                        <?php endif; ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <td align="left"><strong>SL</strong></td>
                                <td align="left"><strong>Supplier Name</strong></td>
                                <td align="left"><strong>Invoice No</strong></td>
                                <td align="left"><strong>Invoice Date</strong></td>
                                <td align="right"><strong>Invoice Amount</strong></td>
                                <td align="right"><strong>Paid Amount</strong></td>
                                <td align="right"><strong>Due Amount</strong></td>
                            </tr>
                        </thead>
                        <tbody>

                            <?php


                            foreach ($allResult as $key => $row):

                                $tinvoieAmount+=$row->invoiceamount;
                                $tpaidAmount+=$row->paidAmount;
                                $tDueAmount+=$row->dueAmount;
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td align="left"><?php echo $row->supName; ?></td>
                                    <td align="left"><a target="_blank"  title="View Purchases" href="<?php echo site_url($this->project . '/viewPurchases/'.$row->generals_id);?>"><?php echo $row->voucher_no; ?></a></td>
                                    <td align="left"><?php echo date('M d, Y', strtotime($row->date)); ?></td>
                                    <td align="right"><?php echo $row->invoiceamount; ?></td>
                                    <td align="right"><?php echo $row->paidAmount; ?></td>
                                    <td align="right"><?php echo $row->dueAmount; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" align="right"><strong>Total (In BDT.)</strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tinvoieAmount, 2, '.', ','); ?></strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tpaidAmount, 2, '.', ','); ?></strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tDueAmount, 2, '.', ','); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                    <br>
                </div>
            </div>

        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
