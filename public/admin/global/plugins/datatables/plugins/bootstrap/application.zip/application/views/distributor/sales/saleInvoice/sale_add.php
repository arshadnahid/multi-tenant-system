<script src="<?php echo base_url(); ?>assets/js/jQueryUI/jquery-new-ui.js"></script>
<style>
    table tr td{
        margin: 0px!important;
        padding: 2px!important;
    }

    table tr td  tfoot .form-control {
        width: 100%;
        height: 25px;
    }
</style>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Transaction</li>
                <li class="active">Sales Invoice Add</li>
                <li class="active"><span style="color:red;"> *</span> <span style="color: red">Mark field must be fill up</span></li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li class="active">
                    <i class="ace-icon fa fa-list"></i>
                    <a href="<?php echo site_url($this->project . '/salesInvoice'); ?>">List</a>
                </li>
            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <table class="mytable table-responsive table table-bordered">
                            <tr>
                                <td  style="padding: 10px!important;">
                                    <div class="col-md-6">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Customer ID <span style="color:red;"> *</span></label>
                                                <div class="col-sm-6">
                                                    <select  id="customerid" name="customer_id"  class="chosen-select form-control" onchange="getCustomerCurrentBalace()" id="form-field-select-3" data-placeholder="Search by Customer ID OR Name">
                                                        <option></option>
                                                        <?php foreach ($customerList as $key => $each_info): ?>
                                                            <option value="<?php echo $each_info->customer_id; ?>"><?php echo $each_info->typeTitle . ' - ' . $each_info->customerPhone . ' [ ' . $each_info->customerName . ' ] '; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                    <div class="clearfix"></div>
                                                    <span id="loadCusSup">
                                                        <table class="customerInfo" >
                                                            <tr>
                                                                <td><b>Address</b> &nbsp; </td>
                                                                <td> &nbsp;:&nbsp;&nbsp; </td>
                                                                <td>&nbsp;&nbsp;&nbsp;<span> </span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><b>Customer Phone</b> &nbsp; </td>
                                                                <td> &nbsp;:&nbsp;&nbsp; </td>
                                                                <td>&nbsp;&nbsp;&nbsp;<span> </span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><b>Customer Name</b> &nbsp; </td>
                                                                <td> &nbsp;:&nbsp;&nbsp; </td>
                                                                <td>&nbsp;&nbsp;&nbsp;<span></span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><b>Customer ID</b> &nbsp; </td>
                                                                <td> &nbsp;:&nbsp;&nbsp; </td>
                                                                <td>&nbsp;&nbsp;&nbsp;<span> </span></td>
                                                            </tr>
                                                        </table>
                                                    </span>
                                                </div>
                                                <div class="col-sm-2" id="newCustomerHide">
                                                    <a  data-toggle="modal" data-target="#myModal" class="saleAddPermission btn btn-xs btn-success"><i class="fa fa-plus"></i>&nbsp;New</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Reference</label>
                                                <div class="col-sm-6">
                                                    <select  name="reference"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Reference ID OR Name">
                                                        <option></option>
                                                        <?php foreach ($referenceList as $key => $each_ref): ?>
                                                            <option value="<?php echo $each_ref->reference_id; ?>"><?php echo $each_ref->referenceName; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                <!--                                    <input type="text" id="form-field-1" name="reference"  value="" class="form-control" placeholder="Reference" />
                                                    -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Payment Type  <span style="color:red;"> *</span></label>
                                                <div class="col-sm-6">
                                                    <select onchange="showBankinfo(this.value)"  name="paymentType"  class="chosen-select form-control" id="paymentType" data-placeholder="Select Payment Type">
                                                        <option></option>
                                                        <!--<option value="1">Full Cash</option>-->
                                                        <option selected value="4">Cash</option>
                                                        <option value="2">Credit</option>
                                                        <option value="3">Cheque / DD/ PO</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="showBankInfo" style="display:none;">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <div class="col-sm-3"></div>
                                                    <div class="col-sm-2">
                                                        <input type="text" value="" name="bankName" id="bankName" class="form-control" placeholder="Bank Name"/>
                                                    </div>
                                                    <div class="col-sm-2">
                                                        <input type="text" value="" name="branchName" id="branchName" class="form-control" placeholder="Branch Name"/>
                                                    </div>
                                                    <div class="col-sm-2">
                                                        <input type="text" value="" class="form-control" id="checkNo" name="checkNo" placeholder="Check NO"/>
                                                    </div>
                                                    <div class="col-sm-2">
                                                        <input class="form-control date-picker" name="checkDate" name="purchasesDate" id="checkDate" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Invoice No</label>
                                                <div class="col-sm-4">
                                                    <input type="text" id="form-field-1" name="userInvoiceId" value="" class="form-control" placeholder="Invoice No"/>
                                                </div>
                                                <div class="col-sm-3">
                                                    <input type="text" id="form-field-1" name="voucherid" readonly value="<?php echo $voucherID; ?>" class="form-control" placeholder="Invoice ID" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Sales Date  <span style="color:red;"> *</span></label>
                                                <div class="col-sm-7">
                                                    <div class="input-group">
                                                        <input class="form-control date-picker" name="saleDate" id="saleDate" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" />
                                                        <span class="input-group-addon">
                                                            <i class="fa fa-calendar bigger-110"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Loader</label>
                                                <div class="col-sm-7">
                                                    <select  name="loader"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Loader">
                                                        <option></option>
                                                        <?php foreach ($employeeList as $key => $eachEmp): ?>
                                                            <option value="<?php echo $eachEmp->id; ?>"><?php echo $eachEmp->personalMobile . ' [ ' . $eachEmp->name . ']'; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Transportation</label>
                                                <div class="col-sm-7">
                                                    <select  name="transportation"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Transportation">
                                                        <option></option>
                                                        <?php foreach ($vehicleList as $key => $eachVehicle): ?>
                                                            <option value="<?php echo $eachVehicle->id; ?>"><?php echo $eachVehicle->vehicleName . ' [ ' . $eachVehicle->vehicleModel . ' ]'; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Shipping Address</label>
                                                <div class="col-sm-7">
                                                    <input class="form-control" placeholder="Shipping Address" name="shippingAddress" />
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="clearfix"></div>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 10px!important;">
                                    <div class="col-md-12">
                                        <div class="col-md-9">
                                            <div class="panel panel-default">
                                                <div class="panel-body">
                                                    <div class="table-header">
                                                        Sales Item
                                                    </div>
                                                    <div class="col-md-12 autocomplete"  style="">
                                                        <div class="row">
                                                            <div class="input-group">
                                                                <span class=" input-group-addon glyphicon glyphicon-search"></span>
                                                                <input id="productNameAutocomplete" class="form-control "
                                                                       placeholder="Scan/Search Product by Name/Code" autocomplete="off">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <table class="table table-bordered table-hover tableAddItem" id="show_item">
                                                        <thead>
                                                            <tr>
<!--                                                            <th nowrap  align="center" id="package_th"><strong>Package <span style="color:red;"> *</span></strong></th>-->
                                                                <th nowrap  style="width:20%" align="center" id=""><strong>Product Category <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width:25%" align="center" id=""><strong>Product <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width: 15%"  align="center" id=""><strong>Bundle <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width:10%" align="center"><strong>Quantity <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap  style="width:12%"  align="center"><strong>Unit Price(BDT)  <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap  style="width:13%"  align="center"><strong>Total Price(BDT) <span style="color:red;"> *</span></strong></th>
                                                                <th align="center" style="width:5%"><strong>Action</strong></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td id="product_td">
                                                                    <select id="categoryId" onchange="getProductList2(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Category">
                                                                        <option value=""></option>
                                                                        <?php foreach ($productCat as $eachCat) : ?>
                                                                            <option categoryName="<?php echo $eachCat->title; ?>" value="<?php echo $eachCat->category_id; ?>"><?php echo $eachCat->title; ?></option>
                                                                        <?php endforeach; ?>
                                                                    </select>
                                                                </td>
                                                                <td id="product_td">
                                                                    <select id="productID2" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Product">
                                                                        <option value=""></option>
                                                                    </select>
                                                                </td>
                                                                <td><input type="hidden" value="" id="stockQtyBundle" /><input id="bundleValue" type="text"  onkeyup="checkStockOverQtyBundle(this.value)" class="form-control text-right bundle decimal"  placeholder="0"></td>
                                                                <td><input type="hidden" value="" id="stockQty"/><input type="text"  onkeyup="checkStockOverQty(this.value)" class="form-control text-right quantity decimal"  placeholder="0"></td>
                                                                <td><input type="text" class="form-control text-right rate decimal" placeholder="0.00"  ></td>
                                                                <td><input type="text" class="form-control text-right price decimal" placeholder="0.00" readonly="readonly"></td>
                                                                <td><a id="add_item" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add</a></td>
                                                            </tr>
                                                        </tbody>
                                                        <tfoot>

                                                        </tfoot>
                                                    </table>

                                                    <table class="table table-bordered table-hover table-success">
                                                        <tr>
                                                            <td>
                                                                <textarea style="border:none;" cols="120"  class="form-control" name="narration" placeholder="Narration......" type="text"></textarea>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="panel  panel-default">
                                                <div class="panel-body">
                                                    <div class="table-header success">
                                                        Payment Calculation
                                                    </div>
                                                    <table class="table table-bordered table-hover ">
                                                        <tbody>
                                                            <tr>
                                                                <td nowrap  align="right"><strong>Total </strong></td>
                                                                <td   align="right"><strong class="total_price"></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td nowrap align="right"><strong>Discount ( - ) </strong></td>
                                                                <td><input type="text"  onkeyup="calDiscount()" id="disCount" style="text-align: right" name="discount" value="" class="form-control" placeholder="0.00"   oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                            </tr>
                                                            <tr>
                                                                <td nowrap   align="right"><strong>Grand Total</strong></td>
                                                                <td><input readonly id="grandTotal" type="text" style="text-align: right" name="grandtotal" value="" class="form-control"  placeholder="0.00"/></td>
                                                            </tr>
                                                            <tr>
                                                                <td nowrap    align="right"><strong>VAT(%) ( + )</strong></td>
                                                                <td><input type="text" id="vatAmount"  style="text-align: right" name="vat" readonly value="<?php
                                                                        if (!empty($configInfo->vat)): echo $configInfo->vat;
                                                                        endif;
                                                                        ?>" class="form-control totalVatAmount"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                            </tr>
                                                            <tr>
                                                                <td nowrap  align="right"><strong>Loader ( + )</strong></td>
                                                                <td><input type="text" id="loader" onkeyup="calcutateFinal()"   style="text-align: right" name="loaderAmount" value=""  class="form-control"  placeholder="0.00"/></td>
                                                            </tr>
                                                            <tr>
                                                                <td nowrap  align="right"><strong>Transportation ( + )</strong></td>
                                                                <td><input type="text" id="transportation" onkeyup="calcutateFinal()"   style="text-align: right" name="transportationAmount" value=""  class="form-control"  placeholder="0.00"/></td>
                                                            </tr>
                                                            <tr>
                                                                <td nowrap  align="right"><strong>Net Total</strong></td>
                                                                <td><input type="text" id="netAmount"  style="text-align: right" name="netTotal" value="" readonly class="form-control"  placeholder="0.00"/></td>
                                                            </tr>
                                                            <tr class="chaque_amount_class" style="display:none">
                                                                <td nowrap  align="right"><strong>Chaque Amount</strong></td>
                                                                <td><input type="text" id="chaque_amount"  style="text-align: right" name="chaque_amount" value=""  class="form-control"  placeholder="0.00"/></td>
                                                            </tr>
                                                            <tr class="partisals"  >
                                                                <td  nowrap   align="right"><strong>Account <span style="color:red;"> * </span></strong></td>
                                                                <td >
                                                                    <select style="width:100%!important;"  name="accountCrPartial" class="chosen-select   checkAccountBalance" id="partialHead" data-placeholder="Search by Account Head">
                                                                        <option value=""></option>
                                                                        <?php
                                                                        foreach ($accountHeadList as $key => $head) {
                                                                            if ($key != 51 || $key != 112) {
                                                                                ?>
                                                                                <optgroup label="<?php echo $head['parentName']; ?>">
                                                                                    <?php
                                                                                    foreach ($head['Accountledger'] as $eachLedger) :
                                                                                        ?>
                                                                                        <option <?php
                                                                            if ($eachLedger->chartId == '54') {
                                                                                echo "selected";
                                                                            }
                                                                                        ?> value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                                                        <?php endforeach; ?>
                                                                                </optgroup>
                                                                                <?php
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </td>
                                                            </tr>
                                                            <tr  class="partisals">
                                                                <td nowrap  align="right"><strong>Payment ( - )<span style="color:red;"> * </span></strong></td>
                                                                <td><input type="text" id="payment" onkeyup="calculatePartialPayment()" style="text-align: right" name="partialPayment" value=""  class="form-control" autocomplete="off"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                        <input type="hidden" id="duePayment"  style="text-align: right" name="duePayment" value="" readonly  class="form-control"  placeholder="0.00"/>
                                                        </tr>
                                                        <tr class="creditDate" style="display:none;">
                                                            <td nowrap   align="right"><strong>Due Date</strong></td>
                                                            <td>
                                                                <div class="input-group">
                                                                    <input class="form-control date-picker" name="creditDueDate" id="dueDate" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" />
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td nowrap align="right"><strong>Due Amount</strong></td>
                                                            <td><input type="text" id="currentDue"  readonly style="text-align: right" name="" value=""  class="form-control" autocomplete="off"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                        </tr>
                                                        <tr>
                                                            <td  nowrap align="right"><strong>Previous Due</strong></td>
                                                            <td><input type="text" id="previousDue"  readonly style="text-align: right" name="" value=""  class="form-control" autocomplete="off"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>

                                                        </tr>
                                                        <tr>
                                                            <td  nowrap align="right"><strong>Total Due</strong></td>
                                                            <td><input type="text" id="totalDue"  readonly style="text-align: right" name="" value=""  class="form-control" autocomplete="off"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                        </tr>
                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </td>
                            </tr>
                            <tr>

                            </tr>
                            <tr>
                                <td>
                                    <div class="clearfix"></div>
                                    <div class="clearfix form-actions" >
                                        <div class="col-md-offset-1 col-md-10">
                                            <button onclick="return isconfirm2()" id="subBtn" class="btn btn-info" type="button">
                                                <i class="ace-icon fa fa-check bigger-110"></i>
                                                Save
                                            </button>
                                            &nbsp; &nbsp; &nbsp;

                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script>


    $("#productNameAutocomplete").autocomplete({

        source: function (request, response) {
            $.getJSON(baseUrl + "SalesController/get_product_list_by_dist_id", {term: request.term},
            response);
        },
        minLength: 1,
        delay: 100,
        response: function (event, ui) {
            if (ui.content) {
                if (ui.content.length == 1) {
                    addRowProduct(ui.content[0].id, ui.content[0].productName, ui.content[0].category_id, ui.content[0].productCatName, ui.content[0].brand_id, ui.content[0].brandName, ui.content[0].unit_id, ui.content[0].unitTtile)
                    var dataIns = $(this).val();
                    $(this).val('');
                    $(this).focus();
                    $(this).autocomplete('close');
                    return false;

                } else if (ui.content.length == 0) {
                    $(this).val('');
                    $(this).focus();
                    $(this).autocomplete('close');
                    return false;
                } else {
                    // alert("This Character and code have no item!!");
                }
            }
        },
        select: function (event, ui) {
            addRowProduct(ui.item.id, ui.item.productName, ui.item.category_id, ui.item.productCatName, ui.item.brand_id, ui.item.brandName, ui.item.unit_id, ui.item.unitTtile)
            $(this).val('');
            return false;
        }

    });
    //        $.ui.autocomplete.prototype._renderItem = function (ul, item) {
    //        var term = this.term.split(' ').join('|');
    //        var re = new RegExp("(" + term + ")", "gi");
    //        var t = item.label.replace(re, "<b style='color:red'>$1</b>");
    //        return $("<li></li>")
    //                .data("item.autocomplete", item)
    //                .append("<a>" + t + "</a>")
    //                .appendTo(ul);
    //    };




    function addRowProduct(productID, productName, productCatID, productCatName, productBrandID, productBrandName, productUnit, unitName) {// quantity,returnQuantity, rate, price
        var quantity;

        var productCatID = productCatID;
        var productCatName = productCatName;

        var productID = productID;
        var productName = productName;

        var productUnit = productUnit;
        var unitName = unitName;

        var rate = 0;
        var price = 0;
        var returnQuantity = $('.returnQuantity').val();
        $.ajax({
            type: "POST",
            url: baseUrl + "FinaneController/getProductStock",
            data: 'product_id=' + productID,
            success: function (data) {
                var mainStock = parseFloat(data);
                if (data != '') {
                    quantity = mainStock;
                }

            }, complete: function () {
                var previousProductID = parseFloat($('#productID_' + productID).val());
                $.ajax({
                    type: "POST",
                    url: baseUrl + "FinaneController/getProductPriceForSale",
                    data: 'product_id=' + productID,
                    success: function (data) {

                        if (data != '') {
                            //$('#rate_' + productID).val(data);
                        }
                    }, complete: function () {

                        if (quantity > 0) {
                            var givenQuantity = 1;
                            var previousProductQuantity = parseInt($('#qty_' + productID).val());

                            if (previousProductID == productID) {
                                givenQuantity = givenQuantity + previousProductQuantity;
                                $('#qty_' + productID).val(givenQuantity);
                                productTotal('_' + productID)
                                return true;
                            }

                            var tab = "";
                            var rowCount = $('#show_item tr').length;

                            if(rowCount == 2){
                                $("#show_item tfoot").prepend('<tr><td colspan="3" align="right"> Total </td><td align="right"><span class="total_quantity">0.00</span></td><td align="right"><span class="total_rate">0.00</span></td><td align="right"><span class="total_totalPrice">0.00</span></td></tr>');
                            }


                            if (productCatID == 1) {
                                tab = '<tr class="new_item' + productID + '">' +
                                    '<td style="padding-left:15px;">' +
                                    productCatName +
                                    '<input id="productID_' + productID + '" name="product_id[]" value="' + productID + '" type="hidden">' +
                                    '<input type="hidden" name="category_id[]" value="' + productCatID + '">' +
                                    '</td>' +
                                    '<td style="padding-left:15px;">' +
                                    productName + '&nbsp;[&nbsp;' + productBrandName + '&nbsp;]&nbsp;' +
                                    '</td>' +

                                    '<td align="right">' +
                                    '   <input type="text" id="bundle_' + productID + '" onkeyup="checkStockOverQtyBundle(this.value)"  class="form-control text-right add_bundle decimal" value="" placeholder=""  name="bundle[]" value="">' +
                                    '</td>' +

                                    '<td align="right">' +
                                    '   <input type="text" id="qty_' + productID + '"  onkeyup="checkStockOverQty(this.value)" class="form-control text-right add_quantity decimal" value="' + givenQuantity + '" placeholder="' + quantity + '"onkeyup="checkStockOverQty(this.value)" name="quantity[]" value="">' +
                                    '</td>' +

                                    '<td align="right">' +
                                    '<input type="text" id="rate_' + productID + '" class="form-control add_rate text-right decimal" name="rate[]" value="' + '' + '" placeholder="0.00">' +
                                    '</td>' +
                                    '<td align="right">' +
                                    '<input readonly type="text" class="add_price text-right form-control" id="tprice_' + productID + '" name="price[]" value="' + price + '">' +
                                    '</td>' +
                                    '<td>' +
                                    '<a del_id="' + productID + '" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a>' +
                                    '</td>' +
                                    '</tr>';
                                $("#show_item tbody").append(tab);

                            } else {

                                tab = '<tr class="new_item' + productID + '">' +

                                    '<td style="padding-left:15px;">' +
                                    productCatName +
                                    '<input id="productID_' + productID + '" name="product_id[]" value="' + productID + '" type="hidden">' +
                                    '<input type="hidden" name="category_id[]" value="' + productCatID + '">' +
                                    '</td>' +

                                    '<td style="padding-left:15px;">' +
                                    productName + '&nbsp;[&nbsp;' + productBrandName + '&nbsp;]&nbsp;' +
                                    '</td>' +

                                    '<td align="right">' +
                                    '   <input type="text" id="bundle_' + productID + '" onkeyup="checkStockOverQtyBundle(this.value)"  class="form-control text-right add_bundle decimal" readonly value="" placeholder=""  name="bundle[]" value="">' +
                                    '</td>' +

                                    '<td align="right">' +
                                    '   <input type="text" id="qty_' + productID + '"  onkeyup="checkStockOverQty(this.value)" class="form-control text-right add_quantity decimal" value="' + givenQuantity + '" placeholder="' + quantity + '"onkeyup="checkStockOverQty(this.value)" name="quantity[]" value="">' +
                                    '</td>' +

                                    '<td align="right">' +
                                    '<input type="text" id="rate_' + productID + '" class="form-control add_rate text-right decimal" name="rate[]" value="' + '' + '" placeholder="0.00">' +
                                    '</td>' +
                                    '<td align="right">' +
                                    '<input readonly type="text" class="add_price text-right form-control" id="tprice_' + productID + '" name="price[]" value="' + price + '">' +
                                    '</td>' +
                                    '<td>' +
                                    '<a del_id="' + productID + '" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a>' +
                                    '</td>' +
                                    '</tr>';
                                $("#show_item tbody").append(tab);

                            }
                            $("#subBtn").attr('disabled', false);



                            findTotalCal();
                            setTimeout(function() {
                                ///calculateCustomerDue();
                                calcutateFinal();
                            }, 100);

                        } else {
                            swal("Quantity Can't be empty!", "Validation Error!", "error");
                            return false;
                        }
                    }
                });
            }
        });
    }


    $(document).on("keyup", ".add_quantityPos", function () {
        var id_arr = $(this).attr('id');
        productTotal(id_arr)

    });













    function isconfirm2() {

        var customerid = $("#customerid").val();
        var saleDate = $("#saleDate").val();
        var paymentType = $("#paymentType").val();
        var paymentType = $("#paymentType").val();
        var dueDate = $("#dueDate").val();
        var partialHead = $("#partialHead").val();
        var thisAllotment = $("#payment").val();
        var bankName = $("#bankName").val();
        var branchName = $("#branchName").val();
        var checkNo = $("#checkNo").val();
        var checkDate = $("#checkDate").val();
        var checkDate = $("#checkDate").val();
        var chaque_amount = parseFloat($("#chaque_amount").val());
        if(isNaN(chaque_amount)){
            chaque_amount=0;
        }
        var bundleValue = $("#bundleValue").val();
        var cylinder = 0;


        //add_price

        var  priceChek = 1;
        var checkEmptyPrice = 0;
        $.each($('.add_price'), function () {
            var checkEmptyPrice1 = $(this).val();
            checkEmptyPrice1 = Number(checkEmptyPrice1);
            if(checkEmptyPrice1 == 0 || checkEmptyPrice1 < 1){
                priceChek=2
            }
        });

        if ($("#culinderReceive").css('display') == 'none') {
            cylinder = 0;
        } else {
            //  var cylinderItem=parseFloat($(".total_quantity2").text());
            var rowCount = $('#show_item2 tfoot tr').length;
            cylinder = 1;
        }
        var totalPrice = parseFloat($(".total_price").text());
        if (isNaN(totalPrice)) {
            totalPrice = 0;
        }
        if (customerid == '') {
            swal("Select Customer Name!", "Validation Error!", "error");
        } else if (saleDate == '') {
            swal("Select Sale Date!", "Validation Error!", "error");
        } else if (paymentType == '') {
            swal("Select Payment Type", "Validation Error!", "error");
        } else if (paymentType == 2 && dueDate == '') {
            swal("Select Due Date!", "Validation Error!", "error");
        } else if (paymentType == 3 && bankName == '') {
            swal("Type Bank Name!", "Validation Error!", "error");
        } else if (paymentType == 3 && branchName == '') {
            swal("Type Branch Name!", "Validation Error!", "error");
        } else if (paymentType == 3 && checkNo == '') {
            swal("Type Check No!", "Validation Error!", "error");
        } else if (paymentType == 3 && checkDate == '') {
            swal("Select Check Date!", "Validation Error!", "error");
        }else if (paymentType == 3 && chaque_amount == '') {
            swal("Given Check Payment!", "Validation Error!", "error");
        } else if (totalPrice == '' || totalPrice < 0) {
            swal("Add Sales Item!", "Validation Error!", "error");
        }else if(priceChek == 2){
            swal("Product price is empty!", "Validation Error!", "error");
        } else if (paymentType == 4 && partialHead == '') {
            swal("Select Account Head!", "Validation Error!", "error");
        } else if (paymentType == 4 && thisAllotment == '') {
            swal("Given Cash Amount!", "Validation Error!", "error");
        } else{
            swal({
                title: "Are you sure ?",
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#73AE28',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true,
                type: 'success'
            },
            function (isConfirm) {
                if (isConfirm) {
                    $("#publicForm").submit();
                } else {
                    return false;
                }
            });
        }
    }
</script>

<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add New Customer</h4>
            </div>
            <div class="modal-body">


                <div class="row">
                    <div class="col-md-12">
                        <form id="publicForm2" action=""  method="post" class="form-horizontal">

                            <?php
                            $this->db->select("*");
                            $this->db->from("customertype");
                            $this->db->where_in('dist_id', array($this->dist_id, 1));
                            $customerType = $this->db->get()->result();

                            // echo $this->db->last_query();die;
                            //$customerType = $this->Common_model->get_data_list_by_single_column('customertype', 'dist_id', $this->dist_id);
                            ?>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer Type</label>
                                <div class="col-sm-9">
                                    <select  name="customerType"  class=" form-control" id="form-field-select-3"  data-placeholder="Search by Customer Type">
                                        <option>-Select Type-</option>
                                        <?php foreach ($customerType as $key => $eachType): ?>
                                            <option value="<?php echo $eachType->type_id; ?>"><?php echo $eachType->typeTitle; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer ID </label>
                                <div class="col-sm-9">
                                    <input type="text" id="customerId" name="customerID" readonly value="<?php echo isset($customerID) ? $customerID : ''; ?>" class="form-control" placeholder="Customer ID" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer Name </label>
                                <div class="col-sm-9">
                                    <input type="text" id="customerName" name="customerName" class="form-control" placeholder="Customer Name" required/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Phone</label>
                                <div class="col-sm-9">
                                    <input type="text"  maxlength="11" id="form-field-1 cstPhone" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" onblur="checkDuplicatePhone(this.value)" name="customerPhone" placeholder="Customer Phone" class="form-control" />
                                    <span id="errorMsg"  style="color:red;display: none;"><i class="ace-icon fa fa-spinner fa-spin orange bigger-120"></i> &nbsp;&nbsp;Phone Number already Exits!!</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email</label>
                                <div class="col-sm-9">
                                    <input type="email" id="form-field-1" name="customerEmail" placeholder="Email" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address</label>
                                <div class="col-sm-9">
                                    <!--<textarea id="editor1" cols="10" rows="5" name="comp_add"></textarea>-->
                                    <textarea  cols="6" rows="3" placeholder="Type Address.." class="form-control" name="customerAddress"></textarea>
                                </div>
                            </div>
                            <div class="clearfix form-actions" >
                                <div class="col-md-offset-3 col-md-9">
                                    <button onclick="saveNewCustomer()" id="subBtn2" class="btn btn-info" type="button">
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        Save
                                    </button>
                                    &nbsp; &nbsp; &nbsp;
                                    <button class="btn" type="reset" data-dismiss="modal">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>


<script>

function checkDuplicateCategory(catName){
    var url = baseUrl+ "SetupController/checkDuplicateCategory";
    $.ajax({
        type: 'POST',
        url: url,
        data:{
            'catName': catName
        },
        success: function (data)
        {
            if(data == 1){
                $("#subBtn").attr('disabled',true);
                $("#errorMsg").show(10);
            }else{
                $("#subBtn").attr('disabled',false);
                $("#errorMsg").hide(10);
            }
        }
    });
}



function calcutateFinal(){

    findVatAmount();
    var loader = parseFloat($("#loader").val());
    if(isNaN(loader)){
        loader=0;
    }
    var transportation = parseFloat($("#transportation").val());
    if(isNaN(transportation)){
        transportation=0;
    }
    var total_price = parseFloat($(".total_price").text());
    if(isNaN(total_price)){
        total_price=0;
    }
    var discount = parseFloat($("#disCount").val());
    if(isNaN(discount)){
        discount=0;
    }
    var total_price = (total_price + transportation +  loader) - discount;

    var payment = parseFloat($("#payment").val());
    if(isNaN(payment)){
        payment=0;
    }
    var previousDue = parseFloat($("#previousDue").val());
    if(isNaN(previousDue)){
        previousDue=0;
    }
    if(payment > total_price ){
        $("#currentDue").val(parseFloat(0.00).toFixed(2));
    }else{
        $("#currentDue").val(parseFloat(total_price - payment).toFixed(2));
    }
    $("#totalDue").val(parseFloat((total_price+previousDue) - payment).toFixed(2));
}

function getCustomerCurrentBalace(){
    var customerId = $("#customerid").val();
    calculateCustomerDue();
    setTimeout(function() {
        //$('.partisals').fadeOut('fast');
        calcutateFinal();
    }, 100);
    $.ajax({
        type: "POST",
        url: baseUrl + "InventoryController/loadCusSupDetails",
        data: {
            supCusId:customerId,
            type:1
        },
        success: function (data) {
            $("#loadCusSup").html(data);
        }
    });
}
function calculatePartialPayment(){
    setTimeout(function() {
        calcutateFinal();
    }, 100);
}
function showDuePayment(paymentValue){
    var netAmount = parseFloat($("#netAmount").val());
    var allocateAmount=parseFloat(paymentValue);
    var dueAmount =netAmount - allocateAmount;
}

function showBankinfo(id){
    $("#payment").val('');
    calcutateFinal();
    calculateCustomerDue();
    $(".chaque_amount_class").hide(10);
    if(id == 3){
        $("#showBankInfo").show(10);
        $(".chaque_amount_class").show(10);
    }else{
        $("#showBankInfo").hide(10);

    }
    if(id == 4){
        $(".partisals").show(10);
    }else{
        $(".partisals").hide(10);
    }
    if(id == 2){
        $(".creditDate").show(10);
    }else{
        $(".creditDate").hide(10);
    }
}
function saveNewCustomer(){
    var customerName=$("#customerName").val();
    var customerId=$("#customerId").val();
    if(customerName == ''){
        alert("Customer Name Can't be empty!!");
        return false;
    }else if(customerId == ''){
        alert("Customer Id Can't be empty!!");
        return false;
    }else{
        var url = baseUrl + "SalesController/saveNewCustomer";
        $.ajax({
            type: 'POST',
            url: url,
            data:$("#publicForm2").serializeArray(),
            success: function (data)
            {
                $('#myModal').modal('toggle');
                $('#newCustomerHide').hide();
                $('#customerid').chosen();
                //$('#customerid option').remove();
                $('#customerid').append($(data));
                $("#customerid").trigger("chosen:updated");
                getCustomerCurrentBalace();
            }
        });
    }
}
function checkDuplicatePhone(phone){
    var url = baseUrl+ "SalesController/checkDuplicatePhone";
    $.ajax({
        type: 'POST',
        url: url,
        data:{
            'phone': phone
        },
        success: function (data)
        {
            if(data == 1){
                $("#subBtn2").attr('disabled',true);
                $("#errorMsg").show(10);
            }else{
                $("#subBtn2").attr('disabled',false);
                $("#errorMsg").hide(10);
            }
        }
    });
}



$(document).ready(function () {

    $('.rate').blur(function () {
        var rate = parseFloat($(this).val());
        if(isNaN(rate)){
            rate=0;
        }
        $(this).val(parseFloat(rate).toFixed(2));
    });


    $('.quantity').keyup(function () {
        priceCal();
    });

    $('.rate').keyup(function () {
        priceCal();
    });
});


function priceCal() {
    var quantity = parseFloat($('.quantity').val());
    if(isNaN(quantity)){
        quantity=0;
    }
    var rate = parseFloat($('.rate').val());
    if(isNaN(rate)){
        rate=0;
    }
    $('.price').val(parseFloat(rate * quantity).toFixed(2));
}

function calDiscount() {
    findDiscount();
    findVatAmount();
    calculatePartialPayment();
}
var findDiscount = function () {
    var totalPrice = parseFloat($(".total_price").text());
    if(isNaN(totalPrice)){
        totalPrice=0;
    }
    if(totalPrice == ''){
        $("#disCount").val('');
    }
    var disCount = parseFloat($("#disCount").val());
    if(isNaN(disCount)){
        disCount=0;
    }
    //var deductDiscount = (disCount / 100) * totalPrice;
    $("#grandTotal").val(parseFloat(Math.round(totalPrice - disCount)).toFixed(2));
    calcutateFinal();
};

var findVatAmount = function () {
    var loader = parseFloat($("#loader").val());
    if(isNaN(loader)){
        loader=0;
    }
    var transportation = parseFloat($("#transportation").val());
    if(isNaN(transportation)){
        transportation=0;
    }
    var vatValue = $("#vatAmount").val();
    if(isNaN(vatValue)){
        vatValue=0;
    }
    var grandTotal = parseFloat($("#grandTotal").val());
    if(isNaN(grandTotal)){
        grandTotal=0;
    }
    var vatForwardAmount = parseFloat((vatValue / 100) * grandTotal);
    if(isNaN(vatForwardAmount)){
        vatForwardAmount=0;
    }
    $(".totalVatAmount").html(parseFloat(Math.round(vatForwardAmount)).toFixed(2));
    $("#netAmount").val(parseFloat(Math.round(vatForwardAmount) + grandTotal + loader + transportation).toFixed(2));
};

var findTotalQty = function () {
    var total_quantity = 0;
    $.each($('.add_quantity'), function () {
        quantity = $(this).val();
        quantity = Number(quantity);
        total_quantity += quantity;
    });
    $('.total_quantity').html(parseFloat(total_quantity));
};

var findTotalReturnQty = function () {
    var total_return_quantity = 0;
    $.each($('.add_ReturnQuantity'), function () {
        quantity = $(this).val();
        quantity = Number(quantity);
        total_return_quantity += quantity;
    });
    $('.total_return_qty').html(parseFloat(total_return_quantity));
};

var findTotalRate = function () {
    var total_rate = 0;
    $.each($('.add_rate'), function () {
        rate = $(this).val();
        rate = Number(rate);
        total_rate += rate;
    });
    $('.total_rate').html(parseFloat(total_rate).toFixed(2));
};

var findTotalPrice = function () {
    var total_price = 0;
    $.each($('.add_price'), function () {
        price = $(this).val();
        price = Number(price);
        total_price += price;
    });
    $('.total_price').html(parseFloat(total_price).toFixed(2));
    $('.total_totalPrice').html(parseFloat(total_price).toFixed(2));
    $('#currentDue').val(parseFloat(total_price).toFixed(2));

};



var findTotalCal = function () {
    findTotalQty();
    findTotalReturnQty();
    findTotalRate();
    findTotalPrice();
    calDiscount();
    calculatePartialPayment();
};


function checkStockOverQty(givenStock){
    var orgiStock=parseFloat($("#stockQty").val());
    var givenStock= parseFloat(givenStock);
    if(isNaN(givenStock)){
        givenStock=0;
    }
    if(isNaN(orgiStock)){
        orgiStock=0;
    }
    //  alert(orgiStock);
    if(orgiStock < givenStock){
        $(".quantity").val('');
        $(".quantity").val(parseFloat(orgiStock));
        productItemValidation("Stock Quantity Not Available.");
    }

}
function checkStockOverQtyBundle(givenStock){
    var orgiStock=parseFloat($("#stockQtyBundle").val());
    var givenStock= parseFloat(givenStock);
    if(isNaN(givenStock)){
        givenStock=0;
    }
    if(isNaN(orgiStock)){
        orgiStock=0;
    }
    //  alert(orgiStock);
    if(orgiStock < givenStock){
        $(".bundle").val('');
        $(".bundle").val(parseFloat(orgiStock));
        productItemValidation("Bundle Stock Not Available.");
    }

}

$(document).on("keyup", ".add_quantity", function () {
    var id_arr = $(this).attr('id');
    var id = id_arr.split("_");
    var element_id = id[id.length - 1];
    var quantity = parseFloat($("#qty_" + element_id).val());
    if(isNaN(quantity)){
        quantity=0;
    }
    var rate= parseFloat($("#rate_" + element_id).val());
    if(isNaN(rate)){
        rate=0;
    }
    var totalAmount = quantity * rate;
    $("#tprice_"+ element_id).val(parseFloat(totalAmount).toFixed(2));
    var row_total = 0;
    $.each($('.add_price'), function () {
        quantity = $(this).val();
        quantity = Number(quantity);
        row_total += quantity;
    });
    $('.total_price').html(parseFloat(row_total).toFixed(2));
    calculateCustomerDue();
    findTotalCal();

});
$(document).on("keyup", ".add_rate", function () {
    var id_arr = $(this).attr('id');
    var id = id_arr.split("_");
    var element_id = id[id.length - 1];
    var quantity = parseFloat($("#qty_" + element_id).val());
    if(isNaN(quantity)){
        quantity=0;
    }
    var rate= parseFloat($("#rate_" + element_id).val());
    if(isNaN(rate)){
        rate=0;
    }
    var totalAmount = quantity * rate;
    $("#tprice_"+ element_id).val(parseFloat(totalAmount).toFixed(2));
    var row_total = 0;
    $.each($('.add_price'), function () {
        quantity = $(this).val();
        quantity = Number(quantity);
        row_total += quantity;
    });
    $('.total_price').html(parseFloat(row_total).toFixed(2));
    calculateCustomerDue();
    findTotalCal();

});


$(document).ready(function () {
    var j = 1;
    $("#add_item").click(function () {
        var productCatID = $('#categoryId').val();
        var productCatName = $('#categoryId').find('option:selected').attr('categoryName');
        var productID = $('#productID2').val();
        var productName = $('#productID2').find('option:selected').attr('productName');
        var quantity = $('.quantity').val();
        var bundle = $('.bundle').val();
        var bundleValue = $('#bundleValue').val();
        var rate = $('.rate').val();
        var price = $('.price').val();
        var rowCount = $('#show_item tr').length;
        if(productCatID  == ''){
            swal("Product Category can't be empty!", "Validation Error!", "error");
            return false;
        }else if(productID == ''){
            swal("Product Name can't be empty!", "Validation Error!", "error");
            return false;
        }else if(quantity == ''){
            swal("Quantity Can't be empty!", "Validation Error!", "error");
            return false;
        }else if(rate == ''){
            swal("Unit Price Can't be empty!", "Validation Error!", "error");
            return false;
        }else{
            if(rowCount == 2){
                $("#show_item tfoot").prepend('<tr><td colspan="3" align="right"> Total </td><td align="right"><span class="total_quantity">0.00</span></td><td align="right"><span class="total_rate">0.00</span></td><td align="right"><span class="total_totalPrice">0.00</span></td></tr>');
            }
            if(productCatID == 1){
                $("#show_item tfoot").prepend('<tr class="new_item' + j + '"><input type="hidden" name="category_id[]" value="'  + productCatID + '"><td style="padding-left:15px;">  ' + productCatName + '<input type="hidden"  name="product_id[]" value="' + productID + '"></td><td style="padding-left:15px;">' + productName + '</td></td><td style="padding-left:15px;"><input type="text" onkeyup="checkStockOverQtyBundle(this.value)"  class="form-control text-right decimal" name="bundle[]" value="' + bundle + '"></td><td align="right"><input type="text" id="qty_'+ j +'" class="form-control text-right add_quantity decimal" onkeyup="checkStockOverQty(this.value)" name="quantity[]" value="' + quantity + '"></td><td align="right"><input type="text" id="rate_'+ j +'" class="form-control add_rate text-right decimal" name="rate[]" value="' + rate + '"></td><td align="right"><input readonly type="text" class="add_price text-right form-control" id="tprice_'+ j +'" name="price[]" value="' + price + '"></td><td><a del_id="'+j+'" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');
            }else{
                $("#show_item tfoot").prepend('<tr class="new_item' + j + '"><input type="hidden" name="category_id[]" value="'  + productCatID + '"><td style="padding-left:15px;">  ' + productCatName + '<input type="hidden"  name="product_id[]" value="' + productID + '"></td><td style="padding-left:15px;">' + productName + '</td></td><td style="padding-left:15px;"><input type="text" class="form-control text-right decimal" onkeyup="checkStockOverQtyBundle(this.value)"  name="bundle[]" readonly value="' + bundle + '"></td><td align="right"><input type="text" id="qty_'+ j +'" class="form-control text-right add_quantity decimal" onkeyup="checkStockOverQty(this.value)" name="quantity[]" value="' + quantity + '"></td><td align="right"><input type="text" id="rate_'+ j +'" class="form-control add_rate text-right decimal" name="rate[]" value="' + rate + '"></td><td align="right"><input readonly type="text" class="add_price text-right form-control" id="tprice_'+ j +'" name="price[]" value="' + price + '"></td><td><a del_id="'+j+'" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');

            }
        }
        $("#subBtn").attr('disabled',false);
        $('.quantity').val('');
        $('.rate').val('');
        $('.price').val('');
        $('.bundle').val('');

        $(".quantity").attr("placeholder", "0");
        $('#categoryId').val('').trigger('chosen:updated');
        $('#productID2').val('').trigger('chosen:updated');
        $('#category_product').val('').trigger('chosen:updated');
        findTotalCal();
        setTimeout(function() {
            ///calculateCustomerDue();
            calcutateFinal();
        }, 100);
        j++;
    });
    $(document).on('click','.delete_item', function () {
        var id = $(this).attr("del_id");
        swal({
            title: "Are you sure ?",
            text: "You won't be able to revert this!",
            showCancelButton: true,
            confirmButtonColor: '#73AE28',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText: "No",
            closeOnConfirm: true,
            closeOnCancel: true,
            type: 'success'
        },
        function (isConfirm) {
            if (isConfirm) {
                $('.new_item' + id).remove();
                findTotalCal();
                setTimeout(function() {
                    calcutateFinal();
                }, 100);
            }else{
                return false;
            }
        });
    });
});


function getProductPrice(product_id) {
    var productCatID = $('#categoryId').val();
    if(productCatID == 1){
        $("#bundleValue").attr('readonly',false);
    }else{
        $("#bundleValue").attr("placeholder", " ");
        $("#bundleValue").val('');
        $("#bundleValue").attr('readonly',true);
    }
    $.ajax({
        type: "POST",
        url: baseUrl + "FinaneController/getProductPriceForSale",
        data: 'product_id=' + product_id,
        success: function (data) {
            $('.rate').val('');
        }
    });
    $.ajax({
        type: "POST",
        url: baseUrl+ "FinaneController/getProductStock",
        data: 'product_id=' + product_id,
        success: function (data) {
            var mainStock = parseFloat(data);
            if(isNaN(mainStock)){
                mainStock=0;
            }
            if(data !=''){
                $("#stockQty").val(data);
                $(".quantity").attr("disabled",false);
                if(mainStock <= 0){
                    $(".quantity").attr("disabled",true);
                    $(".quantity").attr("placeholder", "0 ");
                }else{
                    $(".quantity").attr("disabled",false);
                    $(".quantity").attr("placeholder", ""+mainStock);
                }
            }else{
                $("#stockQty").val('');
                $(".quantity").attr("disabled",true);
                $(".quantity").attr("placeholder", "0");
            }
        }
    });

    if(productCatID == 1){

        $.ajax({
            type: "POST",
            url: baseUrl+ "FinaneController/getProductStockBundle",
            data: 'product_id=' + product_id,
            success: function (data) {
                var mainStock = parseFloat(data);
                if(isNaN(mainStock)){
                    mainStock=0;
                }
                if(data !=''){
                    $("#stockQtyBundle").val(parseFloat(data).toFixed(2));
                    $(".bundle").attr("disabled",false);
                    if(mainStock <= 0){
                        $(".bundle").attr("disabled",true);
                        $(".bundle").attr("placeholder", "  ");
                    }else{
                        $(".bundle").attr("disabled",false);
                        $(".bundle").attr("placeholder", "" + parseFloat(mainStock).toFixed(2));
                    }
                }else{
                    $("#stockQtyBundle").val('');
                    $(".bundle").attr("disabled",true);
                    $(".bundle").attr("placeholder", " ");
                }
            }
        });

    }

}
var calculateCustomerDue = function () {
    var customerid=parseFloat($('#customerid').val());
    var netAmount=parseFloat($('#netAmount').val());
    var payment = parseFloat($("#payment").val());
    if(isNaN(payment)){
        payment=0;
    }
    if(isNaN(netAmount)){
        netAmount=0;
    }
    var url = baseUrl + "SalesController/getCustomerCurrentBalance";
    $.ajax({
        type: 'POST',
        url: url,
        data:{
            customerId: customerid
        },
        success: function (data)
        {
            data=parseFloat(data);
            if(isNaN(data)){
                data=0;
            }
            $('#previousDue').val(parseFloat(data).toFixed(2));
        }
    });
};



function getProductPrice2(product_id) {
    $("#stockQty2").val('');
    $(".quantity2").val('');
    var total_quantity2 = 0;
    $.each($('.add_quantity2'), function () {
        quantity = $(this).val();
        quantity = Number(quantity);
        total_quantity2 += quantity;
    });
    if(isNaN(total_quantity2)){
        total_quantity2=0;
    }

    $.ajax({
        type: "POST",
        url: baseUrl+ "FinaneController/getProductPriceForSale",
        data: 'product_id=' + product_id,
        success: function (data) {
            if (data != '0.00') {
                $('.rate2').val(data);
            } else {
                $('.rate2').val('');
            }

        }
    });
    $.ajax({
        type: "POST",
        url: baseUrl+ "FinaneController/getProductStock",
        data: 'product_id=' + product_id,
        success: function (data) {
            var mainStock = parseFloat(data) - parseFloat(total_quantity);
            if(data !=''){
                $("#stockQty2").val(data);
                $(".quantity2").attr("disabled",false);
                if(mainStock <= 0){
                    $(".quantity2").attr("disabled",true);
                    $(".quantity2").attr("placeholder", "0 ");
                }else{
                    $(".quantity2").attr("disabled",false);
                    $(".quantity2").attr("placeholder", "= "+mainStock);
                }
            }else{
                $("#stockQty2").val('');
                $(".quantity2").attr("disabled",true);
                $(".quantity2").attr("placeholder", " 0");
            }

        }
    });


}

function getProductList2(cat_id) {
    $.ajax({
        type: "POST",
        url: baseUrl+ "InventoryController/getProductList",
        data: 'cat_id=' + cat_id,
        success: function (data) {
            $('#productID2').chosen();
            $('#productID2 option').remove();
            $('#productID2').append($(data));
            $("#productID2").trigger("chosen:updated");
        }
    });




    if(cat_id == 1){
        $("#bundleValue").attr('readonly',false);
    }else{
        $("#bundleValue").attr("placeholder", " ");
        $("#bundleValue").val('');
        $("#bundleValue").attr('readonly',true);
    }





}



</script>

