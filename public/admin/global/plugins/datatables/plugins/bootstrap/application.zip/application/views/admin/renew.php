<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Renew Software</a>
                </li>
            </ul>
        </div>

        <div class="page-content">

            <div class="row">
                <div class="col-md-4 col-md-offset-4">

                    <div class="table-header">

                        Update Renew Date

                    </div>

                    <div>

                        <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <table  class="table table-striped table-bordered table-hover">

                            <thead>
                                <tr>
                                    <th>Today</th>
                                    <th><?php echo date('Y-m-d'); ?></th>
                                </tr>
                                <tr>
                                    <th>Renew Date (1+ Year)</th>
                                    <th><input readonly typ="text" name="renewDate" value="<?php echo date('Y-m-d', strtotime('+1 years')); ?>" class="form-control"/></th>
                                </tr>
                                <tr>
                                    <th colspan="2"><button class="btn btn-success btn-block" type="submit">Update</button></th>
                                </tr>
                            </thead>
                        </table>
                        </form>
                    </div>

                </div><!-- /.col -->
            </div><!-- /.col -->

        </div><!-- /.row -->

    </div><!-- /.page-content -->

</div>






