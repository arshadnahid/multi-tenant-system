<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-16 07:39:37 --> Config Class Initialized
INFO - 2021-05-16 07:39:37 --> Hooks Class Initialized
DEBUG - 2021-05-16 07:39:37 --> UTF-8 Support Enabled
INFO - 2021-05-16 07:39:37 --> Utf8 Class Initialized
INFO - 2021-05-16 07:39:37 --> URI Class Initialized
DEBUG - 2021-05-16 07:39:37 --> No URI present. Default controller set.
INFO - 2021-05-16 07:39:37 --> Router Class Initialized
INFO - 2021-05-16 07:39:37 --> Output Class Initialized
INFO - 2021-05-16 07:39:37 --> Security Class Initialized
DEBUG - 2021-05-16 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 07:39:37 --> Input Class Initialized
INFO - 2021-05-16 07:39:37 --> Language Class Initialized
INFO - 2021-05-16 07:39:37 --> Loader Class Initialized
INFO - 2021-05-16 07:39:37 --> Helper loaded: url_helper
INFO - 2021-05-16 07:39:37 --> Helper loaded: file_helper
INFO - 2021-05-16 07:39:37 --> Helper loaded: utility_helper
INFO - 2021-05-16 07:39:37 --> Helper loaded: unit_helper
INFO - 2021-05-16 07:39:37 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 07:39:37 --> Database Driver Class Initialized
INFO - 2021-05-16 07:39:37 --> Email Class Initialized
DEBUG - 2021-05-16 07:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 07:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 07:39:37 --> Helper loaded: form_helper
INFO - 2021-05-16 07:39:37 --> Form Validation Class Initialized
INFO - 2021-05-16 07:39:37 --> Controller Class Initialized
INFO - 2021-05-16 07:39:37 --> Model "Common_model" initialized
INFO - 2021-05-16 07:39:37 --> Model "Finane_Model" initialized
INFO - 2021-05-16 07:39:37 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 07:39:37 --> Model "Sales_Model" initialized
INFO - 2021-05-16 07:39:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 07:39:37 --> Final output sent to browser
DEBUG - 2021-05-16 07:39:37 --> Total execution time: 0.0481
INFO - 2021-05-16 10:09:16 --> Config Class Initialized
INFO - 2021-05-16 10:09:16 --> Hooks Class Initialized
DEBUG - 2021-05-16 10:09:16 --> UTF-8 Support Enabled
INFO - 2021-05-16 10:09:16 --> Utf8 Class Initialized
INFO - 2021-05-16 10:09:16 --> URI Class Initialized
INFO - 2021-05-16 10:09:16 --> Router Class Initialized
INFO - 2021-05-16 10:09:16 --> Output Class Initialized
INFO - 2021-05-16 10:09:16 --> Security Class Initialized
DEBUG - 2021-05-16 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 10:09:16 --> Input Class Initialized
INFO - 2021-05-16 10:09:16 --> Language Class Initialized
INFO - 2021-05-16 10:09:16 --> Loader Class Initialized
INFO - 2021-05-16 10:09:16 --> Helper loaded: url_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: file_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: utility_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: unit_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 10:09:16 --> Database Driver Class Initialized
INFO - 2021-05-16 10:09:16 --> Email Class Initialized
DEBUG - 2021-05-16 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 10:09:16 --> Helper loaded: form_helper
INFO - 2021-05-16 10:09:16 --> Form Validation Class Initialized
INFO - 2021-05-16 10:09:16 --> Controller Class Initialized
INFO - 2021-05-16 10:09:16 --> Model "Common_model" initialized
INFO - 2021-05-16 10:09:16 --> Model "Finane_Model" initialized
INFO - 2021-05-16 10:09:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 10:09:16 --> Model "Sales_Model" initialized
INFO - 2021-05-16 10:09:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 10:09:16 --> Final output sent to browser
DEBUG - 2021-05-16 10:09:16 --> Total execution time: 0.0499
INFO - 2021-05-16 10:09:16 --> Config Class Initialized
INFO - 2021-05-16 10:09:16 --> Hooks Class Initialized
DEBUG - 2021-05-16 10:09:16 --> UTF-8 Support Enabled
INFO - 2021-05-16 10:09:16 --> Utf8 Class Initialized
INFO - 2021-05-16 10:09:16 --> URI Class Initialized
INFO - 2021-05-16 10:09:16 --> Router Class Initialized
INFO - 2021-05-16 10:09:16 --> Output Class Initialized
INFO - 2021-05-16 10:09:16 --> Security Class Initialized
DEBUG - 2021-05-16 10:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 10:09:16 --> Input Class Initialized
INFO - 2021-05-16 10:09:16 --> Language Class Initialized
INFO - 2021-05-16 10:09:16 --> Loader Class Initialized
INFO - 2021-05-16 10:09:16 --> Helper loaded: url_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: file_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: utility_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: unit_helper
INFO - 2021-05-16 10:09:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 10:09:16 --> Database Driver Class Initialized
INFO - 2021-05-16 10:09:16 --> Email Class Initialized
DEBUG - 2021-05-16 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 10:09:16 --> Helper loaded: form_helper
INFO - 2021-05-16 10:09:16 --> Form Validation Class Initialized
INFO - 2021-05-16 10:09:16 --> Controller Class Initialized
INFO - 2021-05-16 10:09:16 --> Model "Common_model" initialized
INFO - 2021-05-16 10:09:16 --> Model "Finane_Model" initialized
INFO - 2021-05-16 10:09:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 10:09:16 --> Model "Sales_Model" initialized
INFO - 2021-05-16 10:09:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 10:09:16 --> Final output sent to browser
DEBUG - 2021-05-16 10:09:16 --> Total execution time: 0.0683
INFO - 2021-05-16 11:18:47 --> Config Class Initialized
INFO - 2021-05-16 11:18:47 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:18:47 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:18:47 --> Utf8 Class Initialized
INFO - 2021-05-16 11:18:47 --> URI Class Initialized
INFO - 2021-05-16 11:18:47 --> Router Class Initialized
INFO - 2021-05-16 11:18:47 --> Output Class Initialized
INFO - 2021-05-16 11:18:47 --> Security Class Initialized
DEBUG - 2021-05-16 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:18:47 --> Input Class Initialized
INFO - 2021-05-16 11:18:47 --> Language Class Initialized
ERROR - 2021-05-16 11:18:47 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-16 11:18:48 --> Config Class Initialized
INFO - 2021-05-16 11:18:48 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:18:48 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:18:48 --> Utf8 Class Initialized
INFO - 2021-05-16 11:18:48 --> URI Class Initialized
INFO - 2021-05-16 11:18:48 --> Router Class Initialized
INFO - 2021-05-16 11:18:48 --> Output Class Initialized
INFO - 2021-05-16 11:18:48 --> Security Class Initialized
DEBUG - 2021-05-16 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:18:48 --> Input Class Initialized
INFO - 2021-05-16 11:18:48 --> Language Class Initialized
ERROR - 2021-05-16 11:18:48 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-16 11:18:48 --> Config Class Initialized
INFO - 2021-05-16 11:18:48 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:18:48 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:18:48 --> Utf8 Class Initialized
INFO - 2021-05-16 11:18:48 --> URI Class Initialized
INFO - 2021-05-16 11:18:48 --> Router Class Initialized
INFO - 2021-05-16 11:18:48 --> Output Class Initialized
INFO - 2021-05-16 11:18:48 --> Security Class Initialized
DEBUG - 2021-05-16 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:18:48 --> Input Class Initialized
INFO - 2021-05-16 11:18:48 --> Language Class Initialized
ERROR - 2021-05-16 11:18:48 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-16 11:31:27 --> Config Class Initialized
INFO - 2021-05-16 11:31:27 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:31:27 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:31:27 --> Utf8 Class Initialized
INFO - 2021-05-16 11:31:27 --> URI Class Initialized
INFO - 2021-05-16 11:31:27 --> Router Class Initialized
INFO - 2021-05-16 11:31:27 --> Output Class Initialized
INFO - 2021-05-16 11:31:27 --> Security Class Initialized
DEBUG - 2021-05-16 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:31:27 --> Input Class Initialized
INFO - 2021-05-16 11:31:27 --> Language Class Initialized
ERROR - 2021-05-16 11:31:27 --> 404 Page Not Found: Theme/assets
INFO - 2021-05-16 11:46:46 --> Config Class Initialized
INFO - 2021-05-16 11:46:46 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:46:46 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:46:46 --> Utf8 Class Initialized
INFO - 2021-05-16 11:46:46 --> URI Class Initialized
INFO - 2021-05-16 11:46:46 --> Router Class Initialized
INFO - 2021-05-16 11:46:46 --> Output Class Initialized
INFO - 2021-05-16 11:46:46 --> Security Class Initialized
DEBUG - 2021-05-16 11:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:46:46 --> Input Class Initialized
INFO - 2021-05-16 11:46:46 --> Language Class Initialized
INFO - 2021-05-16 11:46:46 --> Loader Class Initialized
INFO - 2021-05-16 11:46:46 --> Helper loaded: url_helper
INFO - 2021-05-16 11:46:46 --> Helper loaded: file_helper
INFO - 2021-05-16 11:46:46 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:46:46 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:46:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:46:46 --> Database Driver Class Initialized
INFO - 2021-05-16 11:46:46 --> Email Class Initialized
DEBUG - 2021-05-16 11:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:46:46 --> Helper loaded: form_helper
INFO - 2021-05-16 11:46:46 --> Form Validation Class Initialized
INFO - 2021-05-16 11:46:46 --> Controller Class Initialized
INFO - 2021-05-16 11:46:46 --> Model "Common_model" initialized
INFO - 2021-05-16 11:46:46 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:46:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:46:46 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:46:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 11:46:46 --> Final output sent to browser
DEBUG - 2021-05-16 11:46:46 --> Total execution time: 0.0722
INFO - 2021-05-16 11:46:55 --> Config Class Initialized
INFO - 2021-05-16 11:46:55 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:46:55 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:46:55 --> Utf8 Class Initialized
INFO - 2021-05-16 11:46:55 --> URI Class Initialized
INFO - 2021-05-16 11:46:55 --> Router Class Initialized
INFO - 2021-05-16 11:46:55 --> Output Class Initialized
INFO - 2021-05-16 11:46:55 --> Security Class Initialized
DEBUG - 2021-05-16 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:46:55 --> Input Class Initialized
INFO - 2021-05-16 11:46:55 --> Language Class Initialized
INFO - 2021-05-16 11:46:55 --> Loader Class Initialized
INFO - 2021-05-16 11:46:55 --> Helper loaded: url_helper
INFO - 2021-05-16 11:46:55 --> Helper loaded: file_helper
INFO - 2021-05-16 11:46:55 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:46:55 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:46:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:46:55 --> Database Driver Class Initialized
INFO - 2021-05-16 11:46:55 --> Email Class Initialized
DEBUG - 2021-05-16 11:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:46:55 --> Helper loaded: form_helper
INFO - 2021-05-16 11:46:55 --> Form Validation Class Initialized
INFO - 2021-05-16 11:46:55 --> Controller Class Initialized
INFO - 2021-05-16 11:46:55 --> Model "Common_model" initialized
INFO - 2021-05-16 11:46:55 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:46:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:46:55 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:46:56 --> Config Class Initialized
INFO - 2021-05-16 11:46:56 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:46:56 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:46:56 --> Utf8 Class Initialized
INFO - 2021-05-16 11:46:56 --> URI Class Initialized
INFO - 2021-05-16 11:46:56 --> Router Class Initialized
INFO - 2021-05-16 11:46:56 --> Output Class Initialized
INFO - 2021-05-16 11:46:56 --> Security Class Initialized
DEBUG - 2021-05-16 11:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:46:56 --> Input Class Initialized
INFO - 2021-05-16 11:46:56 --> Language Class Initialized
INFO - 2021-05-16 11:46:56 --> Loader Class Initialized
INFO - 2021-05-16 11:46:56 --> Helper loaded: url_helper
INFO - 2021-05-16 11:46:56 --> Helper loaded: file_helper
INFO - 2021-05-16 11:46:56 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:46:56 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:46:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:46:56 --> Database Driver Class Initialized
INFO - 2021-05-16 11:46:56 --> Email Class Initialized
DEBUG - 2021-05-16 11:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:46:56 --> Helper loaded: form_helper
INFO - 2021-05-16 11:46:56 --> Form Validation Class Initialized
INFO - 2021-05-16 11:46:56 --> Controller Class Initialized
INFO - 2021-05-16 11:46:56 --> Model "Common_model" initialized
INFO - 2021-05-16 11:46:56 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:46:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:46:56 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:46:56 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:46:56 --> Database Driver Class Initialized
INFO - 2021-05-16 11:46:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-05-16 11:46:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-05-16 11:46:56 --> Final output sent to browser
DEBUG - 2021-05-16 11:46:56 --> Total execution time: 0.7317
INFO - 2021-05-16 11:47:06 --> Config Class Initialized
INFO - 2021-05-16 11:47:06 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:47:06 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:47:06 --> Utf8 Class Initialized
INFO - 2021-05-16 11:47:06 --> URI Class Initialized
INFO - 2021-05-16 11:47:06 --> Router Class Initialized
INFO - 2021-05-16 11:47:06 --> Output Class Initialized
INFO - 2021-05-16 11:47:06 --> Security Class Initialized
DEBUG - 2021-05-16 11:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:47:06 --> Input Class Initialized
INFO - 2021-05-16 11:47:06 --> Language Class Initialized
ERROR - 2021-05-16 11:47:06 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-16 11:47:06 --> Config Class Initialized
INFO - 2021-05-16 11:47:06 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:47:06 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:47:06 --> Utf8 Class Initialized
INFO - 2021-05-16 11:47:06 --> URI Class Initialized
INFO - 2021-05-16 11:47:06 --> Router Class Initialized
INFO - 2021-05-16 11:47:06 --> Output Class Initialized
INFO - 2021-05-16 11:47:06 --> Security Class Initialized
DEBUG - 2021-05-16 11:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:47:06 --> Input Class Initialized
INFO - 2021-05-16 11:47:06 --> Language Class Initialized
INFO - 2021-05-16 11:47:06 --> Loader Class Initialized
INFO - 2021-05-16 11:47:06 --> Helper loaded: url_helper
INFO - 2021-05-16 11:47:06 --> Helper loaded: file_helper
INFO - 2021-05-16 11:47:06 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:47:06 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:47:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:47:06 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:06 --> Email Class Initialized
DEBUG - 2021-05-16 11:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:47:06 --> Helper loaded: form_helper
INFO - 2021-05-16 11:47:06 --> Form Validation Class Initialized
INFO - 2021-05-16 11:47:06 --> Controller Class Initialized
INFO - 2021-05-16 11:47:06 --> Model "Common_model" initialized
INFO - 2021-05-16 11:47:06 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:47:06 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:47:06 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:47:06 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:47:06 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-16 11:47:06 --> Final output sent to browser
DEBUG - 2021-05-16 11:47:06 --> Total execution time: 0.0467
INFO - 2021-05-16 11:47:07 --> Config Class Initialized
INFO - 2021-05-16 11:47:07 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:47:07 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:47:07 --> Utf8 Class Initialized
INFO - 2021-05-16 11:47:07 --> URI Class Initialized
INFO - 2021-05-16 11:47:07 --> Router Class Initialized
INFO - 2021-05-16 11:47:07 --> Output Class Initialized
INFO - 2021-05-16 11:47:07 --> Security Class Initialized
DEBUG - 2021-05-16 11:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:47:07 --> Input Class Initialized
INFO - 2021-05-16 11:47:07 --> Language Class Initialized
INFO - 2021-05-16 11:47:07 --> Loader Class Initialized
INFO - 2021-05-16 11:47:07 --> Helper loaded: url_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: file_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:47:07 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:07 --> Email Class Initialized
DEBUG - 2021-05-16 11:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:47:07 --> Helper loaded: form_helper
INFO - 2021-05-16 11:47:07 --> Form Validation Class Initialized
INFO - 2021-05-16 11:47:07 --> Controller Class Initialized
INFO - 2021-05-16 11:47:07 --> Model "Common_model" initialized
INFO - 2021-05-16 11:47:07 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:47:07 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:47:07 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:47:07 --> Config Class Initialized
INFO - 2021-05-16 11:47:07 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:47:07 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:47:07 --> Utf8 Class Initialized
INFO - 2021-05-16 11:47:07 --> URI Class Initialized
INFO - 2021-05-16 11:47:07 --> Router Class Initialized
INFO - 2021-05-16 11:47:07 --> Output Class Initialized
INFO - 2021-05-16 11:47:07 --> Security Class Initialized
DEBUG - 2021-05-16 11:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:47:07 --> Input Class Initialized
INFO - 2021-05-16 11:47:07 --> Language Class Initialized
INFO - 2021-05-16 11:47:07 --> Loader Class Initialized
INFO - 2021-05-16 11:47:07 --> Helper loaded: url_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: file_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:47:07 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:07 --> Email Class Initialized
DEBUG - 2021-05-16 11:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:47:07 --> Helper loaded: form_helper
INFO - 2021-05-16 11:47:07 --> Form Validation Class Initialized
INFO - 2021-05-16 11:47:07 --> Controller Class Initialized
INFO - 2021-05-16 11:47:07 --> Model "Common_model" initialized
INFO - 2021-05-16 11:47:07 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:47:07 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:47:07 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:47:07 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:47:07 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:07 --> Config Class Initialized
INFO - 2021-05-16 11:47:07 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:47:07 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:47:07 --> Utf8 Class Initialized
INFO - 2021-05-16 11:47:07 --> URI Class Initialized
INFO - 2021-05-16 11:47:07 --> Router Class Initialized
INFO - 2021-05-16 11:47:07 --> Output Class Initialized
INFO - 2021-05-16 11:47:07 --> Security Class Initialized
DEBUG - 2021-05-16 11:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:47:07 --> Input Class Initialized
INFO - 2021-05-16 11:47:07 --> Language Class Initialized
INFO - 2021-05-16 11:47:07 --> Loader Class Initialized
INFO - 2021-05-16 11:47:07 --> Helper loaded: url_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: file_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:47:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:47:07 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:07 --> Email Class Initialized
DEBUG - 2021-05-16 11:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:47:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-16 11:47:08 --> Final output sent to browser
DEBUG - 2021-05-16 11:47:08 --> Total execution time: 0.7880
INFO - 2021-05-16 11:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:47:08 --> Helper loaded: form_helper
INFO - 2021-05-16 11:47:08 --> Form Validation Class Initialized
INFO - 2021-05-16 11:47:08 --> Controller Class Initialized
INFO - 2021-05-16 11:47:08 --> Model "Common_model" initialized
INFO - 2021-05-16 11:47:08 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:47:08 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:47:08 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:47:08 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:47:08 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:08 --> Config Class Initialized
INFO - 2021-05-16 11:47:08 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:47:08 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:47:08 --> Utf8 Class Initialized
INFO - 2021-05-16 11:47:08 --> URI Class Initialized
INFO - 2021-05-16 11:47:08 --> Router Class Initialized
INFO - 2021-05-16 11:47:08 --> Output Class Initialized
INFO - 2021-05-16 11:47:08 --> Security Class Initialized
DEBUG - 2021-05-16 11:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:47:08 --> Input Class Initialized
INFO - 2021-05-16 11:47:08 --> Language Class Initialized
INFO - 2021-05-16 11:47:08 --> Loader Class Initialized
INFO - 2021-05-16 11:47:09 --> Helper loaded: url_helper
INFO - 2021-05-16 11:47:09 --> Helper loaded: file_helper
INFO - 2021-05-16 11:47:09 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:47:09 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:47:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:47:09 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:09 --> Email Class Initialized
DEBUG - 2021-05-16 11:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-05-16 11:47:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-16 11:47:09 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-16 11:47:09 --> Final output sent to browser
DEBUG - 2021-05-16 11:47:09 --> Total execution time: 1.1769
INFO - 2021-05-16 11:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:47:09 --> Helper loaded: form_helper
INFO - 2021-05-16 11:47:09 --> Form Validation Class Initialized
INFO - 2021-05-16 11:47:09 --> Controller Class Initialized
INFO - 2021-05-16 11:47:09 --> Model "Common_model" initialized
INFO - 2021-05-16 11:47:09 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:47:09 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:47:09 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:47:09 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:47:09 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:09 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-16 11:47:09 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-16 11:47:09 --> Final output sent to browser
DEBUG - 2021-05-16 11:47:09 --> Total execution time: 0.7884
INFO - 2021-05-16 11:47:59 --> Config Class Initialized
INFO - 2021-05-16 11:47:59 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:47:59 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:47:59 --> Utf8 Class Initialized
INFO - 2021-05-16 11:47:59 --> URI Class Initialized
INFO - 2021-05-16 11:47:59 --> Router Class Initialized
INFO - 2021-05-16 11:47:59 --> Output Class Initialized
INFO - 2021-05-16 11:47:59 --> Security Class Initialized
DEBUG - 2021-05-16 11:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:47:59 --> Input Class Initialized
INFO - 2021-05-16 11:47:59 --> Language Class Initialized
INFO - 2021-05-16 11:47:59 --> Loader Class Initialized
INFO - 2021-05-16 11:47:59 --> Helper loaded: url_helper
INFO - 2021-05-16 11:47:59 --> Helper loaded: file_helper
INFO - 2021-05-16 11:47:59 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:47:59 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:47:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:47:59 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:59 --> Email Class Initialized
DEBUG - 2021-05-16 11:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:47:59 --> Helper loaded: form_helper
INFO - 2021-05-16 11:47:59 --> Form Validation Class Initialized
INFO - 2021-05-16 11:47:59 --> Controller Class Initialized
INFO - 2021-05-16 11:47:59 --> Model "Common_model" initialized
INFO - 2021-05-16 11:47:59 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:47:59 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:47:59 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:47:59 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:47:59 --> Database Driver Class Initialized
INFO - 2021-05-16 11:47:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-05-16 11:47:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-05-16 11:47:59 --> Final output sent to browser
DEBUG - 2021-05-16 11:47:59 --> Total execution time: 0.0526
INFO - 2021-05-16 11:48:00 --> Config Class Initialized
INFO - 2021-05-16 11:48:00 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:48:00 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:48:00 --> Utf8 Class Initialized
INFO - 2021-05-16 11:48:00 --> URI Class Initialized
INFO - 2021-05-16 11:48:00 --> Router Class Initialized
INFO - 2021-05-16 11:48:00 --> Output Class Initialized
INFO - 2021-05-16 11:48:00 --> Security Class Initialized
DEBUG - 2021-05-16 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:48:00 --> Input Class Initialized
INFO - 2021-05-16 11:48:00 --> Language Class Initialized
ERROR - 2021-05-16 11:48:00 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-16 11:48:00 --> Config Class Initialized
INFO - 2021-05-16 11:48:00 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:48:00 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:48:00 --> Utf8 Class Initialized
INFO - 2021-05-16 11:48:00 --> URI Class Initialized
INFO - 2021-05-16 11:48:00 --> Router Class Initialized
INFO - 2021-05-16 11:48:00 --> Output Class Initialized
INFO - 2021-05-16 11:48:00 --> Security Class Initialized
DEBUG - 2021-05-16 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:48:00 --> Input Class Initialized
INFO - 2021-05-16 11:48:00 --> Language Class Initialized
INFO - 2021-05-16 11:48:00 --> Loader Class Initialized
INFO - 2021-05-16 11:48:00 --> Helper loaded: url_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: file_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:48:00 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:00 --> Email Class Initialized
DEBUG - 2021-05-16 11:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:48:00 --> Helper loaded: form_helper
INFO - 2021-05-16 11:48:00 --> Form Validation Class Initialized
INFO - 2021-05-16 11:48:00 --> Controller Class Initialized
INFO - 2021-05-16 11:48:00 --> Model "Common_model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:48:00 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-16 11:48:00 --> Final output sent to browser
DEBUG - 2021-05-16 11:48:00 --> Total execution time: 0.0731
INFO - 2021-05-16 11:48:00 --> Config Class Initialized
INFO - 2021-05-16 11:48:00 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:48:00 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:48:00 --> Utf8 Class Initialized
INFO - 2021-05-16 11:48:00 --> URI Class Initialized
INFO - 2021-05-16 11:48:00 --> Router Class Initialized
INFO - 2021-05-16 11:48:00 --> Output Class Initialized
INFO - 2021-05-16 11:48:00 --> Security Class Initialized
DEBUG - 2021-05-16 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:48:00 --> Input Class Initialized
INFO - 2021-05-16 11:48:00 --> Language Class Initialized
INFO - 2021-05-16 11:48:00 --> Loader Class Initialized
INFO - 2021-05-16 11:48:00 --> Helper loaded: url_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: file_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:48:00 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:00 --> Email Class Initialized
DEBUG - 2021-05-16 11:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:48:00 --> Helper loaded: form_helper
INFO - 2021-05-16 11:48:00 --> Form Validation Class Initialized
INFO - 2021-05-16 11:48:00 --> Controller Class Initialized
INFO - 2021-05-16 11:48:00 --> Model "Common_model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:48:00 --> Database Driver Class Initialized
ERROR - 2021-05-16 11:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-16 11:48:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-16 11:48:00 --> Final output sent to browser
DEBUG - 2021-05-16 11:48:00 --> Total execution time: 0.0792
INFO - 2021-05-16 11:48:00 --> Config Class Initialized
INFO - 2021-05-16 11:48:00 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:48:00 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:48:00 --> Utf8 Class Initialized
INFO - 2021-05-16 11:48:00 --> URI Class Initialized
INFO - 2021-05-16 11:48:00 --> Router Class Initialized
INFO - 2021-05-16 11:48:00 --> Output Class Initialized
INFO - 2021-05-16 11:48:00 --> Security Class Initialized
DEBUG - 2021-05-16 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:48:00 --> Input Class Initialized
INFO - 2021-05-16 11:48:00 --> Language Class Initialized
INFO - 2021-05-16 11:48:00 --> Loader Class Initialized
INFO - 2021-05-16 11:48:00 --> Helper loaded: url_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: file_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:48:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:48:00 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:00 --> Email Class Initialized
DEBUG - 2021-05-16 11:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:48:00 --> Helper loaded: form_helper
INFO - 2021-05-16 11:48:00 --> Form Validation Class Initialized
INFO - 2021-05-16 11:48:00 --> Controller Class Initialized
INFO - 2021-05-16 11:48:00 --> Model "Common_model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:48:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:48:00 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-16 11:48:00 --> Final output sent to browser
DEBUG - 2021-05-16 11:48:00 --> Total execution time: 0.0657
INFO - 2021-05-16 11:48:01 --> Config Class Initialized
INFO - 2021-05-16 11:48:01 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:48:01 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:48:01 --> Utf8 Class Initialized
INFO - 2021-05-16 11:48:01 --> URI Class Initialized
INFO - 2021-05-16 11:48:01 --> Router Class Initialized
INFO - 2021-05-16 11:48:01 --> Output Class Initialized
INFO - 2021-05-16 11:48:01 --> Security Class Initialized
DEBUG - 2021-05-16 11:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:48:01 --> Input Class Initialized
INFO - 2021-05-16 11:48:01 --> Language Class Initialized
INFO - 2021-05-16 11:48:01 --> Loader Class Initialized
INFO - 2021-05-16 11:48:01 --> Helper loaded: url_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: file_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:48:01 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:01 --> Email Class Initialized
DEBUG - 2021-05-16 11:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:48:01 --> Helper loaded: form_helper
INFO - 2021-05-16 11:48:01 --> Form Validation Class Initialized
INFO - 2021-05-16 11:48:01 --> Controller Class Initialized
INFO - 2021-05-16 11:48:01 --> Model "Common_model" initialized
INFO - 2021-05-16 11:48:01 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:48:01 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:48:01 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:48:01 --> Config Class Initialized
INFO - 2021-05-16 11:48:01 --> Hooks Class Initialized
DEBUG - 2021-05-16 11:48:01 --> UTF-8 Support Enabled
INFO - 2021-05-16 11:48:01 --> Utf8 Class Initialized
INFO - 2021-05-16 11:48:01 --> URI Class Initialized
INFO - 2021-05-16 11:48:01 --> Router Class Initialized
INFO - 2021-05-16 11:48:01 --> Output Class Initialized
INFO - 2021-05-16 11:48:01 --> Security Class Initialized
DEBUG - 2021-05-16 11:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 11:48:01 --> Input Class Initialized
INFO - 2021-05-16 11:48:01 --> Language Class Initialized
INFO - 2021-05-16 11:48:01 --> Loader Class Initialized
INFO - 2021-05-16 11:48:01 --> Helper loaded: url_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: file_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: utility_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: unit_helper
INFO - 2021-05-16 11:48:01 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 11:48:01 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:01 --> Email Class Initialized
DEBUG - 2021-05-16 11:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 11:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 11:48:01 --> Helper loaded: form_helper
INFO - 2021-05-16 11:48:01 --> Form Validation Class Initialized
INFO - 2021-05-16 11:48:01 --> Controller Class Initialized
INFO - 2021-05-16 11:48:01 --> Model "Common_model" initialized
INFO - 2021-05-16 11:48:01 --> Model "Finane_Model" initialized
INFO - 2021-05-16 11:48:01 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 11:48:01 --> Model "Sales_Model" initialized
INFO - 2021-05-16 11:48:01 --> Model "Dashboard_Model" initialized
INFO - 2021-05-16 11:48:01 --> Database Driver Class Initialized
INFO - 2021-05-16 11:48:01 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-16 11:48:01 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-16 11:48:01 --> Final output sent to browser
DEBUG - 2021-05-16 11:48:01 --> Total execution time: 0.1690
INFO - 2021-05-16 19:15:50 --> Config Class Initialized
INFO - 2021-05-16 19:15:50 --> Hooks Class Initialized
DEBUG - 2021-05-16 19:15:50 --> UTF-8 Support Enabled
INFO - 2021-05-16 19:15:50 --> Utf8 Class Initialized
INFO - 2021-05-16 19:15:50 --> URI Class Initialized
DEBUG - 2021-05-16 19:15:50 --> No URI present. Default controller set.
INFO - 2021-05-16 19:15:50 --> Router Class Initialized
INFO - 2021-05-16 19:15:50 --> Output Class Initialized
INFO - 2021-05-16 19:15:50 --> Security Class Initialized
DEBUG - 2021-05-16 19:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 19:15:50 --> Input Class Initialized
INFO - 2021-05-16 19:15:50 --> Language Class Initialized
INFO - 2021-05-16 19:15:50 --> Loader Class Initialized
INFO - 2021-05-16 19:15:50 --> Helper loaded: url_helper
INFO - 2021-05-16 19:15:50 --> Helper loaded: file_helper
INFO - 2021-05-16 19:15:50 --> Helper loaded: utility_helper
INFO - 2021-05-16 19:15:50 --> Helper loaded: unit_helper
INFO - 2021-05-16 19:15:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 19:15:50 --> Database Driver Class Initialized
INFO - 2021-05-16 19:15:50 --> Email Class Initialized
DEBUG - 2021-05-16 19:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 19:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 19:15:50 --> Helper loaded: form_helper
INFO - 2021-05-16 19:15:50 --> Form Validation Class Initialized
INFO - 2021-05-16 19:15:50 --> Controller Class Initialized
INFO - 2021-05-16 19:15:50 --> Model "Common_model" initialized
INFO - 2021-05-16 19:15:50 --> Model "Finane_Model" initialized
INFO - 2021-05-16 19:15:50 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 19:15:50 --> Model "Sales_Model" initialized
INFO - 2021-05-16 19:15:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 19:15:50 --> Final output sent to browser
DEBUG - 2021-05-16 19:15:50 --> Total execution time: 0.1073
INFO - 2021-05-16 22:41:03 --> Config Class Initialized
INFO - 2021-05-16 22:41:03 --> Hooks Class Initialized
DEBUG - 2021-05-16 22:41:03 --> UTF-8 Support Enabled
INFO - 2021-05-16 22:41:03 --> Utf8 Class Initialized
INFO - 2021-05-16 22:41:03 --> URI Class Initialized
DEBUG - 2021-05-16 22:41:03 --> No URI present. Default controller set.
INFO - 2021-05-16 22:41:03 --> Router Class Initialized
INFO - 2021-05-16 22:41:03 --> Output Class Initialized
INFO - 2021-05-16 22:41:03 --> Security Class Initialized
DEBUG - 2021-05-16 22:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 22:41:03 --> Input Class Initialized
INFO - 2021-05-16 22:41:03 --> Language Class Initialized
INFO - 2021-05-16 22:41:03 --> Loader Class Initialized
INFO - 2021-05-16 22:41:03 --> Helper loaded: url_helper
INFO - 2021-05-16 22:41:03 --> Helper loaded: file_helper
INFO - 2021-05-16 22:41:03 --> Helper loaded: utility_helper
INFO - 2021-05-16 22:41:03 --> Helper loaded: unit_helper
INFO - 2021-05-16 22:41:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 22:41:03 --> Database Driver Class Initialized
INFO - 2021-05-16 22:41:03 --> Email Class Initialized
DEBUG - 2021-05-16 22:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 22:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 22:41:03 --> Helper loaded: form_helper
INFO - 2021-05-16 22:41:03 --> Form Validation Class Initialized
INFO - 2021-05-16 22:41:03 --> Controller Class Initialized
INFO - 2021-05-16 22:41:03 --> Model "Common_model" initialized
INFO - 2021-05-16 22:41:03 --> Model "Finane_Model" initialized
INFO - 2021-05-16 22:41:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 22:41:03 --> Model "Sales_Model" initialized
INFO - 2021-05-16 22:41:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 22:41:03 --> Final output sent to browser
DEBUG - 2021-05-16 22:41:03 --> Total execution time: 0.0686
INFO - 2021-05-16 22:41:54 --> Config Class Initialized
INFO - 2021-05-16 22:41:54 --> Hooks Class Initialized
DEBUG - 2021-05-16 22:41:54 --> UTF-8 Support Enabled
INFO - 2021-05-16 22:41:54 --> Utf8 Class Initialized
INFO - 2021-05-16 22:41:54 --> URI Class Initialized
DEBUG - 2021-05-16 22:41:54 --> No URI present. Default controller set.
INFO - 2021-05-16 22:41:54 --> Router Class Initialized
INFO - 2021-05-16 22:41:54 --> Output Class Initialized
INFO - 2021-05-16 22:41:54 --> Security Class Initialized
DEBUG - 2021-05-16 22:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 22:41:54 --> Input Class Initialized
INFO - 2021-05-16 22:41:54 --> Language Class Initialized
INFO - 2021-05-16 22:41:54 --> Loader Class Initialized
INFO - 2021-05-16 22:41:54 --> Helper loaded: url_helper
INFO - 2021-05-16 22:41:54 --> Helper loaded: file_helper
INFO - 2021-05-16 22:41:54 --> Helper loaded: utility_helper
INFO - 2021-05-16 22:41:54 --> Helper loaded: unit_helper
INFO - 2021-05-16 22:41:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 22:41:54 --> Database Driver Class Initialized
INFO - 2021-05-16 22:41:54 --> Email Class Initialized
DEBUG - 2021-05-16 22:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 22:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 22:41:54 --> Helper loaded: form_helper
INFO - 2021-05-16 22:41:54 --> Form Validation Class Initialized
INFO - 2021-05-16 22:41:54 --> Controller Class Initialized
INFO - 2021-05-16 22:41:54 --> Model "Common_model" initialized
INFO - 2021-05-16 22:41:54 --> Model "Finane_Model" initialized
INFO - 2021-05-16 22:41:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 22:41:54 --> Model "Sales_Model" initialized
INFO - 2021-05-16 22:41:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 22:41:54 --> Final output sent to browser
DEBUG - 2021-05-16 22:41:54 --> Total execution time: 0.0616
INFO - 2021-05-16 22:42:04 --> Config Class Initialized
INFO - 2021-05-16 22:42:04 --> Hooks Class Initialized
DEBUG - 2021-05-16 22:42:04 --> UTF-8 Support Enabled
INFO - 2021-05-16 22:42:04 --> Utf8 Class Initialized
INFO - 2021-05-16 22:42:04 --> URI Class Initialized
INFO - 2021-05-16 22:42:04 --> Router Class Initialized
INFO - 2021-05-16 22:42:04 --> Output Class Initialized
INFO - 2021-05-16 22:42:04 --> Security Class Initialized
DEBUG - 2021-05-16 22:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 22:42:04 --> Input Class Initialized
INFO - 2021-05-16 22:42:04 --> Language Class Initialized
INFO - 2021-05-16 22:42:04 --> Loader Class Initialized
INFO - 2021-05-16 22:42:04 --> Helper loaded: url_helper
INFO - 2021-05-16 22:42:04 --> Helper loaded: file_helper
INFO - 2021-05-16 22:42:04 --> Helper loaded: utility_helper
INFO - 2021-05-16 22:42:04 --> Helper loaded: unit_helper
INFO - 2021-05-16 22:42:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 22:42:04 --> Database Driver Class Initialized
INFO - 2021-05-16 22:42:04 --> Email Class Initialized
DEBUG - 2021-05-16 22:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 22:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 22:42:04 --> Helper loaded: form_helper
INFO - 2021-05-16 22:42:04 --> Form Validation Class Initialized
INFO - 2021-05-16 22:42:04 --> Controller Class Initialized
INFO - 2021-05-16 22:42:04 --> Model "Common_model" initialized
INFO - 2021-05-16 22:42:04 --> Model "Finane_Model" initialized
INFO - 2021-05-16 22:42:04 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 22:42:04 --> Model "Sales_Model" initialized
INFO - 2021-05-16 22:42:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 22:42:04 --> Final output sent to browser
DEBUG - 2021-05-16 22:42:04 --> Total execution time: 0.0677
INFO - 2021-05-16 22:42:15 --> Config Class Initialized
INFO - 2021-05-16 22:42:15 --> Hooks Class Initialized
DEBUG - 2021-05-16 22:42:15 --> UTF-8 Support Enabled
INFO - 2021-05-16 22:42:15 --> Utf8 Class Initialized
INFO - 2021-05-16 22:42:15 --> URI Class Initialized
INFO - 2021-05-16 22:42:15 --> Router Class Initialized
INFO - 2021-05-16 22:42:15 --> Output Class Initialized
INFO - 2021-05-16 22:42:15 --> Security Class Initialized
DEBUG - 2021-05-16 22:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 22:42:15 --> Input Class Initialized
INFO - 2021-05-16 22:42:15 --> Language Class Initialized
INFO - 2021-05-16 22:42:15 --> Loader Class Initialized
INFO - 2021-05-16 22:42:15 --> Helper loaded: url_helper
INFO - 2021-05-16 22:42:15 --> Helper loaded: file_helper
INFO - 2021-05-16 22:42:15 --> Helper loaded: utility_helper
INFO - 2021-05-16 22:42:15 --> Helper loaded: unit_helper
INFO - 2021-05-16 22:42:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-16 22:42:15 --> Database Driver Class Initialized
INFO - 2021-05-16 22:42:15 --> Email Class Initialized
DEBUG - 2021-05-16 22:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 22:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 22:42:15 --> Helper loaded: form_helper
INFO - 2021-05-16 22:42:15 --> Form Validation Class Initialized
INFO - 2021-05-16 22:42:15 --> Controller Class Initialized
INFO - 2021-05-16 22:42:15 --> Model "Common_model" initialized
INFO - 2021-05-16 22:42:15 --> Model "Finane_Model" initialized
INFO - 2021-05-16 22:42:15 --> Model "Inventory_Model" initialized
INFO - 2021-05-16 22:42:15 --> Model "Sales_Model" initialized
INFO - 2021-05-16 22:42:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-16 22:42:15 --> Final output sent to browser
DEBUG - 2021-05-16 22:42:15 --> Total execution time: 0.0547
