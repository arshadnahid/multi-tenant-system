
<div style='width:90%;height:100%;margin:0 auto;font-size:16px;'>
    <h1>Advance Equipment Limited (ERP)</h1>    
    <p>We received a request to change your password</p>
    <p>Use the link below to set up a new password for your account. </p>
    <p><a  href="<?php echo site_url($this->project . '/AuthController/resetPasswordUpdate/'.$userId.'/'.$activationCode);?>">Change Password</a></p>
    <p>If you did not make this request, you do not need to do anything.</p>
    <p>Thanks for your time,</p>
     <br /><br />
    The ERP Team<br />    
</div>




