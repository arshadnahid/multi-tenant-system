<?php

echo $mainContent;

?>