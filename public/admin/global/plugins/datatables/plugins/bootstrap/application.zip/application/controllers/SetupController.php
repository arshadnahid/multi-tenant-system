<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class SetupController extends CI_Controller {

    private $timestamp;
    public $admin_id;
    private $dist_id;
    public $project;

    public function __construct() {
        parent::__construct();

        $this->output->set_header("HTTP/1.0 200 OK");
        $this->output->set_header("HTTP/1.1 200 OK");
        $this->output->set_header('Expires: Sat, 26 Jul 2018 05:00:00 GMT');
        $this->output->set_header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");

        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->project = $this->session->userdata('project');
        $this->dist_id = $this->session->userdata('dis_id');
        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url());
        }
        $this->db_hostname = $this->session->userdata('db_hostname');
        $this->db_username = $this->session->userdata('db_username');
        $this->db_password = $this->session->userdata('db_password');
        $this->db_name = $this->session->userdata('db_name');
        $this->db->close();
        $config_app = switch_db_dinamico($this->db_username, $this->db_password, $this->db_name);
        $this->db = $this->load->database($config_app, TRUE);
    }

    public function bankList() {
        $condition = array(
            'dist_id' => $this->dist_id,
            'isActive' => 'Y',
            'isDelete' => 'N',
        );
        $data['title'] = 'Bank List';
        $data['bankList'] = $this->Common_model->get_data_list_by_many_columns('bank', $condition);
        $data['mainContent'] = $this->load->view('distributor/setup/bank/bankList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function addBank() {


        if (isPostBack()) {

            $data['bankName'] = $this->input->post('bankName');
            $data['branchName'] = $this->input->post('branchName');
            $data['bankAccount'] = $this->input->post('bankAccount');
            $data['bankAddress'] = $this->input->post('bankAddress');
            $data['dist_id'] = $this->dist_id;
            $data['isActive'] = 'Y';
            $data['isDelete'] = 'N';
            $data['createdBy'] = $this->admin_id;
            $this->Common_model->insert_data('bank', $data);
            message("Your data successfully inserted into database.");
            redirect(site_url($this->project . '/bankList'));
        }


        $condition = array(
            'dist_id' => $this->dist_id,
            'isActive' => 'Y',
            'isDelete' => 'N',
        );
        $data['title'] = 'Bank List';
        $data['bankList'] = $this->Common_model->get_data_list_by_many_columns('bank', $condition);
        $data['mainContent'] = $this->load->view('distributor/setup/bank/addBank', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function editBank($bankId) {
        if (isPostBack()) {
            $data['bankName'] = $this->input->post('bankName');
            $data['branchName'] = $this->input->post('branchName');
            $data['bankAccount'] = $this->input->post('bankAccount');
            $data['bankAddress'] = $this->input->post('bankAddress');
            $data['isActive'] = 'Y';
            $data['isDelete'] = 'N';
            $data['dist_id'] = $this->dist_id;
            $data['createdBy'] = $this->admin_id;
            $this->Common_model->update_data('bank', $data, 'bankId', $bankId);
            message("Your data successfully inserted into database.");
            redirect(site_url($this->project . '/bankList'));
        }
        $condition = array(
            'dist_id' => $this->dist_id,
            'isActive' => 'Y',
            'isDelete' => 'N',
        );
        $data['title'] = 'Bank List';
        $data['bankList'] = $this->Common_model->get_single_data_by_single_column('bank', 'bankId', $bankId);
        $data['mainContent'] = $this->load->view('distributor/setup/bank/bankEdit', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function incentiveList() {
        if (isPostBack()) {
            $data['company'] = $this->input->post('company');
            $data['targetQty'] = $this->input->post('targetQty');
            $data['start'] = date('Y-m-d', strtotime($this->input->post('start')));
            $data['end'] = date('Y-m-d', strtotime($this->input->post('end')));
            $data['incentive'] = $this->input->post('incentive');
            $data['dist_id'] = $this->dist_id;
            $data['status'] = 1;
            $data['updatedBy'] = $this->admin_id;
            $this->Common_model->insert_data('incentive', $data);
        }
        $data['companyList'] = $this->Common_model->getPublicBrand($this->dist_id);
        $data['incentiveList'] = $this->Common_model->get_data_list_by_single_column('incentive', 'dist_id', $this->dist_id);
        $data['title'] = 'Incentive List';
        $data['mainContent'] = $this->load->view('distributor/setup/incentive', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function checkDuplicateBrandForUpdate() {
        $brandId = $this->input->post('brandId');
        $brandName = $this->input->post('brandName');
        $brandList = $this->db->get_where('brand', array('brandId !=' => $brandId, 'brandName' => $brandName))->row();
        if (!empty($brandList)) {
            echo 1;
        }
    }

    function checkDuplicateProduct() {
        $productName = $this->input->post('productName');
        $productCategory = $this->input->post('productCategory');
        $brandId = $this->input->post('brandId');
        $productId = $this->input->post('productId');
        if (!empty($productId)):
            $productNameExits = $this->Common_model->checkDuplicateModel($this->dist_id, $productName, $productCategory, $brandId, $productId);
        else:
            $productNameExits = $this->Common_model->checkDuplicateModel($this->dist_id, $productName, $productCategory, $brandId);
        endif;
        if (!empty($productNameExits)) {
            echo 1;
        }
    }

    function userMessageList() {
        $this->db->select("*");
        $this->db->from("messageuser");
        $this->db->join("message", "message.msgId=messageuser.msgid");
        $this->db->where('messageuser.userid', $this->dist_id);
        $this->db->order_by('message.msgId', 'DESC');
        $data['allMessage'] = $this->db->get()->result();
        $data['title'] = 'Message List';
        $data['mainContent'] = $this->load->view('distributor/message/messageList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function userAllOfferList() {
        $this->db->select("*");
        $this->db->from("offer");
        $this->db->order_by('offerId', 'DESC');
        $data['allOffer'] = $this->db->get()->result();
        $data['title'] = 'Offer List';
        $data['mainContent'] = $this->load->view('distributor/offer/offerList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function newDecision() {
        if (isPostBack()) {
            $insertId = $this->Common_model->insert_data('newDecision', $_POST);
            if (!empty($insertId)) {
                message("Your data successfully inserted into database.");
                redirect(site_url($this->project . '/newDecisionList'));
            }
        }
        $data = array();
        $data['title'] = 'Decision Tools';
        $dist_id = $this->session->userdata('dist_id');
        $data['login'] = $this->session->userdata('login');
        $data['s_info'] = $this->Common_model->get_data_list_by_single_column('tbl_stock', 'dist_id', $this->dist_id);
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['dist_id'] = $this->session->userdata('dist_id');
        $data['mainContent'] = $this->load->view('distributor/setup/decision/newDecision', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function newDecisionList() {
        $data['newDecisionList'] = $this->Common_model->get_data_list('newDecision', 'percentage', 'DESC');
        $data['title'] = 'Decision Compare';
        $data['mainContent'] = $this->load->view('distributor/setup/decision/newDecisionList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function updatePassword($dist_id = null) {
        $data = array();
        $data['title'] = 'Change Password';
        $data['dist_id'] = $this->dist_id;
        $data['login'] = $this->session->userdata('login');
        $data['dist_name'] = $this->session->userdata('dist_name');
        //$dist_id = $this->session->userdata('dist_id');
        $data['dist_info'] = $this->Common_model->get_single_data_by_single_column('admin', 'admin_id', $this->admin_id);
        $data['mainContent'] = $this->load->view('distributor/setup/profile/chng_pass', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function change_password() {

        //dumpVar($_POST);


        $this->form_validation->set_rules('currentPassword', 'Current Password', 'required');
        $this->form_validation->set_rules('admin_password1', 'New Password', 'required');
        $this->form_validation->set_rules('admin_password2', 'Confirm Password', 'required');
        if ($this->form_validation->run() == FALSE) {
            exception("Required field can't be empty.");
            redirect(site_url($this->project . '/updatePassword/' . $this->admin_id));
        } else {
            $data = array();
            $current_password1 = md5($this->input->post('currentPassword'));
            $admin_password1 = md5($this->input->post('admin_password1'));
            $admin_password2 = md5($this->input->post('admin_password2'));
            $condition = array(
                'admin_id' => $this->admin_id,
                'password' => $current_password1,
            );
            //checkCurrent password
            $adminInfo = $this->Common_model->get_single_data_by_many_columns('admin', $condition);
            if (empty($adminInfo)) {
                //current password not match
                exception("Current password does't match!!");
                redirect(site_url($this->project . '/updatePassword/' . $this->admin_id));
            }
            if ($admin_password1 != $admin_password2) {
                //password not match confirm password
                exception("Given password does't match with confirm password.");
                redirect($this->project . '/updatePassword/' . $this->admin_id);
            } else {
                //every thing is ok.password change successfully
                $data['lastUpdate'] = $this->timestamp;
                $data['password'] = md5($this->input->post('admin_password1'));
                $data['ori_password'] = $this->input->post('admin_password1');
                $updated = $this->Common_model->update_data('admin', $data, 'admin_id', $this->admin_id);

                //echo $this->db->last_query();die;


                if (!empty($updated)):
                    message("Password successfully change.");
                    redirect($this->project . '/distributor_profile');
                else:
                    exception("Password does't updated.");
                    redirect($this->project . '/distributor_profile');
                endif;
            }
        }
    }

    public function distributor_profile() {
        $data = array();
        $data['title'] = 'Profile';
        $data['dist_id'] = $this->dist_id;
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['login'] = $this->session->userdata('login');
        $dist_id = $this->dist_id;
        $data['adminInfo'] = $this->Common_model->get_single_data_by_single_column('admin', 'admin_id', $this->admin_id);
        $data['mainContent'] = $this->load->view('distributor/setup/profile/dist_profile', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function decision_tools() {
        $data = array();
        $data['title'] = 'Decision Tools';
        $dist_id = $this->session->userdata('dist_id');
        $data['login'] = $this->session->userdata('login');
        //$data['s_info'] = $this->Common_model->get_data_list_by_single_column('tbl_stock', 'dist_id', $this->dist_id);
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['dist_id'] = $this->session->userdata('dist_id');
        $data['mainContent'] = $this->load->view('distributor/setup/decision/decision_form', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    //new
    public function save_decision_tools() {
        $data['dec_title'] = $this->input->post('dec_title', TRUE);
        $data['asset_amount'] = $this->input->post('asset_amount', TRUE);
        $data['invest_type'] = $this->input->post('invest_type', TRUE);
        $data['note'] = $this->input->post('note', TRUE);
        $data['dist_id'] = $this->dist_id;
        $data['bank_saving_type'] = $this->input->post('bank_saving_type', TRUE);
        $data['amount_of_saving'] = $this->input->post('amount_of_saving', TRUE);
        $data['period_time'] = $this->input->post('period_time', TRUE);
        $data['interest_per_month'] = $this->input->post('interest_per_month', TRUE);
        $data['per_month_interest_amount'] = $this->input->post('per_month_interest_amount', TRUE);
        $data['company_name'] = $this->input->post('company_name', TRUE);
        $data['invest_amount'] = $this->input->post('invest_amount', TRUE);
        $data['per_month_profit_amount'] = $this->input->post('per_month_profit_amount', TRUE);
        $data['return_of_invest_time'] = $this->input->post('return_of_invest_time', TRUE);
        $this->Common_model->insert_data('tbl_decision', $data);
        redirect(site_url($this->project . '/compare_decision'));
    }

    //new
    public function compare_decision() {
        $data = array();
        $data['title'] = 'Compare Decision';
        $dist_id = $this->dist_id;
        $data['login'] = $this->session->userdata('login');
        $data['offer_info'] = $this->Common_model->compare_decision_info($this->dist_id);
        $data['dist_name'] = $this->session->userdata('dist_name');
        $data['dist_id'] = $this->session->userdata('dist_id');
        //$data['s_info'] = $this->Common_model->get_data_list_by_single_column('tbl_stock', 'dist_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/decision/compare_decision', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function SystemConfig() {
        if (isPostBack()) {


          


            $data['companyName'] = $this->input->post('companyName');
            $data['phone'] = $this->input->post('phone');
            $data['email'] = $this->input->post('email');
            $data['address'] = $this->input->post('address');
            $data['website'] = $this->input->post('website');
            $data['invoice_format_type'] = $this->input->post('invoice_format_type');
            $data['invoice_title'] = $this->input->post('invoice_title');
            $data['report_header'] = $this->input->post('report_header');
            $data['report_footer'] = $this->input->post('report_footer');
            $data['website'] = $this->input->post('website');
            $data['dist_id'] = $this->dist_id;
            //$data['vat'] = $this->input->post('vat');
            if (!empty($this->input->post('image')[0])):
                $data['logo'] = $this->input->post('image')[0];
            endif;
            $data['updated_at'] = $this->timestamp;
            $data['updated_by'] = $this->admin_id;
          


            $exits = $this->Common_model->get_single_data_by_single_column('system_config', 'dist_id', $this->dist_id);
            if (!empty($exits)):
                message("Your System Configuration successfully updated into database.");
                $this->Common_model->update_data('system_config', $data, 'dist_id', $this->dist_id);
            else:
                message("Your System Configuration successfully inserted into database.");
                $this->Common_model->insert_data('system_config', $data, 'dist_id', $this->dist_id);
            endif;
            redirect(site_url($this->project . '/SystemConfig'));
        }
        $data['title'] = 'System || Config';
        $data['configInfo'] = $this->Common_model->get_single_data_by_single_column('system_config', 'dist_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/systemConfg', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function getAllMessage() {
        $this->db->select("*");
        $this->db->from("messageuser");
        $this->db->join("message", "message.msgId=messageuser.msgid");
        $this->db->where("messageuser.userid", $this->dist_id);
        $data['allMessage'] = $this->db->get()->result();
        // echo $this->db->last_query();die;
        $data['title'] = 'All Message';
        $data['mainContent'] = $this->load->view('distributor/message/messageList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function saveNewSupplier() {
        $data['supID'] = $this->input->post('supplierId');
        $data['supName'] = $this->input->post('supName');
        $data['supEmail'] = $this->input->post('supEmail');
        $data['supPhone'] = $this->input->post('supPhone');
        $data['supAddress'] = $this->input->post('supAddress');
        $data['dist_id'] = $this->dist_id;
        $data['updated_by'] = $this->admin_id;
        $insertID = $this->Common_model->insert_data('supplier', $data);
        if (!empty($insertID)):
            echo '<option value="' . $insertID . '" selected="selected">' . $data['supID'] . ' [ ' . $data['supName'] . ' ] ' . '</option>';
        endif;
    }

    function userStatusChange() {
        $userId = $this->input->post('userId');
        $data['status'] = $this->input->post('status');
        $this->Common_model->update_data('admin', $data, 'admin_id', $userId);
        message("User Status successfully change");
        echo 1;
    }

    function userList() {
        $data['title'] = 'User List';
        $data['userList'] = $this->Common_model->get_data_list_by_single_column('admin', 'distributor_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/user/userList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function addUser() {
        if (isPostBack()) {
            $data['name'] = $this->input->post('name');
            $data['phone'] = $this->input->post('phone');
            $data['email'] = $this->input->post('email');
            $data['password'] = md5($this->input->post('password'));
            $data['ori_password'] = $this->input->post('password');
            $data['distributor_id'] = $this->dist_id;
            //$this->session->set_userdata('m_distributorid', $userInfo->m_distributorid);
            $data['m_distributorid'] = $this->session->userdata('m_distributorid');
            $data['accessType'] = 2;
            $data['type'] = 'Master';
            $data['status'] = '1';
            $data['updated_by'] = $this->admin_id;
            $insertId = $this->Common_model->insert_data('admin', $data);
            //echo $this->db->last_query();die;
            if (!empty($insertId)) {
                message("New User Created successfully.");
                redirect(site_url($this->project . '/userList'));
            }
        }
        $data['title'] = 'User List';
        $data['userList'] = $this->Common_model->get_data_list_by_single_column('admin', 'distributor_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/user/addUser', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function editUser($editId) {
        if (isPostBack()) {
            $data['name'] = $this->input->post('name');
            $data['phone'] = $this->input->post('phone');
            $data['email'] = $this->input->post('email');
            $data['distributor_id'] = $this->dist_id;
            $data['updated_by'] = $this->admin_id;
            $this->Common_model->update_data('admin', $data, 'admin_id', $editId);
            message("User update successfully.");
            redirect(site_url($this->project . '/userList'));
        }
        $data['title'] = 'User List';
        $data['editInfo'] = $this->Common_model->get_single_data_by_single_column('admin', 'admin_id', $editId);
        $data['userList'] = $this->Common_model->get_data_list_by_single_column('admin', 'distributor_id', $this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/setup/user/editUser', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function suplierStatusChange() {
        $supid = $this->input->post('supID');
        $data['status'] = $this->input->post('status');
        $this->Common_model->update_data('supplier', $data, 'sup_id', $supid);
        message("Supplier status successfully Change.");
        return 1;
    }

    function customerStatusChange() {
        $supid = $this->input->post('supID');
        $data['status'] = $this->input->post('status');
        $this->Common_model->update_data('customer', $data, 'customer_id', $supid);
        message("customer status successfully Change.");
        return 1;
    }

    function deletedata() {
        // dumpVar($_POST);
        $table = $this->input->post('table');
        $column = $this->input->post('column');
        $id = $this->input->post('id');
        $type = $this->input->post('type');
        $condition = array(
            'dist_id' => $this->dist_id,
            'ledger_type' => $type,
            'client_vendor_id' => $id,
        );
        $transactionExit = $this->Common_model->get_single_data_by_many_columns('client_vendor_ledger', $condition);
        if (empty($transactionExit)) {
            $this->Common_model->delete_data($table, $column, $id);
            message("Your data successfully deleted from database.");
            echo 1;
        } else {
            if ($type == 1) {
                exception("This customer can't be deleted.already have a transaction  by this customer!");
                echo 1;
            } else {
                exception("This Supplier can't be deleted.already have a transaction  by this supplier!");
                echo 1;
            }
        }
    }

    function supplierDelete() {
        $id = $this->input->post('id');
        $condition = array(
            'dist_id' => $this->dist_id,
            'ledger_type' => 2,
            'client_vendor_id' => $id,
        );
        $transactionExit = $this->Common_model->get_single_data_by_many_columns('client_vendor_ledger', $condition);
        if (empty($transactionExit)) {
            $this->Common_model->delete_data('supplier', 'sup_id', $id);
            message("Your data successfully deleted from database.");
            echo 1;
        } else {
            exception("This supplier can't be deleted.already have a transaction  by this supplier!");
            echo 1;
        }
    }

    function customerDelete() {
        $id = $this->input->post('id');
        $condition = array(
            'dist_id' => $this->dist_id,
            'ledger_type' => 1,
            'client_vendor_id' => $id,
        );
        $transactionExit = $this->Common_model->get_single_data_by_many_columns('client_vendor_ledger', $condition);
        if (empty($transactionExit)) {
            $this->Common_model->delete_data('customer', 'customer_id', $id);
            message("Your data successfully deleted from database.");
            echo 1;
        } else {
            exception("This customer can't be deleted.already have a transaction  by this customer!");
            echo 1;
        }
    }

    function checkDuplicateEmail() {
        $phone = $this->input->post('phone');
        if (!empty($phone)):
            $array = array(
                'supPhone' => $phone,
                'dist_id' => $this->dist_id,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('supplier', $array);
            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateBrand() {
        $brandName = $this->input->post('brandName');
        if (!empty($brandName)):
            $duplicateBrandCondition = array(
                'brandName' => $brandName,
                'dist_id' => $this->dist_id,
            );
            $exitsBrandName = $this->Common_model->get_single_data_by_many_columns('brand', $duplicateBrandCondition);
            if (!empty($exitsBrandName)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateUnit() {
        $unitName = $this->input->post('unitName');
        if (!empty($unitName)):
            $exitsUnitName = $this->Common_model->cehckDuplicateUnit($unitName, $this->dist_id);
            if (!empty($exitsUnitName)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateEmailForUser() {
        $email = $this->input->post('email');
        if (!empty($email)):
            $condition = array(
                'email' => $email,
                'distributor_id' => $this->dist_id,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('admin', $condition);
            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function checkDuplicateEmailForUserEdit() {
        $email = $this->input->post('email');
        $adminId = $this->input->post('adminId');
        if (!empty($email)):
            $condition = array(
                'email' => $email,
                'distributor_id' => $this->dist_id,
                'admin_id !=' => $adminId,
            );
            $exitsSup = $this->Common_model->get_single_data_by_many_columns('admin', $condition);
            if (!empty($exitsSup)) {
                echo "1";
            } else {
                echo 2;
            }
        else:
            echo 2;
        endif;
    }

    function productStatusChange() {
        $product = $this->input->post('productid');
        $data['status'] = $this->input->post('status');
        $this->Common_model->update_data('product', $data, 'product_id', $product);
        message("Product Status successfully change.");
        echo 1;
    }

    function checkDuplicateCategory() {
        $catName = $this->input->post('catName');
        $condition = array(
            'dist_id' => $this->dist_id,
            'title' => $catName
        );
        $exitsData = $this->Common_model->checkPublicProductCat($catName);
        if (!empty($exitsData)) {
            echo 1;
        } else {
            echo 2;
        }
    }

    function checkDuplicateCategoryforUpdate() {
        $catName = $this->input->post('catName');
        $updatedID = $this->input->post('updatedID');
        $condition = array(
            'dist_id' => $this->dist_id,
            'title' => $catName,
            'category_id !=' => $updatedID
        );
        $this->db->select("*");
        $this->db->from("productcategory");
        $this->db->where('dist_id', $this->dist_id);
        $this->db->where('title', $catName);
        $this->db->where('category_id', $updatedID);
        $exitsData = $this->Common_model->get_single_data_by_many_columns('productcategory', $condition);
        //echo $this->db->last_query();die;
        if (!empty($exitsData)) {
            echo 1;
        } else {
            echo 2;
        }
    }

}
