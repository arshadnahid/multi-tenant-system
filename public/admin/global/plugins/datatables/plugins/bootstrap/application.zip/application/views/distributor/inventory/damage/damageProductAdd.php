
<style>
    table tr td{
        margin: 0px!important;
        padding: 2px!important;
    }

    table tr td  tfoot .form-control {
        width: 100%;
        height: 25px;
    }
</style>


<div class="main-content" >
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li >Inventory Damage</li>
                <li class="active">Damage Product Add</li>
              
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a class="" href="<?php echo site_url($this->project . '/damageProduct'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <table class="mytable table-responsive table table-bordered">
                            <tr>
                                <td  style="padding: 10px!important;"
                                     <div class="col-md-10 col-md-offset-1">
                                        <div class="col-md-6">
                                            <div class="form-group  ">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><span style="color:red;"> *</span> Date</label>
                                                <div class="col-sm-7">
                                                    <div class="input-group">
                                                        <input class="form-control date-picker" name="date" id="date" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" required/>
                                                        <span class="input-group-addon">
                                                            <i class="fa fa-calendar bigger-110"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 10px!important;">
                                    <div class="col-md-10 col-md-offset-1">
                                        <div class="panel panel-default">
                                            <div class="panel-body">
                                                <div class="table-header">
                                                    Damage Product Item
                                                </div>
                                                <table class="table table-bordered table-hover" id="show_item">
                                                    <thead>
                                                        <tr>
                                                            <th nowrap style="width:20%;border-radius:10px;" align="center"><strong>Product Category<span style="color:red;"> *</span></strong></th>
                                                            <th nowrap style="width:25%;border-radius:10px;" align="center"><strong>Product <span style="color:red;"> *</span></strong></th>
                                                            <th nowrap style="width:10%;border-radius:10px;" align="center"><strong>Quantity <span style="color:red;"> *</span></strong></th>
                                                            <th nowrap style="width:12%;border-radius:10px;" align="center"><strong>Unit Price(BDT)  <span style="color:red;"> *</span></strong></th>
                                                            <th nowrap style="width:13%;border-radius:10px;" align="center"><strong>Total Price(BDT) <span style="color:red;"> *</span></strong></th>
                                                            <th align="center" style="width:5%;"><strong>Action</strong></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <select id="categoryId" onchange="getProductList2(this.value)"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Category">
                                                                    <option value=""></option>
                                                                    <?php foreach ($productCat as $key => $eachCat):
                                                                        ?>
                                                                        <option categoryName="<?php echo $eachCat->title; ?>" categoryId="<?php echo $eachCat->category_id; ?>" value="<?php echo $eachCat->category_id; ?>"><?php echo $eachCat->title; ?></option>
                                                                        <?php
                                                                    endforeach;
                                                                    ?>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <select id="productID2" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Product">
                                                                    <option value=""></option>
                                                                </select>
                                                            </td>
                                                            <td><input type="text" class="form-control text-right quantity decimal"   placeholder="0"></td>
                                                            <td><input type="text" class="form-control text-right rate decimal" placeholder="0.00"  ></td>
                                                            <td><input type="text" class="form-control text-right price decimal" placeholder="0.00" readonly="readonly"></td>
                                                            <td><a id="add_item" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add</a></td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="clearfix"></div>
                                    <div class="clearfix form-actions" >
                                        <div class="col-md-offset-3 col-md-9">
                                            <button onclick="return isconfirm2()" id="subBtn" class="btn btn-info" type="button">
                                                <i class="ace-icon fa fa-check bigger-110"></i>
                                                Save
                                            </button>
                                            &nbsp; &nbsp; &nbsp;

                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </form>

                </div><!-- /.col -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script>


    function isconfirm2(){
        var date=$("#date").val();
        if(date == ''){
            swal("Select  Date!", "Validation Error!", "error");
        }else{
            swal({
                title: "Are you sure ?",
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#73AE28',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true,
                type: 'success'
            },
            function (isConfirm) {
                if (isConfirm) {
                    $("#publicForm").submit();
                }else{
                    return false;
                }
            });
        }
    }
</script>
<script type="text/javascript" src="<?php echo base_url('assets/purchases/damageAdd.js'); ?>"></script>

