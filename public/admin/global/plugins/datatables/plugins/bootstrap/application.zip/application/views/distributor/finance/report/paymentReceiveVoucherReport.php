
<?php
if (isset($_POST['start_date'])):
    $from_date = $this->input->post('start_date');
    $to_date = $this->input->post('end_date');
    $vType = $this->input->post('reportType');
endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Account</a>
                </li>
                <li>Account Report</li>
                <li class="active">Payment / Receive Voucher Report</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/account'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-8 col-sm-offset-2">
                            <div class="table-header">
                                Payment / Receive Voucher Report
                            </div><br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Report Type</label>
                                        <div class="col-sm-8">
                                            <select name="reportType" id="reportType" class="form-control required">
                                                <option selected disabled>Select Type</option>
                                                <option <?php
if ($vType == 2) {
    echo "selected";
}
?> value="2">Payment</option>
                                                <option value="3" <?php
                                                    if ($vType == 3) {
                                                        echo "selected";
                                                    }
?>>Receive</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From Date</label>
                                        <div class="col-sm-8">
                                            <input type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                                        if (!empty($from_date)) {
                                                            echo $from_date;
                                                        } else {
                                                            echo date('Y-m-d');
                                                        }
?>" data-date-format='yyyy-mm-dd' placeholder="Start Date: yyyy-mm-dd"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                                   if (!empty($to_date)):
                                                       echo $to_date;
                                                   else:
                                                       echo date('Y-m-d');
                                                   endif;
?>" data-date-format='yyyy-mm-dd' placeholder="End Date: yyyy-mm-dd"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <div class="col-sm-6">
                                            <button type="button"  onclick="return isconfirm2()" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-6">
                                            <button type="button" class="btn btn-info btn-sm" id="btn-print" onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):


               // dumpVar($_POST);


                $reportType = $this->input->post('reportType');
                $start_date = $this->input->post('start_date');
                $to_date = $this->input->post('end_date');
                $dist_id = $this->dist_id;
                ?>
                <div class="row">
                    <div class="col-xs-8 col-xs-offset-2">
                        <div class="table-header">

                            <?php
                            if ($reportType == 2) {
                                echo "Payment Voucher Report";
                            } else {
                                echo "Receive Voucher Report";
                            }
                            ?><span style="color:greenyellow;">From <?php echo $from_date; ?> To <?php echo $to_date; ?></span>
                        </div>
                    </div>
                    <div class="col-xs-8 col-xs-offset-2">
                        <div class="noPrint">
    <!--                            <button style="border-radius:100px 0 100px 0;" href="<?php echo site_url($this->project . '/SalesController/salesReport_export_excel/') ?>" class="btn btn-success pull-right noPrint">
                            <i class="ace-icon fa fa-download"></i>
                            Excel
                        </button>-->
                        </div>
                        <?php if ($companyInfo->invoice_format_type == 1): ?>
                            <table class="table table-responsive">
                                <tr>
                                    <td style="text-align:center;">
                                        <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                        <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                        <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                        <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                        <strong>Website : </strong><?php echo $companyInfo->website; ?><br>

                                        <strong style="font-size: 18px;">
                                            <?php
                                            if ($reportType == 2) {
                                                echo "Payment Voucher Report";
                                            } else {
                                                echo "Receive Voucher Report";
                                            }
                                            ?>
                                        </strong>
                                    </td>
                                </tr>
                            </table>

                        <?php else: ?>
                            <div class="row text-center">
                                <?php echo $companyInfo->report_header; ?>
                                <strong style="font-size: 18px;"><?php
                        if ($reportType == 2) {
                            echo "Payment Voucher Report";
                        } else {
                            echo "Receive Voucher Report";
                        }
                                ?></strong><br>
                            </div>
                        <?php endif; ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <td align="left"><strong>SL</strong></td>
                                    <td align="left"><strong>Date</strong></td>
                                    <td align="left"><strong>Voucher No.</strong></td>
                                    <td align="left"><strong>Voucher By</strong></td>
                                    <td align="right"><strong>Amount</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //dumpVar($data);
                                $total_debit = 0;

                                foreach ($result as $key => $eachResult):
                                    ?>
                                    <tr>
                                        <td><?php echo $key + 1; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($eachResult->date)); ?></td>
                                        <?php if ($eachResult->form_id == 2): ?>
                                            <td><a title="view invoice" href="<?php echo site_url($this->project . '/paymentVoucherView/' . $eachResult->generals_id); ?>"><?php echo $eachResult->voucher_no; ?></a></td>
                                        <?php else: ?>
                                            <td><a title="view invoice" href="<?php echo site_url($this->project . '/receiveVoucherView/' . $eachResult->generals_id); ?>"><?php echo $eachResult->voucher_no; ?></a></td>
                                        <?php endif; ?>

                                        <td>
                                            <?php
                                            if (!empty($eachResult->customerID)):
                                                echo $eachResult->customerID . '[' . $eachResult->customerName . ']';
                                            elseif (!empty($eachResult->supID)):
                                                echo $eachResult->supID . '[' . $eachResult->supName . ']';
                                            else:
                                                echo $eachResult->miscellaneous;
                                            endif;
                                            ?>
                                        </td>
                                        <td align="right"><?php
                                    echo $eachResult->debit;
                                    $total_debit+=$eachResult->debit;
                                            ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <!-- /Search Balance -->
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" align="right"><strong>
                                            <?php
                                            if ($reportType == 2) :
                                                echo "Total Payment";
                                            else:
                                                echo "Total Receive";
                                            endif;
                                            ?>
                                            Amount</strong></td>
                                    <td align="right"><strong><?php echo number_format((float) abs($total_debit), 2, '.', ','); ?>&nbsp;</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

<script>

    function isconfirm2(){
        var repotrtType=$("#reportType").val();

        if (repotrtType == '' || repotrtType == null) {
            swal("Select Report Type!", "Validation Error!", "error");
        }else{

            $("#publicForm").submit();
        }
    }




</script>

