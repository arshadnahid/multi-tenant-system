<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ServerFilterController extends CI_Controller {

    private $timestamp;
    public $admin_id;
    public $dist_id;
    public $project;

    public function __construct() {
        parent::__construct();
        //$this->load->model('Common_model', 'Finane_Model', 'Inventory_Model', 'Sales_Model');

        $this->output->set_header("HTTP/1.0 200 OK");
        $this->output->set_header("HTTP/1.1 200 OK");
        $this->output->set_header('Expires: Sat, 26 Jul 2018 05:00:00 GMT');
        $this->output->set_header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->load->model('ServerFilterModel', 'Filter_Model');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->project = $this->session->userdata('project');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->dist_id = $this->session->userdata('dis_id');

        $this->db_hostname = $this->session->userdata('db_hostname');
        $this->db_username = $this->session->userdata('db_username');
        $this->db_password = $this->session->userdata('db_password');
        $this->db_name = $this->session->userdata('db_name');
        $this->db->close();
        $config_app = switch_db_dinamico($this->db_username, $this->db_password, $this->db_name);
        $this->db = $this->load->database($config_app, TRUE);
    }

    public function brandListServerFilter() {
        $this->Filter_Model->filterData('brand', array('brandName'), array('brandName'), array('brandName'), $this->dist_id);
        $list = $this->Filter_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $brands) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $brands->brandName;
            if ($brands->dist_id != 1):
                $row[] = '<a class="blue" href="' . site_url($this->project . '/brandEdit/' . $brands->brandId) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteBrand(' . $brands->brandId . ')">
    <i class="ace-icon fa fa-trash-o bigger-130"></i></a>';
            else:
                $row[] = '';
            endif;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all(),
            "recordsFiltered" => $this->Filter_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    public function productCatListServerFilter() {
        $this->Filter_Model->filterData('productcategory', array('title'), array('title'), array('title'), $this->dist_id);
        $list = $this->Filter_Model->get_productCat_datatables();



        $data = array();
        $no = $_POST['start'];
        foreach ($list as $productCat) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $productCat->title;
            if ($productCat->dist_id != 1):
                $row[] = '<a class="blue inventoryEditPermission" href="' . site_url($this->project . '/updateProductCat/' . $productCat->category_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteProductCategory(' . $productCat->category_id . ')">
    <i class="ace-icon fa fa-trash-o bigger-130"></i></a>';
            else:
                $row[] = '';
            endif;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_productCat(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_productCat(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    public function unitListServerList() {
        $this->Filter_Model->filterData('unit', array('unitTtile', 'code'), array('unitTtile', 'code'), array('unitTtile', 'code'), $this->dist_id);
        $list = $this->Filter_Model->get_datatables_unit();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $unit) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $unit->unitTtile;
            $row[] = $unit->code;
            if ($unit->dist_id != 1):
                $row[] = '<a class="blue inventoryEditPermission" href="' . site_url($this->project . '/unitEdit/' . $unit->unit_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteUnit(' . $unit->unit_id . ')">
    <i class="ace-icon fa fa-trash-o bigger-130"></i></a>';
            else:
                $row[] = '';
            endif;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_unit(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_unit(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    public function supplierListServerFilter() {
        $this->Filter_Model->filterData('supplier', array('supID', 'supName', 'supEmail', 'supPhone', 'supAddress', 'status'), array('supID', 'supName', 'supEmail', 'supPhone', 'supAddress', 'status'), array('supID', 'supName', 'supEmail', 'supPhone', 'supAddress', 'status'), $this->dist_id);
        $list = $this->Filter_Model->get_sup_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $supplier) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $supplier->supID;
            $row[] = $supplier->supName;
            $row[] = $supplier->supEmail;
            $row[] = $supplier->supPhone;
            $row[] = $supplier->supAddress;
            if ($supplier->status == 1):
                $row[] = '<a href="javascript:void(0)" onclick="supplierStatusChange(' . $supplier->sup_id . ',2)" class="label label-danger arrowed">
                    <i class="ace-icon fa fa-fire bigger-110"></i>
                    Inactive</a>';
            else:
                $row[] = '<a href="javascript:void(0)" onclick="supplierStatusChange(' . $supplier->sup_id . ',1)" class="label label-success arrowed">
                    <i class="ace-icon fa fa-check bigger-110"></i>
                    Active
                </a>';
            endif;
            $row[] = '<a class="blue inventoryEditPermission" href="' . site_url($this->project . '/supplierUpdate/' . $supplier->sup_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteSupplier(' . $supplier->sup_id . ',2)">
                                                    <i class="ace-icon fa fa-trash-o bigger-130"></i>
                                                </a>';
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all(),
            "recordsFiltered" => $this->Filter_Model->count_filtered(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function customerListServerList() {

        $this->Filter_Model->filterData('customer', array('customerID', 'customerName', 'customerPhone', 'customerEmail', 'customerAddress'), array('customerID', 'customerName', 'customerPhone', 'customerEmail', 'customerAddress',), array('customerID', 'customerName', 'customerPhone', 'customerEmail', 'customerAddress',), $this->dist_id);
        $list = $this->Filter_Model->get_cus_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customer) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $this->Common_model->tableRow('customertype', 'type_id', $customer->customerType)->typeTitle;
            $row[] = $customer->customerID;
            $row[] = $customer->customerName;
            $row[] = $customer->customerPhone;
            $row[] = $customer->customerEmail;
            $row[] = $customer->customerAddress;

            if ($customer->status == 1):
                $row[] = '<a href="javascript:void(0)" onclick="customerStatusChange(' . $customer->customer_id . ',2)" class="label label-danger arrowed">
                    <i class="ace-icon fa fa-fire bigger-110"></i>
                    Inactive</a>';
            else:
                $row[] = '<a href="javascript:void(0)" onclick="customerStatusChange(' . $customer->customer_id . ',1)" class="label label-success arrowed">
                    <i class="ace-icon fa fa-check bigger-110"></i>
                    Active
                </a>';
            endif;
            $row[] = '<a class="blue inventoryEditPermission" href="' . site_url($this->project . '/editCustomer/' . $customer->customer_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteCustomer(' . $customer->customer_id . ',1)">
                                                    <i class="ace-icon fa fa-trash-o bigger-130"></i>
                                                </a>';
            $data[] = $row;
        }




        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_cus(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_cus(),
            "data" => $data
        );
//output to json format
        echo json_encode($output);
    }

    public function productListServerFilter() {
        $this->Filter_Model->filterData('product', array('productcategory.title', 'brand.brandName', 'product.product_code', 'product.productName', 'product.purchases_price', 'product.retailPrice', 'product.salesPrice', 'product.status'), array('productcategory.title', 'brand.brandName', 'product.product_code', 'product.productName', 'product.purchases_price', 'product.retailPrice', 'product.salesPrice', 'product.status'), array('productcategory.title', 'brand.brandName', 'product.product_code', 'product.productName', 'product.purchases_price', 'product.retailPrice', 'product.salesPrice', 'product.status'), $this->dist_id);
        $list = $this->Filter_Model->get_product_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $products) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $products->title;
            $row[] = $products->brandName;
            $row[] = $products->product_code;
            $row[] = $products->productName;
            $row[] = $products->purchases_price;
            $row[] = $products->retailPrice;
            $row[] = $products->salesPrice;
            if ($products->dist_id != 1):
                if ($products->status == 1):
                    $row[] = '<a href="javascript:void(0)" onclick="productStatusChange(' . $products->product_id . ',2)" class="label label-danger arrowed">
                    <i class="ace-icon fa fa-fire bigger-110"></i>
                    Inactive</a>';
                else:
                    $row[] = '<a href="javascript:void(0)" onclick="productStatusChange(' . $products->product_id . ',1)" class="label label-success arrowed">
                    <i class="ace-icon fa fa-check bigger-110"></i>
                    Active
                </a>';
                endif;
            else:
                $row[] = '';
            endif;
            if ($products->dist_id != 1):
                $row[] = '<a class="blue inventoryEditPermission" href="' . site_url($this->project . '/updateProduct/' . $products->product_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteProduct(' . $products->product_id . ',2)">
          <i class="ace-icon fa fa-trash-o bigger-130"></i>
        </a>';
            else:
                $row[] = '';
            endif;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_product(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_product(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function salesList() {

        $saleEditCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '111',
        );
        $saleEditPermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $saleEditCondition);
        $saleDeleteCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '112',
        );
        $saleDeletePermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $saleDeleteCondition);

        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'form.name', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), $this->dist_id);
        $list = $this->Filter_Model->get_sales_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $sale) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = date('M d, Y', strtotime($sale->date));
            $row[] = '<a title="view invoice" href="' . site_url($this->project . '/salesInvoice_view/' . $sale->generals_id) . '">' . $sale->voucher_no . '</a>';
            $row[] = $sale->name;
            $row[] = '<a title="View Customer Dashboard" href="' . site_url($this->project . '/customerDashboard/' . $sale->customer_id) . '">' . $sale->customerID . ' [ ' . $sale->customerName . ' ] ' . '</a>';
            $row[] = $sale->narration;

             if ($sale->payType == 1 || $sale->payType == 4) {
                $row[] = 'Cash';
            } else if ($sale->payType == 2) {
                $row[] = 'Credit';
            } else {
                $row[] = 'Bank';
            }

            $row[] = number_format((float) $sale->debit, 2, '.', ',');
            $row[] = $this->Common_model->getInvoiceDueAmount($sale->generals_id, $sale->voucher_no, $sale->debit, $this->dist_id);
            // $row[] = number_format((float) $this->Sales_Model->getGpAmountByInvoiceId($this->dist_id, $sale->generals_id), 2, '.', ',');



            if (empty($saleDeletePermition) && !empty($saleEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/salesInvoice_view/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green saleEditPermission" href="' . site_url($this->project . '/salesInvoice_edit/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a> ';
            } elseif (!empty($saleDeletePermition) && empty($saleEditPermition)) {


                $row[] = '<a class="blue" href="' . site_url($this->project . '/salesInvoice_view/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>


    <a class="saleDeletePermission red " href="' . site_url($this->project . '/saleDelete/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-trash-o bigger-130"></i></a>
    ';
            } else if (!empty($saleDeletePermition) && !empty($saleEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/salesInvoice_view/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green saleEditPermission" href="' . site_url($this->project . '/salesInvoice_edit/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    <a class="saleDeletePermission red " href="' . site_url($this->project . '/saleDelete/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-trash-o bigger-130"></i></a>
    ';
            } else {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/salesInvoice_view/' . $sale->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>';
            }







            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_sales(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_sales(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function purchasesList() {

        $inventoryDeleteCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '118',
        );

        $inventoryDeletePermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $inventoryDeleteCondition);


        $inventoryEditCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '117',
        );

        $inventoryEditPermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $inventoryEditCondition);


        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'generals.narration', 'generals.debit'), $this->dist_id);
        $list = $this->Filter_Model->get_purchases_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $purchases) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = date('M d, Y', strtotime($purchases->date));
            $row[] = '<a title="view Voucher" href="' . site_url($this->project . '/viewPurchases/' . $purchases->generals_id) . '">' . $purchases->voucher_no . '</a></td>';
            $row[] = $purchases->name;
            $row[] = '<a title="View Supplier Dashboard" href="' . site_url($this->project . '/supplierDashboard/' . $purchases->sup_id) . '">' . $purchases->supID . ' [ ' . $purchases->supName . ' ] ' . '</a>';
            $row[] = $purchases->narration;
            $row[] = number_format((float) $purchases->debit, 2, '.', ',');


            if (empty($inventoryDeletePermition) && !empty($inventoryEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/viewPurchases/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green inventoryEditPermission" href="' . site_url($this->project . '/purchases_edit/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a> ';
            } elseif (!empty($inventoryDeletePermition) && empty($inventoryEditPermition)) {

                $row[] = '<a class="blue" href="' . site_url($this->project . '/viewPurchases/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>


    <a class="inventoryDeletePermission red " href="' . site_url($this->project . '/purchasesDelete/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-trash-o bigger-130"></i></a>
    ';
            } else if (!empty($inventoryDeletePermition) && !empty($inventoryEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/viewPurchases/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green inventoryEditPermission" href="' . site_url($this->project . '/purchases_edit/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>

    <a class="inventoryDeletePermission red " href="' . site_url($this->project . '/purchasesDelete/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-trash-o bigger-130"></i></a>
    ';
            } else {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/viewPurchases/' . $purchases->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>';
            }








            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_purchases(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_purchases(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function paymentList() {

        $financeEditCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '114',
        );

        $financeEditPermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $financeEditCondition);
        $financeDeleteCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '115',
        );
        $financeDeletePermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $financeDeleteCondition);

        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), $this->dist_id);
        $list = $this->Filter_Model->get_payment_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $payment) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = date('M d, Y', strtotime($payment->date));
            $row[] = '<a title="View Payment Voucher" href="' . site_url($this->project . '/paymentVoucherView/' . $payment->generals_id) . '">' . $payment->voucher_no . '</a></td>';
            $row[] = $payment->name;

            if (!empty($payment->customer_id)) {
                $row[] = '<a title="View Customer  Dashboard" href="' . site_url($this->project . '/customerDashboard/' . $payment->customer_id) . '">' . $payment->customerID . ' [ ' . $payment->customerName . ' ] ' . '</a>';
            } else if (!empty($payment->supplier_id)) {
                $row[] = '<a title="View Supplier  Dashboard" href="' . site_url($this->project . '/supplierDashboard/' . $payment->supplier_id) . '">' . $payment->supID . ' [ ' . $payment->supName . ' ] ' . '</a>';
            } else {
                $row[] = $payment->miscellaneous;
            }

            $row[] = $payment->narration;
            $row[] = number_format((float) $payment->debit, 2, '.', ',');

            if (empty($financeDeletePermition) && !empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/paymentVoucherView/' . $payment->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green financeEditPermission" href="' . site_url($this->project . '/paymentVoucherEdit/' . $payment->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a> ';
            } elseif (!empty($financeDeletePermition) && empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/paymentVoucherView/' . $payment->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>

    ';
            } else if (!empty($financeDeletePermition) && !empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/paymentVoucherView/' . $payment->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green financeEditPermission" href="' . site_url($this->project . '/paymentVoucherEdit/' . $payment->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>

    ';
            } else {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/paymentVoucherView/' . $payment->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_payment(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_payment(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function receiveList() {

        $financeEditCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '114',
        );
        $financeEditPermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $financeEditCondition);
        $financeDeleteCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '115',
        );
        $financeDeletePermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $financeDeleteCondition);
        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), $this->dist_id);
        $list = $this->Filter_Model->get_receive_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $receive) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = '<a title="View Receive Voucher" href="' . site_url($this->project . '/receiveVoucherView/' . $receive->generals_id) . '">' . $receive->voucher_no . '</a>';
            $row[] = date('M d, Y', strtotime($receive->date));
            $row[] = $receive->name;
            if (!empty($receive->customer_id)) {
                $row[] = '<a title="View Customer  Dashboard" href="' . site_url($this->project . '/customerDashboard/' . $receive->customer_id) . '">' . $receive->customerID . ' [ ' . $receive->customerName . ' ] ' . '</a>';
            } else if (!empty($receive->supplier_id)) {
                $row[] = '<a title="View Supplier  Dashboard" href="' . site_url($this->project . '/supplierDashboard/' . $receive->supplier_id) . '">' . $receive->supID . ' [ ' . $receive->supName . ' ] ' . '</a>';
            } else {
                $row[] = $receive->miscellaneous;
            }

            $row[] = $receive->narration;
            $row[] = number_format((float) $receive->debit, 2, '.', ',');

            if (empty($financeDeletePermition) && !empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/receiveVoucherView/' . $receive->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green financeEditPermission" href="' . site_url($this->project . '/receiveVoucherEdit/' . $receive->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a> ';
            } elseif (!empty($financeDeletePermition) && empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/receiveVoucherView/' . $receive->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>

    ';
            } else if (!empty($financeDeletePermition) && !empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/receiveVoucherView/' . $receive->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green financeEditPermission" href="' . site_url($this->project . '/receiveVoucherEdit/' . $receive->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>

    ';
            } else {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/receiveVoucherView/' . $receive->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_receive(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_receive(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function journalListServerFilter() {




        $financeEditCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '114',
        );
        $financeEditPermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $financeEditCondition);
        $financeDeleteCondition = array(
            'admin_id' => $this->admin_id,
            'navigation_id' => '115',
        );
        $financeDeletePermition = $this->Common_model->get_single_data_by_many_columns('admin_role', $financeDeleteCondition);



        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'form.name', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'generals.narration', 'generals.debit'), $this->dist_id);
        $list = $this->Filter_Model->get_journal_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $journal) {
            $no++;
            $row = array();
            $row[] = $no;
          $row[] = '<a title="View Journal Voucher" href="' . site_url($this->project . '/journalVoucherView/' . $journal->generals_id) . '">' . $journal->voucher_no . '</a>';
            $row[] = date('M d, Y', strtotime($journal->date));
            $row[] = $journal->name;
            $row[] = $journal->narration;
            $row[] = number_format((float) $journal->debit, 2, '.', ',');


            if (empty($financeDeletePermition) && !empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/journalVoucherView/' . $journal->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green financeEditPermission" href="' . site_url($this->project . '/journalVoucherEdit/' . $journal->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a> ';
            } elseif (!empty($financeDeletePermition) && empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/journalVoucherView/' . $journal->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>

    ';
            } else if (!empty($financeDeletePermition) && !empty($financeEditPermition)) {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/journalVoucherView/' . $journal->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green financeEditPermission" href="' . site_url($this->project . '/journalVoucherEdit/' . $journal->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>

    ';
            } else {
                $row[] = '<a class="blue" href="' . site_url($this->project . '/journalVoucherView/' . $journal->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>';
            }



            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_journal(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_journal(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function billVoucherList() {

        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), array('generals.date', 'generals.voucher_no', 'form.name', 'supplier.supID', 'supplier.supName', 'customer.customerID', 'customer.customerName', 'generals.narration', 'generals.debit'), $this->dist_id);
        $list = $this->Filter_Model->get_bill_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $bill) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = date('M d, Y', strtotime($bill->date));
            $row[] = '<a title="View Payment Voucher" href="' . site_url($this->project . '/paymentVoucherView/' . $bill->generals_id) . '">' . $bill->voucher_no . '</a></td>';
            $row[] = $bill->name;

            if (!empty($bill->customer_id)) {
                $row[] = '<a title="View Customer  Dashboard" href="' . site_url($this->project . '/customerDashboard/' . $bill->customer_id) . '">' . $bill->customerID . ' [ ' . $bill->customerName . ' ] ' . '</a>';
            } else if (!empty($bill->supplier_id)) {
                $row[] = '<a title="View Supplier  Dashboard" href="' . site_url($this->project . '/supplierDashboard/' . $bill->supplier_id) . '">' . $bill->supID . ' [ ' . $bill->supName . ' ] ' . '</a>';
            } else {
                $row[] = $bill->miscellaneous;
            }
            $row[] = $bill->narration;
            $row[] = number_format((float) $bill->debit, 2, '.', ',');
            $row[] = '<a class="blue" href="' . site_url($this->project . '/billInvoice_view/' . $bill->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>
    <a class="green financeEditPermission" href="' . site_url($this->project . '/billInvoice_edit/' . $bill->generals_id) . '">
    <i class="ace-icon fa fa-pencil bigger-130"></i></a>
    ';
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_bill(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_bill(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function cusPayListServerFilter() {

        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'generals.credit', 'customer.customerID', 'customer.customerName'), array('generals.date', 'generals.voucher_no', 'generals.credit', 'customer.customerName', 'customer.customerName'), array('generals.date', 'generals.voucher_no', 'generals.credit', 'customer.customerID', 'customer.customerName'), $this->dist_id);
        //  $this->Filter_Model->filterData('moneyreceit', array('moneyreceit.date', 'moneyreceit.receitID', 'moneyreceit.moneyReceitid', 'moneyreceit.totalPayment', 'moneyreceit.checkStatus', 'moneyreceit.paymentType', 'customer.customerID', 'customer.customerName'), array('moneyreceit.date', 'moneyreceit.receitID', 'moneyreceit.moneyReceitid', 'moneyreceit.totalPayment', 'moneyreceit.checkStatus', 'moneyreceit.paymentType', 'customer.customerID', 'customer.customerName'), array('moneyreceit.date', 'moneyreceit.receitID', 'moneyreceit.moneyReceitid', 'moneyreceit.totalPayment', 'moneyreceit.checkStatus', 'moneyreceit.paymentType', 'customer.customerID', 'customer.customerName'), $this->dist_id);
        $list = $this->Filter_Model->get_cusPay_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $cusPay) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = date('M d, Y', strtotime($cusPay->date));
            $row[] = '<a title="View Money Receit" href="' . site_url($this->project . '/viewMoneryReceiptForPayment/' . $cusPay->generals_id) . '">' . $cusPay->voucher_no . '</a></td>';
            $row[] = '<a title="View Customer  Dashboard" href="' . site_url($this->project . '/customerDashboard/' . $cusPay->customer_id) . '">' . $cusPay->cusName . '</a>';
            $row[] = number_format((float) $cusPay->credit, 2, '.', ',');
            $row[] = '<a class="blue" href="' . site_url($this->project . '/viewMoneryReceiptForPayment/' . $cusPay->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_cusPay(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_cusPay(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function supPayListServerList() {

        $this->Filter_Model->filterData('generals', array('generals.date', 'generals.voucher_no', 'generals.credit', 'supplier.supID', 'supplier.supName'), array('generals.date', 'generals.voucher_no', 'generals.credit', 'supplier.supID', 'supplier.supName'), array('generals.date', 'generals.voucher_no', 'generals.credit', 'supplier.supID', 'supplier.supName'), $this->dist_id);
        $list = $this->Filter_Model->get_supPay_datatables();
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $supPay) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = date('M d, Y', strtotime($supPay->date));
            $row[] = '<a title="View Money Receit" href="' . site_url($this->project . '/viewMoneryReceiptForPayment/' . $supPay->generals_id) . '">' . $supPay->voucher_no . '</a></td>';
            $row[] = '<a title="View Supplier  Dashboard" href="' . site_url($this->project . '/supplierDashboard/' . $supPay->sup_id) . '">' . $supPay->supName . '</a>';
            $row[] = number_format((float) $supPay->credit, 2, '.', ',');
            $row[] = '<a class="blue" href="' . site_url($this->project . '/viewMoneryReceiptForPayment/' . $supPay->generals_id) . '">
    <i class="ace-icon fa fa-search-plus bigger-130"></i></a>';
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_supPay(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_supPay(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function productTypeList() {
        $this->Filter_Model->filterData('product_type', array('product_type.product_type_name'), array('product_type.product_type_name'), array('product_type.product_type_name'), $this->dist_id);
        $list = $this->Filter_Model->get_product_type_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $products) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $products->product_type_name;

            if ($products->dist_id != 1):
                if ($products->is_active == "Y"):
                    $row[] = '<a href="javascript:void(0)" onclick="productTypeStatusChange(' . $products->product_type_id . ',0)" class="label label-danger arrowed">
                    <i class="ace-icon fa fa-fire bigger-110"></i>
                    Inactive</a>';
                else:
                    $row[] = '<a href="javascript:void(0)" onclick="productTypeStatusChange(' . $products->product_type_id . ',1)" class="label label-success arrowed">
                    <i class="ace-icon fa fa-check bigger-110"></i>
                    Active
                </a>';
                endif;
            else:
                $row[] = '';
            endif;
            if ($products->dist_id != 1):
                $row[] = '<a class="blue inventoryEditPermission" href="' . site_url($this->project . '/editproductType/' . $products->product_type_id) . '">
                <i class="ace-icon fa fa-pencil bigger-130"></i></a>
                <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteProductType(' . $products->product_type_id . ',2)">
                  <i class="ace-icon fa fa-trash-o bigger-130"></i>
                </a>';
            else:
                $row[] = '';
            endif;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_productType(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_product_type(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

    public function productPackageList() {
        $this->Filter_Model->filterData('package', array('package.package_name'), array('package.package_name'), array('package.package_name'), $this->dist_id);
        $list = $this->Filter_Model->get_product_package_datatables();
        //$list = $this->Filter_Model->get_product_type_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $products) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $products->package_name;

            if ($products->dist_id != 1):
                if ($products->is_active == "Y"):
                    $row[] = '<a href="javascript:void(0)" onclick="productPackageStatusChange(' . $products->package_id . ',0)" class="label label-danger arrowed">
                    <i class="ace-icon fa fa-fire bigger-110"></i>
                    Inactive</a>';
                else:
                    $row[] = '<a href="javascript:void(0)" onclick="productPackageStatusChange(' . $products->package_id . ',1)" class="label label-success arrowed">
                    <i class="ace-icon fa fa-check bigger-110"></i>
                    Active
                </a>';
                endif;
            else:
                $row[] = '';
            endif;
            if ($products->dist_id != 1):
                $row[] = '<a class="inventoryEditPermission" href="' . site_url($this->project . '/productPackageView/' . $products->package_id) . '">
                        <i class="ace-icon fa fa-search-plus bigger-130"></i>
                    </a>
                    <a class="blue inventoryEditPermission" href="' . site_url($this->project . '/productPackageEdit/' . $products->package_id) . '">
                <i class="ace-icon fa fa-pencil bigger-130"></i></a>
                <a class="red inventoryDeletePermission" href="javascript:void(0)" onclick="deleteProductpackage(' . $products->package_id . ',2)">
                  <i class="ace-icon fa fa-trash-o bigger-130"></i>
                </a>';
            else:
                $row[] = '';
            endif;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Filter_Model->count_all_productPackage(),
            //"recordsTotal" => $this->Filter_Model->count_all_productType(),
            "recordsFiltered" => $this->Filter_Model->count_filtered_product_package(),
            //"recordsFiltered" => $this->Filter_Model->count_filtered_product_type(),
            "data" => $data,
        );
//output to json format
        echo json_encode($output);
    }

}
