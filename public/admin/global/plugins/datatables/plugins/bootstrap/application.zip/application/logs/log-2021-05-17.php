<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-17 01:57:03 --> Config Class Initialized
INFO - 2021-05-17 01:57:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 01:57:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 01:57:03 --> Utf8 Class Initialized
INFO - 2021-05-17 01:57:03 --> URI Class Initialized
DEBUG - 2021-05-17 01:57:03 --> No URI present. Default controller set.
INFO - 2021-05-17 01:57:03 --> Router Class Initialized
INFO - 2021-05-17 01:57:03 --> Output Class Initialized
INFO - 2021-05-17 01:57:03 --> Security Class Initialized
DEBUG - 2021-05-17 01:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 01:57:03 --> Input Class Initialized
INFO - 2021-05-17 01:57:03 --> Language Class Initialized
INFO - 2021-05-17 01:57:03 --> Loader Class Initialized
INFO - 2021-05-17 01:57:03 --> Helper loaded: url_helper
INFO - 2021-05-17 01:57:03 --> Helper loaded: file_helper
INFO - 2021-05-17 01:57:03 --> Helper loaded: utility_helper
INFO - 2021-05-17 01:57:03 --> Helper loaded: unit_helper
INFO - 2021-05-17 01:57:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 01:57:03 --> Database Driver Class Initialized
INFO - 2021-05-17 01:57:03 --> Email Class Initialized
DEBUG - 2021-05-17 01:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 01:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 01:57:03 --> Helper loaded: form_helper
INFO - 2021-05-17 01:57:03 --> Form Validation Class Initialized
INFO - 2021-05-17 01:57:03 --> Controller Class Initialized
INFO - 2021-05-17 01:57:03 --> Model "Common_model" initialized
INFO - 2021-05-17 01:57:03 --> Model "Finane_Model" initialized
INFO - 2021-05-17 01:57:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 01:57:03 --> Model "Sales_Model" initialized
INFO - 2021-05-17 01:57:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 01:57:03 --> Final output sent to browser
DEBUG - 2021-05-17 01:57:03 --> Total execution time: 0.0595
INFO - 2021-05-17 01:57:04 --> Config Class Initialized
INFO - 2021-05-17 01:57:04 --> Hooks Class Initialized
DEBUG - 2021-05-17 01:57:04 --> UTF-8 Support Enabled
INFO - 2021-05-17 01:57:04 --> Utf8 Class Initialized
INFO - 2021-05-17 01:57:04 --> URI Class Initialized
INFO - 2021-05-17 01:57:04 --> Router Class Initialized
INFO - 2021-05-17 01:57:04 --> Output Class Initialized
INFO - 2021-05-17 01:57:04 --> Security Class Initialized
DEBUG - 2021-05-17 01:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 01:57:04 --> Input Class Initialized
INFO - 2021-05-17 01:57:04 --> Language Class Initialized
INFO - 2021-05-17 01:57:04 --> Loader Class Initialized
INFO - 2021-05-17 01:57:04 --> Helper loaded: url_helper
INFO - 2021-05-17 01:57:04 --> Helper loaded: file_helper
INFO - 2021-05-17 01:57:04 --> Helper loaded: utility_helper
INFO - 2021-05-17 01:57:04 --> Helper loaded: unit_helper
INFO - 2021-05-17 01:57:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 01:57:04 --> Database Driver Class Initialized
INFO - 2021-05-17 01:57:04 --> Email Class Initialized
DEBUG - 2021-05-17 01:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 01:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 01:57:04 --> Helper loaded: form_helper
INFO - 2021-05-17 01:57:04 --> Form Validation Class Initialized
INFO - 2021-05-17 01:57:04 --> Controller Class Initialized
INFO - 2021-05-17 01:57:04 --> Model "Common_model" initialized
INFO - 2021-05-17 01:57:04 --> Model "Finane_Model" initialized
INFO - 2021-05-17 01:57:04 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 01:57:04 --> Model "Sales_Model" initialized
INFO - 2021-05-17 01:57:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/forgotpassword.php
INFO - 2021-05-17 01:57:04 --> Final output sent to browser
DEBUG - 2021-05-17 01:57:04 --> Total execution time: 0.0411
INFO - 2021-05-17 01:57:06 --> Config Class Initialized
INFO - 2021-05-17 01:57:06 --> Hooks Class Initialized
DEBUG - 2021-05-17 01:57:06 --> UTF-8 Support Enabled
INFO - 2021-05-17 01:57:06 --> Utf8 Class Initialized
INFO - 2021-05-17 01:57:06 --> URI Class Initialized
DEBUG - 2021-05-17 01:57:06 --> No URI present. Default controller set.
INFO - 2021-05-17 01:57:06 --> Router Class Initialized
INFO - 2021-05-17 01:57:06 --> Output Class Initialized
INFO - 2021-05-17 01:57:06 --> Security Class Initialized
DEBUG - 2021-05-17 01:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 01:57:06 --> Input Class Initialized
INFO - 2021-05-17 01:57:06 --> Language Class Initialized
INFO - 2021-05-17 01:57:07 --> Loader Class Initialized
INFO - 2021-05-17 01:57:07 --> Helper loaded: url_helper
INFO - 2021-05-17 01:57:07 --> Helper loaded: file_helper
INFO - 2021-05-17 01:57:07 --> Helper loaded: utility_helper
INFO - 2021-05-17 01:57:07 --> Helper loaded: unit_helper
INFO - 2021-05-17 01:57:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 01:57:07 --> Database Driver Class Initialized
INFO - 2021-05-17 01:57:07 --> Email Class Initialized
DEBUG - 2021-05-17 01:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 01:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 01:57:07 --> Helper loaded: form_helper
INFO - 2021-05-17 01:57:07 --> Form Validation Class Initialized
INFO - 2021-05-17 01:57:07 --> Controller Class Initialized
INFO - 2021-05-17 01:57:07 --> Model "Common_model" initialized
INFO - 2021-05-17 01:57:07 --> Model "Finane_Model" initialized
INFO - 2021-05-17 01:57:07 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 01:57:07 --> Model "Sales_Model" initialized
INFO - 2021-05-17 01:57:07 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 01:57:07 --> Final output sent to browser
DEBUG - 2021-05-17 01:57:07 --> Total execution time: 0.0458
INFO - 2021-05-17 01:57:08 --> Config Class Initialized
INFO - 2021-05-17 01:57:08 --> Hooks Class Initialized
DEBUG - 2021-05-17 01:57:08 --> UTF-8 Support Enabled
INFO - 2021-05-17 01:57:08 --> Utf8 Class Initialized
INFO - 2021-05-17 01:57:08 --> URI Class Initialized
INFO - 2021-05-17 01:57:08 --> Router Class Initialized
INFO - 2021-05-17 01:57:08 --> Output Class Initialized
INFO - 2021-05-17 01:57:08 --> Security Class Initialized
DEBUG - 2021-05-17 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 01:57:08 --> Input Class Initialized
INFO - 2021-05-17 01:57:08 --> Language Class Initialized
INFO - 2021-05-17 01:57:08 --> Loader Class Initialized
INFO - 2021-05-17 01:57:08 --> Helper loaded: url_helper
INFO - 2021-05-17 01:57:08 --> Helper loaded: file_helper
INFO - 2021-05-17 01:57:08 --> Helper loaded: utility_helper
INFO - 2021-05-17 01:57:08 --> Helper loaded: unit_helper
INFO - 2021-05-17 01:57:08 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 01:57:08 --> Database Driver Class Initialized
INFO - 2021-05-17 01:57:08 --> Email Class Initialized
DEBUG - 2021-05-17 01:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 01:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 01:57:08 --> Helper loaded: form_helper
INFO - 2021-05-17 01:57:08 --> Form Validation Class Initialized
INFO - 2021-05-17 01:57:08 --> Controller Class Initialized
INFO - 2021-05-17 01:57:08 --> Model "Common_model" initialized
INFO - 2021-05-17 01:57:08 --> Model "Finane_Model" initialized
INFO - 2021-05-17 01:57:08 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 01:57:08 --> Model "Sales_Model" initialized
ERROR - 2021-05-17 01:57:08 --> Query error: Table 'aelbfopi_cement_central_db.admin' doesn't exist - Invalid query: SELECT *
FROM `admin`
WHERE `email` IS NULL
AND `password` = 'd41d8cd98f00b204e9800998ecf8427e'
AND `accessType` = 2
ERROR - 2021-05-17 01:57:08 --> Severity: Error --> Call to a member function row() on a non-object /home/aelbfopi/amarcement.com/application/models/Common_model.php 1264
INFO - 2021-05-17 01:57:09 --> Config Class Initialized
INFO - 2021-05-17 01:57:09 --> Hooks Class Initialized
DEBUG - 2021-05-17 01:57:09 --> UTF-8 Support Enabled
INFO - 2021-05-17 01:57:09 --> Utf8 Class Initialized
INFO - 2021-05-17 01:57:09 --> URI Class Initialized
INFO - 2021-05-17 01:57:09 --> Router Class Initialized
INFO - 2021-05-17 01:57:09 --> Output Class Initialized
INFO - 2021-05-17 01:57:09 --> Security Class Initialized
DEBUG - 2021-05-17 01:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 01:57:09 --> Input Class Initialized
INFO - 2021-05-17 01:57:09 --> Language Class Initialized
INFO - 2021-05-17 01:57:09 --> Loader Class Initialized
INFO - 2021-05-17 01:57:09 --> Helper loaded: url_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: file_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: utility_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: unit_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 01:57:09 --> Database Driver Class Initialized
INFO - 2021-05-17 01:57:09 --> Email Class Initialized
DEBUG - 2021-05-17 01:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 01:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 01:57:09 --> Helper loaded: form_helper
INFO - 2021-05-17 01:57:09 --> Form Validation Class Initialized
INFO - 2021-05-17 01:57:09 --> Controller Class Initialized
INFO - 2021-05-17 01:57:09 --> Model "Common_model" initialized
INFO - 2021-05-17 01:57:09 --> Model "Finane_Model" initialized
INFO - 2021-05-17 01:57:09 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 01:57:09 --> Model "Sales_Model" initialized
INFO - 2021-05-17 01:57:09 --> Config Class Initialized
INFO - 2021-05-17 01:57:09 --> Hooks Class Initialized
DEBUG - 2021-05-17 01:57:09 --> UTF-8 Support Enabled
INFO - 2021-05-17 01:57:09 --> Utf8 Class Initialized
INFO - 2021-05-17 01:57:09 --> URI Class Initialized
INFO - 2021-05-17 01:57:09 --> Router Class Initialized
INFO - 2021-05-17 01:57:09 --> Output Class Initialized
INFO - 2021-05-17 01:57:09 --> Security Class Initialized
DEBUG - 2021-05-17 01:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 01:57:09 --> Input Class Initialized
INFO - 2021-05-17 01:57:09 --> Language Class Initialized
INFO - 2021-05-17 01:57:09 --> Loader Class Initialized
INFO - 2021-05-17 01:57:09 --> Helper loaded: url_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: file_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: utility_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: unit_helper
INFO - 2021-05-17 01:57:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 01:57:09 --> Database Driver Class Initialized
INFO - 2021-05-17 01:57:09 --> Email Class Initialized
DEBUG - 2021-05-17 01:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 01:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 01:57:09 --> Helper loaded: form_helper
INFO - 2021-05-17 01:57:09 --> Form Validation Class Initialized
INFO - 2021-05-17 01:57:09 --> Controller Class Initialized
INFO - 2021-05-17 01:57:09 --> Model "Common_model" initialized
INFO - 2021-05-17 01:57:09 --> Model "Finane_Model" initialized
INFO - 2021-05-17 01:57:09 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 01:57:09 --> Model "Sales_Model" initialized
INFO - 2021-05-17 01:57:09 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/forgotpassword.php
INFO - 2021-05-17 01:57:09 --> Final output sent to browser
DEBUG - 2021-05-17 01:57:09 --> Total execution time: 0.0378
INFO - 2021-05-17 02:06:46 --> Config Class Initialized
INFO - 2021-05-17 02:06:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 02:06:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 02:06:46 --> Utf8 Class Initialized
INFO - 2021-05-17 02:06:46 --> URI Class Initialized
INFO - 2021-05-17 02:06:46 --> Router Class Initialized
INFO - 2021-05-17 02:06:46 --> Output Class Initialized
INFO - 2021-05-17 02:06:46 --> Security Class Initialized
DEBUG - 2021-05-17 02:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 02:06:46 --> Input Class Initialized
INFO - 2021-05-17 02:06:46 --> Language Class Initialized
INFO - 2021-05-17 02:06:46 --> Loader Class Initialized
INFO - 2021-05-17 02:06:46 --> Helper loaded: url_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: file_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 02:06:46 --> Database Driver Class Initialized
INFO - 2021-05-17 02:06:46 --> Email Class Initialized
DEBUG - 2021-05-17 02:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 02:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 02:06:46 --> Helper loaded: form_helper
INFO - 2021-05-17 02:06:46 --> Form Validation Class Initialized
INFO - 2021-05-17 02:06:46 --> Controller Class Initialized
INFO - 2021-05-17 02:06:46 --> Model "Common_model" initialized
INFO - 2021-05-17 02:06:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 02:06:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 02:06:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 02:06:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 02:06:46 --> Final output sent to browser
DEBUG - 2021-05-17 02:06:46 --> Total execution time: 0.0490
INFO - 2021-05-17 02:06:46 --> Config Class Initialized
INFO - 2021-05-17 02:06:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 02:06:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 02:06:46 --> Utf8 Class Initialized
INFO - 2021-05-17 02:06:46 --> URI Class Initialized
DEBUG - 2021-05-17 02:06:46 --> No URI present. Default controller set.
INFO - 2021-05-17 02:06:46 --> Router Class Initialized
INFO - 2021-05-17 02:06:46 --> Output Class Initialized
INFO - 2021-05-17 02:06:46 --> Security Class Initialized
DEBUG - 2021-05-17 02:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 02:06:46 --> Input Class Initialized
INFO - 2021-05-17 02:06:46 --> Language Class Initialized
INFO - 2021-05-17 02:06:46 --> Loader Class Initialized
INFO - 2021-05-17 02:06:46 --> Helper loaded: url_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: file_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 02:06:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 02:06:46 --> Database Driver Class Initialized
INFO - 2021-05-17 02:06:46 --> Email Class Initialized
DEBUG - 2021-05-17 02:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 02:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 02:06:46 --> Helper loaded: form_helper
INFO - 2021-05-17 02:06:46 --> Form Validation Class Initialized
INFO - 2021-05-17 02:06:46 --> Controller Class Initialized
INFO - 2021-05-17 02:06:46 --> Model "Common_model" initialized
INFO - 2021-05-17 02:06:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 02:06:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 02:06:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 02:06:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 02:06:46 --> Final output sent to browser
DEBUG - 2021-05-17 02:06:46 --> Total execution time: 0.0380
INFO - 2021-05-17 02:25:14 --> Config Class Initialized
INFO - 2021-05-17 02:25:14 --> Hooks Class Initialized
DEBUG - 2021-05-17 02:25:14 --> UTF-8 Support Enabled
INFO - 2021-05-17 02:25:14 --> Utf8 Class Initialized
INFO - 2021-05-17 02:25:14 --> URI Class Initialized
INFO - 2021-05-17 02:25:14 --> Router Class Initialized
INFO - 2021-05-17 02:25:14 --> Output Class Initialized
INFO - 2021-05-17 02:25:14 --> Security Class Initialized
DEBUG - 2021-05-17 02:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 02:25:14 --> Input Class Initialized
INFO - 2021-05-17 02:25:14 --> Language Class Initialized
INFO - 2021-05-17 02:25:14 --> Loader Class Initialized
INFO - 2021-05-17 02:25:14 --> Helper loaded: url_helper
INFO - 2021-05-17 02:25:14 --> Helper loaded: file_helper
INFO - 2021-05-17 02:25:14 --> Helper loaded: utility_helper
INFO - 2021-05-17 02:25:14 --> Helper loaded: unit_helper
INFO - 2021-05-17 02:25:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 02:25:14 --> Database Driver Class Initialized
INFO - 2021-05-17 02:25:14 --> Email Class Initialized
DEBUG - 2021-05-17 02:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 02:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 02:25:14 --> Helper loaded: form_helper
INFO - 2021-05-17 02:25:14 --> Form Validation Class Initialized
INFO - 2021-05-17 02:25:14 --> Controller Class Initialized
INFO - 2021-05-17 02:25:14 --> Model "Common_model" initialized
INFO - 2021-05-17 02:25:14 --> Model "Finane_Model" initialized
INFO - 2021-05-17 02:25:14 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 02:25:14 --> Model "Sales_Model" initialized
INFO - 2021-05-17 02:25:14 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 02:25:14 --> Final output sent to browser
DEBUG - 2021-05-17 02:25:14 --> Total execution time: 0.0598
INFO - 2021-05-17 02:25:16 --> Config Class Initialized
INFO - 2021-05-17 02:25:16 --> Hooks Class Initialized
DEBUG - 2021-05-17 02:25:16 --> UTF-8 Support Enabled
INFO - 2021-05-17 02:25:16 --> Utf8 Class Initialized
INFO - 2021-05-17 02:25:16 --> URI Class Initialized
DEBUG - 2021-05-17 02:25:16 --> No URI present. Default controller set.
INFO - 2021-05-17 02:25:16 --> Router Class Initialized
INFO - 2021-05-17 02:25:16 --> Output Class Initialized
INFO - 2021-05-17 02:25:16 --> Security Class Initialized
DEBUG - 2021-05-17 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 02:25:16 --> Input Class Initialized
INFO - 2021-05-17 02:25:16 --> Language Class Initialized
INFO - 2021-05-17 02:25:16 --> Loader Class Initialized
INFO - 2021-05-17 02:25:16 --> Helper loaded: url_helper
INFO - 2021-05-17 02:25:16 --> Helper loaded: file_helper
INFO - 2021-05-17 02:25:16 --> Helper loaded: utility_helper
INFO - 2021-05-17 02:25:16 --> Helper loaded: unit_helper
INFO - 2021-05-17 02:25:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 02:25:16 --> Database Driver Class Initialized
INFO - 2021-05-17 02:25:16 --> Email Class Initialized
DEBUG - 2021-05-17 02:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 02:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 02:25:16 --> Helper loaded: form_helper
INFO - 2021-05-17 02:25:16 --> Form Validation Class Initialized
INFO - 2021-05-17 02:25:16 --> Controller Class Initialized
INFO - 2021-05-17 02:25:16 --> Model "Common_model" initialized
INFO - 2021-05-17 02:25:16 --> Model "Finane_Model" initialized
INFO - 2021-05-17 02:25:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 02:25:16 --> Model "Sales_Model" initialized
INFO - 2021-05-17 02:25:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 02:25:16 --> Final output sent to browser
DEBUG - 2021-05-17 02:25:16 --> Total execution time: 0.0381
INFO - 2021-05-17 03:10:07 --> Config Class Initialized
INFO - 2021-05-17 03:10:07 --> Hooks Class Initialized
DEBUG - 2021-05-17 03:10:07 --> UTF-8 Support Enabled
INFO - 2021-05-17 03:10:07 --> Utf8 Class Initialized
INFO - 2021-05-17 03:10:07 --> URI Class Initialized
DEBUG - 2021-05-17 03:10:07 --> No URI present. Default controller set.
INFO - 2021-05-17 03:10:07 --> Router Class Initialized
INFO - 2021-05-17 03:10:07 --> Output Class Initialized
INFO - 2021-05-17 03:10:07 --> Security Class Initialized
DEBUG - 2021-05-17 03:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 03:10:07 --> Input Class Initialized
INFO - 2021-05-17 03:10:07 --> Language Class Initialized
INFO - 2021-05-17 03:10:07 --> Loader Class Initialized
INFO - 2021-05-17 03:10:07 --> Helper loaded: url_helper
INFO - 2021-05-17 03:10:07 --> Helper loaded: file_helper
INFO - 2021-05-17 03:10:07 --> Helper loaded: utility_helper
INFO - 2021-05-17 03:10:07 --> Helper loaded: unit_helper
INFO - 2021-05-17 03:10:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 03:10:07 --> Database Driver Class Initialized
INFO - 2021-05-17 03:10:07 --> Email Class Initialized
DEBUG - 2021-05-17 03:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 03:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 03:10:07 --> Helper loaded: form_helper
INFO - 2021-05-17 03:10:07 --> Form Validation Class Initialized
INFO - 2021-05-17 03:10:07 --> Controller Class Initialized
INFO - 2021-05-17 03:10:07 --> Model "Common_model" initialized
INFO - 2021-05-17 03:10:07 --> Model "Finane_Model" initialized
INFO - 2021-05-17 03:10:07 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 03:10:07 --> Model "Sales_Model" initialized
INFO - 2021-05-17 03:10:07 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 03:10:07 --> Final output sent to browser
DEBUG - 2021-05-17 03:10:07 --> Total execution time: 0.0591
INFO - 2021-05-17 04:11:09 --> Config Class Initialized
INFO - 2021-05-17 04:11:09 --> Hooks Class Initialized
DEBUG - 2021-05-17 04:11:09 --> UTF-8 Support Enabled
INFO - 2021-05-17 04:11:09 --> Utf8 Class Initialized
INFO - 2021-05-17 04:11:09 --> URI Class Initialized
DEBUG - 2021-05-17 04:11:09 --> No URI present. Default controller set.
INFO - 2021-05-17 04:11:09 --> Router Class Initialized
INFO - 2021-05-17 04:11:09 --> Output Class Initialized
INFO - 2021-05-17 04:11:09 --> Security Class Initialized
DEBUG - 2021-05-17 04:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 04:11:09 --> Input Class Initialized
INFO - 2021-05-17 04:11:09 --> Language Class Initialized
INFO - 2021-05-17 04:11:09 --> Loader Class Initialized
INFO - 2021-05-17 04:11:09 --> Helper loaded: url_helper
INFO - 2021-05-17 04:11:09 --> Helper loaded: file_helper
INFO - 2021-05-17 04:11:09 --> Helper loaded: utility_helper
INFO - 2021-05-17 04:11:09 --> Helper loaded: unit_helper
INFO - 2021-05-17 04:11:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 04:11:09 --> Database Driver Class Initialized
INFO - 2021-05-17 04:11:09 --> Email Class Initialized
DEBUG - 2021-05-17 04:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 04:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 04:11:09 --> Helper loaded: form_helper
INFO - 2021-05-17 04:11:09 --> Form Validation Class Initialized
INFO - 2021-05-17 04:11:09 --> Controller Class Initialized
INFO - 2021-05-17 04:11:09 --> Model "Common_model" initialized
INFO - 2021-05-17 04:11:09 --> Model "Finane_Model" initialized
INFO - 2021-05-17 04:11:09 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 04:11:09 --> Model "Sales_Model" initialized
INFO - 2021-05-17 04:11:09 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 04:11:09 --> Final output sent to browser
DEBUG - 2021-05-17 04:11:09 --> Total execution time: 0.0588
INFO - 2021-05-17 05:51:56 --> Config Class Initialized
INFO - 2021-05-17 05:51:56 --> Hooks Class Initialized
DEBUG - 2021-05-17 05:51:56 --> UTF-8 Support Enabled
INFO - 2021-05-17 05:51:56 --> Utf8 Class Initialized
INFO - 2021-05-17 05:51:56 --> URI Class Initialized
INFO - 2021-05-17 05:51:56 --> Router Class Initialized
INFO - 2021-05-17 05:51:56 --> Output Class Initialized
INFO - 2021-05-17 05:51:56 --> Security Class Initialized
DEBUG - 2021-05-17 05:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 05:51:56 --> Input Class Initialized
INFO - 2021-05-17 05:51:56 --> Language Class Initialized
INFO - 2021-05-17 05:51:56 --> Loader Class Initialized
INFO - 2021-05-17 05:51:56 --> Helper loaded: url_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: file_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: utility_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: unit_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 05:51:56 --> Database Driver Class Initialized
INFO - 2021-05-17 05:51:56 --> Email Class Initialized
DEBUG - 2021-05-17 05:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 05:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 05:51:56 --> Helper loaded: form_helper
INFO - 2021-05-17 05:51:56 --> Form Validation Class Initialized
INFO - 2021-05-17 05:51:56 --> Controller Class Initialized
INFO - 2021-05-17 05:51:56 --> Model "Common_model" initialized
INFO - 2021-05-17 05:51:56 --> Model "Finane_Model" initialized
INFO - 2021-05-17 05:51:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 05:51:56 --> Model "Sales_Model" initialized
INFO - 2021-05-17 05:51:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 05:51:56 --> Final output sent to browser
DEBUG - 2021-05-17 05:51:56 --> Total execution time: 0.0563
INFO - 2021-05-17 05:51:56 --> Config Class Initialized
INFO - 2021-05-17 05:51:56 --> Hooks Class Initialized
DEBUG - 2021-05-17 05:51:56 --> UTF-8 Support Enabled
INFO - 2021-05-17 05:51:56 --> Utf8 Class Initialized
INFO - 2021-05-17 05:51:56 --> URI Class Initialized
INFO - 2021-05-17 05:51:56 --> Router Class Initialized
INFO - 2021-05-17 05:51:56 --> Output Class Initialized
INFO - 2021-05-17 05:51:56 --> Security Class Initialized
DEBUG - 2021-05-17 05:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 05:51:56 --> Input Class Initialized
INFO - 2021-05-17 05:51:56 --> Language Class Initialized
INFO - 2021-05-17 05:51:56 --> Loader Class Initialized
INFO - 2021-05-17 05:51:56 --> Helper loaded: url_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: file_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: utility_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: unit_helper
INFO - 2021-05-17 05:51:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 05:51:56 --> Database Driver Class Initialized
INFO - 2021-05-17 05:51:56 --> Email Class Initialized
DEBUG - 2021-05-17 05:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 05:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 05:51:56 --> Helper loaded: form_helper
INFO - 2021-05-17 05:51:56 --> Form Validation Class Initialized
INFO - 2021-05-17 05:51:56 --> Controller Class Initialized
INFO - 2021-05-17 05:51:56 --> Model "Common_model" initialized
INFO - 2021-05-17 05:51:56 --> Model "Finane_Model" initialized
INFO - 2021-05-17 05:51:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 05:51:56 --> Model "Sales_Model" initialized
INFO - 2021-05-17 05:51:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 05:51:56 --> Final output sent to browser
DEBUG - 2021-05-17 05:51:56 --> Total execution time: 0.0406
INFO - 2021-05-17 06:43:06 --> Config Class Initialized
INFO - 2021-05-17 06:43:06 --> Hooks Class Initialized
DEBUG - 2021-05-17 06:43:06 --> UTF-8 Support Enabled
INFO - 2021-05-17 06:43:06 --> Utf8 Class Initialized
INFO - 2021-05-17 06:43:06 --> URI Class Initialized
DEBUG - 2021-05-17 06:43:06 --> No URI present. Default controller set.
INFO - 2021-05-17 06:43:06 --> Router Class Initialized
INFO - 2021-05-17 06:43:06 --> Output Class Initialized
INFO - 2021-05-17 06:43:06 --> Security Class Initialized
DEBUG - 2021-05-17 06:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 06:43:06 --> Input Class Initialized
INFO - 2021-05-17 06:43:06 --> Language Class Initialized
INFO - 2021-05-17 06:43:06 --> Loader Class Initialized
INFO - 2021-05-17 06:43:06 --> Helper loaded: url_helper
INFO - 2021-05-17 06:43:06 --> Helper loaded: file_helper
INFO - 2021-05-17 06:43:06 --> Helper loaded: utility_helper
INFO - 2021-05-17 06:43:06 --> Helper loaded: unit_helper
INFO - 2021-05-17 06:43:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 06:43:06 --> Database Driver Class Initialized
INFO - 2021-05-17 06:43:06 --> Email Class Initialized
DEBUG - 2021-05-17 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 06:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 06:43:06 --> Helper loaded: form_helper
INFO - 2021-05-17 06:43:06 --> Form Validation Class Initialized
INFO - 2021-05-17 06:43:06 --> Controller Class Initialized
INFO - 2021-05-17 06:43:06 --> Model "Common_model" initialized
INFO - 2021-05-17 06:43:06 --> Model "Finane_Model" initialized
INFO - 2021-05-17 06:43:06 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 06:43:06 --> Model "Sales_Model" initialized
INFO - 2021-05-17 06:43:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 06:43:06 --> Final output sent to browser
DEBUG - 2021-05-17 06:43:06 --> Total execution time: 0.0620
INFO - 2021-05-17 09:10:38 --> Config Class Initialized
INFO - 2021-05-17 09:10:38 --> Hooks Class Initialized
DEBUG - 2021-05-17 09:10:38 --> UTF-8 Support Enabled
INFO - 2021-05-17 09:10:38 --> Utf8 Class Initialized
INFO - 2021-05-17 09:10:38 --> URI Class Initialized
INFO - 2021-05-17 09:10:38 --> Router Class Initialized
INFO - 2021-05-17 09:10:38 --> Output Class Initialized
INFO - 2021-05-17 09:10:38 --> Security Class Initialized
DEBUG - 2021-05-17 09:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 09:10:38 --> Input Class Initialized
INFO - 2021-05-17 09:10:38 --> Language Class Initialized
ERROR - 2021-05-17 09:10:38 --> 404 Page Not Found: admin/Assets/jquery.filer
INFO - 2021-05-17 09:10:44 --> Config Class Initialized
INFO - 2021-05-17 09:10:44 --> Hooks Class Initialized
DEBUG - 2021-05-17 09:10:44 --> UTF-8 Support Enabled
INFO - 2021-05-17 09:10:44 --> Utf8 Class Initialized
INFO - 2021-05-17 09:10:44 --> URI Class Initialized
INFO - 2021-05-17 09:10:44 --> Router Class Initialized
INFO - 2021-05-17 09:10:44 --> Output Class Initialized
INFO - 2021-05-17 09:10:44 --> Security Class Initialized
DEBUG - 2021-05-17 09:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 09:10:44 --> Input Class Initialized
INFO - 2021-05-17 09:10:44 --> Language Class Initialized
ERROR - 2021-05-17 09:10:44 --> 404 Page Not Found: Public/assets
INFO - 2021-05-17 09:10:46 --> Config Class Initialized
INFO - 2021-05-17 09:10:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 09:10:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 09:10:46 --> Utf8 Class Initialized
INFO - 2021-05-17 09:10:46 --> URI Class Initialized
INFO - 2021-05-17 09:10:46 --> Router Class Initialized
INFO - 2021-05-17 09:10:46 --> Output Class Initialized
INFO - 2021-05-17 09:10:46 --> Security Class Initialized
DEBUG - 2021-05-17 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 09:10:46 --> Input Class Initialized
INFO - 2021-05-17 09:10:46 --> Language Class Initialized
ERROR - 2021-05-17 09:10:46 --> 404 Page Not Found: Assets/newweb
INFO - 2021-05-17 09:10:47 --> Config Class Initialized
INFO - 2021-05-17 09:10:47 --> Hooks Class Initialized
DEBUG - 2021-05-17 09:10:47 --> UTF-8 Support Enabled
INFO - 2021-05-17 09:10:47 --> Utf8 Class Initialized
INFO - 2021-05-17 09:10:47 --> URI Class Initialized
INFO - 2021-05-17 09:10:47 --> Router Class Initialized
INFO - 2021-05-17 09:10:47 --> Output Class Initialized
INFO - 2021-05-17 09:10:47 --> Security Class Initialized
DEBUG - 2021-05-17 09:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 09:10:47 --> Input Class Initialized
INFO - 2021-05-17 09:10:47 --> Language Class Initialized
ERROR - 2021-05-17 09:10:47 --> 404 Page Not Found: Assets/jquery.filer
INFO - 2021-05-17 11:12:07 --> Config Class Initialized
INFO - 2021-05-17 11:12:07 --> Hooks Class Initialized
DEBUG - 2021-05-17 11:12:07 --> UTF-8 Support Enabled
INFO - 2021-05-17 11:12:07 --> Utf8 Class Initialized
INFO - 2021-05-17 11:12:07 --> URI Class Initialized
INFO - 2021-05-17 11:12:07 --> Router Class Initialized
INFO - 2021-05-17 11:12:07 --> Output Class Initialized
INFO - 2021-05-17 11:12:07 --> Security Class Initialized
DEBUG - 2021-05-17 11:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 11:12:07 --> Input Class Initialized
INFO - 2021-05-17 11:12:07 --> Language Class Initialized
ERROR - 2021-05-17 11:12:07 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-17 11:12:07 --> Config Class Initialized
INFO - 2021-05-17 11:12:07 --> Hooks Class Initialized
DEBUG - 2021-05-17 11:12:07 --> UTF-8 Support Enabled
INFO - 2021-05-17 11:12:07 --> Utf8 Class Initialized
INFO - 2021-05-17 11:12:07 --> URI Class Initialized
INFO - 2021-05-17 11:12:07 --> Router Class Initialized
INFO - 2021-05-17 11:12:07 --> Output Class Initialized
INFO - 2021-05-17 11:12:07 --> Security Class Initialized
DEBUG - 2021-05-17 11:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 11:12:07 --> Input Class Initialized
INFO - 2021-05-17 11:12:07 --> Language Class Initialized
ERROR - 2021-05-17 11:12:07 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-17 11:12:07 --> Config Class Initialized
INFO - 2021-05-17 11:12:07 --> Hooks Class Initialized
DEBUG - 2021-05-17 11:12:07 --> UTF-8 Support Enabled
INFO - 2021-05-17 11:12:07 --> Utf8 Class Initialized
INFO - 2021-05-17 11:12:07 --> URI Class Initialized
INFO - 2021-05-17 11:12:07 --> Router Class Initialized
INFO - 2021-05-17 11:12:07 --> Output Class Initialized
INFO - 2021-05-17 11:12:07 --> Security Class Initialized
DEBUG - 2021-05-17 11:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 11:12:07 --> Input Class Initialized
INFO - 2021-05-17 11:12:07 --> Language Class Initialized
ERROR - 2021-05-17 11:12:07 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-17 14:54:42 --> Config Class Initialized
INFO - 2021-05-17 14:54:42 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:54:42 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:54:42 --> Utf8 Class Initialized
INFO - 2021-05-17 14:54:42 --> URI Class Initialized
INFO - 2021-05-17 14:54:42 --> Router Class Initialized
INFO - 2021-05-17 14:54:42 --> Output Class Initialized
INFO - 2021-05-17 14:54:42 --> Security Class Initialized
DEBUG - 2021-05-17 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:54:42 --> Input Class Initialized
INFO - 2021-05-17 14:54:42 --> Language Class Initialized
INFO - 2021-05-17 14:54:42 --> Loader Class Initialized
INFO - 2021-05-17 14:54:42 --> Helper loaded: url_helper
INFO - 2021-05-17 14:54:42 --> Helper loaded: file_helper
INFO - 2021-05-17 14:54:42 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:54:42 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:54:42 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:54:42 --> Database Driver Class Initialized
INFO - 2021-05-17 14:54:42 --> Email Class Initialized
DEBUG - 2021-05-17 14:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:54:42 --> Helper loaded: form_helper
INFO - 2021-05-17 14:54:42 --> Form Validation Class Initialized
INFO - 2021-05-17 14:54:42 --> Controller Class Initialized
INFO - 2021-05-17 14:54:42 --> Model "Common_model" initialized
INFO - 2021-05-17 14:54:42 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:54:42 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:54:42 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:54:42 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 14:54:42 --> Final output sent to browser
DEBUG - 2021-05-17 14:54:42 --> Total execution time: 0.1591
INFO - 2021-05-17 14:54:55 --> Config Class Initialized
INFO - 2021-05-17 14:54:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:54:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:54:55 --> Utf8 Class Initialized
INFO - 2021-05-17 14:54:55 --> URI Class Initialized
INFO - 2021-05-17 14:54:55 --> Router Class Initialized
INFO - 2021-05-17 14:54:55 --> Output Class Initialized
INFO - 2021-05-17 14:54:55 --> Security Class Initialized
DEBUG - 2021-05-17 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:54:55 --> Input Class Initialized
INFO - 2021-05-17 14:54:55 --> Language Class Initialized
INFO - 2021-05-17 14:54:55 --> Loader Class Initialized
INFO - 2021-05-17 14:54:55 --> Helper loaded: url_helper
INFO - 2021-05-17 14:54:55 --> Helper loaded: file_helper
INFO - 2021-05-17 14:54:55 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:54:55 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:54:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:54:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:54:55 --> Email Class Initialized
DEBUG - 2021-05-17 14:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:54:55 --> Helper loaded: form_helper
INFO - 2021-05-17 14:54:55 --> Form Validation Class Initialized
INFO - 2021-05-17 14:54:55 --> Controller Class Initialized
INFO - 2021-05-17 14:54:55 --> Model "Common_model" initialized
INFO - 2021-05-17 14:54:55 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:54:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:54:55 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:54:56 --> Config Class Initialized
INFO - 2021-05-17 14:54:56 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:54:56 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:54:56 --> Utf8 Class Initialized
INFO - 2021-05-17 14:54:56 --> URI Class Initialized
INFO - 2021-05-17 14:54:56 --> Router Class Initialized
INFO - 2021-05-17 14:54:56 --> Output Class Initialized
INFO - 2021-05-17 14:54:56 --> Security Class Initialized
DEBUG - 2021-05-17 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:54:56 --> Input Class Initialized
INFO - 2021-05-17 14:54:56 --> Language Class Initialized
INFO - 2021-05-17 14:54:56 --> Loader Class Initialized
INFO - 2021-05-17 14:54:56 --> Helper loaded: url_helper
INFO - 2021-05-17 14:54:56 --> Helper loaded: file_helper
INFO - 2021-05-17 14:54:56 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:54:56 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:54:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:54:56 --> Database Driver Class Initialized
INFO - 2021-05-17 14:54:56 --> Email Class Initialized
DEBUG - 2021-05-17 14:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:54:56 --> Helper loaded: form_helper
INFO - 2021-05-17 14:54:56 --> Form Validation Class Initialized
INFO - 2021-05-17 14:54:56 --> Controller Class Initialized
INFO - 2021-05-17 14:54:56 --> Model "Common_model" initialized
INFO - 2021-05-17 14:54:56 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:54:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:54:56 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:54:56 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:54:56 --> Database Driver Class Initialized
INFO - 2021-05-17 14:54:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-05-17 14:54:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-05-17 14:54:56 --> Final output sent to browser
DEBUG - 2021-05-17 14:54:56 --> Total execution time: 0.2858
INFO - 2021-05-17 14:54:59 --> Config Class Initialized
INFO - 2021-05-17 14:54:59 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:54:59 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:54:59 --> Utf8 Class Initialized
INFO - 2021-05-17 14:54:59 --> URI Class Initialized
INFO - 2021-05-17 14:54:59 --> Router Class Initialized
INFO - 2021-05-17 14:54:59 --> Output Class Initialized
INFO - 2021-05-17 14:54:59 --> Security Class Initialized
DEBUG - 2021-05-17 14:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:54:59 --> Input Class Initialized
INFO - 2021-05-17 14:54:59 --> Language Class Initialized
INFO - 2021-05-17 14:54:59 --> Loader Class Initialized
INFO - 2021-05-17 14:54:59 --> Helper loaded: url_helper
INFO - 2021-05-17 14:54:59 --> Helper loaded: file_helper
INFO - 2021-05-17 14:54:59 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:54:59 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:54:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:54:59 --> Database Driver Class Initialized
INFO - 2021-05-17 14:54:59 --> Email Class Initialized
DEBUG - 2021-05-17 14:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:54:59 --> Helper loaded: form_helper
INFO - 2021-05-17 14:54:59 --> Form Validation Class Initialized
INFO - 2021-05-17 14:54:59 --> Controller Class Initialized
INFO - 2021-05-17 14:54:59 --> Model "Common_model" initialized
INFO - 2021-05-17 14:54:59 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:54:59 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:54:59 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:54:59 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:54:59 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-17 14:55:00 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:00 --> Total execution time: 0.6692
INFO - 2021-05-17 14:55:00 --> Config Class Initialized
INFO - 2021-05-17 14:55:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:00 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:00 --> URI Class Initialized
INFO - 2021-05-17 14:55:00 --> Router Class Initialized
INFO - 2021-05-17 14:55:00 --> Output Class Initialized
INFO - 2021-05-17 14:55:00 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:00 --> Input Class Initialized
INFO - 2021-05-17 14:55:00 --> Language Class Initialized
INFO - 2021-05-17 14:55:00 --> Loader Class Initialized
INFO - 2021-05-17 14:55:00 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:00 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:00 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:00 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:00 --> Controller Class Initialized
INFO - 2021-05-17 14:55:00 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:00 --> Config Class Initialized
INFO - 2021-05-17 14:55:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:00 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:00 --> URI Class Initialized
INFO - 2021-05-17 14:55:00 --> Router Class Initialized
INFO - 2021-05-17 14:55:00 --> Output Class Initialized
INFO - 2021-05-17 14:55:00 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:00 --> Input Class Initialized
INFO - 2021-05-17 14:55:00 --> Language Class Initialized
INFO - 2021-05-17 14:55:00 --> Loader Class Initialized
INFO - 2021-05-17 14:55:00 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:00 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-05-17 14:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-17 14:55:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-17 14:55:00 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:00 --> Total execution time: 0.4642
INFO - 2021-05-17 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:00 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:00 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:00 --> Controller Class Initialized
INFO - 2021-05-17 14:55:00 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-17 14:55:00 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:00 --> Total execution time: 0.2234
INFO - 2021-05-17 14:55:01 --> Config Class Initialized
INFO - 2021-05-17 14:55:01 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:01 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:01 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:01 --> URI Class Initialized
INFO - 2021-05-17 14:55:01 --> Router Class Initialized
INFO - 2021-05-17 14:55:01 --> Output Class Initialized
INFO - 2021-05-17 14:55:01 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:01 --> Input Class Initialized
INFO - 2021-05-17 14:55:01 --> Language Class Initialized
ERROR - 2021-05-17 14:55:01 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:55:03 --> Config Class Initialized
INFO - 2021-05-17 14:55:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:03 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:03 --> URI Class Initialized
INFO - 2021-05-17 14:55:03 --> Router Class Initialized
INFO - 2021-05-17 14:55:03 --> Output Class Initialized
INFO - 2021-05-17 14:55:03 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:03 --> Input Class Initialized
INFO - 2021-05-17 14:55:03 --> Language Class Initialized
INFO - 2021-05-17 14:55:03 --> Loader Class Initialized
INFO - 2021-05-17 14:55:03 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:03 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:03 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:03 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:03 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:03 --> Controller Class Initialized
INFO - 2021-05-17 14:55:03 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:03 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:03 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:03 --> Config Class Initialized
INFO - 2021-05-17 14:55:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:03 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:03 --> URI Class Initialized
INFO - 2021-05-17 14:55:03 --> Router Class Initialized
INFO - 2021-05-17 14:55:03 --> Output Class Initialized
INFO - 2021-05-17 14:55:03 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:03 --> Input Class Initialized
INFO - 2021-05-17 14:55:03 --> Language Class Initialized
INFO - 2021-05-17 14:55:03 --> Loader Class Initialized
INFO - 2021-05-17 14:55:03 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:03 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:03 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:03 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:03 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:03 --> Controller Class Initialized
INFO - 2021-05-17 14:55:03 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:03 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:03 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:03 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:03 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:04 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:04 --> Total execution time: 0.9223
INFO - 2021-05-17 14:55:25 --> Config Class Initialized
INFO - 2021-05-17 14:55:25 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:25 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:25 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:25 --> URI Class Initialized
INFO - 2021-05-17 14:55:25 --> Router Class Initialized
INFO - 2021-05-17 14:55:25 --> Output Class Initialized
INFO - 2021-05-17 14:55:25 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:25 --> Input Class Initialized
INFO - 2021-05-17 14:55:25 --> Language Class Initialized
INFO - 2021-05-17 14:55:26 --> Loader Class Initialized
INFO - 2021-05-17 14:55:26 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:26 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:26 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:26 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:26 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:26 --> Controller Class Initialized
INFO - 2021-05-17 14:55:26 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:26 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:26 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:26 --> Total execution time: 0.1368
INFO - 2021-05-17 14:55:26 --> Config Class Initialized
INFO - 2021-05-17 14:55:26 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:26 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:26 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:26 --> URI Class Initialized
INFO - 2021-05-17 14:55:26 --> Router Class Initialized
INFO - 2021-05-17 14:55:26 --> Output Class Initialized
INFO - 2021-05-17 14:55:26 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:26 --> Input Class Initialized
INFO - 2021-05-17 14:55:26 --> Language Class Initialized
ERROR - 2021-05-17 14:55:26 --> 404 Page Not Found: Cement_demo/DistributorDashboard
INFO - 2021-05-17 14:55:26 --> Config Class Initialized
INFO - 2021-05-17 14:55:26 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:26 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:26 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:26 --> URI Class Initialized
INFO - 2021-05-17 14:55:26 --> Router Class Initialized
INFO - 2021-05-17 14:55:26 --> Output Class Initialized
INFO - 2021-05-17 14:55:26 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:26 --> Input Class Initialized
INFO - 2021-05-17 14:55:26 --> Language Class Initialized
INFO - 2021-05-17 14:55:26 --> Loader Class Initialized
INFO - 2021-05-17 14:55:26 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:26 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:26 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:26 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:26 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:26 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:26 --> Controller Class Initialized
INFO - 2021-05-17 14:55:26 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:26 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:26 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-17 14:55:26 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:26 --> Total execution time: 0.1026
INFO - 2021-05-17 14:55:27 --> Config Class Initialized
INFO - 2021-05-17 14:55:27 --> Config Class Initialized
INFO - 2021-05-17 14:55:27 --> Hooks Class Initialized
INFO - 2021-05-17 14:55:27 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:27 --> UTF-8 Support Enabled
DEBUG - 2021-05-17 14:55:27 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:27 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:27 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:27 --> URI Class Initialized
INFO - 2021-05-17 14:55:27 --> URI Class Initialized
INFO - 2021-05-17 14:55:27 --> Router Class Initialized
INFO - 2021-05-17 14:55:27 --> Router Class Initialized
INFO - 2021-05-17 14:55:27 --> Output Class Initialized
INFO - 2021-05-17 14:55:27 --> Output Class Initialized
INFO - 2021-05-17 14:55:27 --> Security Class Initialized
INFO - 2021-05-17 14:55:27 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-17 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:27 --> Input Class Initialized
INFO - 2021-05-17 14:55:27 --> Input Class Initialized
INFO - 2021-05-17 14:55:27 --> Language Class Initialized
INFO - 2021-05-17 14:55:27 --> Language Class Initialized
INFO - 2021-05-17 14:55:27 --> Loader Class Initialized
INFO - 2021-05-17 14:55:27 --> Loader Class Initialized
INFO - 2021-05-17 14:55:27 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:27 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:27 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:27 --> Email Class Initialized
INFO - 2021-05-17 14:55:27 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-05-17 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:27 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:27 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:27 --> Controller Class Initialized
INFO - 2021-05-17 14:55:27 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:27 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-17 14:55:27 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:27 --> Total execution time: 0.0729
INFO - 2021-05-17 14:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:27 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:27 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:27 --> Controller Class Initialized
INFO - 2021-05-17 14:55:27 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:27 --> Database Driver Class Initialized
ERROR - 2021-05-17 14:55:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-17 14:55:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-17 14:55:27 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:27 --> Total execution time: 0.1272
INFO - 2021-05-17 14:55:27 --> Config Class Initialized
INFO - 2021-05-17 14:55:27 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:27 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:27 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:27 --> URI Class Initialized
INFO - 2021-05-17 14:55:27 --> Router Class Initialized
INFO - 2021-05-17 14:55:27 --> Output Class Initialized
INFO - 2021-05-17 14:55:27 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:27 --> Input Class Initialized
INFO - 2021-05-17 14:55:27 --> Language Class Initialized
INFO - 2021-05-17 14:55:27 --> Loader Class Initialized
INFO - 2021-05-17 14:55:27 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:27 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:27 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:27 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:27 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:27 --> Controller Class Initialized
INFO - 2021-05-17 14:55:27 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:27 --> Config Class Initialized
INFO - 2021-05-17 14:55:27 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:27 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:27 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:27 --> URI Class Initialized
INFO - 2021-05-17 14:55:27 --> Router Class Initialized
INFO - 2021-05-17 14:55:27 --> Output Class Initialized
INFO - 2021-05-17 14:55:27 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:27 --> Input Class Initialized
INFO - 2021-05-17 14:55:27 --> Language Class Initialized
INFO - 2021-05-17 14:55:27 --> Loader Class Initialized
INFO - 2021-05-17 14:55:27 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:27 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:27 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:27 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:27 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:27 --> Controller Class Initialized
INFO - 2021-05-17 14:55:27 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:27 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:27 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:27 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:27 --> Total execution time: 0.1181
INFO - 2021-05-17 14:55:44 --> Config Class Initialized
INFO - 2021-05-17 14:55:44 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:44 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:44 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:44 --> URI Class Initialized
INFO - 2021-05-17 14:55:44 --> Router Class Initialized
INFO - 2021-05-17 14:55:44 --> Output Class Initialized
INFO - 2021-05-17 14:55:44 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:44 --> Input Class Initialized
INFO - 2021-05-17 14:55:44 --> Language Class Initialized
INFO - 2021-05-17 14:55:44 --> Loader Class Initialized
INFO - 2021-05-17 14:55:44 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:44 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:44 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:44 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:44 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:44 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:44 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:44 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:44 --> Controller Class Initialized
INFO - 2021-05-17 14:55:44 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:44 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:44 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:44 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:44 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:44 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:44 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:44 --> Total execution time: 0.4719
INFO - 2021-05-17 14:55:45 --> Config Class Initialized
INFO - 2021-05-17 14:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:45 --> URI Class Initialized
INFO - 2021-05-17 14:55:45 --> Router Class Initialized
INFO - 2021-05-17 14:55:45 --> Output Class Initialized
INFO - 2021-05-17 14:55:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:45 --> Input Class Initialized
INFO - 2021-05-17 14:55:45 --> Language Class Initialized
ERROR - 2021-05-17 14:55:45 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:55:45 --> Config Class Initialized
INFO - 2021-05-17 14:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:45 --> URI Class Initialized
INFO - 2021-05-17 14:55:45 --> Router Class Initialized
INFO - 2021-05-17 14:55:45 --> Output Class Initialized
INFO - 2021-05-17 14:55:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:45 --> Input Class Initialized
INFO - 2021-05-17 14:55:45 --> Language Class Initialized
INFO - 2021-05-17 14:55:45 --> Loader Class Initialized
INFO - 2021-05-17 14:55:45 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:45 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:45 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:45 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:45 --> Controller Class Initialized
INFO - 2021-05-17 14:55:45 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-17 14:55:45 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:45 --> Total execution time: 0.1047
INFO - 2021-05-17 14:55:45 --> Config Class Initialized
INFO - 2021-05-17 14:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:45 --> URI Class Initialized
INFO - 2021-05-17 14:55:45 --> Router Class Initialized
INFO - 2021-05-17 14:55:45 --> Output Class Initialized
INFO - 2021-05-17 14:55:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:45 --> Input Class Initialized
INFO - 2021-05-17 14:55:45 --> Language Class Initialized
INFO - 2021-05-17 14:55:45 --> Loader Class Initialized
INFO - 2021-05-17 14:55:45 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:45 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:45 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:45 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:45 --> Controller Class Initialized
INFO - 2021-05-17 14:55:45 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:45 --> Config Class Initialized
INFO - 2021-05-17 14:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:45 --> URI Class Initialized
INFO - 2021-05-17 14:55:45 --> Router Class Initialized
INFO - 2021-05-17 14:55:45 --> Output Class Initialized
INFO - 2021-05-17 14:55:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:45 --> Input Class Initialized
INFO - 2021-05-17 14:55:45 --> Language Class Initialized
INFO - 2021-05-17 14:55:45 --> Loader Class Initialized
INFO - 2021-05-17 14:55:45 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:45 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:45 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:45 --> Total execution time: 0.2042
INFO - 2021-05-17 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:45 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:45 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:45 --> Controller Class Initialized
INFO - 2021-05-17 14:55:45 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:45 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-17 14:55:45 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:45 --> Total execution time: 0.1016
INFO - 2021-05-17 14:55:45 --> Config Class Initialized
INFO - 2021-05-17 14:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:45 --> URI Class Initialized
INFO - 2021-05-17 14:55:45 --> Router Class Initialized
INFO - 2021-05-17 14:55:45 --> Output Class Initialized
INFO - 2021-05-17 14:55:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:45 --> Input Class Initialized
INFO - 2021-05-17 14:55:45 --> Language Class Initialized
ERROR - 2021-05-17 14:55:45 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:55:45 --> Config Class Initialized
INFO - 2021-05-17 14:55:45 --> Hooks Class Initialized
INFO - 2021-05-17 14:55:45 --> Config Class Initialized
INFO - 2021-05-17 14:55:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:45 --> URI Class Initialized
DEBUG - 2021-05-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:46 --> URI Class Initialized
INFO - 2021-05-17 14:55:46 --> Router Class Initialized
INFO - 2021-05-17 14:55:46 --> Router Class Initialized
INFO - 2021-05-17 14:55:46 --> Output Class Initialized
INFO - 2021-05-17 14:55:46 --> Security Class Initialized
INFO - 2021-05-17 14:55:46 --> Output Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:46 --> Input Class Initialized
INFO - 2021-05-17 14:55:46 --> Language Class Initialized
INFO - 2021-05-17 14:55:46 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:46 --> Input Class Initialized
INFO - 2021-05-17 14:55:46 --> Language Class Initialized
INFO - 2021-05-17 14:55:46 --> Loader Class Initialized
INFO - 2021-05-17 14:55:46 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:46 --> Loader Class Initialized
INFO - 2021-05-17 14:55:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:46 --> Email Class Initialized
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:46 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:46 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:46 --> Controller Class Initialized
INFO - 2021-05-17 14:55:46 --> Email Class Initialized
INFO - 2021-05-17 14:55:46 --> Model "Common_model" initialized
DEBUG - 2021-05-17 14:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-17 14:55:46 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:46 --> Total execution time: 0.0530
INFO - 2021-05-17 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:46 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:46 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:46 --> Controller Class Initialized
INFO - 2021-05-17 14:55:46 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
ERROR - 2021-05-17 14:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-17 14:55:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-17 14:55:46 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:46 --> Total execution time: 0.0763
INFO - 2021-05-17 14:55:46 --> Config Class Initialized
INFO - 2021-05-17 14:55:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:46 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:46 --> URI Class Initialized
INFO - 2021-05-17 14:55:46 --> Router Class Initialized
INFO - 2021-05-17 14:55:46 --> Output Class Initialized
INFO - 2021-05-17 14:55:46 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:46 --> Input Class Initialized
INFO - 2021-05-17 14:55:46 --> Language Class Initialized
INFO - 2021-05-17 14:55:46 --> Loader Class Initialized
INFO - 2021-05-17 14:55:46 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:46 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:46 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:46 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:46 --> Controller Class Initialized
INFO - 2021-05-17 14:55:46 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:46 --> Config Class Initialized
INFO - 2021-05-17 14:55:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:46 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:46 --> URI Class Initialized
INFO - 2021-05-17 14:55:46 --> Router Class Initialized
INFO - 2021-05-17 14:55:46 --> Output Class Initialized
INFO - 2021-05-17 14:55:46 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:46 --> Input Class Initialized
INFO - 2021-05-17 14:55:46 --> Language Class Initialized
INFO - 2021-05-17 14:55:46 --> Loader Class Initialized
INFO - 2021-05-17 14:55:46 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:46 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:46 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:46 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:46 --> Controller Class Initialized
INFO - 2021-05-17 14:55:46 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
ERROR - 2021-05-17 14:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-17 14:55:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-17 14:55:46 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:46 --> Total execution time: 0.0671
INFO - 2021-05-17 14:55:46 --> Config Class Initialized
INFO - 2021-05-17 14:55:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:46 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:46 --> URI Class Initialized
INFO - 2021-05-17 14:55:46 --> Router Class Initialized
INFO - 2021-05-17 14:55:46 --> Output Class Initialized
INFO - 2021-05-17 14:55:46 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:46 --> Input Class Initialized
INFO - 2021-05-17 14:55:46 --> Language Class Initialized
INFO - 2021-05-17 14:55:46 --> Loader Class Initialized
INFO - 2021-05-17 14:55:46 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:46 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:46 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:46 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:46 --> Controller Class Initialized
INFO - 2021-05-17 14:55:46 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:46 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:46 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:46 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:46 --> Total execution time: 0.1436
INFO - 2021-05-17 14:55:46 --> Config Class Initialized
INFO - 2021-05-17 14:55:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:46 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:46 --> URI Class Initialized
INFO - 2021-05-17 14:55:47 --> Router Class Initialized
INFO - 2021-05-17 14:55:47 --> Output Class Initialized
INFO - 2021-05-17 14:55:47 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:47 --> Input Class Initialized
INFO - 2021-05-17 14:55:47 --> Language Class Initialized
INFO - 2021-05-17 14:55:47 --> Loader Class Initialized
INFO - 2021-05-17 14:55:47 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:47 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:47 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:47 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:47 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:47 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:47 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:47 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:47 --> Controller Class Initialized
INFO - 2021-05-17 14:55:47 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:47 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:47 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:47 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:47 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:47 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-17 14:55:47 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:47 --> Total execution time: 0.0761
INFO - 2021-05-17 14:55:49 --> Config Class Initialized
INFO - 2021-05-17 14:55:49 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:49 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:49 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:49 --> URI Class Initialized
INFO - 2021-05-17 14:55:49 --> Router Class Initialized
INFO - 2021-05-17 14:55:49 --> Output Class Initialized
INFO - 2021-05-17 14:55:49 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:49 --> Input Class Initialized
INFO - 2021-05-17 14:55:49 --> Language Class Initialized
INFO - 2021-05-17 14:55:49 --> Loader Class Initialized
INFO - 2021-05-17 14:55:49 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:49 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:49 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:49 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:49 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:49 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:49 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:49 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:49 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:49 --> Controller Class Initialized
INFO - 2021-05-17 14:55:49 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:49 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:49 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:49 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:49 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:49 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:49 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:49 --> Total execution time: 0.1365
INFO - 2021-05-17 14:55:50 --> Config Class Initialized
INFO - 2021-05-17 14:55:50 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:50 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:50 --> URI Class Initialized
INFO - 2021-05-17 14:55:50 --> Router Class Initialized
INFO - 2021-05-17 14:55:50 --> Output Class Initialized
INFO - 2021-05-17 14:55:50 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:50 --> Input Class Initialized
INFO - 2021-05-17 14:55:50 --> Language Class Initialized
ERROR - 2021-05-17 14:55:50 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:55:50 --> Config Class Initialized
INFO - 2021-05-17 14:55:50 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:50 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:50 --> Config Class Initialized
INFO - 2021-05-17 14:55:50 --> Hooks Class Initialized
INFO - 2021-05-17 14:55:50 --> URI Class Initialized
DEBUG - 2021-05-17 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:50 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:50 --> URI Class Initialized
INFO - 2021-05-17 14:55:50 --> Router Class Initialized
INFO - 2021-05-17 14:55:50 --> Router Class Initialized
INFO - 2021-05-17 14:55:50 --> Output Class Initialized
INFO - 2021-05-17 14:55:50 --> Security Class Initialized
INFO - 2021-05-17 14:55:50 --> Output Class Initialized
DEBUG - 2021-05-17 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:50 --> Input Class Initialized
INFO - 2021-05-17 14:55:50 --> Security Class Initialized
INFO - 2021-05-17 14:55:50 --> Language Class Initialized
DEBUG - 2021-05-17 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:50 --> Input Class Initialized
INFO - 2021-05-17 14:55:50 --> Language Class Initialized
INFO - 2021-05-17 14:55:50 --> Loader Class Initialized
INFO - 2021-05-17 14:55:50 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:50 --> Loader Class Initialized
INFO - 2021-05-17 14:55:50 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:50 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:50 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:50 --> Email Class Initialized
INFO - 2021-05-17 14:55:50 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-05-17 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:50 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:50 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:50 --> Controller Class Initialized
INFO - 2021-05-17 14:55:50 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:50 --> Database Driver Class Initialized
ERROR - 2021-05-17 14:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-17 14:55:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-17 14:55:50 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:50 --> Total execution time: 0.0939
INFO - 2021-05-17 14:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:50 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:50 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:50 --> Controller Class Initialized
INFO - 2021-05-17 14:55:50 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:50 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-17 14:55:50 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:50 --> Total execution time: 0.1516
INFO - 2021-05-17 14:55:50 --> Config Class Initialized
INFO - 2021-05-17 14:55:50 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:50 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:50 --> URI Class Initialized
INFO - 2021-05-17 14:55:50 --> Router Class Initialized
INFO - 2021-05-17 14:55:50 --> Output Class Initialized
INFO - 2021-05-17 14:55:50 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:50 --> Input Class Initialized
INFO - 2021-05-17 14:55:50 --> Language Class Initialized
INFO - 2021-05-17 14:55:50 --> Loader Class Initialized
INFO - 2021-05-17 14:55:50 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:50 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:50 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:50 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:50 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:50 --> Controller Class Initialized
INFO - 2021-05-17 14:55:50 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:50 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:51 --> Config Class Initialized
INFO - 2021-05-17 14:55:51 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:51 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:51 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:51 --> URI Class Initialized
INFO - 2021-05-17 14:55:51 --> Router Class Initialized
INFO - 2021-05-17 14:55:51 --> Output Class Initialized
INFO - 2021-05-17 14:55:51 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:51 --> Input Class Initialized
INFO - 2021-05-17 14:55:51 --> Language Class Initialized
INFO - 2021-05-17 14:55:51 --> Loader Class Initialized
INFO - 2021-05-17 14:55:51 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:51 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:51 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:51 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:51 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:51 --> Controller Class Initialized
INFO - 2021-05-17 14:55:51 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:51 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:51 --> Config Class Initialized
INFO - 2021-05-17 14:55:51 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:51 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:51 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:51 --> URI Class Initialized
INFO - 2021-05-17 14:55:51 --> Router Class Initialized
INFO - 2021-05-17 14:55:51 --> Output Class Initialized
INFO - 2021-05-17 14:55:51 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:51 --> Input Class Initialized
INFO - 2021-05-17 14:55:51 --> Language Class Initialized
INFO - 2021-05-17 14:55:51 --> Loader Class Initialized
INFO - 2021-05-17 14:55:51 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:51 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:51 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:51 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:51 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:51 --> Total execution time: 0.1119
INFO - 2021-05-17 14:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:51 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:51 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:51 --> Controller Class Initialized
INFO - 2021-05-17 14:55:51 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:51 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:51 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-17 14:55:51 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:51 --> Total execution time: 0.0858
INFO - 2021-05-17 14:55:52 --> Config Class Initialized
INFO - 2021-05-17 14:55:52 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:52 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:52 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:52 --> URI Class Initialized
INFO - 2021-05-17 14:55:52 --> Router Class Initialized
INFO - 2021-05-17 14:55:52 --> Output Class Initialized
INFO - 2021-05-17 14:55:52 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:52 --> Input Class Initialized
INFO - 2021-05-17 14:55:52 --> Language Class Initialized
INFO - 2021-05-17 14:55:52 --> Loader Class Initialized
INFO - 2021-05-17 14:55:52 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:52 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:52 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:52 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:52 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:52 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:52 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:52 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:52 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:52 --> Controller Class Initialized
INFO - 2021-05-17 14:55:52 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:52 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:52 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:52 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:52 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:52 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:52 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-05-17 14:55:52 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-05-17 14:55:52 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:52 --> Total execution time: 0.1130
INFO - 2021-05-17 14:55:53 --> Config Class Initialized
INFO - 2021-05-17 14:55:53 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:53 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:53 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:53 --> URI Class Initialized
INFO - 2021-05-17 14:55:53 --> Router Class Initialized
INFO - 2021-05-17 14:55:53 --> Output Class Initialized
INFO - 2021-05-17 14:55:53 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:53 --> Input Class Initialized
INFO - 2021-05-17 14:55:53 --> Language Class Initialized
ERROR - 2021-05-17 14:55:53 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:55:53 --> Config Class Initialized
INFO - 2021-05-17 14:55:53 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:53 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:53 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:53 --> URI Class Initialized
INFO - 2021-05-17 14:55:53 --> Router Class Initialized
INFO - 2021-05-17 14:55:53 --> Output Class Initialized
INFO - 2021-05-17 14:55:53 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:53 --> Input Class Initialized
INFO - 2021-05-17 14:55:53 --> Language Class Initialized
INFO - 2021-05-17 14:55:53 --> Config Class Initialized
INFO - 2021-05-17 14:55:53 --> Hooks Class Initialized
INFO - 2021-05-17 14:55:53 --> Loader Class Initialized
DEBUG - 2021-05-17 14:55:53 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:53 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:53 --> URI Class Initialized
INFO - 2021-05-17 14:55:53 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:53 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:53 --> Router Class Initialized
INFO - 2021-05-17 14:55:53 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:53 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:53 --> Output Class Initialized
INFO - 2021-05-17 14:55:53 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:53 --> Input Class Initialized
INFO - 2021-05-17 14:55:53 --> Language Class Initialized
INFO - 2021-05-17 14:55:53 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:53 --> Loader Class Initialized
INFO - 2021-05-17 14:55:53 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:53 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:53 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:53 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:53 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:53 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:53 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:53 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:53 --> Controller Class Initialized
INFO - 2021-05-17 14:55:53 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:53 --> Email Class Initialized
INFO - 2021-05-17 14:55:53 --> Model "Finane_Model" initialized
DEBUG - 2021-05-17 14:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:53 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:53 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:53 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:53 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:53 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-17 14:55:53 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:53 --> Total execution time: 0.0913
INFO - 2021-05-17 14:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:53 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:53 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:53 --> Controller Class Initialized
INFO - 2021-05-17 14:55:53 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:53 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:53 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:53 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:53 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:53 --> Database Driver Class Initialized
ERROR - 2021-05-17 14:55:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-17 14:55:53 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-17 14:55:53 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:53 --> Total execution time: 0.1131
INFO - 2021-05-17 14:55:54 --> Config Class Initialized
INFO - 2021-05-17 14:55:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:54 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:54 --> URI Class Initialized
INFO - 2021-05-17 14:55:54 --> Router Class Initialized
INFO - 2021-05-17 14:55:54 --> Output Class Initialized
INFO - 2021-05-17 14:55:54 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:54 --> Input Class Initialized
INFO - 2021-05-17 14:55:54 --> Language Class Initialized
INFO - 2021-05-17 14:55:54 --> Loader Class Initialized
INFO - 2021-05-17 14:55:54 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:54 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:54 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:54 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:54 --> Controller Class Initialized
INFO - 2021-05-17 14:55:54 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:54 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:54 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:54 --> Config Class Initialized
INFO - 2021-05-17 14:55:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:54 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:54 --> URI Class Initialized
INFO - 2021-05-17 14:55:54 --> Router Class Initialized
INFO - 2021-05-17 14:55:54 --> Output Class Initialized
INFO - 2021-05-17 14:55:54 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:54 --> Input Class Initialized
INFO - 2021-05-17 14:55:54 --> Language Class Initialized
INFO - 2021-05-17 14:55:54 --> Loader Class Initialized
INFO - 2021-05-17 14:55:54 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:54 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:54 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:54 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:54 --> Controller Class Initialized
INFO - 2021-05-17 14:55:54 --> Config Class Initialized
INFO - 2021-05-17 14:55:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:54 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:54 --> URI Class Initialized
INFO - 2021-05-17 14:55:54 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:54 --> Router Class Initialized
INFO - 2021-05-17 14:55:54 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:54 --> Output Class Initialized
INFO - 2021-05-17 14:55:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:54 --> Security Class Initialized
INFO - 2021-05-17 14:55:54 --> Model "Sales_Model" initialized
DEBUG - 2021-05-17 14:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:54 --> Input Class Initialized
INFO - 2021-05-17 14:55:54 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:54 --> Language Class Initialized
INFO - 2021-05-17 14:55:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-17 14:55:54 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:54 --> Total execution time: 0.0595
INFO - 2021-05-17 14:55:54 --> Loader Class Initialized
INFO - 2021-05-17 14:55:54 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:54 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:54 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:54 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:54 --> Controller Class Initialized
INFO - 2021-05-17 14:55:54 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:54 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:54 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:54 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:54 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:54 --> Total execution time: 0.1230
INFO - 2021-05-17 14:55:57 --> Config Class Initialized
INFO - 2021-05-17 14:55:57 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:57 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:57 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:57 --> URI Class Initialized
INFO - 2021-05-17 14:55:58 --> Router Class Initialized
INFO - 2021-05-17 14:55:58 --> Output Class Initialized
INFO - 2021-05-17 14:55:58 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:58 --> Input Class Initialized
INFO - 2021-05-17 14:55:58 --> Language Class Initialized
INFO - 2021-05-17 14:55:58 --> Loader Class Initialized
INFO - 2021-05-17 14:55:58 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:58 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:58 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:58 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:58 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:58 --> Controller Class Initialized
INFO - 2021-05-17 14:55:58 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:58 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:55:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:55:58 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:58 --> Total execution time: 0.1552
INFO - 2021-05-17 14:55:58 --> Config Class Initialized
INFO - 2021-05-17 14:55:58 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:58 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:58 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:58 --> URI Class Initialized
INFO - 2021-05-17 14:55:58 --> Router Class Initialized
INFO - 2021-05-17 14:55:58 --> Output Class Initialized
INFO - 2021-05-17 14:55:58 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:58 --> Input Class Initialized
INFO - 2021-05-17 14:55:58 --> Language Class Initialized
ERROR - 2021-05-17 14:55:58 --> 404 Page Not Found: Cement_demo/DistributorDashboard
INFO - 2021-05-17 14:55:58 --> Config Class Initialized
INFO - 2021-05-17 14:55:58 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:58 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:58 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:58 --> URI Class Initialized
INFO - 2021-05-17 14:55:58 --> Router Class Initialized
INFO - 2021-05-17 14:55:58 --> Output Class Initialized
INFO - 2021-05-17 14:55:58 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:58 --> Input Class Initialized
INFO - 2021-05-17 14:55:58 --> Language Class Initialized
INFO - 2021-05-17 14:55:58 --> Loader Class Initialized
INFO - 2021-05-17 14:55:58 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:58 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:58 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:58 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:58 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:58 --> Controller Class Initialized
INFO - 2021-05-17 14:55:58 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:58 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-05-17 14:55:58 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:58 --> Total execution time: 0.1178
INFO - 2021-05-17 14:55:58 --> Config Class Initialized
INFO - 2021-05-17 14:55:58 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:55:58 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:55:58 --> Utf8 Class Initialized
INFO - 2021-05-17 14:55:58 --> URI Class Initialized
INFO - 2021-05-17 14:55:58 --> Router Class Initialized
INFO - 2021-05-17 14:55:58 --> Output Class Initialized
INFO - 2021-05-17 14:55:58 --> Security Class Initialized
DEBUG - 2021-05-17 14:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:55:58 --> Input Class Initialized
INFO - 2021-05-17 14:55:58 --> Language Class Initialized
INFO - 2021-05-17 14:55:58 --> Loader Class Initialized
INFO - 2021-05-17 14:55:58 --> Helper loaded: url_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: file_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:55:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:55:58 --> Database Driver Class Initialized
INFO - 2021-05-17 14:55:58 --> Email Class Initialized
DEBUG - 2021-05-17 14:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:55:58 --> Helper loaded: form_helper
INFO - 2021-05-17 14:55:58 --> Form Validation Class Initialized
INFO - 2021-05-17 14:55:58 --> Controller Class Initialized
INFO - 2021-05-17 14:55:58 --> Model "Common_model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:55:58 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:55:58 --> Database Driver Class Initialized
ERROR - 2021-05-17 14:55:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-05-17 14:55:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-05-17 14:55:58 --> Final output sent to browser
DEBUG - 2021-05-17 14:55:58 --> Total execution time: 0.0645
INFO - 2021-05-17 14:56:00 --> Config Class Initialized
INFO - 2021-05-17 14:56:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:00 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:00 --> Config Class Initialized
INFO - 2021-05-17 14:56:00 --> Hooks Class Initialized
INFO - 2021-05-17 14:56:00 --> URI Class Initialized
INFO - 2021-05-17 14:56:00 --> Router Class Initialized
DEBUG - 2021-05-17 14:56:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:00 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:00 --> URI Class Initialized
INFO - 2021-05-17 14:56:00 --> Output Class Initialized
INFO - 2021-05-17 14:56:00 --> Security Class Initialized
INFO - 2021-05-17 14:56:00 --> Router Class Initialized
DEBUG - 2021-05-17 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:00 --> Input Class Initialized
INFO - 2021-05-17 14:56:00 --> Language Class Initialized
INFO - 2021-05-17 14:56:00 --> Output Class Initialized
INFO - 2021-05-17 14:56:00 --> Security Class Initialized
INFO - 2021-05-17 14:56:00 --> Loader Class Initialized
DEBUG - 2021-05-17 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:00 --> Input Class Initialized
INFO - 2021-05-17 14:56:00 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:00 --> Language Class Initialized
INFO - 2021-05-17 14:56:00 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:00 --> Loader Class Initialized
INFO - 2021-05-17 14:56:00 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:00 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:00 --> Email Class Initialized
INFO - 2021-05-17 14:56:00 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:00 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:00 --> Controller Class Initialized
DEBUG - 2021-05-17 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:00 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:00 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:00 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:00 --> Controller Class Initialized
INFO - 2021-05-17 14:56:00 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:56:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-05-17 14:56:00 --> Final output sent to browser
DEBUG - 2021-05-17 14:56:00 --> Total execution time: 0.0701
INFO - 2021-05-17 14:56:00 --> Config Class Initialized
INFO - 2021-05-17 14:56:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:00 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:00 --> URI Class Initialized
INFO - 2021-05-17 14:56:00 --> Router Class Initialized
INFO - 2021-05-17 14:56:00 --> Output Class Initialized
INFO - 2021-05-17 14:56:00 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:00 --> Input Class Initialized
INFO - 2021-05-17 14:56:00 --> Language Class Initialized
INFO - 2021-05-17 14:56:00 --> Loader Class Initialized
INFO - 2021-05-17 14:56:00 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:00 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:00 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:00 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:00 --> Controller Class Initialized
INFO - 2021-05-17 14:56:00 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:56:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:56:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:56:00 --> Final output sent to browser
DEBUG - 2021-05-17 14:56:00 --> Total execution time: 0.1901
INFO - 2021-05-17 14:56:01 --> Config Class Initialized
INFO - 2021-05-17 14:56:01 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:01 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:01 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:01 --> URI Class Initialized
INFO - 2021-05-17 14:56:01 --> Router Class Initialized
INFO - 2021-05-17 14:56:01 --> Output Class Initialized
INFO - 2021-05-17 14:56:01 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:01 --> Input Class Initialized
INFO - 2021-05-17 14:56:01 --> Language Class Initialized
INFO - 2021-05-17 14:56:01 --> Loader Class Initialized
INFO - 2021-05-17 14:56:01 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:01 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:01 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:01 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:01 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:01 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:01 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:01 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:01 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:01 --> Controller Class Initialized
INFO - 2021-05-17 14:56:01 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:01 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:01 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:01 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:01 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:01 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/setup/listChartOfAccount.php
INFO - 2021-05-17 14:56:01 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:56:01 --> Final output sent to browser
DEBUG - 2021-05-17 14:56:01 --> Total execution time: 0.4308
INFO - 2021-05-17 14:56:02 --> Config Class Initialized
INFO - 2021-05-17 14:56:02 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:02 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:02 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:02 --> URI Class Initialized
INFO - 2021-05-17 14:56:02 --> Router Class Initialized
INFO - 2021-05-17 14:56:02 --> Output Class Initialized
INFO - 2021-05-17 14:56:02 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:02 --> Input Class Initialized
INFO - 2021-05-17 14:56:02 --> Language Class Initialized
ERROR - 2021-05-17 14:56:02 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:56:03 --> Config Class Initialized
INFO - 2021-05-17 14:56:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:03 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:03 --> URI Class Initialized
INFO - 2021-05-17 14:56:03 --> Router Class Initialized
INFO - 2021-05-17 14:56:03 --> Output Class Initialized
INFO - 2021-05-17 14:56:03 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:03 --> Input Class Initialized
INFO - 2021-05-17 14:56:03 --> Language Class Initialized
INFO - 2021-05-17 14:56:03 --> Loader Class Initialized
INFO - 2021-05-17 14:56:03 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:03 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:03 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:03 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:03 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:03 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:03 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:03 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:03 --> Controller Class Initialized
INFO - 2021-05-17 14:56:03 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:03 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:03 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:04 --> Config Class Initialized
INFO - 2021-05-17 14:56:04 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:04 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:04 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:04 --> URI Class Initialized
INFO - 2021-05-17 14:56:04 --> Router Class Initialized
INFO - 2021-05-17 14:56:04 --> Output Class Initialized
INFO - 2021-05-17 14:56:04 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:04 --> Input Class Initialized
INFO - 2021-05-17 14:56:04 --> Language Class Initialized
INFO - 2021-05-17 14:56:04 --> Loader Class Initialized
INFO - 2021-05-17 14:56:04 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:04 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:04 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:04 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:04 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:04 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:04 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:04 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:04 --> Controller Class Initialized
INFO - 2021-05-17 14:56:04 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:04 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:04 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:04 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:04 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:56:04 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:56:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:56:04 --> Final output sent to browser
DEBUG - 2021-05-17 14:56:04 --> Total execution time: 0.1102
INFO - 2021-05-17 14:56:54 --> Config Class Initialized
INFO - 2021-05-17 14:56:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:54 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:54 --> URI Class Initialized
INFO - 2021-05-17 14:56:54 --> Router Class Initialized
INFO - 2021-05-17 14:56:54 --> Output Class Initialized
INFO - 2021-05-17 14:56:54 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:54 --> Input Class Initialized
INFO - 2021-05-17 14:56:54 --> Language Class Initialized
INFO - 2021-05-17 14:56:54 --> Loader Class Initialized
INFO - 2021-05-17 14:56:54 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:54 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:54 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:54 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:54 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:54 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:54 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:54 --> Controller Class Initialized
INFO - 2021-05-17 14:56:54 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:54 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:54 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/setup/listChartOfAccount.php
INFO - 2021-05-17 14:56:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:56:54 --> Final output sent to browser
DEBUG - 2021-05-17 14:56:54 --> Total execution time: 0.1332
INFO - 2021-05-17 14:56:54 --> Config Class Initialized
INFO - 2021-05-17 14:56:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:54 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:54 --> URI Class Initialized
INFO - 2021-05-17 14:56:54 --> Router Class Initialized
INFO - 2021-05-17 14:56:54 --> Output Class Initialized
INFO - 2021-05-17 14:56:54 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:54 --> Input Class Initialized
INFO - 2021-05-17 14:56:54 --> Language Class Initialized
ERROR - 2021-05-17 14:56:54 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:56:55 --> Config Class Initialized
INFO - 2021-05-17 14:56:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:55 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:55 --> URI Class Initialized
INFO - 2021-05-17 14:56:55 --> Router Class Initialized
INFO - 2021-05-17 14:56:55 --> Output Class Initialized
INFO - 2021-05-17 14:56:55 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:55 --> Input Class Initialized
INFO - 2021-05-17 14:56:55 --> Language Class Initialized
INFO - 2021-05-17 14:56:55 --> Loader Class Initialized
INFO - 2021-05-17 14:56:55 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:55 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:55 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:55 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:55 --> Controller Class Initialized
INFO - 2021-05-17 14:56:55 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:55 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:55 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:55 --> Config Class Initialized
INFO - 2021-05-17 14:56:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:55 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:55 --> URI Class Initialized
INFO - 2021-05-17 14:56:55 --> Router Class Initialized
INFO - 2021-05-17 14:56:55 --> Output Class Initialized
INFO - 2021-05-17 14:56:55 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:55 --> Input Class Initialized
INFO - 2021-05-17 14:56:55 --> Language Class Initialized
INFO - 2021-05-17 14:56:55 --> Loader Class Initialized
INFO - 2021-05-17 14:56:55 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:55 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:55 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:55 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:55 --> Controller Class Initialized
INFO - 2021-05-17 14:56:55 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:55 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:55 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:55 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:56:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:56:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:56:55 --> Final output sent to browser
DEBUG - 2021-05-17 14:56:55 --> Total execution time: 0.1134
INFO - 2021-05-17 14:56:59 --> Config Class Initialized
INFO - 2021-05-17 14:56:59 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:59 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:59 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:59 --> URI Class Initialized
INFO - 2021-05-17 14:56:59 --> Router Class Initialized
INFO - 2021-05-17 14:56:59 --> Output Class Initialized
INFO - 2021-05-17 14:56:59 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:59 --> Input Class Initialized
INFO - 2021-05-17 14:56:59 --> Language Class Initialized
INFO - 2021-05-17 14:56:59 --> Loader Class Initialized
INFO - 2021-05-17 14:56:59 --> Helper loaded: url_helper
INFO - 2021-05-17 14:56:59 --> Helper loaded: file_helper
INFO - 2021-05-17 14:56:59 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:56:59 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:56:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:56:59 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:59 --> Email Class Initialized
DEBUG - 2021-05-17 14:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:56:59 --> Helper loaded: form_helper
INFO - 2021-05-17 14:56:59 --> Form Validation Class Initialized
INFO - 2021-05-17 14:56:59 --> Controller Class Initialized
INFO - 2021-05-17 14:56:59 --> Model "Common_model" initialized
INFO - 2021-05-17 14:56:59 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:56:59 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:56:59 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:56:59 --> Database Driver Class Initialized
INFO - 2021-05-17 14:56:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/setup/ViewChartOfAccount.php
INFO - 2021-05-17 14:56:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:56:59 --> Final output sent to browser
DEBUG - 2021-05-17 14:56:59 --> Total execution time: 0.4361
INFO - 2021-05-17 14:56:59 --> Config Class Initialized
INFO - 2021-05-17 14:56:59 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:56:59 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:56:59 --> Utf8 Class Initialized
INFO - 2021-05-17 14:56:59 --> URI Class Initialized
INFO - 2021-05-17 14:56:59 --> Router Class Initialized
INFO - 2021-05-17 14:56:59 --> Output Class Initialized
INFO - 2021-05-17 14:56:59 --> Security Class Initialized
DEBUG - 2021-05-17 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:56:59 --> Input Class Initialized
INFO - 2021-05-17 14:56:59 --> Language Class Initialized
ERROR - 2021-05-17 14:56:59 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:57:00 --> Config Class Initialized
INFO - 2021-05-17 14:57:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:57:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:57:00 --> Utf8 Class Initialized
INFO - 2021-05-17 14:57:00 --> URI Class Initialized
INFO - 2021-05-17 14:57:00 --> Router Class Initialized
INFO - 2021-05-17 14:57:00 --> Output Class Initialized
INFO - 2021-05-17 14:57:00 --> Security Class Initialized
DEBUG - 2021-05-17 14:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:57:00 --> Input Class Initialized
INFO - 2021-05-17 14:57:00 --> Language Class Initialized
INFO - 2021-05-17 14:57:00 --> Loader Class Initialized
INFO - 2021-05-17 14:57:00 --> Helper loaded: url_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: file_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:57:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:57:00 --> Email Class Initialized
DEBUG - 2021-05-17 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:57:00 --> Helper loaded: form_helper
INFO - 2021-05-17 14:57:00 --> Form Validation Class Initialized
INFO - 2021-05-17 14:57:00 --> Controller Class Initialized
INFO - 2021-05-17 14:57:00 --> Model "Common_model" initialized
INFO - 2021-05-17 14:57:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:57:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:57:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:57:00 --> Config Class Initialized
INFO - 2021-05-17 14:57:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:57:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:57:00 --> Utf8 Class Initialized
INFO - 2021-05-17 14:57:00 --> URI Class Initialized
INFO - 2021-05-17 14:57:00 --> Router Class Initialized
INFO - 2021-05-17 14:57:00 --> Output Class Initialized
INFO - 2021-05-17 14:57:00 --> Security Class Initialized
DEBUG - 2021-05-17 14:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:57:00 --> Input Class Initialized
INFO - 2021-05-17 14:57:00 --> Language Class Initialized
INFO - 2021-05-17 14:57:00 --> Loader Class Initialized
INFO - 2021-05-17 14:57:00 --> Helper loaded: url_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: file_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:57:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:57:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:57:00 --> Email Class Initialized
DEBUG - 2021-05-17 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:57:00 --> Helper loaded: form_helper
INFO - 2021-05-17 14:57:00 --> Form Validation Class Initialized
INFO - 2021-05-17 14:57:00 --> Controller Class Initialized
INFO - 2021-05-17 14:57:00 --> Model "Common_model" initialized
INFO - 2021-05-17 14:57:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:57:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:57:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:57:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:57:00 --> Database Driver Class Initialized
INFO - 2021-05-17 14:57:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:57:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:57:00 --> Final output sent to browser
DEBUG - 2021-05-17 14:57:00 --> Total execution time: 0.1013
INFO - 2021-05-17 14:58:17 --> Config Class Initialized
INFO - 2021-05-17 14:58:17 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:17 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:17 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:17 --> URI Class Initialized
INFO - 2021-05-17 14:58:17 --> Router Class Initialized
INFO - 2021-05-17 14:58:17 --> Output Class Initialized
INFO - 2021-05-17 14:58:17 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:17 --> Input Class Initialized
INFO - 2021-05-17 14:58:17 --> Language Class Initialized
INFO - 2021-05-17 14:58:17 --> Loader Class Initialized
INFO - 2021-05-17 14:58:17 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:17 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:17 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:17 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:17 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:17 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:17 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:17 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:17 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:17 --> Controller Class Initialized
INFO - 2021-05-17 14:58:17 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:17 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:17 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:17 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:17 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:17 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-05-17 14:58:17 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:17 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:17 --> Total execution time: 0.2643
INFO - 2021-05-17 14:58:18 --> Config Class Initialized
INFO - 2021-05-17 14:58:18 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:18 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:18 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:18 --> URI Class Initialized
INFO - 2021-05-17 14:58:18 --> Router Class Initialized
INFO - 2021-05-17 14:58:18 --> Output Class Initialized
INFO - 2021-05-17 14:58:18 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:18 --> Input Class Initialized
INFO - 2021-05-17 14:58:18 --> Language Class Initialized
ERROR - 2021-05-17 14:58:18 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:58:18 --> Config Class Initialized
INFO - 2021-05-17 14:58:18 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:18 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:18 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:18 --> URI Class Initialized
INFO - 2021-05-17 14:58:18 --> Router Class Initialized
INFO - 2021-05-17 14:58:18 --> Output Class Initialized
INFO - 2021-05-17 14:58:18 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:18 --> Input Class Initialized
INFO - 2021-05-17 14:58:18 --> Language Class Initialized
INFO - 2021-05-17 14:58:18 --> Loader Class Initialized
INFO - 2021-05-17 14:58:18 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:18 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:18 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:18 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:18 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:18 --> Controller Class Initialized
INFO - 2021-05-17 14:58:18 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:18 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:18 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:18 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:18 --> Config Class Initialized
INFO - 2021-05-17 14:58:18 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:18 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:18 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:18 --> URI Class Initialized
INFO - 2021-05-17 14:58:18 --> Router Class Initialized
INFO - 2021-05-17 14:58:18 --> Output Class Initialized
INFO - 2021-05-17 14:58:18 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:18 --> Input Class Initialized
INFO - 2021-05-17 14:58:18 --> Language Class Initialized
INFO - 2021-05-17 14:58:18 --> Loader Class Initialized
INFO - 2021-05-17 14:58:18 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:18 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:18 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:18 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:18 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:18 --> Controller Class Initialized
INFO - 2021-05-17 14:58:19 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:19 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:19 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:19 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:19 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:58:19 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:58:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:19 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:19 --> Total execution time: 0.2542
INFO - 2021-05-17 14:58:31 --> Config Class Initialized
INFO - 2021-05-17 14:58:31 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:31 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:31 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:31 --> URI Class Initialized
INFO - 2021-05-17 14:58:31 --> Router Class Initialized
INFO - 2021-05-17 14:58:31 --> Output Class Initialized
INFO - 2021-05-17 14:58:31 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:31 --> Input Class Initialized
INFO - 2021-05-17 14:58:31 --> Language Class Initialized
INFO - 2021-05-17 14:58:31 --> Loader Class Initialized
INFO - 2021-05-17 14:58:31 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:31 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:31 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:31 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:31 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:31 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:31 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:31 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:31 --> Controller Class Initialized
INFO - 2021-05-17 14:58:31 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:31 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:31 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:31 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:31 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-05-17 14:58:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:31 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:31 --> Total execution time: 0.3226
INFO - 2021-05-17 14:58:31 --> Config Class Initialized
INFO - 2021-05-17 14:58:31 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:31 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:31 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:31 --> URI Class Initialized
INFO - 2021-05-17 14:58:31 --> Router Class Initialized
INFO - 2021-05-17 14:58:31 --> Output Class Initialized
INFO - 2021-05-17 14:58:31 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:31 --> Input Class Initialized
INFO - 2021-05-17 14:58:31 --> Language Class Initialized
ERROR - 2021-05-17 14:58:31 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:58:32 --> Config Class Initialized
INFO - 2021-05-17 14:58:32 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:32 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:32 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:32 --> URI Class Initialized
INFO - 2021-05-17 14:58:32 --> Router Class Initialized
INFO - 2021-05-17 14:58:32 --> Output Class Initialized
INFO - 2021-05-17 14:58:32 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:32 --> Input Class Initialized
INFO - 2021-05-17 14:58:32 --> Language Class Initialized
INFO - 2021-05-17 14:58:32 --> Loader Class Initialized
INFO - 2021-05-17 14:58:32 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:32 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:32 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:32 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:32 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:32 --> Controller Class Initialized
INFO - 2021-05-17 14:58:32 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:32 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:32 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:32 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:32 --> Config Class Initialized
INFO - 2021-05-17 14:58:32 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:32 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:32 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:32 --> URI Class Initialized
INFO - 2021-05-17 14:58:32 --> Router Class Initialized
INFO - 2021-05-17 14:58:32 --> Output Class Initialized
INFO - 2021-05-17 14:58:32 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:32 --> Input Class Initialized
INFO - 2021-05-17 14:58:32 --> Language Class Initialized
INFO - 2021-05-17 14:58:32 --> Loader Class Initialized
INFO - 2021-05-17 14:58:32 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:32 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:32 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:32 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:32 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:32 --> Controller Class Initialized
INFO - 2021-05-17 14:58:32 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:32 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:32 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:32 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:32 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:58:32 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:58:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:32 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:32 --> Total execution time: 0.1110
INFO - 2021-05-17 14:58:39 --> Config Class Initialized
INFO - 2021-05-17 14:58:39 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:39 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:39 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:39 --> URI Class Initialized
INFO - 2021-05-17 14:58:39 --> Router Class Initialized
INFO - 2021-05-17 14:58:39 --> Output Class Initialized
INFO - 2021-05-17 14:58:39 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:39 --> Input Class Initialized
INFO - 2021-05-17 14:58:39 --> Language Class Initialized
INFO - 2021-05-17 14:58:39 --> Loader Class Initialized
INFO - 2021-05-17 14:58:39 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:39 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:39 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:39 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:39 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:39 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:39 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:39 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:39 --> Controller Class Initialized
INFO - 2021-05-17 14:58:39 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:39 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:39 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:39 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:39 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-05-17 14:58:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:39 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:39 --> Total execution time: 0.3498
INFO - 2021-05-17 14:58:40 --> Config Class Initialized
INFO - 2021-05-17 14:58:40 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:40 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:40 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:40 --> URI Class Initialized
INFO - 2021-05-17 14:58:40 --> Router Class Initialized
INFO - 2021-05-17 14:58:40 --> Output Class Initialized
INFO - 2021-05-17 14:58:40 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:40 --> Input Class Initialized
INFO - 2021-05-17 14:58:40 --> Language Class Initialized
ERROR - 2021-05-17 14:58:40 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:58:40 --> Config Class Initialized
INFO - 2021-05-17 14:58:40 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:40 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:40 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:40 --> URI Class Initialized
INFO - 2021-05-17 14:58:40 --> Router Class Initialized
INFO - 2021-05-17 14:58:40 --> Output Class Initialized
INFO - 2021-05-17 14:58:40 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:40 --> Input Class Initialized
INFO - 2021-05-17 14:58:40 --> Language Class Initialized
INFO - 2021-05-17 14:58:40 --> Loader Class Initialized
INFO - 2021-05-17 14:58:40 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:40 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:40 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:40 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:40 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:40 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:40 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:40 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:40 --> Controller Class Initialized
INFO - 2021-05-17 14:58:40 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:40 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:40 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:40 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:41 --> Config Class Initialized
INFO - 2021-05-17 14:58:41 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:41 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:41 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:41 --> URI Class Initialized
INFO - 2021-05-17 14:58:41 --> Router Class Initialized
INFO - 2021-05-17 14:58:41 --> Output Class Initialized
INFO - 2021-05-17 14:58:41 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:41 --> Input Class Initialized
INFO - 2021-05-17 14:58:41 --> Language Class Initialized
INFO - 2021-05-17 14:58:41 --> Loader Class Initialized
INFO - 2021-05-17 14:58:41 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:41 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:41 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:41 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:41 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:41 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:41 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:41 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:41 --> Controller Class Initialized
INFO - 2021-05-17 14:58:41 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:41 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:41 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:41 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:41 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:58:41 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:58:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:41 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:41 --> Total execution time: 0.2264
INFO - 2021-05-17 14:58:55 --> Config Class Initialized
INFO - 2021-05-17 14:58:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:55 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:55 --> URI Class Initialized
INFO - 2021-05-17 14:58:55 --> Router Class Initialized
INFO - 2021-05-17 14:58:55 --> Output Class Initialized
INFO - 2021-05-17 14:58:55 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:55 --> Input Class Initialized
INFO - 2021-05-17 14:58:55 --> Language Class Initialized
INFO - 2021-05-17 14:58:55 --> Loader Class Initialized
INFO - 2021-05-17 14:58:55 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:55 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:55 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:55 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:55 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:55 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:55 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:55 --> Controller Class Initialized
INFO - 2021-05-17 14:58:55 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:55 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:55 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-05-17 14:58:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:55 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:55 --> Total execution time: 0.2084
INFO - 2021-05-17 14:58:56 --> Config Class Initialized
INFO - 2021-05-17 14:58:56 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:56 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:56 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:56 --> URI Class Initialized
INFO - 2021-05-17 14:58:56 --> Router Class Initialized
INFO - 2021-05-17 14:58:56 --> Output Class Initialized
INFO - 2021-05-17 14:58:56 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:56 --> Input Class Initialized
INFO - 2021-05-17 14:58:56 --> Language Class Initialized
ERROR - 2021-05-17 14:58:56 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:58:56 --> Config Class Initialized
INFO - 2021-05-17 14:58:56 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:56 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:56 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:56 --> URI Class Initialized
INFO - 2021-05-17 14:58:56 --> Router Class Initialized
INFO - 2021-05-17 14:58:56 --> Output Class Initialized
INFO - 2021-05-17 14:58:56 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:56 --> Input Class Initialized
INFO - 2021-05-17 14:58:56 --> Language Class Initialized
INFO - 2021-05-17 14:58:56 --> Loader Class Initialized
INFO - 2021-05-17 14:58:56 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:56 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:56 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:56 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:56 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:56 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:56 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:56 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:56 --> Controller Class Initialized
INFO - 2021-05-17 14:58:56 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:56 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:56 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:57 --> Config Class Initialized
INFO - 2021-05-17 14:58:57 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:58:57 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:58:57 --> Utf8 Class Initialized
INFO - 2021-05-17 14:58:57 --> URI Class Initialized
INFO - 2021-05-17 14:58:57 --> Router Class Initialized
INFO - 2021-05-17 14:58:57 --> Output Class Initialized
INFO - 2021-05-17 14:58:57 --> Security Class Initialized
DEBUG - 2021-05-17 14:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:58:57 --> Input Class Initialized
INFO - 2021-05-17 14:58:57 --> Language Class Initialized
INFO - 2021-05-17 14:58:57 --> Loader Class Initialized
INFO - 2021-05-17 14:58:57 --> Helper loaded: url_helper
INFO - 2021-05-17 14:58:57 --> Helper loaded: file_helper
INFO - 2021-05-17 14:58:57 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:58:57 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:58:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:58:57 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:57 --> Email Class Initialized
DEBUG - 2021-05-17 14:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:58:57 --> Helper loaded: form_helper
INFO - 2021-05-17 14:58:57 --> Form Validation Class Initialized
INFO - 2021-05-17 14:58:57 --> Controller Class Initialized
INFO - 2021-05-17 14:58:57 --> Model "Common_model" initialized
INFO - 2021-05-17 14:58:57 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:58:57 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:58:57 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:58:57 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:58:57 --> Database Driver Class Initialized
INFO - 2021-05-17 14:58:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:58:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:58:57 --> Final output sent to browser
DEBUG - 2021-05-17 14:58:57 --> Total execution time: 0.2291
INFO - 2021-05-17 14:59:03 --> Config Class Initialized
INFO - 2021-05-17 14:59:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:03 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:03 --> URI Class Initialized
INFO - 2021-05-17 14:59:03 --> Router Class Initialized
INFO - 2021-05-17 14:59:03 --> Output Class Initialized
INFO - 2021-05-17 14:59:03 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:03 --> Input Class Initialized
INFO - 2021-05-17 14:59:03 --> Language Class Initialized
INFO - 2021-05-17 14:59:03 --> Loader Class Initialized
INFO - 2021-05-17 14:59:03 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:03 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:03 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:03 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:03 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:03 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:03 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:03 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:03 --> Controller Class Initialized
INFO - 2021-05-17 14:59:03 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:03 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:03 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:03 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-05-17 14:59:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:04 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:04 --> Total execution time: 0.4327
INFO - 2021-05-17 14:59:04 --> Config Class Initialized
INFO - 2021-05-17 14:59:04 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:04 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:04 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:04 --> URI Class Initialized
INFO - 2021-05-17 14:59:04 --> Router Class Initialized
INFO - 2021-05-17 14:59:04 --> Output Class Initialized
INFO - 2021-05-17 14:59:04 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:04 --> Input Class Initialized
INFO - 2021-05-17 14:59:04 --> Language Class Initialized
ERROR - 2021-05-17 14:59:04 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:59:04 --> Config Class Initialized
INFO - 2021-05-17 14:59:04 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:04 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:04 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:04 --> URI Class Initialized
INFO - 2021-05-17 14:59:04 --> Router Class Initialized
INFO - 2021-05-17 14:59:04 --> Output Class Initialized
INFO - 2021-05-17 14:59:04 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:04 --> Input Class Initialized
INFO - 2021-05-17 14:59:04 --> Language Class Initialized
INFO - 2021-05-17 14:59:04 --> Loader Class Initialized
INFO - 2021-05-17 14:59:04 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:04 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:04 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:04 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:04 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:04 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:04 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:04 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:04 --> Controller Class Initialized
INFO - 2021-05-17 14:59:04 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:04 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:04 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:04 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:05 --> Config Class Initialized
INFO - 2021-05-17 14:59:05 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:05 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:05 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:05 --> URI Class Initialized
INFO - 2021-05-17 14:59:05 --> Router Class Initialized
INFO - 2021-05-17 14:59:05 --> Output Class Initialized
INFO - 2021-05-17 14:59:05 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:05 --> Input Class Initialized
INFO - 2021-05-17 14:59:05 --> Language Class Initialized
INFO - 2021-05-17 14:59:05 --> Loader Class Initialized
INFO - 2021-05-17 14:59:05 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:05 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:05 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:05 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:05 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:05 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:05 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:05 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:05 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:05 --> Controller Class Initialized
INFO - 2021-05-17 14:59:05 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:05 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:05 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:05 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:05 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:59:05 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:05 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:59:05 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:05 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:05 --> Total execution time: 0.1453
INFO - 2021-05-17 14:59:15 --> Config Class Initialized
INFO - 2021-05-17 14:59:15 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:15 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:15 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:15 --> URI Class Initialized
INFO - 2021-05-17 14:59:15 --> Router Class Initialized
INFO - 2021-05-17 14:59:15 --> Output Class Initialized
INFO - 2021-05-17 14:59:15 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:15 --> Input Class Initialized
INFO - 2021-05-17 14:59:15 --> Language Class Initialized
INFO - 2021-05-17 14:59:15 --> Loader Class Initialized
INFO - 2021-05-17 14:59:15 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:15 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:15 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:15 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:15 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:15 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:15 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:15 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:15 --> Controller Class Initialized
INFO - 2021-05-17 14:59:15 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:15 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:15 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:15 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:15 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/balanceSheet.php
INFO - 2021-05-17 14:59:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:15 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:15 --> Total execution time: 0.1117
INFO - 2021-05-17 14:59:16 --> Config Class Initialized
INFO - 2021-05-17 14:59:16 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:16 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:16 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:16 --> URI Class Initialized
INFO - 2021-05-17 14:59:16 --> Router Class Initialized
INFO - 2021-05-17 14:59:16 --> Output Class Initialized
INFO - 2021-05-17 14:59:16 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:16 --> Input Class Initialized
INFO - 2021-05-17 14:59:16 --> Language Class Initialized
ERROR - 2021-05-17 14:59:16 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:59:17 --> Config Class Initialized
INFO - 2021-05-17 14:59:17 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:17 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:17 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:17 --> URI Class Initialized
INFO - 2021-05-17 14:59:17 --> Router Class Initialized
INFO - 2021-05-17 14:59:17 --> Output Class Initialized
INFO - 2021-05-17 14:59:17 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:17 --> Input Class Initialized
INFO - 2021-05-17 14:59:17 --> Language Class Initialized
INFO - 2021-05-17 14:59:17 --> Loader Class Initialized
INFO - 2021-05-17 14:59:17 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:17 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:17 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:17 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:17 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:17 --> Controller Class Initialized
INFO - 2021-05-17 14:59:17 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:17 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:17 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:17 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:17 --> Config Class Initialized
INFO - 2021-05-17 14:59:17 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:17 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:17 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:17 --> URI Class Initialized
INFO - 2021-05-17 14:59:17 --> Router Class Initialized
INFO - 2021-05-17 14:59:17 --> Output Class Initialized
INFO - 2021-05-17 14:59:17 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:17 --> Input Class Initialized
INFO - 2021-05-17 14:59:17 --> Language Class Initialized
INFO - 2021-05-17 14:59:17 --> Loader Class Initialized
INFO - 2021-05-17 14:59:17 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:17 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:17 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:17 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:17 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:17 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:17 --> Controller Class Initialized
INFO - 2021-05-17 14:59:17 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:17 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:17 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:17 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:17 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:59:17 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:17 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:59:17 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:17 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:17 --> Total execution time: 0.1068
INFO - 2021-05-17 14:59:18 --> Config Class Initialized
INFO - 2021-05-17 14:59:18 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:18 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:18 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:18 --> URI Class Initialized
INFO - 2021-05-17 14:59:18 --> Router Class Initialized
INFO - 2021-05-17 14:59:18 --> Output Class Initialized
INFO - 2021-05-17 14:59:18 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:18 --> Input Class Initialized
INFO - 2021-05-17 14:59:18 --> Language Class Initialized
INFO - 2021-05-17 14:59:18 --> Loader Class Initialized
INFO - 2021-05-17 14:59:18 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:18 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:18 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:18 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:18 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:18 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:18 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:18 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:18 --> Controller Class Initialized
INFO - 2021-05-17 14:59:18 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:18 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:18 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:18 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:18 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/balanceSheet.php
INFO - 2021-05-17 14:59:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:23 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:23 --> Total execution time: 4.3522
INFO - 2021-05-17 14:59:23 --> Config Class Initialized
INFO - 2021-05-17 14:59:23 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:23 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:23 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:23 --> URI Class Initialized
INFO - 2021-05-17 14:59:23 --> Router Class Initialized
INFO - 2021-05-17 14:59:23 --> Output Class Initialized
INFO - 2021-05-17 14:59:23 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:23 --> Input Class Initialized
INFO - 2021-05-17 14:59:23 --> Language Class Initialized
ERROR - 2021-05-17 14:59:23 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 14:59:23 --> Config Class Initialized
INFO - 2021-05-17 14:59:23 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:23 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:23 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:23 --> URI Class Initialized
INFO - 2021-05-17 14:59:23 --> Router Class Initialized
INFO - 2021-05-17 14:59:23 --> Output Class Initialized
INFO - 2021-05-17 14:59:23 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:23 --> Input Class Initialized
INFO - 2021-05-17 14:59:23 --> Language Class Initialized
INFO - 2021-05-17 14:59:23 --> Loader Class Initialized
INFO - 2021-05-17 14:59:23 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:23 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:23 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:23 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:23 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:23 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:23 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:23 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:23 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:23 --> Controller Class Initialized
INFO - 2021-05-17 14:59:23 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:23 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:23 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:23 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:24 --> Config Class Initialized
INFO - 2021-05-17 14:59:24 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:24 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:24 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:24 --> URI Class Initialized
INFO - 2021-05-17 14:59:24 --> Router Class Initialized
INFO - 2021-05-17 14:59:24 --> Output Class Initialized
INFO - 2021-05-17 14:59:24 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:24 --> Input Class Initialized
INFO - 2021-05-17 14:59:24 --> Language Class Initialized
INFO - 2021-05-17 14:59:24 --> Loader Class Initialized
INFO - 2021-05-17 14:59:24 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:24 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:24 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:24 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:24 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:24 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:24 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:24 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:24 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:24 --> Controller Class Initialized
INFO - 2021-05-17 14:59:24 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:24 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:24 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:24 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:24 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:59:24 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:24 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:59:24 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:24 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:24 --> Total execution time: 0.1035
INFO - 2021-05-17 14:59:44 --> Config Class Initialized
INFO - 2021-05-17 14:59:44 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:44 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:44 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:44 --> URI Class Initialized
INFO - 2021-05-17 14:59:44 --> Router Class Initialized
INFO - 2021-05-17 14:59:44 --> Output Class Initialized
INFO - 2021-05-17 14:59:44 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:44 --> Input Class Initialized
INFO - 2021-05-17 14:59:44 --> Language Class Initialized
INFO - 2021-05-17 14:59:44 --> Loader Class Initialized
INFO - 2021-05-17 14:59:44 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:44 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:44 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:44 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:44 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:44 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:44 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:44 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:44 --> Controller Class Initialized
INFO - 2021-05-17 14:59:44 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:44 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:44 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:44 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:44 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-05-17 14:59:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:44 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:44 --> Total execution time: 0.1466
INFO - 2021-05-17 14:59:44 --> Config Class Initialized
INFO - 2021-05-17 14:59:44 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:44 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:44 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:45 --> URI Class Initialized
INFO - 2021-05-17 14:59:45 --> Router Class Initialized
INFO - 2021-05-17 14:59:45 --> Output Class Initialized
INFO - 2021-05-17 14:59:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:45 --> Input Class Initialized
INFO - 2021-05-17 14:59:45 --> Language Class Initialized
ERROR - 2021-05-17 14:59:45 --> 404 Page Not Found: Cement_demo/generalLedger
INFO - 2021-05-17 14:59:45 --> Config Class Initialized
INFO - 2021-05-17 14:59:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:45 --> URI Class Initialized
INFO - 2021-05-17 14:59:45 --> Router Class Initialized
INFO - 2021-05-17 14:59:45 --> Output Class Initialized
INFO - 2021-05-17 14:59:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:45 --> Input Class Initialized
INFO - 2021-05-17 14:59:45 --> Language Class Initialized
INFO - 2021-05-17 14:59:45 --> Loader Class Initialized
INFO - 2021-05-17 14:59:45 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:45 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:45 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:45 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:45 --> Controller Class Initialized
INFO - 2021-05-17 14:59:45 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:45 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:45 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:45 --> Config Class Initialized
INFO - 2021-05-17 14:59:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:45 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:45 --> URI Class Initialized
INFO - 2021-05-17 14:59:45 --> Router Class Initialized
INFO - 2021-05-17 14:59:45 --> Output Class Initialized
INFO - 2021-05-17 14:59:45 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:45 --> Input Class Initialized
INFO - 2021-05-17 14:59:45 --> Language Class Initialized
INFO - 2021-05-17 14:59:45 --> Loader Class Initialized
INFO - 2021-05-17 14:59:45 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:45 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:45 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:45 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:45 --> Controller Class Initialized
INFO - 2021-05-17 14:59:45 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:45 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:45 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:45 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:59:45 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:59:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:45 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:45 --> Total execution time: 0.1034
INFO - 2021-05-17 14:59:54 --> Config Class Initialized
INFO - 2021-05-17 14:59:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:54 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:54 --> URI Class Initialized
INFO - 2021-05-17 14:59:54 --> Router Class Initialized
INFO - 2021-05-17 14:59:54 --> Output Class Initialized
INFO - 2021-05-17 14:59:54 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:54 --> Input Class Initialized
INFO - 2021-05-17 14:59:54 --> Language Class Initialized
INFO - 2021-05-17 14:59:54 --> Loader Class Initialized
INFO - 2021-05-17 14:59:54 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:54 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:54 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:54 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:54 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:54 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:54 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:54 --> Controller Class Initialized
INFO - 2021-05-17 14:59:54 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:54 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:54 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:54 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-05-17 14:59:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:54 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:54 --> Total execution time: 0.2108
INFO - 2021-05-17 14:59:54 --> Config Class Initialized
INFO - 2021-05-17 14:59:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:54 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:54 --> URI Class Initialized
INFO - 2021-05-17 14:59:54 --> Router Class Initialized
INFO - 2021-05-17 14:59:54 --> Output Class Initialized
INFO - 2021-05-17 14:59:54 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:54 --> Input Class Initialized
INFO - 2021-05-17 14:59:54 --> Language Class Initialized
ERROR - 2021-05-17 14:59:54 --> 404 Page Not Found: Cement_demo/generalLedger
INFO - 2021-05-17 14:59:55 --> Config Class Initialized
INFO - 2021-05-17 14:59:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:55 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:55 --> URI Class Initialized
INFO - 2021-05-17 14:59:55 --> Router Class Initialized
INFO - 2021-05-17 14:59:55 --> Output Class Initialized
INFO - 2021-05-17 14:59:55 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:55 --> Input Class Initialized
INFO - 2021-05-17 14:59:55 --> Language Class Initialized
INFO - 2021-05-17 14:59:55 --> Loader Class Initialized
INFO - 2021-05-17 14:59:55 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:55 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:55 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:55 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:55 --> Controller Class Initialized
INFO - 2021-05-17 14:59:55 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:55 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:55 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:55 --> Config Class Initialized
INFO - 2021-05-17 14:59:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:55 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:55 --> URI Class Initialized
INFO - 2021-05-17 14:59:55 --> Router Class Initialized
INFO - 2021-05-17 14:59:55 --> Output Class Initialized
INFO - 2021-05-17 14:59:55 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:55 --> Input Class Initialized
INFO - 2021-05-17 14:59:55 --> Language Class Initialized
INFO - 2021-05-17 14:59:55 --> Loader Class Initialized
INFO - 2021-05-17 14:59:55 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:55 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:55 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:55 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:55 --> Controller Class Initialized
INFO - 2021-05-17 14:59:55 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:55 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:55 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:55 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 14:59:55 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 14:59:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:55 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:55 --> Total execution time: 0.1225
INFO - 2021-05-17 14:59:58 --> Config Class Initialized
INFO - 2021-05-17 14:59:58 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:58 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:58 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:58 --> URI Class Initialized
INFO - 2021-05-17 14:59:58 --> Router Class Initialized
INFO - 2021-05-17 14:59:58 --> Output Class Initialized
INFO - 2021-05-17 14:59:58 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:58 --> Input Class Initialized
INFO - 2021-05-17 14:59:58 --> Language Class Initialized
INFO - 2021-05-17 14:59:58 --> Loader Class Initialized
INFO - 2021-05-17 14:59:58 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:58 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:58 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:58 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:58 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:58 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:58 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:58 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:58 --> Controller Class Initialized
INFO - 2021-05-17 14:59:58 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:58 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:58 --> Model "Sales_Model" initialized
INFO - 2021-05-17 14:59:58 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/receive/receiveVoucherView.php
INFO - 2021-05-17 14:59:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 14:59:58 --> Final output sent to browser
DEBUG - 2021-05-17 14:59:58 --> Total execution time: 0.1267
INFO - 2021-05-17 14:59:59 --> Config Class Initialized
INFO - 2021-05-17 14:59:59 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:59 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:59 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:59 --> URI Class Initialized
INFO - 2021-05-17 14:59:59 --> Router Class Initialized
INFO - 2021-05-17 14:59:59 --> Output Class Initialized
INFO - 2021-05-17 14:59:59 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:59 --> Input Class Initialized
INFO - 2021-05-17 14:59:59 --> Language Class Initialized
ERROR - 2021-05-17 14:59:59 --> 404 Page Not Found: Cement_demo/receiveVoucherView
INFO - 2021-05-17 14:59:59 --> Config Class Initialized
INFO - 2021-05-17 14:59:59 --> Hooks Class Initialized
DEBUG - 2021-05-17 14:59:59 --> UTF-8 Support Enabled
INFO - 2021-05-17 14:59:59 --> Utf8 Class Initialized
INFO - 2021-05-17 14:59:59 --> URI Class Initialized
INFO - 2021-05-17 14:59:59 --> Router Class Initialized
INFO - 2021-05-17 14:59:59 --> Output Class Initialized
INFO - 2021-05-17 14:59:59 --> Security Class Initialized
DEBUG - 2021-05-17 14:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 14:59:59 --> Input Class Initialized
INFO - 2021-05-17 14:59:59 --> Language Class Initialized
INFO - 2021-05-17 14:59:59 --> Loader Class Initialized
INFO - 2021-05-17 14:59:59 --> Helper loaded: url_helper
INFO - 2021-05-17 14:59:59 --> Helper loaded: file_helper
INFO - 2021-05-17 14:59:59 --> Helper loaded: utility_helper
INFO - 2021-05-17 14:59:59 --> Helper loaded: unit_helper
INFO - 2021-05-17 14:59:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 14:59:59 --> Database Driver Class Initialized
INFO - 2021-05-17 14:59:59 --> Email Class Initialized
DEBUG - 2021-05-17 14:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 14:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 14:59:59 --> Helper loaded: form_helper
INFO - 2021-05-17 14:59:59 --> Form Validation Class Initialized
INFO - 2021-05-17 14:59:59 --> Controller Class Initialized
INFO - 2021-05-17 14:59:59 --> Model "Common_model" initialized
INFO - 2021-05-17 14:59:59 --> Model "Finane_Model" initialized
INFO - 2021-05-17 14:59:59 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 14:59:59 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:00:00 --> Config Class Initialized
INFO - 2021-05-17 15:00:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:00:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:00:00 --> Utf8 Class Initialized
INFO - 2021-05-17 15:00:00 --> URI Class Initialized
INFO - 2021-05-17 15:00:00 --> Router Class Initialized
INFO - 2021-05-17 15:00:00 --> Output Class Initialized
INFO - 2021-05-17 15:00:00 --> Security Class Initialized
DEBUG - 2021-05-17 15:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:00:00 --> Input Class Initialized
INFO - 2021-05-17 15:00:00 --> Language Class Initialized
INFO - 2021-05-17 15:00:00 --> Loader Class Initialized
INFO - 2021-05-17 15:00:00 --> Helper loaded: url_helper
INFO - 2021-05-17 15:00:00 --> Helper loaded: file_helper
INFO - 2021-05-17 15:00:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:00:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:00:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:00:00 --> Database Driver Class Initialized
INFO - 2021-05-17 15:00:00 --> Email Class Initialized
DEBUG - 2021-05-17 15:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:00:00 --> Helper loaded: form_helper
INFO - 2021-05-17 15:00:00 --> Form Validation Class Initialized
INFO - 2021-05-17 15:00:00 --> Controller Class Initialized
INFO - 2021-05-17 15:00:00 --> Model "Common_model" initialized
INFO - 2021-05-17 15:00:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:00:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:00:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:00:00 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 15:00:00 --> Database Driver Class Initialized
INFO - 2021-05-17 15:00:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 15:00:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:00:00 --> Final output sent to browser
DEBUG - 2021-05-17 15:00:00 --> Total execution time: 0.1570
INFO - 2021-05-17 15:00:14 --> Config Class Initialized
INFO - 2021-05-17 15:00:14 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:00:14 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:00:14 --> Utf8 Class Initialized
INFO - 2021-05-17 15:00:14 --> URI Class Initialized
INFO - 2021-05-17 15:00:14 --> Router Class Initialized
INFO - 2021-05-17 15:00:14 --> Output Class Initialized
INFO - 2021-05-17 15:00:14 --> Security Class Initialized
DEBUG - 2021-05-17 15:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:00:14 --> Input Class Initialized
INFO - 2021-05-17 15:00:14 --> Language Class Initialized
INFO - 2021-05-17 15:00:14 --> Loader Class Initialized
INFO - 2021-05-17 15:00:14 --> Helper loaded: url_helper
INFO - 2021-05-17 15:00:14 --> Helper loaded: file_helper
INFO - 2021-05-17 15:00:14 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:00:14 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:00:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:00:14 --> Database Driver Class Initialized
INFO - 2021-05-17 15:00:14 --> Email Class Initialized
DEBUG - 2021-05-17 15:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:00:14 --> Helper loaded: form_helper
INFO - 2021-05-17 15:00:14 --> Form Validation Class Initialized
INFO - 2021-05-17 15:00:14 --> Controller Class Initialized
INFO - 2021-05-17 15:00:14 --> Model "Common_model" initialized
INFO - 2021-05-17 15:00:14 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:00:14 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:00:14 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:00:14 --> Database Driver Class Initialized
INFO - 2021-05-17 15:00:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/setup/ViewChartOfAccount.php
INFO - 2021-05-17 15:00:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:00:15 --> Final output sent to browser
DEBUG - 2021-05-17 15:00:15 --> Total execution time: 0.6313
INFO - 2021-05-17 15:00:15 --> Config Class Initialized
INFO - 2021-05-17 15:00:15 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:00:15 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:00:15 --> Utf8 Class Initialized
INFO - 2021-05-17 15:00:15 --> URI Class Initialized
INFO - 2021-05-17 15:00:15 --> Router Class Initialized
INFO - 2021-05-17 15:00:15 --> Output Class Initialized
INFO - 2021-05-17 15:00:15 --> Security Class Initialized
DEBUG - 2021-05-17 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:00:15 --> Input Class Initialized
INFO - 2021-05-17 15:00:15 --> Language Class Initialized
ERROR - 2021-05-17 15:00:15 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 15:00:16 --> Config Class Initialized
INFO - 2021-05-17 15:00:16 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:00:16 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:00:16 --> Utf8 Class Initialized
INFO - 2021-05-17 15:00:16 --> URI Class Initialized
INFO - 2021-05-17 15:00:16 --> Router Class Initialized
INFO - 2021-05-17 15:00:16 --> Output Class Initialized
INFO - 2021-05-17 15:00:16 --> Security Class Initialized
DEBUG - 2021-05-17 15:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:00:16 --> Input Class Initialized
INFO - 2021-05-17 15:00:16 --> Language Class Initialized
INFO - 2021-05-17 15:00:16 --> Loader Class Initialized
INFO - 2021-05-17 15:00:16 --> Helper loaded: url_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: file_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:00:16 --> Database Driver Class Initialized
INFO - 2021-05-17 15:00:16 --> Email Class Initialized
DEBUG - 2021-05-17 15:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:00:16 --> Helper loaded: form_helper
INFO - 2021-05-17 15:00:16 --> Form Validation Class Initialized
INFO - 2021-05-17 15:00:16 --> Controller Class Initialized
INFO - 2021-05-17 15:00:16 --> Model "Common_model" initialized
INFO - 2021-05-17 15:00:16 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:00:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:00:16 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:00:16 --> Config Class Initialized
INFO - 2021-05-17 15:00:16 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:00:16 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:00:16 --> Utf8 Class Initialized
INFO - 2021-05-17 15:00:16 --> URI Class Initialized
INFO - 2021-05-17 15:00:16 --> Router Class Initialized
INFO - 2021-05-17 15:00:16 --> Output Class Initialized
INFO - 2021-05-17 15:00:16 --> Security Class Initialized
DEBUG - 2021-05-17 15:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:00:16 --> Input Class Initialized
INFO - 2021-05-17 15:00:16 --> Language Class Initialized
INFO - 2021-05-17 15:00:16 --> Loader Class Initialized
INFO - 2021-05-17 15:00:16 --> Helper loaded: url_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: file_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:00:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:00:16 --> Database Driver Class Initialized
INFO - 2021-05-17 15:00:16 --> Email Class Initialized
DEBUG - 2021-05-17 15:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:00:16 --> Helper loaded: form_helper
INFO - 2021-05-17 15:00:16 --> Form Validation Class Initialized
INFO - 2021-05-17 15:00:16 --> Controller Class Initialized
INFO - 2021-05-17 15:00:16 --> Model "Common_model" initialized
INFO - 2021-05-17 15:00:16 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:00:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:00:16 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:00:16 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 15:00:16 --> Database Driver Class Initialized
INFO - 2021-05-17 15:00:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 15:00:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:00:16 --> Final output sent to browser
DEBUG - 2021-05-17 15:00:16 --> Total execution time: 0.1858
INFO - 2021-05-17 15:01:33 --> Config Class Initialized
INFO - 2021-05-17 15:01:33 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:33 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:33 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:33 --> URI Class Initialized
INFO - 2021-05-17 15:01:33 --> Router Class Initialized
INFO - 2021-05-17 15:01:34 --> Output Class Initialized
INFO - 2021-05-17 15:01:34 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:34 --> Input Class Initialized
INFO - 2021-05-17 15:01:34 --> Language Class Initialized
INFO - 2021-05-17 15:01:34 --> Loader Class Initialized
INFO - 2021-05-17 15:01:34 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:34 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:34 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:34 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:34 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:34 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:34 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:34 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:34 --> Controller Class Initialized
INFO - 2021-05-17 15:01:34 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:34 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:34 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:34 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:34 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/payment/paymentVoucher.php
INFO - 2021-05-17 15:01:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:01:34 --> Final output sent to browser
DEBUG - 2021-05-17 15:01:34 --> Total execution time: 0.1578
INFO - 2021-05-17 15:01:34 --> Config Class Initialized
INFO - 2021-05-17 15:01:34 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:34 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:34 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:34 --> URI Class Initialized
INFO - 2021-05-17 15:01:34 --> Router Class Initialized
INFO - 2021-05-17 15:01:34 --> Output Class Initialized
INFO - 2021-05-17 15:01:34 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:34 --> Input Class Initialized
INFO - 2021-05-17 15:01:34 --> Language Class Initialized
ERROR - 2021-05-17 15:01:34 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 15:01:35 --> Config Class Initialized
INFO - 2021-05-17 15:01:35 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:35 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:35 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:35 --> URI Class Initialized
INFO - 2021-05-17 15:01:35 --> Router Class Initialized
INFO - 2021-05-17 15:01:35 --> Output Class Initialized
INFO - 2021-05-17 15:01:35 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:35 --> Input Class Initialized
INFO - 2021-05-17 15:01:35 --> Language Class Initialized
INFO - 2021-05-17 15:01:35 --> Loader Class Initialized
INFO - 2021-05-17 15:01:35 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:35 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:35 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:35 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:35 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:35 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:35 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:35 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:35 --> Controller Class Initialized
INFO - 2021-05-17 15:01:35 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:35 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:35 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:35 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:35 --> Model "ServerFilterModel" initialized
INFO - 2021-05-17 15:01:35 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:35 --> Final output sent to browser
DEBUG - 2021-05-17 15:01:35 --> Total execution time: 0.1124
INFO - 2021-05-17 15:01:36 --> Config Class Initialized
INFO - 2021-05-17 15:01:36 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:36 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:36 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:36 --> URI Class Initialized
INFO - 2021-05-17 15:01:36 --> Router Class Initialized
INFO - 2021-05-17 15:01:36 --> Output Class Initialized
INFO - 2021-05-17 15:01:36 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:36 --> Input Class Initialized
INFO - 2021-05-17 15:01:36 --> Language Class Initialized
INFO - 2021-05-17 15:01:36 --> Loader Class Initialized
INFO - 2021-05-17 15:01:36 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:36 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:36 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:36 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:36 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:36 --> Controller Class Initialized
INFO - 2021-05-17 15:01:36 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:36 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:36 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:36 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:36 --> Config Class Initialized
INFO - 2021-05-17 15:01:36 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:36 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:36 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:36 --> URI Class Initialized
INFO - 2021-05-17 15:01:36 --> Router Class Initialized
INFO - 2021-05-17 15:01:36 --> Output Class Initialized
INFO - 2021-05-17 15:01:36 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:36 --> Input Class Initialized
INFO - 2021-05-17 15:01:36 --> Language Class Initialized
INFO - 2021-05-17 15:01:36 --> Loader Class Initialized
INFO - 2021-05-17 15:01:36 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:36 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:36 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:36 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:36 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:36 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:36 --> Controller Class Initialized
INFO - 2021-05-17 15:01:36 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:36 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:36 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:36 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:36 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 15:01:36 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:36 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 15:01:36 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:01:36 --> Final output sent to browser
DEBUG - 2021-05-17 15:01:36 --> Total execution time: 0.1164
INFO - 2021-05-17 15:01:37 --> Config Class Initialized
INFO - 2021-05-17 15:01:37 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:37 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:37 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:37 --> URI Class Initialized
INFO - 2021-05-17 15:01:37 --> Router Class Initialized
INFO - 2021-05-17 15:01:37 --> Output Class Initialized
INFO - 2021-05-17 15:01:37 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:37 --> Input Class Initialized
INFO - 2021-05-17 15:01:37 --> Language Class Initialized
INFO - 2021-05-17 15:01:37 --> Loader Class Initialized
INFO - 2021-05-17 15:01:37 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:37 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:37 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:37 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:37 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:37 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:37 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:37 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:37 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:37 --> Controller Class Initialized
INFO - 2021-05-17 15:01:37 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:37 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:37 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:37 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:37 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/payment/paymentVoucherAdd.php
INFO - 2021-05-17 15:01:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:01:37 --> Final output sent to browser
DEBUG - 2021-05-17 15:01:37 --> Total execution time: 0.1112
INFO - 2021-05-17 15:01:37 --> Config Class Initialized
INFO - 2021-05-17 15:01:37 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:37 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:37 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:37 --> URI Class Initialized
INFO - 2021-05-17 15:01:37 --> Router Class Initialized
INFO - 2021-05-17 15:01:37 --> Output Class Initialized
INFO - 2021-05-17 15:01:37 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:37 --> Input Class Initialized
INFO - 2021-05-17 15:01:37 --> Language Class Initialized
ERROR - 2021-05-17 15:01:37 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 15:01:38 --> Config Class Initialized
INFO - 2021-05-17 15:01:38 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:38 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:38 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:38 --> URI Class Initialized
INFO - 2021-05-17 15:01:38 --> Router Class Initialized
INFO - 2021-05-17 15:01:38 --> Output Class Initialized
INFO - 2021-05-17 15:01:38 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:38 --> Input Class Initialized
INFO - 2021-05-17 15:01:38 --> Language Class Initialized
INFO - 2021-05-17 15:01:38 --> Loader Class Initialized
INFO - 2021-05-17 15:01:38 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:38 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:38 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:38 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:38 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:38 --> Controller Class Initialized
INFO - 2021-05-17 15:01:38 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:38 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:38 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:38 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:38 --> Config Class Initialized
INFO - 2021-05-17 15:01:38 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:38 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:38 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:38 --> URI Class Initialized
INFO - 2021-05-17 15:01:38 --> Router Class Initialized
INFO - 2021-05-17 15:01:38 --> Output Class Initialized
INFO - 2021-05-17 15:01:38 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:38 --> Input Class Initialized
INFO - 2021-05-17 15:01:38 --> Language Class Initialized
INFO - 2021-05-17 15:01:38 --> Loader Class Initialized
INFO - 2021-05-17 15:01:38 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:38 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:38 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:38 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:38 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:38 --> Controller Class Initialized
INFO - 2021-05-17 15:01:38 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:38 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:38 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:38 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:38 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 15:01:38 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:38 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 15:01:38 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:01:38 --> Final output sent to browser
DEBUG - 2021-05-17 15:01:38 --> Total execution time: 0.1321
INFO - 2021-05-17 15:01:41 --> Config Class Initialized
INFO - 2021-05-17 15:01:41 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:41 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:41 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:41 --> URI Class Initialized
INFO - 2021-05-17 15:01:41 --> Router Class Initialized
INFO - 2021-05-17 15:01:41 --> Output Class Initialized
INFO - 2021-05-17 15:01:41 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:41 --> Input Class Initialized
INFO - 2021-05-17 15:01:41 --> Language Class Initialized
INFO - 2021-05-17 15:01:41 --> Loader Class Initialized
INFO - 2021-05-17 15:01:41 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:41 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:41 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:41 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:41 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:41 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:41 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:41 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:41 --> Controller Class Initialized
INFO - 2021-05-17 15:01:41 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:41 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:41 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:41 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:41 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/payList.php
INFO - 2021-05-17 15:01:41 --> Final output sent to browser
DEBUG - 2021-05-17 15:01:41 --> Total execution time: 0.0716
INFO - 2021-05-17 15:01:45 --> Config Class Initialized
INFO - 2021-05-17 15:01:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:01:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:01:45 --> Utf8 Class Initialized
INFO - 2021-05-17 15:01:45 --> URI Class Initialized
INFO - 2021-05-17 15:01:45 --> Router Class Initialized
INFO - 2021-05-17 15:01:45 --> Output Class Initialized
INFO - 2021-05-17 15:01:45 --> Security Class Initialized
DEBUG - 2021-05-17 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:01:45 --> Input Class Initialized
INFO - 2021-05-17 15:01:45 --> Language Class Initialized
INFO - 2021-05-17 15:01:45 --> Loader Class Initialized
INFO - 2021-05-17 15:01:45 --> Helper loaded: url_helper
INFO - 2021-05-17 15:01:45 --> Helper loaded: file_helper
INFO - 2021-05-17 15:01:45 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:01:45 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:01:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:01:45 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:45 --> Email Class Initialized
DEBUG - 2021-05-17 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:01:45 --> Helper loaded: form_helper
INFO - 2021-05-17 15:01:45 --> Form Validation Class Initialized
INFO - 2021-05-17 15:01:45 --> Controller Class Initialized
INFO - 2021-05-17 15:01:45 --> Model "Common_model" initialized
INFO - 2021-05-17 15:01:45 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:01:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:01:45 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:01:45 --> Database Driver Class Initialized
INFO - 2021-05-17 15:01:45 --> Final output sent to browser
DEBUG - 2021-05-17 15:01:45 --> Total execution time: 0.2095
INFO - 2021-05-17 15:03:15 --> Config Class Initialized
INFO - 2021-05-17 15:03:15 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:03:15 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:03:15 --> Utf8 Class Initialized
INFO - 2021-05-17 15:03:15 --> URI Class Initialized
INFO - 2021-05-17 15:03:15 --> Router Class Initialized
INFO - 2021-05-17 15:03:15 --> Output Class Initialized
INFO - 2021-05-17 15:03:15 --> Security Class Initialized
DEBUG - 2021-05-17 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:03:15 --> Input Class Initialized
INFO - 2021-05-17 15:03:15 --> Language Class Initialized
INFO - 2021-05-17 15:03:15 --> Loader Class Initialized
INFO - 2021-05-17 15:03:15 --> Helper loaded: url_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: file_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:03:15 --> Database Driver Class Initialized
INFO - 2021-05-17 15:03:15 --> Email Class Initialized
DEBUG - 2021-05-17 15:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:03:15 --> Helper loaded: form_helper
INFO - 2021-05-17 15:03:15 --> Form Validation Class Initialized
INFO - 2021-05-17 15:03:15 --> Controller Class Initialized
INFO - 2021-05-17 15:03:15 --> Model "Common_model" initialized
INFO - 2021-05-17 15:03:15 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:03:15 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:03:15 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:03:15 --> Database Driver Class Initialized
INFO - 2021-05-17 15:03:15 --> Final output sent to browser
DEBUG - 2021-05-17 15:03:15 --> Total execution time: 0.1778
INFO - 2021-05-17 15:03:15 --> Config Class Initialized
INFO - 2021-05-17 15:03:15 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:03:15 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:03:15 --> Utf8 Class Initialized
INFO - 2021-05-17 15:03:15 --> URI Class Initialized
INFO - 2021-05-17 15:03:15 --> Router Class Initialized
INFO - 2021-05-17 15:03:15 --> Output Class Initialized
INFO - 2021-05-17 15:03:15 --> Security Class Initialized
DEBUG - 2021-05-17 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:03:15 --> Input Class Initialized
INFO - 2021-05-17 15:03:15 --> Language Class Initialized
INFO - 2021-05-17 15:03:15 --> Loader Class Initialized
INFO - 2021-05-17 15:03:15 --> Helper loaded: url_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: file_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:03:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:03:15 --> Database Driver Class Initialized
INFO - 2021-05-17 15:03:15 --> Email Class Initialized
DEBUG - 2021-05-17 15:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:03:15 --> Helper loaded: form_helper
INFO - 2021-05-17 15:03:15 --> Form Validation Class Initialized
INFO - 2021-05-17 15:03:15 --> Controller Class Initialized
INFO - 2021-05-17 15:03:15 --> Model "Common_model" initialized
INFO - 2021-05-17 15:03:15 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:03:15 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:03:15 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:03:15 --> Database Driver Class Initialized
INFO - 2021-05-17 15:03:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/payList.php
INFO - 2021-05-17 15:03:15 --> Final output sent to browser
DEBUG - 2021-05-17 15:03:15 --> Total execution time: 0.0838
INFO - 2021-05-17 15:04:07 --> Config Class Initialized
INFO - 2021-05-17 15:04:07 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:07 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:07 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:07 --> URI Class Initialized
INFO - 2021-05-17 15:04:07 --> Router Class Initialized
INFO - 2021-05-17 15:04:07 --> Output Class Initialized
INFO - 2021-05-17 15:04:07 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:07 --> Input Class Initialized
INFO - 2021-05-17 15:04:07 --> Language Class Initialized
INFO - 2021-05-17 15:04:07 --> Loader Class Initialized
INFO - 2021-05-17 15:04:07 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:07 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:07 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:07 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:07 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:07 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:07 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:07 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:07 --> Controller Class Initialized
INFO - 2021-05-17 15:04:07 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:07 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:07 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:07 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:07 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:07 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/setup/listChartOfAccount.php
INFO - 2021-05-17 15:04:07 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:04:07 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:07 --> Total execution time: 0.2414
INFO - 2021-05-17 15:04:07 --> Config Class Initialized
INFO - 2021-05-17 15:04:07 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:07 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:07 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:07 --> URI Class Initialized
INFO - 2021-05-17 15:04:07 --> Router Class Initialized
INFO - 2021-05-17 15:04:07 --> Output Class Initialized
INFO - 2021-05-17 15:04:07 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:07 --> Input Class Initialized
INFO - 2021-05-17 15:04:07 --> Language Class Initialized
ERROR - 2021-05-17 15:04:07 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 15:04:08 --> Config Class Initialized
INFO - 2021-05-17 15:04:08 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:08 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:08 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:08 --> URI Class Initialized
INFO - 2021-05-17 15:04:08 --> Router Class Initialized
INFO - 2021-05-17 15:04:08 --> Output Class Initialized
INFO - 2021-05-17 15:04:08 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:08 --> Input Class Initialized
INFO - 2021-05-17 15:04:08 --> Language Class Initialized
INFO - 2021-05-17 15:04:08 --> Loader Class Initialized
INFO - 2021-05-17 15:04:08 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:08 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:08 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:08 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:08 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:08 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:08 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:08 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:08 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:08 --> Controller Class Initialized
INFO - 2021-05-17 15:04:08 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:08 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:08 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:08 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:09 --> Config Class Initialized
INFO - 2021-05-17 15:04:09 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:09 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:09 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:09 --> URI Class Initialized
INFO - 2021-05-17 15:04:09 --> Router Class Initialized
INFO - 2021-05-17 15:04:09 --> Output Class Initialized
INFO - 2021-05-17 15:04:09 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:09 --> Input Class Initialized
INFO - 2021-05-17 15:04:09 --> Language Class Initialized
INFO - 2021-05-17 15:04:09 --> Loader Class Initialized
INFO - 2021-05-17 15:04:09 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:09 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:09 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:09 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:09 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:09 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:09 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:09 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:09 --> Controller Class Initialized
INFO - 2021-05-17 15:04:09 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:09 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:09 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:09 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:09 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 15:04:09 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:10 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 15:04:10 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:04:10 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:10 --> Total execution time: 1.2020
INFO - 2021-05-17 15:04:12 --> Config Class Initialized
INFO - 2021-05-17 15:04:12 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:12 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:12 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:12 --> URI Class Initialized
INFO - 2021-05-17 15:04:12 --> Router Class Initialized
INFO - 2021-05-17 15:04:12 --> Output Class Initialized
INFO - 2021-05-17 15:04:12 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:12 --> Input Class Initialized
INFO - 2021-05-17 15:04:12 --> Language Class Initialized
INFO - 2021-05-17 15:04:12 --> Loader Class Initialized
INFO - 2021-05-17 15:04:12 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:12 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:12 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:12 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:12 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:12 --> Controller Class Initialized
INFO - 2021-05-17 15:04:12 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:12 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:12 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:12 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:12 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:12 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/setup/chartOfAccount.php
INFO - 2021-05-17 15:04:12 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:04:12 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:12 --> Total execution time: 0.0779
INFO - 2021-05-17 15:04:12 --> Config Class Initialized
INFO - 2021-05-17 15:04:12 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:12 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:12 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:12 --> URI Class Initialized
INFO - 2021-05-17 15:04:12 --> Router Class Initialized
INFO - 2021-05-17 15:04:12 --> Output Class Initialized
INFO - 2021-05-17 15:04:12 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:12 --> Input Class Initialized
INFO - 2021-05-17 15:04:12 --> Language Class Initialized
ERROR - 2021-05-17 15:04:12 --> 404 Page Not Found: Cement_demo/assets
INFO - 2021-05-17 15:04:12 --> Config Class Initialized
INFO - 2021-05-17 15:04:12 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:12 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:12 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:12 --> URI Class Initialized
INFO - 2021-05-17 15:04:12 --> Router Class Initialized
INFO - 2021-05-17 15:04:12 --> Output Class Initialized
INFO - 2021-05-17 15:04:12 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:12 --> Input Class Initialized
INFO - 2021-05-17 15:04:12 --> Language Class Initialized
INFO - 2021-05-17 15:04:12 --> Loader Class Initialized
INFO - 2021-05-17 15:04:12 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:12 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:12 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:12 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:12 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:12 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:12 --> Controller Class Initialized
INFO - 2021-05-17 15:04:12 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:12 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:12 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:12 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:13 --> Config Class Initialized
INFO - 2021-05-17 15:04:13 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:13 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:13 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:13 --> URI Class Initialized
INFO - 2021-05-17 15:04:13 --> Router Class Initialized
INFO - 2021-05-17 15:04:13 --> Output Class Initialized
INFO - 2021-05-17 15:04:13 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:13 --> Input Class Initialized
INFO - 2021-05-17 15:04:13 --> Language Class Initialized
INFO - 2021-05-17 15:04:13 --> Loader Class Initialized
INFO - 2021-05-17 15:04:13 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:13 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:13 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:13 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:13 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:13 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:13 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:13 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:13 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:13 --> Controller Class Initialized
INFO - 2021-05-17 15:04:13 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:13 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:13 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:13 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:13 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 15:04:13 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:13 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 15:04:13 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:04:13 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:13 --> Total execution time: 0.1211
INFO - 2021-05-17 15:04:19 --> Config Class Initialized
INFO - 2021-05-17 15:04:19 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:19 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:19 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:19 --> URI Class Initialized
INFO - 2021-05-17 15:04:19 --> Router Class Initialized
INFO - 2021-05-17 15:04:19 --> Output Class Initialized
INFO - 2021-05-17 15:04:19 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:19 --> Input Class Initialized
INFO - 2021-05-17 15:04:19 --> Language Class Initialized
INFO - 2021-05-17 15:04:19 --> Loader Class Initialized
INFO - 2021-05-17 15:04:19 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:19 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:19 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:19 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:19 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:19 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:19 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:19 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:19 --> Controller Class Initialized
INFO - 2021-05-17 15:04:19 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:19 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:19 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:19 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:19 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTree.php
ERROR - 2021-05-17 15:04:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/aelbfopi/amarcement.com/application/controllers/FinaneController.php 72
INFO - 2021-05-17 15:04:19 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:19 --> Total execution time: 0.0707
INFO - 2021-05-17 15:04:20 --> Config Class Initialized
INFO - 2021-05-17 15:04:20 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:20 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:20 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:20 --> URI Class Initialized
INFO - 2021-05-17 15:04:20 --> Router Class Initialized
INFO - 2021-05-17 15:04:20 --> Output Class Initialized
INFO - 2021-05-17 15:04:20 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:20 --> Input Class Initialized
INFO - 2021-05-17 15:04:20 --> Language Class Initialized
INFO - 2021-05-17 15:04:20 --> Loader Class Initialized
INFO - 2021-05-17 15:04:20 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:20 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:20 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:20 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:20 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:20 --> Controller Class Initialized
INFO - 2021-05-17 15:04:20 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:20 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:20 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:20 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:20 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:20 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:20 --> Total execution time: 0.0752
INFO - 2021-05-17 15:04:20 --> Config Class Initialized
INFO - 2021-05-17 15:04:20 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:20 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:20 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:20 --> URI Class Initialized
INFO - 2021-05-17 15:04:20 --> Router Class Initialized
INFO - 2021-05-17 15:04:20 --> Output Class Initialized
INFO - 2021-05-17 15:04:20 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:20 --> Input Class Initialized
INFO - 2021-05-17 15:04:20 --> Language Class Initialized
INFO - 2021-05-17 15:04:20 --> Loader Class Initialized
INFO - 2021-05-17 15:04:20 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:20 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:20 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:20 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:20 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:20 --> Controller Class Initialized
INFO - 2021-05-17 15:04:20 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:20 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:20 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:20 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:20 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:32 --> Config Class Initialized
INFO - 2021-05-17 15:04:32 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:32 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:32 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:32 --> URI Class Initialized
INFO - 2021-05-17 15:04:32 --> Router Class Initialized
INFO - 2021-05-17 15:04:32 --> Output Class Initialized
INFO - 2021-05-17 15:04:32 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:32 --> Input Class Initialized
INFO - 2021-05-17 15:04:32 --> Language Class Initialized
INFO - 2021-05-17 15:04:32 --> Loader Class Initialized
INFO - 2021-05-17 15:04:32 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:32 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:32 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:32 --> Config Class Initialized
INFO - 2021-05-17 15:04:32 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:32 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:32 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:32 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:32 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:32 --> Controller Class Initialized
INFO - 2021-05-17 15:04:32 --> URI Class Initialized
INFO - 2021-05-17 15:04:32 --> Router Class Initialized
INFO - 2021-05-17 15:04:32 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:32 --> Output Class Initialized
INFO - 2021-05-17 15:04:32 --> Security Class Initialized
INFO - 2021-05-17 15:04:32 --> Model "Finane_Model" initialized
DEBUG - 2021-05-17 15:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:32 --> Input Class Initialized
INFO - 2021-05-17 15:04:32 --> Language Class Initialized
INFO - 2021-05-17 15:04:32 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:32 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:32 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:32 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:32 --> Total execution time: 0.0541
INFO - 2021-05-17 15:04:32 --> Loader Class Initialized
INFO - 2021-05-17 15:04:32 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:32 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:32 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:32 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:32 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:32 --> Controller Class Initialized
INFO - 2021-05-17 15:04:32 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:32 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:32 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:32 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:32 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:33 --> Config Class Initialized
INFO - 2021-05-17 15:04:33 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:04:33 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:04:33 --> Utf8 Class Initialized
INFO - 2021-05-17 15:04:33 --> URI Class Initialized
INFO - 2021-05-17 15:04:33 --> Router Class Initialized
INFO - 2021-05-17 15:04:33 --> Output Class Initialized
INFO - 2021-05-17 15:04:33 --> Security Class Initialized
DEBUG - 2021-05-17 15:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:04:33 --> Input Class Initialized
INFO - 2021-05-17 15:04:33 --> Language Class Initialized
INFO - 2021-05-17 15:04:33 --> Loader Class Initialized
INFO - 2021-05-17 15:04:33 --> Helper loaded: url_helper
INFO - 2021-05-17 15:04:33 --> Helper loaded: file_helper
INFO - 2021-05-17 15:04:33 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:04:33 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:04:33 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:04:33 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:33 --> Email Class Initialized
DEBUG - 2021-05-17 15:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:04:33 --> Helper loaded: form_helper
INFO - 2021-05-17 15:04:33 --> Form Validation Class Initialized
INFO - 2021-05-17 15:04:33 --> Controller Class Initialized
INFO - 2021-05-17 15:04:33 --> Model "Common_model" initialized
INFO - 2021-05-17 15:04:33 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:04:33 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:04:33 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:04:33 --> Database Driver Class Initialized
INFO - 2021-05-17 15:04:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTree.php
ERROR - 2021-05-17 15:04:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/aelbfopi/amarcement.com/application/controllers/FinaneController.php 76
INFO - 2021-05-17 15:04:33 --> Final output sent to browser
DEBUG - 2021-05-17 15:04:33 --> Total execution time: 0.0764
INFO - 2021-05-17 15:05:29 --> Config Class Initialized
INFO - 2021-05-17 15:05:29 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:05:29 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:29 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:29 --> URI Class Initialized
INFO - 2021-05-17 15:05:29 --> Config Class Initialized
INFO - 2021-05-17 15:05:29 --> Router Class Initialized
INFO - 2021-05-17 15:05:29 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:05:30 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:30 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:30 --> Output Class Initialized
INFO - 2021-05-17 15:05:30 --> URI Class Initialized
INFO - 2021-05-17 15:05:30 --> Security Class Initialized
DEBUG - 2021-05-17 15:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:30 --> Input Class Initialized
INFO - 2021-05-17 15:05:30 --> Router Class Initialized
INFO - 2021-05-17 15:05:30 --> Language Class Initialized
INFO - 2021-05-17 15:05:30 --> Output Class Initialized
INFO - 2021-05-17 15:05:30 --> Security Class Initialized
DEBUG - 2021-05-17 15:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:30 --> Input Class Initialized
INFO - 2021-05-17 15:05:30 --> Language Class Initialized
INFO - 2021-05-17 15:05:30 --> Loader Class Initialized
INFO - 2021-05-17 15:05:30 --> Loader Class Initialized
INFO - 2021-05-17 15:05:30 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:30 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:30 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:30 --> Email Class Initialized
INFO - 2021-05-17 15:05:30 --> Email Class Initialized
DEBUG - 2021-05-17 15:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-17 15:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:30 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:30 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:30 --> Controller Class Initialized
INFO - 2021-05-17 15:05:30 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:30 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:30 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:30 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:30 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:30 --> Final output sent to browser
DEBUG - 2021-05-17 15:05:30 --> Total execution time: 0.0702
INFO - 2021-05-17 15:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:30 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:30 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:30 --> Controller Class Initialized
INFO - 2021-05-17 15:05:30 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:30 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:30 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:30 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:30 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTree.php
ERROR - 2021-05-17 15:05:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/aelbfopi/amarcement.com/application/controllers/FinaneController.php 76
INFO - 2021-05-17 15:05:30 --> Final output sent to browser
DEBUG - 2021-05-17 15:05:30 --> Total execution time: 0.1086
INFO - 2021-05-17 15:05:31 --> Config Class Initialized
INFO - 2021-05-17 15:05:31 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:05:31 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:31 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:31 --> URI Class Initialized
INFO - 2021-05-17 15:05:31 --> Router Class Initialized
INFO - 2021-05-17 15:05:31 --> Output Class Initialized
INFO - 2021-05-17 15:05:31 --> Security Class Initialized
DEBUG - 2021-05-17 15:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:31 --> Input Class Initialized
INFO - 2021-05-17 15:05:31 --> Language Class Initialized
INFO - 2021-05-17 15:05:31 --> Loader Class Initialized
INFO - 2021-05-17 15:05:31 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:31 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:31 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:31 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:31 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:31 --> Email Class Initialized
DEBUG - 2021-05-17 15:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:31 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:31 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:31 --> Controller Class Initialized
INFO - 2021-05-17 15:05:31 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:31 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:31 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:31 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:31 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:37 --> Config Class Initialized
INFO - 2021-05-17 15:05:37 --> Config Class Initialized
INFO - 2021-05-17 15:05:37 --> Hooks Class Initialized
INFO - 2021-05-17 15:05:37 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-05-17 15:05:37 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:37 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:37 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:37 --> URI Class Initialized
INFO - 2021-05-17 15:05:37 --> URI Class Initialized
INFO - 2021-05-17 15:05:37 --> Router Class Initialized
INFO - 2021-05-17 15:05:37 --> Router Class Initialized
INFO - 2021-05-17 15:05:37 --> Output Class Initialized
INFO - 2021-05-17 15:05:37 --> Output Class Initialized
INFO - 2021-05-17 15:05:37 --> Security Class Initialized
INFO - 2021-05-17 15:05:37 --> Security Class Initialized
DEBUG - 2021-05-17 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:37 --> Input Class Initialized
INFO - 2021-05-17 15:05:37 --> Language Class Initialized
DEBUG - 2021-05-17 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:37 --> Input Class Initialized
INFO - 2021-05-17 15:05:37 --> Language Class Initialized
INFO - 2021-05-17 15:05:37 --> Loader Class Initialized
INFO - 2021-05-17 15:05:37 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:37 --> Loader Class Initialized
INFO - 2021-05-17 15:05:37 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:37 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:37 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:37 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:37 --> Email Class Initialized
DEBUG - 2021-05-17 15:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:37 --> Email Class Initialized
INFO - 2021-05-17 15:05:37 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:37 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:37 --> Controller Class Initialized
DEBUG - 2021-05-17 15:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:37 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:37 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:37 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:37 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:37 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:37 --> Final output sent to browser
DEBUG - 2021-05-17 15:05:37 --> Total execution time: 0.0750
INFO - 2021-05-17 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:37 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:37 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:37 --> Controller Class Initialized
INFO - 2021-05-17 15:05:37 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:37 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:37 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:37 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:37 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTree.php
ERROR - 2021-05-17 15:05:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/aelbfopi/amarcement.com/application/controllers/FinaneController.php 72
INFO - 2021-05-17 15:05:37 --> Final output sent to browser
DEBUG - 2021-05-17 15:05:37 --> Total execution time: 0.1045
INFO - 2021-05-17 15:05:38 --> Config Class Initialized
INFO - 2021-05-17 15:05:38 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:05:38 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:38 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:38 --> URI Class Initialized
INFO - 2021-05-17 15:05:38 --> Router Class Initialized
INFO - 2021-05-17 15:05:38 --> Output Class Initialized
INFO - 2021-05-17 15:05:38 --> Security Class Initialized
DEBUG - 2021-05-17 15:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:38 --> Input Class Initialized
INFO - 2021-05-17 15:05:38 --> Language Class Initialized
INFO - 2021-05-17 15:05:38 --> Loader Class Initialized
INFO - 2021-05-17 15:05:38 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:38 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:38 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:38 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:38 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:38 --> Email Class Initialized
DEBUG - 2021-05-17 15:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:38 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:38 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:38 --> Controller Class Initialized
INFO - 2021-05-17 15:05:38 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:38 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:38 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:38 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:38 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:42 --> Config Class Initialized
INFO - 2021-05-17 15:05:42 --> Hooks Class Initialized
INFO - 2021-05-17 15:05:42 --> Config Class Initialized
INFO - 2021-05-17 15:05:42 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:05:42 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:42 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:42 --> URI Class Initialized
DEBUG - 2021-05-17 15:05:42 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:42 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:42 --> URI Class Initialized
INFO - 2021-05-17 15:05:42 --> Router Class Initialized
INFO - 2021-05-17 15:05:42 --> Router Class Initialized
INFO - 2021-05-17 15:05:42 --> Output Class Initialized
INFO - 2021-05-17 15:05:42 --> Security Class Initialized
INFO - 2021-05-17 15:05:42 --> Output Class Initialized
DEBUG - 2021-05-17 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:42 --> Input Class Initialized
INFO - 2021-05-17 15:05:42 --> Language Class Initialized
INFO - 2021-05-17 15:05:42 --> Security Class Initialized
DEBUG - 2021-05-17 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:42 --> Input Class Initialized
INFO - 2021-05-17 15:05:42 --> Language Class Initialized
INFO - 2021-05-17 15:05:42 --> Loader Class Initialized
INFO - 2021-05-17 15:05:42 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:42 --> Loader Class Initialized
INFO - 2021-05-17 15:05:42 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:42 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:42 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:42 --> Email Class Initialized
INFO - 2021-05-17 15:05:42 --> Database Driver Class Initialized
DEBUG - 2021-05-17 15:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:42 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:42 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:42 --> Controller Class Initialized
INFO - 2021-05-17 15:05:42 --> Email Class Initialized
DEBUG - 2021-05-17 15:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:42 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:42 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:42 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:42 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:43 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:43 --> Final output sent to browser
DEBUG - 2021-05-17 15:05:43 --> Total execution time: 0.0589
INFO - 2021-05-17 15:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:43 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:43 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:43 --> Controller Class Initialized
INFO - 2021-05-17 15:05:43 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:43 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:43 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:43 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:43 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:43 --> Config Class Initialized
INFO - 2021-05-17 15:05:43 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:05:43 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:05:43 --> Utf8 Class Initialized
INFO - 2021-05-17 15:05:43 --> URI Class Initialized
INFO - 2021-05-17 15:05:43 --> Router Class Initialized
INFO - 2021-05-17 15:05:43 --> Output Class Initialized
INFO - 2021-05-17 15:05:43 --> Security Class Initialized
DEBUG - 2021-05-17 15:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:05:43 --> Input Class Initialized
INFO - 2021-05-17 15:05:43 --> Language Class Initialized
INFO - 2021-05-17 15:05:43 --> Loader Class Initialized
INFO - 2021-05-17 15:05:43 --> Helper loaded: url_helper
INFO - 2021-05-17 15:05:43 --> Helper loaded: file_helper
INFO - 2021-05-17 15:05:43 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:05:43 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:05:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:05:43 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:43 --> Email Class Initialized
DEBUG - 2021-05-17 15:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:05:44 --> Helper loaded: form_helper
INFO - 2021-05-17 15:05:44 --> Form Validation Class Initialized
INFO - 2021-05-17 15:05:44 --> Controller Class Initialized
INFO - 2021-05-17 15:05:44 --> Model "Common_model" initialized
INFO - 2021-05-17 15:05:44 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:05:44 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:05:44 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:05:44 --> Database Driver Class Initialized
INFO - 2021-05-17 15:05:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTree.php
ERROR - 2021-05-17 15:05:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/aelbfopi/amarcement.com/application/controllers/FinaneController.php 76
INFO - 2021-05-17 15:05:44 --> Final output sent to browser
DEBUG - 2021-05-17 15:05:44 --> Total execution time: 0.0673
INFO - 2021-05-17 15:06:00 --> Config Class Initialized
INFO - 2021-05-17 15:06:00 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:06:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:06:00 --> Utf8 Class Initialized
INFO - 2021-05-17 15:06:00 --> URI Class Initialized
INFO - 2021-05-17 15:06:00 --> Router Class Initialized
INFO - 2021-05-17 15:06:00 --> Config Class Initialized
INFO - 2021-05-17 15:06:00 --> Hooks Class Initialized
INFO - 2021-05-17 15:06:00 --> Output Class Initialized
INFO - 2021-05-17 15:06:00 --> Security Class Initialized
DEBUG - 2021-05-17 15:06:00 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:06:00 --> Utf8 Class Initialized
DEBUG - 2021-05-17 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:06:00 --> Input Class Initialized
INFO - 2021-05-17 15:06:00 --> Language Class Initialized
INFO - 2021-05-17 15:06:00 --> URI Class Initialized
INFO - 2021-05-17 15:06:00 --> Router Class Initialized
INFO - 2021-05-17 15:06:00 --> Output Class Initialized
INFO - 2021-05-17 15:06:00 --> Security Class Initialized
INFO - 2021-05-17 15:06:00 --> Loader Class Initialized
DEBUG - 2021-05-17 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:06:00 --> Helper loaded: url_helper
INFO - 2021-05-17 15:06:00 --> Input Class Initialized
INFO - 2021-05-17 15:06:00 --> Language Class Initialized
INFO - 2021-05-17 15:06:00 --> Helper loaded: file_helper
INFO - 2021-05-17 15:06:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:06:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:06:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:06:00 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:00 --> Loader Class Initialized
INFO - 2021-05-17 15:06:00 --> Email Class Initialized
INFO - 2021-05-17 15:06:00 --> Helper loaded: url_helper
INFO - 2021-05-17 15:06:00 --> Helper loaded: file_helper
DEBUG - 2021-05-17 15:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:06:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:06:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:06:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:06:00 --> Helper loaded: form_helper
INFO - 2021-05-17 15:06:00 --> Form Validation Class Initialized
INFO - 2021-05-17 15:06:00 --> Controller Class Initialized
INFO - 2021-05-17 15:06:00 --> Model "Common_model" initialized
INFO - 2021-05-17 15:06:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:06:00 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:06:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:06:00 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:00 --> Email Class Initialized
INFO - 2021-05-17 15:06:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTree.php
ERROR - 2021-05-17 15:06:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/aelbfopi/amarcement.com/application/controllers/FinaneController.php 80
INFO - 2021-05-17 15:06:00 --> Final output sent to browser
DEBUG - 2021-05-17 15:06:00 --> Total execution time: 0.0578
DEBUG - 2021-05-17 15:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:06:00 --> Helper loaded: form_helper
INFO - 2021-05-17 15:06:00 --> Form Validation Class Initialized
INFO - 2021-05-17 15:06:00 --> Controller Class Initialized
INFO - 2021-05-17 15:06:00 --> Model "Common_model" initialized
INFO - 2021-05-17 15:06:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:06:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:06:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:06:00 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:00 --> Final output sent to browser
DEBUG - 2021-05-17 15:06:00 --> Total execution time: 0.0788
INFO - 2021-05-17 15:06:03 --> Config Class Initialized
INFO - 2021-05-17 15:06:03 --> Hooks Class Initialized
INFO - 2021-05-17 15:06:03 --> Config Class Initialized
INFO - 2021-05-17 15:06:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:06:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:06:03 --> Utf8 Class Initialized
INFO - 2021-05-17 15:06:03 --> URI Class Initialized
DEBUG - 2021-05-17 15:06:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:06:03 --> Utf8 Class Initialized
INFO - 2021-05-17 15:06:03 --> URI Class Initialized
INFO - 2021-05-17 15:06:03 --> Router Class Initialized
INFO - 2021-05-17 15:06:03 --> Output Class Initialized
INFO - 2021-05-17 15:06:03 --> Security Class Initialized
INFO - 2021-05-17 15:06:03 --> Router Class Initialized
DEBUG - 2021-05-17 15:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:06:03 --> Input Class Initialized
INFO - 2021-05-17 15:06:03 --> Language Class Initialized
INFO - 2021-05-17 15:06:03 --> Output Class Initialized
INFO - 2021-05-17 15:06:03 --> Security Class Initialized
DEBUG - 2021-05-17 15:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:06:03 --> Input Class Initialized
INFO - 2021-05-17 15:06:03 --> Language Class Initialized
INFO - 2021-05-17 15:06:03 --> Loader Class Initialized
INFO - 2021-05-17 15:06:03 --> Helper loaded: url_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: file_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:06:03 --> Loader Class Initialized
INFO - 2021-05-17 15:06:03 --> Helper loaded: url_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: file_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:06:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:06:03 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:03 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:03 --> Email Class Initialized
DEBUG - 2021-05-17 15:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:06:03 --> Email Class Initialized
INFO - 2021-05-17 15:06:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-05-17 15:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:06:03 --> Helper loaded: form_helper
INFO - 2021-05-17 15:06:03 --> Form Validation Class Initialized
INFO - 2021-05-17 15:06:03 --> Controller Class Initialized
INFO - 2021-05-17 15:06:03 --> Model "Common_model" initialized
INFO - 2021-05-17 15:06:03 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:06:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:06:03 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:06:03 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTree.php
ERROR - 2021-05-17 15:06:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/aelbfopi/amarcement.com/application/controllers/FinaneController.php 76
INFO - 2021-05-17 15:06:03 --> Final output sent to browser
DEBUG - 2021-05-17 15:06:03 --> Total execution time: 0.0812
INFO - 2021-05-17 15:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:06:03 --> Helper loaded: form_helper
INFO - 2021-05-17 15:06:03 --> Form Validation Class Initialized
INFO - 2021-05-17 15:06:03 --> Controller Class Initialized
INFO - 2021-05-17 15:06:03 --> Model "Common_model" initialized
INFO - 2021-05-17 15:06:03 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:06:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:06:03 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:06:03 --> Database Driver Class Initialized
INFO - 2021-05-17 15:06:03 --> Final output sent to browser
DEBUG - 2021-05-17 15:06:03 --> Total execution time: 0.1024
INFO - 2021-05-17 15:08:56 --> Config Class Initialized
INFO - 2021-05-17 15:08:56 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:08:56 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:08:56 --> Utf8 Class Initialized
INFO - 2021-05-17 15:08:56 --> URI Class Initialized
INFO - 2021-05-17 15:08:56 --> Router Class Initialized
INFO - 2021-05-17 15:08:56 --> Output Class Initialized
INFO - 2021-05-17 15:08:56 --> Security Class Initialized
DEBUG - 2021-05-17 15:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:08:56 --> Input Class Initialized
INFO - 2021-05-17 15:08:56 --> Language Class Initialized
ERROR - 2021-05-17 15:08:56 --> 404 Page Not Found: admin/Jquery-multiple-file-upload/multiplefileupload.html
INFO - 2021-05-17 15:08:57 --> Config Class Initialized
INFO - 2021-05-17 15:08:57 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:08:57 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:08:57 --> Utf8 Class Initialized
INFO - 2021-05-17 15:08:57 --> URI Class Initialized
INFO - 2021-05-17 15:08:57 --> Router Class Initialized
INFO - 2021-05-17 15:08:57 --> Output Class Initialized
INFO - 2021-05-17 15:08:57 --> Security Class Initialized
DEBUG - 2021-05-17 15:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:08:57 --> Input Class Initialized
INFO - 2021-05-17 15:08:57 --> Language Class Initialized
ERROR - 2021-05-17 15:08:57 --> 404 Page Not Found: admin/Assets/jquery-multiple-file-upload
INFO - 2021-05-17 15:08:57 --> Config Class Initialized
INFO - 2021-05-17 15:08:57 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:08:57 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:08:57 --> Utf8 Class Initialized
INFO - 2021-05-17 15:08:57 --> URI Class Initialized
INFO - 2021-05-17 15:08:57 --> Router Class Initialized
INFO - 2021-05-17 15:08:57 --> Output Class Initialized
INFO - 2021-05-17 15:08:57 --> Security Class Initialized
DEBUG - 2021-05-17 15:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:08:57 --> Input Class Initialized
INFO - 2021-05-17 15:08:57 --> Language Class Initialized
ERROR - 2021-05-17 15:08:57 --> 404 Page Not Found: Public/assets
INFO - 2021-05-17 15:08:57 --> Config Class Initialized
INFO - 2021-05-17 15:08:57 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:08:57 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:08:57 --> Utf8 Class Initialized
INFO - 2021-05-17 15:08:57 --> URI Class Initialized
INFO - 2021-05-17 15:08:57 --> Router Class Initialized
INFO - 2021-05-17 15:08:57 --> Output Class Initialized
INFO - 2021-05-17 15:08:57 --> Security Class Initialized
DEBUG - 2021-05-17 15:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:08:57 --> Input Class Initialized
INFO - 2021-05-17 15:08:57 --> Language Class Initialized
ERROR - 2021-05-17 15:08:57 --> 404 Page Not Found: Assets/jquery-multiple-file-upload
INFO - 2021-05-17 15:09:45 --> Config Class Initialized
INFO - 2021-05-17 15:09:45 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:09:45 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:09:45 --> Utf8 Class Initialized
INFO - 2021-05-17 15:09:45 --> URI Class Initialized
INFO - 2021-05-17 15:09:45 --> Router Class Initialized
INFO - 2021-05-17 15:09:45 --> Output Class Initialized
INFO - 2021-05-17 15:09:45 --> Security Class Initialized
DEBUG - 2021-05-17 15:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:09:45 --> Input Class Initialized
INFO - 2021-05-17 15:09:45 --> Language Class Initialized
INFO - 2021-05-17 15:09:45 --> Loader Class Initialized
INFO - 2021-05-17 15:09:45 --> Helper loaded: url_helper
INFO - 2021-05-17 15:09:45 --> Helper loaded: file_helper
INFO - 2021-05-17 15:09:45 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:09:45 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:09:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:09:45 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:45 --> Email Class Initialized
DEBUG - 2021-05-17 15:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:09:45 --> Helper loaded: form_helper
INFO - 2021-05-17 15:09:45 --> Form Validation Class Initialized
INFO - 2021-05-17 15:09:45 --> Controller Class Initialized
INFO - 2021-05-17 15:09:45 --> Model "Common_model" initialized
INFO - 2021-05-17 15:09:45 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:09:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:09:45 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:09:45 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/receive/receiveVoucherEdit.php
INFO - 2021-05-17 15:09:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:09:46 --> Final output sent to browser
DEBUG - 2021-05-17 15:09:46 --> Total execution time: 0.3831
INFO - 2021-05-17 15:09:46 --> Config Class Initialized
INFO - 2021-05-17 15:09:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:09:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:09:46 --> Utf8 Class Initialized
INFO - 2021-05-17 15:09:46 --> URI Class Initialized
INFO - 2021-05-17 15:09:46 --> Router Class Initialized
INFO - 2021-05-17 15:09:46 --> Output Class Initialized
INFO - 2021-05-17 15:09:46 --> Security Class Initialized
DEBUG - 2021-05-17 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:09:46 --> Input Class Initialized
INFO - 2021-05-17 15:09:46 --> Language Class Initialized
ERROR - 2021-05-17 15:09:46 --> 404 Page Not Found: Cement_demo/receiveVoucherEdit
INFO - 2021-05-17 15:09:46 --> Config Class Initialized
INFO - 2021-05-17 15:09:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:09:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:09:46 --> Utf8 Class Initialized
INFO - 2021-05-17 15:09:46 --> URI Class Initialized
INFO - 2021-05-17 15:09:46 --> Router Class Initialized
INFO - 2021-05-17 15:09:46 --> Output Class Initialized
INFO - 2021-05-17 15:09:46 --> Security Class Initialized
DEBUG - 2021-05-17 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:09:46 --> Input Class Initialized
INFO - 2021-05-17 15:09:46 --> Language Class Initialized
INFO - 2021-05-17 15:09:46 --> Loader Class Initialized
INFO - 2021-05-17 15:09:46 --> Helper loaded: url_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: file_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:09:46 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:46 --> Email Class Initialized
DEBUG - 2021-05-17 15:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:09:46 --> Helper loaded: form_helper
INFO - 2021-05-17 15:09:46 --> Form Validation Class Initialized
INFO - 2021-05-17 15:09:46 --> Controller Class Initialized
INFO - 2021-05-17 15:09:46 --> Model "Common_model" initialized
INFO - 2021-05-17 15:09:46 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:09:46 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:09:46 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:09:46 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:46 --> Final output sent to browser
DEBUG - 2021-05-17 15:09:46 --> Total execution time: 0.1066
INFO - 2021-05-17 15:09:46 --> Config Class Initialized
INFO - 2021-05-17 15:09:46 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:09:46 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:09:46 --> Utf8 Class Initialized
INFO - 2021-05-17 15:09:46 --> URI Class Initialized
INFO - 2021-05-17 15:09:46 --> Router Class Initialized
INFO - 2021-05-17 15:09:46 --> Output Class Initialized
INFO - 2021-05-17 15:09:46 --> Security Class Initialized
DEBUG - 2021-05-17 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:09:46 --> Input Class Initialized
INFO - 2021-05-17 15:09:46 --> Language Class Initialized
INFO - 2021-05-17 15:09:46 --> Loader Class Initialized
INFO - 2021-05-17 15:09:46 --> Helper loaded: url_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: file_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:09:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:09:46 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:46 --> Email Class Initialized
DEBUG - 2021-05-17 15:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:09:47 --> Helper loaded: form_helper
INFO - 2021-05-17 15:09:47 --> Form Validation Class Initialized
INFO - 2021-05-17 15:09:47 --> Controller Class Initialized
INFO - 2021-05-17 15:09:47 --> Model "Common_model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:09:47 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/payList.php
INFO - 2021-05-17 15:09:47 --> Final output sent to browser
DEBUG - 2021-05-17 15:09:47 --> Total execution time: 0.0723
INFO - 2021-05-17 15:09:47 --> Config Class Initialized
INFO - 2021-05-17 15:09:47 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:09:47 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:09:47 --> Utf8 Class Initialized
INFO - 2021-05-17 15:09:47 --> URI Class Initialized
INFO - 2021-05-17 15:09:47 --> Router Class Initialized
INFO - 2021-05-17 15:09:47 --> Output Class Initialized
INFO - 2021-05-17 15:09:47 --> Security Class Initialized
DEBUG - 2021-05-17 15:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:09:47 --> Input Class Initialized
INFO - 2021-05-17 15:09:47 --> Language Class Initialized
INFO - 2021-05-17 15:09:47 --> Loader Class Initialized
INFO - 2021-05-17 15:09:47 --> Helper loaded: url_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: file_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:09:47 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:47 --> Email Class Initialized
DEBUG - 2021-05-17 15:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:09:47 --> Helper loaded: form_helper
INFO - 2021-05-17 15:09:47 --> Form Validation Class Initialized
INFO - 2021-05-17 15:09:47 --> Controller Class Initialized
INFO - 2021-05-17 15:09:47 --> Model "Common_model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:09:47 --> Config Class Initialized
INFO - 2021-05-17 15:09:47 --> Hooks Class Initialized
DEBUG - 2021-05-17 15:09:47 --> UTF-8 Support Enabled
INFO - 2021-05-17 15:09:47 --> Utf8 Class Initialized
INFO - 2021-05-17 15:09:47 --> URI Class Initialized
INFO - 2021-05-17 15:09:47 --> Router Class Initialized
INFO - 2021-05-17 15:09:47 --> Output Class Initialized
INFO - 2021-05-17 15:09:47 --> Security Class Initialized
DEBUG - 2021-05-17 15:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 15:09:47 --> Input Class Initialized
INFO - 2021-05-17 15:09:47 --> Language Class Initialized
INFO - 2021-05-17 15:09:47 --> Loader Class Initialized
INFO - 2021-05-17 15:09:47 --> Helper loaded: url_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: file_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: utility_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: unit_helper
INFO - 2021-05-17 15:09:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 15:09:47 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:47 --> Email Class Initialized
DEBUG - 2021-05-17 15:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 15:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 15:09:47 --> Helper loaded: form_helper
INFO - 2021-05-17 15:09:47 --> Form Validation Class Initialized
INFO - 2021-05-17 15:09:47 --> Controller Class Initialized
INFO - 2021-05-17 15:09:47 --> Model "Common_model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Finane_Model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Sales_Model" initialized
INFO - 2021-05-17 15:09:47 --> Model "Dashboard_Model" initialized
INFO - 2021-05-17 15:09:47 --> Database Driver Class Initialized
INFO - 2021-05-17 15:09:48 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-05-17 15:09:48 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-05-17 15:09:48 --> Final output sent to browser
DEBUG - 2021-05-17 15:09:48 --> Total execution time: 0.9605
INFO - 2021-05-17 21:33:50 --> Config Class Initialized
INFO - 2021-05-17 21:33:50 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:33:50 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:33:50 --> Utf8 Class Initialized
INFO - 2021-05-17 21:33:50 --> URI Class Initialized
INFO - 2021-05-17 21:33:50 --> Router Class Initialized
INFO - 2021-05-17 21:33:50 --> Output Class Initialized
INFO - 2021-05-17 21:33:50 --> Security Class Initialized
DEBUG - 2021-05-17 21:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:33:50 --> Input Class Initialized
INFO - 2021-05-17 21:33:50 --> Language Class Initialized
INFO - 2021-05-17 21:33:50 --> Loader Class Initialized
INFO - 2021-05-17 21:33:50 --> Helper loaded: url_helper
INFO - 2021-05-17 21:33:50 --> Helper loaded: file_helper
INFO - 2021-05-17 21:33:50 --> Helper loaded: utility_helper
INFO - 2021-05-17 21:33:50 --> Helper loaded: unit_helper
INFO - 2021-05-17 21:33:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 21:33:50 --> Database Driver Class Initialized
INFO - 2021-05-17 21:33:50 --> Email Class Initialized
DEBUG - 2021-05-17 21:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 21:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 21:33:50 --> Helper loaded: form_helper
INFO - 2021-05-17 21:33:50 --> Form Validation Class Initialized
INFO - 2021-05-17 21:33:50 --> Controller Class Initialized
INFO - 2021-05-17 21:33:50 --> Model "Common_model" initialized
INFO - 2021-05-17 21:33:50 --> Model "Finane_Model" initialized
INFO - 2021-05-17 21:33:50 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 21:33:50 --> Model "Sales_Model" initialized
INFO - 2021-05-17 21:33:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 21:33:50 --> Final output sent to browser
DEBUG - 2021-05-17 21:33:50 --> Total execution time: 0.0536
INFO - 2021-05-17 21:33:54 --> Config Class Initialized
INFO - 2021-05-17 21:33:54 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:33:54 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:33:54 --> Utf8 Class Initialized
INFO - 2021-05-17 21:33:54 --> URI Class Initialized
DEBUG - 2021-05-17 21:33:54 --> No URI present. Default controller set.
INFO - 2021-05-17 21:33:54 --> Router Class Initialized
INFO - 2021-05-17 21:33:54 --> Output Class Initialized
INFO - 2021-05-17 21:33:54 --> Security Class Initialized
DEBUG - 2021-05-17 21:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:33:54 --> Input Class Initialized
INFO - 2021-05-17 21:33:54 --> Language Class Initialized
INFO - 2021-05-17 21:33:54 --> Loader Class Initialized
INFO - 2021-05-17 21:33:54 --> Helper loaded: url_helper
INFO - 2021-05-17 21:33:54 --> Helper loaded: file_helper
INFO - 2021-05-17 21:33:54 --> Helper loaded: utility_helper
INFO - 2021-05-17 21:33:54 --> Helper loaded: unit_helper
INFO - 2021-05-17 21:33:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 21:33:54 --> Database Driver Class Initialized
INFO - 2021-05-17 21:33:54 --> Email Class Initialized
DEBUG - 2021-05-17 21:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 21:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 21:33:54 --> Helper loaded: form_helper
INFO - 2021-05-17 21:33:54 --> Form Validation Class Initialized
INFO - 2021-05-17 21:33:54 --> Controller Class Initialized
INFO - 2021-05-17 21:33:54 --> Model "Common_model" initialized
INFO - 2021-05-17 21:33:54 --> Model "Finane_Model" initialized
INFO - 2021-05-17 21:33:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 21:33:54 --> Model "Sales_Model" initialized
INFO - 2021-05-17 21:33:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 21:33:54 --> Final output sent to browser
DEBUG - 2021-05-17 21:33:54 --> Total execution time: 0.0596
INFO - 2021-05-17 21:33:55 --> Config Class Initialized
INFO - 2021-05-17 21:33:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:33:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:33:55 --> Utf8 Class Initialized
INFO - 2021-05-17 21:33:55 --> URI Class Initialized
INFO - 2021-05-17 21:33:55 --> Router Class Initialized
INFO - 2021-05-17 21:33:55 --> Output Class Initialized
INFO - 2021-05-17 21:33:55 --> Security Class Initialized
DEBUG - 2021-05-17 21:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:33:55 --> Input Class Initialized
INFO - 2021-05-17 21:33:55 --> Language Class Initialized
ERROR - 2021-05-17 21:33:55 --> 404 Page Not Found: admin/Assets/uploadify
INFO - 2021-05-17 21:33:55 --> Config Class Initialized
INFO - 2021-05-17 21:33:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:33:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:33:55 --> Utf8 Class Initialized
INFO - 2021-05-17 21:33:55 --> URI Class Initialized
INFO - 2021-05-17 21:33:55 --> Router Class Initialized
INFO - 2021-05-17 21:33:55 --> Output Class Initialized
INFO - 2021-05-17 21:33:55 --> Security Class Initialized
DEBUG - 2021-05-17 21:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:33:55 --> Input Class Initialized
INFO - 2021-05-17 21:33:55 --> Language Class Initialized
ERROR - 2021-05-17 21:33:55 --> 404 Page Not Found: admin/Uploadify/uploadify.css
INFO - 2021-05-17 21:33:55 --> Config Class Initialized
INFO - 2021-05-17 21:33:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:33:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:33:55 --> Utf8 Class Initialized
INFO - 2021-05-17 21:33:55 --> URI Class Initialized
INFO - 2021-05-17 21:33:55 --> Router Class Initialized
INFO - 2021-05-17 21:33:55 --> Output Class Initialized
INFO - 2021-05-17 21:33:55 --> Security Class Initialized
DEBUG - 2021-05-17 21:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:33:55 --> Input Class Initialized
INFO - 2021-05-17 21:33:55 --> Language Class Initialized
ERROR - 2021-05-17 21:33:55 --> 404 Page Not Found: Assets/uploadify
INFO - 2021-05-17 21:33:55 --> Config Class Initialized
INFO - 2021-05-17 21:33:55 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:33:55 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:33:55 --> Utf8 Class Initialized
INFO - 2021-05-17 21:33:55 --> URI Class Initialized
INFO - 2021-05-17 21:33:55 --> Router Class Initialized
INFO - 2021-05-17 21:33:55 --> Output Class Initialized
INFO - 2021-05-17 21:33:55 --> Security Class Initialized
DEBUG - 2021-05-17 21:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:33:55 --> Input Class Initialized
INFO - 2021-05-17 21:33:55 --> Language Class Initialized
ERROR - 2021-05-17 21:33:55 --> 404 Page Not Found: Theme/assets
INFO - 2021-05-17 21:33:56 --> Config Class Initialized
INFO - 2021-05-17 21:33:56 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:33:56 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:33:56 --> Utf8 Class Initialized
INFO - 2021-05-17 21:33:56 --> URI Class Initialized
INFO - 2021-05-17 21:33:56 --> Router Class Initialized
INFO - 2021-05-17 21:33:56 --> Output Class Initialized
INFO - 2021-05-17 21:33:56 --> Security Class Initialized
DEBUG - 2021-05-17 21:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:33:56 --> Input Class Initialized
INFO - 2021-05-17 21:33:56 --> Language Class Initialized
ERROR - 2021-05-17 21:33:56 --> 404 Page Not Found: Public/assets
INFO - 2021-05-17 21:34:02 --> Config Class Initialized
INFO - 2021-05-17 21:34:02 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:34:02 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:34:02 --> Utf8 Class Initialized
INFO - 2021-05-17 21:34:02 --> URI Class Initialized
INFO - 2021-05-17 21:34:02 --> Router Class Initialized
INFO - 2021-05-17 21:34:02 --> Output Class Initialized
INFO - 2021-05-17 21:34:02 --> Security Class Initialized
DEBUG - 2021-05-17 21:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:34:02 --> Input Class Initialized
INFO - 2021-05-17 21:34:02 --> Language Class Initialized
INFO - 2021-05-17 21:34:02 --> Loader Class Initialized
INFO - 2021-05-17 21:34:02 --> Helper loaded: url_helper
INFO - 2021-05-17 21:34:02 --> Helper loaded: file_helper
INFO - 2021-05-17 21:34:02 --> Helper loaded: utility_helper
INFO - 2021-05-17 21:34:02 --> Helper loaded: unit_helper
INFO - 2021-05-17 21:34:02 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 21:34:02 --> Database Driver Class Initialized
INFO - 2021-05-17 21:34:02 --> Email Class Initialized
DEBUG - 2021-05-17 21:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 21:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 21:34:02 --> Helper loaded: form_helper
INFO - 2021-05-17 21:34:02 --> Form Validation Class Initialized
INFO - 2021-05-17 21:34:02 --> Controller Class Initialized
INFO - 2021-05-17 21:34:02 --> Model "Common_model" initialized
INFO - 2021-05-17 21:34:02 --> Model "Finane_Model" initialized
INFO - 2021-05-17 21:34:02 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 21:34:02 --> Model "Sales_Model" initialized
INFO - 2021-05-17 21:34:02 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 21:34:02 --> Final output sent to browser
DEBUG - 2021-05-17 21:34:02 --> Total execution time: 0.0446
INFO - 2021-05-17 21:34:05 --> Config Class Initialized
INFO - 2021-05-17 21:34:05 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:34:05 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:34:05 --> Utf8 Class Initialized
INFO - 2021-05-17 21:34:05 --> URI Class Initialized
INFO - 2021-05-17 21:34:05 --> Router Class Initialized
INFO - 2021-05-17 21:34:05 --> Output Class Initialized
INFO - 2021-05-17 21:34:05 --> Security Class Initialized
DEBUG - 2021-05-17 21:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:34:05 --> Input Class Initialized
INFO - 2021-05-17 21:34:05 --> Language Class Initialized
INFO - 2021-05-17 21:34:05 --> Loader Class Initialized
INFO - 2021-05-17 21:34:05 --> Helper loaded: url_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: file_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: utility_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: unit_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 21:34:05 --> Database Driver Class Initialized
INFO - 2021-05-17 21:34:05 --> Email Class Initialized
DEBUG - 2021-05-17 21:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 21:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 21:34:05 --> Helper loaded: form_helper
INFO - 2021-05-17 21:34:05 --> Form Validation Class Initialized
INFO - 2021-05-17 21:34:05 --> Controller Class Initialized
INFO - 2021-05-17 21:34:05 --> Model "Common_model" initialized
INFO - 2021-05-17 21:34:05 --> Model "Finane_Model" initialized
INFO - 2021-05-17 21:34:05 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 21:34:05 --> Model "Sales_Model" initialized
INFO - 2021-05-17 21:34:05 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 21:34:05 --> Final output sent to browser
DEBUG - 2021-05-17 21:34:05 --> Total execution time: 0.0455
INFO - 2021-05-17 21:34:05 --> Config Class Initialized
INFO - 2021-05-17 21:34:05 --> Hooks Class Initialized
DEBUG - 2021-05-17 21:34:05 --> UTF-8 Support Enabled
INFO - 2021-05-17 21:34:05 --> Utf8 Class Initialized
INFO - 2021-05-17 21:34:05 --> URI Class Initialized
INFO - 2021-05-17 21:34:05 --> Router Class Initialized
INFO - 2021-05-17 21:34:05 --> Output Class Initialized
INFO - 2021-05-17 21:34:05 --> Security Class Initialized
DEBUG - 2021-05-17 21:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 21:34:05 --> Input Class Initialized
INFO - 2021-05-17 21:34:05 --> Language Class Initialized
INFO - 2021-05-17 21:34:05 --> Loader Class Initialized
INFO - 2021-05-17 21:34:05 --> Helper loaded: url_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: file_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: utility_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: unit_helper
INFO - 2021-05-17 21:34:05 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 21:34:05 --> Database Driver Class Initialized
INFO - 2021-05-17 21:34:05 --> Email Class Initialized
DEBUG - 2021-05-17 21:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 21:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 21:34:05 --> Helper loaded: form_helper
INFO - 2021-05-17 21:34:05 --> Form Validation Class Initialized
INFO - 2021-05-17 21:34:05 --> Controller Class Initialized
INFO - 2021-05-17 21:34:05 --> Model "Common_model" initialized
INFO - 2021-05-17 21:34:05 --> Model "Finane_Model" initialized
INFO - 2021-05-17 21:34:05 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 21:34:05 --> Model "Sales_Model" initialized
INFO - 2021-05-17 21:34:05 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 21:34:05 --> Final output sent to browser
DEBUG - 2021-05-17 21:34:05 --> Total execution time: 0.0532
INFO - 2021-05-17 22:38:59 --> Config Class Initialized
INFO - 2021-05-17 22:38:59 --> Hooks Class Initialized
DEBUG - 2021-05-17 22:38:59 --> UTF-8 Support Enabled
INFO - 2021-05-17 22:38:59 --> Utf8 Class Initialized
INFO - 2021-05-17 22:38:59 --> URI Class Initialized
DEBUG - 2021-05-17 22:39:00 --> No URI present. Default controller set.
INFO - 2021-05-17 22:39:00 --> Router Class Initialized
INFO - 2021-05-17 22:39:00 --> Output Class Initialized
INFO - 2021-05-17 22:39:00 --> Security Class Initialized
DEBUG - 2021-05-17 22:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 22:39:00 --> Input Class Initialized
INFO - 2021-05-17 22:39:00 --> Language Class Initialized
INFO - 2021-05-17 22:39:00 --> Loader Class Initialized
INFO - 2021-05-17 22:39:00 --> Helper loaded: url_helper
INFO - 2021-05-17 22:39:00 --> Helper loaded: file_helper
INFO - 2021-05-17 22:39:00 --> Helper loaded: utility_helper
INFO - 2021-05-17 22:39:00 --> Helper loaded: unit_helper
INFO - 2021-05-17 22:39:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 22:39:00 --> Database Driver Class Initialized
INFO - 2021-05-17 22:39:00 --> Email Class Initialized
DEBUG - 2021-05-17 22:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 22:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 22:39:00 --> Helper loaded: form_helper
INFO - 2021-05-17 22:39:00 --> Form Validation Class Initialized
INFO - 2021-05-17 22:39:00 --> Controller Class Initialized
INFO - 2021-05-17 22:39:00 --> Model "Common_model" initialized
INFO - 2021-05-17 22:39:00 --> Model "Finane_Model" initialized
INFO - 2021-05-17 22:39:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 22:39:00 --> Model "Sales_Model" initialized
INFO - 2021-05-17 22:39:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 22:39:00 --> Final output sent to browser
DEBUG - 2021-05-17 22:39:00 --> Total execution time: 0.0600
INFO - 2021-05-17 22:40:41 --> Config Class Initialized
INFO - 2021-05-17 22:40:41 --> Hooks Class Initialized
DEBUG - 2021-05-17 22:40:41 --> UTF-8 Support Enabled
INFO - 2021-05-17 22:40:41 --> Utf8 Class Initialized
INFO - 2021-05-17 22:40:41 --> URI Class Initialized
INFO - 2021-05-17 22:40:41 --> Router Class Initialized
INFO - 2021-05-17 22:40:41 --> Output Class Initialized
INFO - 2021-05-17 22:40:41 --> Security Class Initialized
DEBUG - 2021-05-17 22:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 22:40:41 --> Input Class Initialized
INFO - 2021-05-17 22:40:41 --> Language Class Initialized
INFO - 2021-05-17 22:40:41 --> Loader Class Initialized
INFO - 2021-05-17 22:40:41 --> Helper loaded: url_helper
INFO - 2021-05-17 22:40:41 --> Helper loaded: file_helper
INFO - 2021-05-17 22:40:41 --> Helper loaded: utility_helper
INFO - 2021-05-17 22:40:41 --> Helper loaded: unit_helper
INFO - 2021-05-17 22:40:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-17 22:40:41 --> Database Driver Class Initialized
INFO - 2021-05-17 22:40:41 --> Email Class Initialized
DEBUG - 2021-05-17 22:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 22:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 22:40:41 --> Helper loaded: form_helper
INFO - 2021-05-17 22:40:41 --> Form Validation Class Initialized
INFO - 2021-05-17 22:40:41 --> Controller Class Initialized
INFO - 2021-05-17 22:40:41 --> Model "Common_model" initialized
INFO - 2021-05-17 22:40:41 --> Model "Finane_Model" initialized
INFO - 2021-05-17 22:40:41 --> Model "Inventory_Model" initialized
INFO - 2021-05-17 22:40:41 --> Model "Sales_Model" initialized
INFO - 2021-05-17 22:40:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-17 22:40:41 --> Final output sent to browser
DEBUG - 2021-05-17 22:40:41 --> Total execution time: 0.0525
