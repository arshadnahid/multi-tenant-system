<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-06 00:59:41 --> Config Class Initialized
INFO - 2021-04-06 00:59:41 --> Hooks Class Initialized
DEBUG - 2021-04-06 00:59:41 --> UTF-8 Support Enabled
INFO - 2021-04-06 00:59:41 --> Utf8 Class Initialized
INFO - 2021-04-06 00:59:41 --> URI Class Initialized
INFO - 2021-04-06 00:59:41 --> Router Class Initialized
INFO - 2021-04-06 00:59:41 --> Output Class Initialized
INFO - 2021-04-06 00:59:41 --> Security Class Initialized
DEBUG - 2021-04-06 00:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 00:59:41 --> Input Class Initialized
INFO - 2021-04-06 00:59:41 --> Language Class Initialized
INFO - 2021-04-06 00:59:41 --> Loader Class Initialized
INFO - 2021-04-06 00:59:41 --> Helper loaded: url_helper
INFO - 2021-04-06 00:59:41 --> Helper loaded: file_helper
INFO - 2021-04-06 00:59:41 --> Helper loaded: utility_helper
INFO - 2021-04-06 00:59:41 --> Helper loaded: unit_helper
INFO - 2021-04-06 00:59:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 00:59:41 --> Database Driver Class Initialized
INFO - 2021-04-06 00:59:41 --> Email Class Initialized
DEBUG - 2021-04-06 00:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 00:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 00:59:41 --> Helper loaded: form_helper
INFO - 2021-04-06 00:59:41 --> Form Validation Class Initialized
INFO - 2021-04-06 00:59:41 --> Controller Class Initialized
INFO - 2021-04-06 00:59:41 --> Model "Common_model" initialized
INFO - 2021-04-06 00:59:41 --> Model "Finane_Model" initialized
INFO - 2021-04-06 00:59:41 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 00:59:41 --> Model "Sales_Model" initialized
INFO - 2021-04-06 00:59:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 00:59:41 --> Final output sent to browser
DEBUG - 2021-04-06 00:59:41 --> Total execution time: 0.0439
INFO - 2021-04-06 01:19:54 --> Config Class Initialized
INFO - 2021-04-06 01:19:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 01:19:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 01:19:54 --> Utf8 Class Initialized
INFO - 2021-04-06 01:19:54 --> URI Class Initialized
INFO - 2021-04-06 01:19:54 --> Router Class Initialized
INFO - 2021-04-06 01:19:54 --> Output Class Initialized
INFO - 2021-04-06 01:19:54 --> Security Class Initialized
DEBUG - 2021-04-06 01:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 01:19:54 --> Input Class Initialized
INFO - 2021-04-06 01:19:54 --> Language Class Initialized
INFO - 2021-04-06 01:19:54 --> Loader Class Initialized
INFO - 2021-04-06 01:19:54 --> Helper loaded: url_helper
INFO - 2021-04-06 01:19:54 --> Helper loaded: file_helper
INFO - 2021-04-06 01:19:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 01:19:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 01:19:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 01:19:54 --> Database Driver Class Initialized
INFO - 2021-04-06 01:19:54 --> Email Class Initialized
DEBUG - 2021-04-06 01:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 01:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 01:19:54 --> Helper loaded: form_helper
INFO - 2021-04-06 01:19:54 --> Form Validation Class Initialized
INFO - 2021-04-06 01:19:54 --> Controller Class Initialized
INFO - 2021-04-06 01:19:54 --> Model "Common_model" initialized
INFO - 2021-04-06 01:19:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 01:19:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 01:19:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 01:19:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 01:19:54 --> Final output sent to browser
DEBUG - 2021-04-06 01:19:54 --> Total execution time: 0.0454
INFO - 2021-04-06 01:19:55 --> Config Class Initialized
INFO - 2021-04-06 01:19:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 01:19:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 01:19:55 --> Utf8 Class Initialized
INFO - 2021-04-06 01:19:55 --> URI Class Initialized
INFO - 2021-04-06 01:19:55 --> Router Class Initialized
INFO - 2021-04-06 01:19:55 --> Output Class Initialized
INFO - 2021-04-06 01:19:55 --> Security Class Initialized
DEBUG - 2021-04-06 01:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 01:19:55 --> Input Class Initialized
INFO - 2021-04-06 01:19:55 --> Language Class Initialized
INFO - 2021-04-06 01:19:55 --> Loader Class Initialized
INFO - 2021-04-06 01:19:55 --> Helper loaded: url_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: file_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 01:19:55 --> Database Driver Class Initialized
INFO - 2021-04-06 01:19:55 --> Email Class Initialized
DEBUG - 2021-04-06 01:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 01:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 01:19:55 --> Helper loaded: form_helper
INFO - 2021-04-06 01:19:55 --> Form Validation Class Initialized
INFO - 2021-04-06 01:19:55 --> Controller Class Initialized
INFO - 2021-04-06 01:19:55 --> Model "Common_model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 01:19:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 01:19:55 --> Final output sent to browser
DEBUG - 2021-04-06 01:19:55 --> Total execution time: 0.0374
INFO - 2021-04-06 01:19:55 --> Config Class Initialized
INFO - 2021-04-06 01:19:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 01:19:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 01:19:55 --> Utf8 Class Initialized
INFO - 2021-04-06 01:19:55 --> URI Class Initialized
INFO - 2021-04-06 01:19:55 --> Router Class Initialized
INFO - 2021-04-06 01:19:55 --> Output Class Initialized
INFO - 2021-04-06 01:19:55 --> Security Class Initialized
DEBUG - 2021-04-06 01:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 01:19:55 --> Input Class Initialized
INFO - 2021-04-06 01:19:55 --> Language Class Initialized
INFO - 2021-04-06 01:19:55 --> Loader Class Initialized
INFO - 2021-04-06 01:19:55 --> Helper loaded: url_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: file_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 01:19:55 --> Database Driver Class Initialized
INFO - 2021-04-06 01:19:55 --> Email Class Initialized
DEBUG - 2021-04-06 01:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 01:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 01:19:55 --> Helper loaded: form_helper
INFO - 2021-04-06 01:19:55 --> Form Validation Class Initialized
INFO - 2021-04-06 01:19:55 --> Controller Class Initialized
INFO - 2021-04-06 01:19:55 --> Model "Common_model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 01:19:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 01:19:55 --> Final output sent to browser
DEBUG - 2021-04-06 01:19:55 --> Total execution time: 0.0402
INFO - 2021-04-06 01:19:55 --> Config Class Initialized
INFO - 2021-04-06 01:19:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 01:19:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 01:19:55 --> Utf8 Class Initialized
INFO - 2021-04-06 01:19:55 --> URI Class Initialized
INFO - 2021-04-06 01:19:55 --> Router Class Initialized
INFO - 2021-04-06 01:19:55 --> Output Class Initialized
INFO - 2021-04-06 01:19:55 --> Security Class Initialized
DEBUG - 2021-04-06 01:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 01:19:55 --> Input Class Initialized
INFO - 2021-04-06 01:19:55 --> Language Class Initialized
INFO - 2021-04-06 01:19:55 --> Loader Class Initialized
INFO - 2021-04-06 01:19:55 --> Helper loaded: url_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: file_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 01:19:55 --> Database Driver Class Initialized
INFO - 2021-04-06 01:19:55 --> Email Class Initialized
DEBUG - 2021-04-06 01:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 01:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 01:19:55 --> Helper loaded: form_helper
INFO - 2021-04-06 01:19:55 --> Form Validation Class Initialized
INFO - 2021-04-06 01:19:55 --> Controller Class Initialized
INFO - 2021-04-06 01:19:55 --> Model "Common_model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 01:19:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 01:19:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 01:19:55 --> Final output sent to browser
DEBUG - 2021-04-06 01:19:55 --> Total execution time: 0.0497
INFO - 2021-04-06 01:19:55 --> Config Class Initialized
INFO - 2021-04-06 01:19:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 01:19:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 01:19:55 --> Utf8 Class Initialized
INFO - 2021-04-06 01:19:55 --> URI Class Initialized
DEBUG - 2021-04-06 01:19:55 --> No URI present. Default controller set.
INFO - 2021-04-06 01:19:55 --> Router Class Initialized
INFO - 2021-04-06 01:19:55 --> Output Class Initialized
INFO - 2021-04-06 01:19:55 --> Security Class Initialized
DEBUG - 2021-04-06 01:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 01:19:55 --> Input Class Initialized
INFO - 2021-04-06 01:19:55 --> Language Class Initialized
INFO - 2021-04-06 01:19:55 --> Loader Class Initialized
INFO - 2021-04-06 01:19:55 --> Helper loaded: url_helper
INFO - 2021-04-06 01:19:55 --> Helper loaded: file_helper
INFO - 2021-04-06 01:19:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 01:19:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 01:19:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 01:19:56 --> Database Driver Class Initialized
INFO - 2021-04-06 01:19:56 --> Email Class Initialized
DEBUG - 2021-04-06 01:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 01:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 01:19:56 --> Helper loaded: form_helper
INFO - 2021-04-06 01:19:56 --> Form Validation Class Initialized
INFO - 2021-04-06 01:19:56 --> Controller Class Initialized
INFO - 2021-04-06 01:19:56 --> Model "Common_model" initialized
INFO - 2021-04-06 01:19:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 01:19:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 01:19:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 01:19:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 01:19:56 --> Final output sent to browser
DEBUG - 2021-04-06 01:19:56 --> Total execution time: 0.0378
INFO - 2021-04-06 03:51:31 --> Config Class Initialized
INFO - 2021-04-06 03:51:31 --> Hooks Class Initialized
DEBUG - 2021-04-06 03:51:31 --> UTF-8 Support Enabled
INFO - 2021-04-06 03:51:31 --> Utf8 Class Initialized
INFO - 2021-04-06 03:51:31 --> URI Class Initialized
INFO - 2021-04-06 03:51:31 --> Router Class Initialized
INFO - 2021-04-06 03:51:31 --> Output Class Initialized
INFO - 2021-04-06 03:51:31 --> Security Class Initialized
DEBUG - 2021-04-06 03:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 03:51:31 --> Input Class Initialized
INFO - 2021-04-06 03:51:31 --> Language Class Initialized
INFO - 2021-04-06 03:51:31 --> Loader Class Initialized
INFO - 2021-04-06 03:51:31 --> Helper loaded: url_helper
INFO - 2021-04-06 03:51:31 --> Helper loaded: file_helper
INFO - 2021-04-06 03:51:31 --> Helper loaded: utility_helper
INFO - 2021-04-06 03:51:31 --> Helper loaded: unit_helper
INFO - 2021-04-06 03:51:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 03:51:31 --> Database Driver Class Initialized
INFO - 2021-04-06 03:51:31 --> Email Class Initialized
DEBUG - 2021-04-06 03:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 03:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 03:51:31 --> Helper loaded: form_helper
INFO - 2021-04-06 03:51:31 --> Form Validation Class Initialized
INFO - 2021-04-06 03:51:31 --> Controller Class Initialized
INFO - 2021-04-06 03:51:31 --> Model "Common_model" initialized
INFO - 2021-04-06 03:51:31 --> Model "Finane_Model" initialized
INFO - 2021-04-06 03:51:31 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 03:51:31 --> Model "Sales_Model" initialized
INFO - 2021-04-06 03:51:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 03:51:31 --> Final output sent to browser
DEBUG - 2021-04-06 03:51:31 --> Total execution time: 0.0568
INFO - 2021-04-06 03:51:32 --> Config Class Initialized
INFO - 2021-04-06 03:51:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 03:51:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 03:51:32 --> Utf8 Class Initialized
INFO - 2021-04-06 03:51:32 --> URI Class Initialized
INFO - 2021-04-06 03:51:32 --> Router Class Initialized
INFO - 2021-04-06 03:51:32 --> Output Class Initialized
INFO - 2021-04-06 03:51:32 --> Security Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 03:51:32 --> Input Class Initialized
INFO - 2021-04-06 03:51:32 --> Language Class Initialized
INFO - 2021-04-06 03:51:32 --> Loader Class Initialized
INFO - 2021-04-06 03:51:32 --> Helper loaded: url_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: file_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 03:51:32 --> Database Driver Class Initialized
INFO - 2021-04-06 03:51:32 --> Email Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 03:51:32 --> Helper loaded: form_helper
INFO - 2021-04-06 03:51:32 --> Form Validation Class Initialized
INFO - 2021-04-06 03:51:32 --> Controller Class Initialized
INFO - 2021-04-06 03:51:32 --> Model "Common_model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 03:51:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 03:51:32 --> Final output sent to browser
DEBUG - 2021-04-06 03:51:32 --> Total execution time: 0.0521
INFO - 2021-04-06 03:51:32 --> Config Class Initialized
INFO - 2021-04-06 03:51:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 03:51:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 03:51:32 --> Utf8 Class Initialized
INFO - 2021-04-06 03:51:32 --> URI Class Initialized
INFO - 2021-04-06 03:51:32 --> Router Class Initialized
INFO - 2021-04-06 03:51:32 --> Output Class Initialized
INFO - 2021-04-06 03:51:32 --> Security Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 03:51:32 --> Input Class Initialized
INFO - 2021-04-06 03:51:32 --> Language Class Initialized
INFO - 2021-04-06 03:51:32 --> Loader Class Initialized
INFO - 2021-04-06 03:51:32 --> Helper loaded: url_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: file_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 03:51:32 --> Database Driver Class Initialized
INFO - 2021-04-06 03:51:32 --> Email Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 03:51:32 --> Helper loaded: form_helper
INFO - 2021-04-06 03:51:32 --> Form Validation Class Initialized
INFO - 2021-04-06 03:51:32 --> Controller Class Initialized
INFO - 2021-04-06 03:51:32 --> Model "Common_model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 03:51:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 03:51:32 --> Final output sent to browser
DEBUG - 2021-04-06 03:51:32 --> Total execution time: 0.0438
INFO - 2021-04-06 03:51:32 --> Config Class Initialized
INFO - 2021-04-06 03:51:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 03:51:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 03:51:32 --> Utf8 Class Initialized
INFO - 2021-04-06 03:51:32 --> URI Class Initialized
INFO - 2021-04-06 03:51:32 --> Router Class Initialized
INFO - 2021-04-06 03:51:32 --> Output Class Initialized
INFO - 2021-04-06 03:51:32 --> Security Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 03:51:32 --> Input Class Initialized
INFO - 2021-04-06 03:51:32 --> Language Class Initialized
INFO - 2021-04-06 03:51:32 --> Loader Class Initialized
INFO - 2021-04-06 03:51:32 --> Helper loaded: url_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: file_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 03:51:32 --> Database Driver Class Initialized
INFO - 2021-04-06 03:51:32 --> Email Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 03:51:32 --> Helper loaded: form_helper
INFO - 2021-04-06 03:51:32 --> Form Validation Class Initialized
INFO - 2021-04-06 03:51:32 --> Controller Class Initialized
INFO - 2021-04-06 03:51:32 --> Model "Common_model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 03:51:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 03:51:32 --> Final output sent to browser
DEBUG - 2021-04-06 03:51:32 --> Total execution time: 0.0469
INFO - 2021-04-06 03:51:32 --> Config Class Initialized
INFO - 2021-04-06 03:51:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 03:51:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 03:51:32 --> Utf8 Class Initialized
INFO - 2021-04-06 03:51:32 --> URI Class Initialized
DEBUG - 2021-04-06 03:51:32 --> No URI present. Default controller set.
INFO - 2021-04-06 03:51:32 --> Router Class Initialized
INFO - 2021-04-06 03:51:32 --> Output Class Initialized
INFO - 2021-04-06 03:51:32 --> Security Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 03:51:32 --> Input Class Initialized
INFO - 2021-04-06 03:51:32 --> Language Class Initialized
INFO - 2021-04-06 03:51:32 --> Loader Class Initialized
INFO - 2021-04-06 03:51:32 --> Helper loaded: url_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: file_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 03:51:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 03:51:32 --> Database Driver Class Initialized
INFO - 2021-04-06 03:51:32 --> Email Class Initialized
DEBUG - 2021-04-06 03:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 03:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 03:51:32 --> Helper loaded: form_helper
INFO - 2021-04-06 03:51:32 --> Form Validation Class Initialized
INFO - 2021-04-06 03:51:32 --> Controller Class Initialized
INFO - 2021-04-06 03:51:32 --> Model "Common_model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 03:51:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 03:51:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 03:51:32 --> Final output sent to browser
DEBUG - 2021-04-06 03:51:32 --> Total execution time: 0.0557
INFO - 2021-04-06 07:45:55 --> Config Class Initialized
INFO - 2021-04-06 07:45:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 07:45:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 07:45:55 --> Utf8 Class Initialized
INFO - 2021-04-06 07:45:55 --> URI Class Initialized
INFO - 2021-04-06 07:45:55 --> Router Class Initialized
INFO - 2021-04-06 07:45:55 --> Output Class Initialized
INFO - 2021-04-06 07:45:55 --> Security Class Initialized
DEBUG - 2021-04-06 07:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 07:45:55 --> Input Class Initialized
INFO - 2021-04-06 07:45:55 --> Language Class Initialized
INFO - 2021-04-06 07:45:55 --> Loader Class Initialized
INFO - 2021-04-06 07:45:55 --> Helper loaded: url_helper
INFO - 2021-04-06 07:45:55 --> Helper loaded: file_helper
INFO - 2021-04-06 07:45:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 07:45:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 07:45:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 07:45:55 --> Database Driver Class Initialized
INFO - 2021-04-06 07:45:55 --> Email Class Initialized
DEBUG - 2021-04-06 07:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 07:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 07:45:55 --> Helper loaded: form_helper
INFO - 2021-04-06 07:45:55 --> Form Validation Class Initialized
INFO - 2021-04-06 07:45:55 --> Controller Class Initialized
INFO - 2021-04-06 07:45:55 --> Model "Common_model" initialized
INFO - 2021-04-06 07:45:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 07:45:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 07:45:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 07:45:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 07:45:55 --> Final output sent to browser
DEBUG - 2021-04-06 07:45:55 --> Total execution time: 0.0488
INFO - 2021-04-06 07:45:56 --> Config Class Initialized
INFO - 2021-04-06 07:45:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 07:45:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 07:45:56 --> Utf8 Class Initialized
INFO - 2021-04-06 07:45:56 --> URI Class Initialized
DEBUG - 2021-04-06 07:45:56 --> No URI present. Default controller set.
INFO - 2021-04-06 07:45:56 --> Router Class Initialized
INFO - 2021-04-06 07:45:56 --> Output Class Initialized
INFO - 2021-04-06 07:45:56 --> Security Class Initialized
DEBUG - 2021-04-06 07:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 07:45:56 --> Input Class Initialized
INFO - 2021-04-06 07:45:56 --> Language Class Initialized
INFO - 2021-04-06 07:45:56 --> Loader Class Initialized
INFO - 2021-04-06 07:45:56 --> Helper loaded: url_helper
INFO - 2021-04-06 07:45:56 --> Helper loaded: file_helper
INFO - 2021-04-06 07:45:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 07:45:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 07:45:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 07:45:56 --> Database Driver Class Initialized
INFO - 2021-04-06 07:45:56 --> Email Class Initialized
DEBUG - 2021-04-06 07:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 07:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 07:45:56 --> Helper loaded: form_helper
INFO - 2021-04-06 07:45:56 --> Form Validation Class Initialized
INFO - 2021-04-06 07:45:56 --> Controller Class Initialized
INFO - 2021-04-06 07:45:56 --> Model "Common_model" initialized
INFO - 2021-04-06 07:45:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 07:45:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 07:45:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 07:45:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 07:45:56 --> Final output sent to browser
DEBUG - 2021-04-06 07:45:56 --> Total execution time: 0.0372
INFO - 2021-04-06 09:55:47 --> Config Class Initialized
INFO - 2021-04-06 09:55:47 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:55:47 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:55:47 --> Utf8 Class Initialized
INFO - 2021-04-06 09:55:47 --> URI Class Initialized
INFO - 2021-04-06 09:55:47 --> Router Class Initialized
INFO - 2021-04-06 09:55:47 --> Output Class Initialized
INFO - 2021-04-06 09:55:47 --> Security Class Initialized
DEBUG - 2021-04-06 09:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:55:47 --> Input Class Initialized
INFO - 2021-04-06 09:55:47 --> Language Class Initialized
INFO - 2021-04-06 09:55:47 --> Loader Class Initialized
INFO - 2021-04-06 09:55:47 --> Helper loaded: url_helper
INFO - 2021-04-06 09:55:47 --> Helper loaded: file_helper
INFO - 2021-04-06 09:55:47 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:55:47 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:55:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:55:47 --> Database Driver Class Initialized
INFO - 2021-04-06 09:55:47 --> Email Class Initialized
DEBUG - 2021-04-06 09:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:55:47 --> Helper loaded: form_helper
INFO - 2021-04-06 09:55:47 --> Form Validation Class Initialized
INFO - 2021-04-06 09:55:47 --> Controller Class Initialized
INFO - 2021-04-06 09:55:47 --> Model "Common_model" initialized
INFO - 2021-04-06 09:55:47 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:55:47 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:55:47 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:55:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 09:55:47 --> Final output sent to browser
DEBUG - 2021-04-06 09:55:47 --> Total execution time: 0.0585
INFO - 2021-04-06 09:59:53 --> Config Class Initialized
INFO - 2021-04-06 09:59:53 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:53 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:53 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:53 --> URI Class Initialized
INFO - 2021-04-06 09:59:53 --> Router Class Initialized
INFO - 2021-04-06 09:59:53 --> Output Class Initialized
INFO - 2021-04-06 09:59:53 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:53 --> Input Class Initialized
INFO - 2021-04-06 09:59:53 --> Language Class Initialized
INFO - 2021-04-06 09:59:53 --> Loader Class Initialized
INFO - 2021-04-06 09:59:53 --> Helper loaded: url_helper
INFO - 2021-04-06 09:59:53 --> Helper loaded: file_helper
INFO - 2021-04-06 09:59:53 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:59:53 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:59:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:59:53 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:53 --> Email Class Initialized
DEBUG - 2021-04-06 09:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:59:54 --> Helper loaded: form_helper
INFO - 2021-04-06 09:59:54 --> Form Validation Class Initialized
INFO - 2021-04-06 09:59:54 --> Controller Class Initialized
INFO - 2021-04-06 09:59:54 --> Model "Common_model" initialized
INFO - 2021-04-06 09:59:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:59:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:59:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:59:54 --> Config Class Initialized
INFO - 2021-04-06 09:59:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:54 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:54 --> URI Class Initialized
INFO - 2021-04-06 09:59:54 --> Router Class Initialized
INFO - 2021-04-06 09:59:54 --> Output Class Initialized
INFO - 2021-04-06 09:59:54 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:54 --> Input Class Initialized
INFO - 2021-04-06 09:59:54 --> Language Class Initialized
INFO - 2021-04-06 09:59:54 --> Loader Class Initialized
INFO - 2021-04-06 09:59:54 --> Helper loaded: url_helper
INFO - 2021-04-06 09:59:54 --> Helper loaded: file_helper
INFO - 2021-04-06 09:59:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:59:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:59:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:59:54 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:54 --> Email Class Initialized
DEBUG - 2021-04-06 09:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:59:54 --> Helper loaded: form_helper
INFO - 2021-04-06 09:59:54 --> Form Validation Class Initialized
INFO - 2021-04-06 09:59:54 --> Controller Class Initialized
INFO - 2021-04-06 09:59:54 --> Model "Common_model" initialized
INFO - 2021-04-06 09:59:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:59:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:59:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:59:54 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 09:59:54 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 09:59:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 09:59:55 --> Final output sent to browser
DEBUG - 2021-04-06 09:59:55 --> Total execution time: 1.6599
INFO - 2021-04-06 09:59:56 --> Config Class Initialized
INFO - 2021-04-06 09:59:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:56 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:56 --> URI Class Initialized
INFO - 2021-04-06 09:59:56 --> Router Class Initialized
INFO - 2021-04-06 09:59:56 --> Output Class Initialized
INFO - 2021-04-06 09:59:56 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:56 --> Input Class Initialized
INFO - 2021-04-06 09:59:56 --> Language Class Initialized
ERROR - 2021-04-06 09:59:56 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 09:59:56 --> Config Class Initialized
INFO - 2021-04-06 09:59:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:56 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:56 --> URI Class Initialized
INFO - 2021-04-06 09:59:56 --> Router Class Initialized
INFO - 2021-04-06 09:59:56 --> Output Class Initialized
INFO - 2021-04-06 09:59:56 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:56 --> Input Class Initialized
INFO - 2021-04-06 09:59:56 --> Language Class Initialized
INFO - 2021-04-06 09:59:56 --> Loader Class Initialized
INFO - 2021-04-06 09:59:56 --> Helper loaded: url_helper
INFO - 2021-04-06 09:59:56 --> Helper loaded: file_helper
INFO - 2021-04-06 09:59:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:59:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:59:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:59:56 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:56 --> Email Class Initialized
DEBUG - 2021-04-06 09:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:59:56 --> Helper loaded: form_helper
INFO - 2021-04-06 09:59:56 --> Form Validation Class Initialized
INFO - 2021-04-06 09:59:56 --> Controller Class Initialized
INFO - 2021-04-06 09:59:56 --> Model "Common_model" initialized
INFO - 2021-04-06 09:59:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:59:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:59:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:59:56 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 09:59:56 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:57 --> Config Class Initialized
INFO - 2021-04-06 09:59:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:57 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:57 --> URI Class Initialized
INFO - 2021-04-06 09:59:57 --> Router Class Initialized
INFO - 2021-04-06 09:59:57 --> Output Class Initialized
INFO - 2021-04-06 09:59:57 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:57 --> Input Class Initialized
INFO - 2021-04-06 09:59:57 --> Language Class Initialized
INFO - 2021-04-06 09:59:57 --> Loader Class Initialized
INFO - 2021-04-06 09:59:57 --> Helper loaded: url_helper
INFO - 2021-04-06 09:59:57 --> Helper loaded: file_helper
INFO - 2021-04-06 09:59:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:59:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:59:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:59:57 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:57 --> Email Class Initialized
DEBUG - 2021-04-06 09:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:59:58 --> Config Class Initialized
INFO - 2021-04-06 09:59:58 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:58 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:58 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:58 --> URI Class Initialized
INFO - 2021-04-06 09:59:58 --> Router Class Initialized
INFO - 2021-04-06 09:59:58 --> Output Class Initialized
INFO - 2021-04-06 09:59:58 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:58 --> Input Class Initialized
INFO - 2021-04-06 09:59:58 --> Language Class Initialized
INFO - 2021-04-06 09:59:58 --> Loader Class Initialized
INFO - 2021-04-06 09:59:58 --> Helper loaded: url_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: file_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:59:58 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:58 --> Email Class Initialized
DEBUG - 2021-04-06 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:59:58 --> Config Class Initialized
INFO - 2021-04-06 09:59:58 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:58 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:58 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:58 --> URI Class Initialized
INFO - 2021-04-06 09:59:58 --> Router Class Initialized
INFO - 2021-04-06 09:59:58 --> Output Class Initialized
INFO - 2021-04-06 09:59:58 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:58 --> Input Class Initialized
INFO - 2021-04-06 09:59:58 --> Language Class Initialized
INFO - 2021-04-06 09:59:58 --> Loader Class Initialized
INFO - 2021-04-06 09:59:58 --> Helper loaded: url_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: file_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:59:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:59:58 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:58 --> Email Class Initialized
DEBUG - 2021-04-06 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:59:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 09:59:58 --> Final output sent to browser
DEBUG - 2021-04-06 09:59:58 --> Total execution time: 2.1653
INFO - 2021-04-06 09:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:59:58 --> Helper loaded: form_helper
INFO - 2021-04-06 09:59:58 --> Form Validation Class Initialized
INFO - 2021-04-06 09:59:58 --> Controller Class Initialized
INFO - 2021-04-06 09:59:58 --> Model "Common_model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 09:59:58 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 09:59:58 --> Final output sent to browser
DEBUG - 2021-04-06 09:59:58 --> Total execution time: 0.7831
INFO - 2021-04-06 09:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:59:58 --> Helper loaded: form_helper
INFO - 2021-04-06 09:59:58 --> Form Validation Class Initialized
INFO - 2021-04-06 09:59:58 --> Controller Class Initialized
INFO - 2021-04-06 09:59:58 --> Model "Common_model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:59:58 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 09:59:58 --> Database Driver Class Initialized
ERROR - 2021-04-06 09:59:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 09:59:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 09:59:59 --> Final output sent to browser
DEBUG - 2021-04-06 09:59:59 --> Total execution time: 1.1405
INFO - 2021-04-06 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:59:59 --> Helper loaded: form_helper
INFO - 2021-04-06 09:59:59 --> Form Validation Class Initialized
INFO - 2021-04-06 09:59:59 --> Controller Class Initialized
INFO - 2021-04-06 09:59:59 --> Model "Common_model" initialized
INFO - 2021-04-06 09:59:59 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:59:59 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:59:59 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:59:59 --> Config Class Initialized
INFO - 2021-04-06 09:59:59 --> Hooks Class Initialized
DEBUG - 2021-04-06 09:59:59 --> UTF-8 Support Enabled
INFO - 2021-04-06 09:59:59 --> Utf8 Class Initialized
INFO - 2021-04-06 09:59:59 --> URI Class Initialized
INFO - 2021-04-06 09:59:59 --> Router Class Initialized
INFO - 2021-04-06 09:59:59 --> Output Class Initialized
INFO - 2021-04-06 09:59:59 --> Security Class Initialized
DEBUG - 2021-04-06 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 09:59:59 --> Input Class Initialized
INFO - 2021-04-06 09:59:59 --> Language Class Initialized
INFO - 2021-04-06 09:59:59 --> Loader Class Initialized
INFO - 2021-04-06 09:59:59 --> Helper loaded: url_helper
INFO - 2021-04-06 09:59:59 --> Helper loaded: file_helper
INFO - 2021-04-06 09:59:59 --> Helper loaded: utility_helper
INFO - 2021-04-06 09:59:59 --> Helper loaded: unit_helper
INFO - 2021-04-06 09:59:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 09:59:59 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:59 --> Email Class Initialized
DEBUG - 2021-04-06 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 09:59:59 --> Helper loaded: form_helper
INFO - 2021-04-06 09:59:59 --> Form Validation Class Initialized
INFO - 2021-04-06 09:59:59 --> Controller Class Initialized
INFO - 2021-04-06 09:59:59 --> Model "Common_model" initialized
INFO - 2021-04-06 09:59:59 --> Model "Finane_Model" initialized
INFO - 2021-04-06 09:59:59 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 09:59:59 --> Model "Sales_Model" initialized
INFO - 2021-04-06 09:59:59 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 09:59:59 --> Database Driver Class Initialized
INFO - 2021-04-06 09:59:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 09:59:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 09:59:59 --> Final output sent to browser
DEBUG - 2021-04-06 09:59:59 --> Total execution time: 0.3922
INFO - 2021-04-06 10:00:30 --> Config Class Initialized
INFO - 2021-04-06 10:00:30 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:30 --> URI Class Initialized
INFO - 2021-04-06 10:00:30 --> Router Class Initialized
INFO - 2021-04-06 10:00:30 --> Output Class Initialized
INFO - 2021-04-06 10:00:30 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:30 --> Input Class Initialized
INFO - 2021-04-06 10:00:30 --> Language Class Initialized
INFO - 2021-04-06 10:00:30 --> Loader Class Initialized
INFO - 2021-04-06 10:00:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:30 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:30 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:30 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:30 --> Controller Class Initialized
INFO - 2021-04-06 10:00:30 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:00:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:00:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:00:30 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:30 --> Total execution time: 0.0829
INFO - 2021-04-06 10:00:30 --> Config Class Initialized
INFO - 2021-04-06 10:00:30 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:30 --> URI Class Initialized
INFO - 2021-04-06 10:00:30 --> Config Class Initialized
INFO - 2021-04-06 10:00:30 --> Hooks Class Initialized
INFO - 2021-04-06 10:00:30 --> Router Class Initialized
DEBUG - 2021-04-06 10:00:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:30 --> URI Class Initialized
INFO - 2021-04-06 10:00:30 --> Output Class Initialized
INFO - 2021-04-06 10:00:30 --> Security Class Initialized
INFO - 2021-04-06 10:00:30 --> Router Class Initialized
DEBUG - 2021-04-06 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:30 --> Input Class Initialized
INFO - 2021-04-06 10:00:30 --> Language Class Initialized
ERROR - 2021-04-06 10:00:30 --> 404 Page Not Found: Estiaenterprise_rc/DistributorDashboard
INFO - 2021-04-06 10:00:30 --> Output Class Initialized
INFO - 2021-04-06 10:00:30 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:30 --> Input Class Initialized
INFO - 2021-04-06 10:00:30 --> Language Class Initialized
INFO - 2021-04-06 10:00:30 --> Loader Class Initialized
INFO - 2021-04-06 10:00:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:30 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:30 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:30 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:30 --> Controller Class Initialized
INFO - 2021-04-06 10:00:30 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:00:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:00:30 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:30 --> Total execution time: 0.1775
INFO - 2021-04-06 10:00:30 --> Config Class Initialized
INFO - 2021-04-06 10:00:30 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:30 --> URI Class Initialized
INFO - 2021-04-06 10:00:30 --> Config Class Initialized
INFO - 2021-04-06 10:00:30 --> Hooks Class Initialized
INFO - 2021-04-06 10:00:30 --> Router Class Initialized
DEBUG - 2021-04-06 10:00:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:30 --> URI Class Initialized
INFO - 2021-04-06 10:00:30 --> Output Class Initialized
INFO - 2021-04-06 10:00:30 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:30 --> Input Class Initialized
INFO - 2021-04-06 10:00:30 --> Language Class Initialized
INFO - 2021-04-06 10:00:30 --> Router Class Initialized
INFO - 2021-04-06 10:00:30 --> Output Class Initialized
INFO - 2021-04-06 10:00:30 --> Loader Class Initialized
INFO - 2021-04-06 10:00:30 --> Security Class Initialized
INFO - 2021-04-06 10:00:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: file_helper
DEBUG - 2021-04-06 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:30 --> Input Class Initialized
INFO - 2021-04-06 10:00:30 --> Language Class Initialized
INFO - 2021-04-06 10:00:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:30 --> Loader Class Initialized
INFO - 2021-04-06 10:00:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:30 --> Email Class Initialized
INFO - 2021-04-06 10:00:30 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-04-06 10:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:30 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:30 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:30 --> Controller Class Initialized
INFO - 2021-04-06 10:00:30 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:30 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:00:31 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:00:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:00:31 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:31 --> Total execution time: 0.0546
INFO - 2021-04-06 10:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:31 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:31 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:31 --> Controller Class Initialized
INFO - 2021-04-06 10:00:31 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:00:31 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:00:31 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:31 --> Total execution time: 0.0675
INFO - 2021-04-06 10:00:31 --> Config Class Initialized
INFO - 2021-04-06 10:00:31 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:31 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:31 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:31 --> URI Class Initialized
INFO - 2021-04-06 10:00:31 --> Router Class Initialized
INFO - 2021-04-06 10:00:31 --> Output Class Initialized
INFO - 2021-04-06 10:00:31 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:31 --> Input Class Initialized
INFO - 2021-04-06 10:00:31 --> Language Class Initialized
INFO - 2021-04-06 10:00:31 --> Loader Class Initialized
INFO - 2021-04-06 10:00:31 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:31 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:31 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:31 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:31 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:31 --> Controller Class Initialized
INFO - 2021-04-06 10:00:31 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:31 --> Config Class Initialized
INFO - 2021-04-06 10:00:31 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:31 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:31 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:31 --> URI Class Initialized
INFO - 2021-04-06 10:00:31 --> Router Class Initialized
INFO - 2021-04-06 10:00:31 --> Output Class Initialized
INFO - 2021-04-06 10:00:31 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:31 --> Input Class Initialized
INFO - 2021-04-06 10:00:31 --> Language Class Initialized
INFO - 2021-04-06 10:00:31 --> Loader Class Initialized
INFO - 2021-04-06 10:00:31 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:31 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:31 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:31 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:31 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:31 --> Controller Class Initialized
INFO - 2021-04-06 10:00:31 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:31 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:00:31 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:00:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:00:31 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:31 --> Total execution time: 0.1171
INFO - 2021-04-06 10:00:34 --> Config Class Initialized
INFO - 2021-04-06 10:00:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:34 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:34 --> URI Class Initialized
INFO - 2021-04-06 10:00:34 --> Router Class Initialized
INFO - 2021-04-06 10:00:34 --> Output Class Initialized
INFO - 2021-04-06 10:00:34 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:34 --> Input Class Initialized
INFO - 2021-04-06 10:00:34 --> Language Class Initialized
INFO - 2021-04-06 10:00:34 --> Loader Class Initialized
INFO - 2021-04-06 10:00:34 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:34 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:34 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:34 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:34 --> Controller Class Initialized
INFO - 2021-04-06 10:00:34 --> Config Class Initialized
INFO - 2021-04-06 10:00:34 --> Hooks Class Initialized
INFO - 2021-04-06 10:00:34 --> Model "Common_model" initialized
DEBUG - 2021-04-06 10:00:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:34 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:34 --> URI Class Initialized
INFO - 2021-04-06 10:00:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:34 --> Router Class Initialized
INFO - 2021-04-06 10:00:34 --> Output Class Initialized
INFO - 2021-04-06 10:00:34 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:34 --> Input Class Initialized
INFO - 2021-04-06 10:00:34 --> Language Class Initialized
INFO - 2021-04-06 10:00:34 --> Loader Class Initialized
INFO - 2021-04-06 10:00:34 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:34 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:00:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:00:34 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:34 --> Total execution time: 0.1021
INFO - 2021-04-06 10:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:34 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:34 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:34 --> Controller Class Initialized
INFO - 2021-04-06 10:00:34 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:00:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:00:34 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:34 --> Total execution time: 0.1356
INFO - 2021-04-06 10:00:35 --> Config Class Initialized
INFO - 2021-04-06 10:00:35 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:35 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:35 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:35 --> URI Class Initialized
INFO - 2021-04-06 10:00:35 --> Router Class Initialized
INFO - 2021-04-06 10:00:35 --> Output Class Initialized
INFO - 2021-04-06 10:00:35 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:35 --> Input Class Initialized
INFO - 2021-04-06 10:00:35 --> Language Class Initialized
ERROR - 2021-04-06 10:00:35 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:00:35 --> Config Class Initialized
INFO - 2021-04-06 10:00:35 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:35 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:35 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:35 --> URI Class Initialized
INFO - 2021-04-06 10:00:35 --> Router Class Initialized
INFO - 2021-04-06 10:00:35 --> Output Class Initialized
INFO - 2021-04-06 10:00:35 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:35 --> Input Class Initialized
INFO - 2021-04-06 10:00:35 --> Language Class Initialized
INFO - 2021-04-06 10:00:35 --> Loader Class Initialized
INFO - 2021-04-06 10:00:35 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:35 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:35 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:35 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:35 --> Controller Class Initialized
INFO - 2021-04-06 10:00:35 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:35 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:35 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:35 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:35 --> Config Class Initialized
INFO - 2021-04-06 10:00:35 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:00:35 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:00:35 --> Utf8 Class Initialized
INFO - 2021-04-06 10:00:35 --> URI Class Initialized
INFO - 2021-04-06 10:00:35 --> Router Class Initialized
INFO - 2021-04-06 10:00:35 --> Output Class Initialized
INFO - 2021-04-06 10:00:35 --> Security Class Initialized
DEBUG - 2021-04-06 10:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:00:35 --> Input Class Initialized
INFO - 2021-04-06 10:00:35 --> Language Class Initialized
INFO - 2021-04-06 10:00:35 --> Loader Class Initialized
INFO - 2021-04-06 10:00:35 --> Helper loaded: url_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: file_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:00:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:00:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:35 --> Email Class Initialized
DEBUG - 2021-04-06 10:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:00:35 --> Helper loaded: form_helper
INFO - 2021-04-06 10:00:35 --> Form Validation Class Initialized
INFO - 2021-04-06 10:00:35 --> Controller Class Initialized
INFO - 2021-04-06 10:00:35 --> Model "Common_model" initialized
INFO - 2021-04-06 10:00:35 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:00:35 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:00:35 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:00:35 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:00:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:00:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:00:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:00:35 --> Final output sent to browser
DEBUG - 2021-04-06 10:00:35 --> Total execution time: 0.0794
INFO - 2021-04-06 10:01:43 --> Config Class Initialized
INFO - 2021-04-06 10:01:43 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:01:43 --> Utf8 Class Initialized
INFO - 2021-04-06 10:01:43 --> URI Class Initialized
INFO - 2021-04-06 10:01:43 --> Router Class Initialized
INFO - 2021-04-06 10:01:43 --> Output Class Initialized
INFO - 2021-04-06 10:01:43 --> Security Class Initialized
DEBUG - 2021-04-06 10:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:01:43 --> Input Class Initialized
INFO - 2021-04-06 10:01:43 --> Language Class Initialized
INFO - 2021-04-06 10:01:43 --> Loader Class Initialized
INFO - 2021-04-06 10:01:43 --> Helper loaded: url_helper
INFO - 2021-04-06 10:01:43 --> Helper loaded: file_helper
INFO - 2021-04-06 10:01:43 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:01:43 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:01:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:01:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:01:43 --> Email Class Initialized
DEBUG - 2021-04-06 10:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:01:43 --> Helper loaded: form_helper
INFO - 2021-04-06 10:01:43 --> Form Validation Class Initialized
INFO - 2021-04-06 10:01:43 --> Controller Class Initialized
INFO - 2021-04-06 10:01:43 --> Model "Common_model" initialized
INFO - 2021-04-06 10:01:43 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:01:43 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:01:43 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:01:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:01:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:01:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:01:43 --> Final output sent to browser
DEBUG - 2021-04-06 10:01:43 --> Total execution time: 0.1866
INFO - 2021-04-06 10:01:43 --> Config Class Initialized
INFO - 2021-04-06 10:01:43 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:01:43 --> Utf8 Class Initialized
INFO - 2021-04-06 10:01:43 --> URI Class Initialized
INFO - 2021-04-06 10:01:43 --> Router Class Initialized
INFO - 2021-04-06 10:01:43 --> Output Class Initialized
INFO - 2021-04-06 10:01:43 --> Security Class Initialized
DEBUG - 2021-04-06 10:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:01:43 --> Input Class Initialized
INFO - 2021-04-06 10:01:43 --> Language Class Initialized
ERROR - 2021-04-06 10:01:43 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:01:44 --> Config Class Initialized
INFO - 2021-04-06 10:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:01:44 --> Utf8 Class Initialized
INFO - 2021-04-06 10:01:44 --> URI Class Initialized
INFO - 2021-04-06 10:01:44 --> Router Class Initialized
INFO - 2021-04-06 10:01:44 --> Output Class Initialized
INFO - 2021-04-06 10:01:44 --> Security Class Initialized
DEBUG - 2021-04-06 10:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:01:44 --> Input Class Initialized
INFO - 2021-04-06 10:01:44 --> Language Class Initialized
INFO - 2021-04-06 10:01:44 --> Loader Class Initialized
INFO - 2021-04-06 10:01:44 --> Helper loaded: url_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: file_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:01:44 --> Database Driver Class Initialized
INFO - 2021-04-06 10:01:44 --> Email Class Initialized
DEBUG - 2021-04-06 10:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:01:44 --> Helper loaded: form_helper
INFO - 2021-04-06 10:01:44 --> Form Validation Class Initialized
INFO - 2021-04-06 10:01:44 --> Controller Class Initialized
INFO - 2021-04-06 10:01:44 --> Model "Common_model" initialized
INFO - 2021-04-06 10:01:44 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:01:44 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:01:44 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:01:44 --> Config Class Initialized
INFO - 2021-04-06 10:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:01:44 --> Utf8 Class Initialized
INFO - 2021-04-06 10:01:44 --> URI Class Initialized
INFO - 2021-04-06 10:01:44 --> Router Class Initialized
INFO - 2021-04-06 10:01:44 --> Output Class Initialized
INFO - 2021-04-06 10:01:44 --> Security Class Initialized
DEBUG - 2021-04-06 10:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:01:44 --> Input Class Initialized
INFO - 2021-04-06 10:01:44 --> Language Class Initialized
INFO - 2021-04-06 10:01:44 --> Loader Class Initialized
INFO - 2021-04-06 10:01:44 --> Helper loaded: url_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: file_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:01:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:01:44 --> Database Driver Class Initialized
INFO - 2021-04-06 10:01:44 --> Email Class Initialized
DEBUG - 2021-04-06 10:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:01:44 --> Helper loaded: form_helper
INFO - 2021-04-06 10:01:44 --> Form Validation Class Initialized
INFO - 2021-04-06 10:01:44 --> Controller Class Initialized
INFO - 2021-04-06 10:01:44 --> Model "Common_model" initialized
INFO - 2021-04-06 10:01:44 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:01:44 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:01:44 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:01:44 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:01:44 --> Database Driver Class Initialized
INFO - 2021-04-06 10:01:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:01:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:01:44 --> Final output sent to browser
DEBUG - 2021-04-06 10:01:44 --> Total execution time: 0.0762
INFO - 2021-04-06 10:02:16 --> Config Class Initialized
INFO - 2021-04-06 10:02:16 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:02:16 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:02:16 --> Utf8 Class Initialized
INFO - 2021-04-06 10:02:16 --> URI Class Initialized
INFO - 2021-04-06 10:02:16 --> Router Class Initialized
INFO - 2021-04-06 10:02:16 --> Output Class Initialized
INFO - 2021-04-06 10:02:16 --> Security Class Initialized
DEBUG - 2021-04-06 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:02:16 --> Input Class Initialized
INFO - 2021-04-06 10:02:16 --> Language Class Initialized
INFO - 2021-04-06 10:02:16 --> Loader Class Initialized
INFO - 2021-04-06 10:02:16 --> Helper loaded: url_helper
INFO - 2021-04-06 10:02:16 --> Helper loaded: file_helper
INFO - 2021-04-06 10:02:16 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:02:16 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:02:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:02:16 --> Database Driver Class Initialized
INFO - 2021-04-06 10:02:16 --> Email Class Initialized
DEBUG - 2021-04-06 10:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:02:16 --> Helper loaded: form_helper
INFO - 2021-04-06 10:02:16 --> Form Validation Class Initialized
INFO - 2021-04-06 10:02:16 --> Controller Class Initialized
INFO - 2021-04-06 10:02:16 --> Model "Common_model" initialized
INFO - 2021-04-06 10:02:16 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:02:16 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:02:16 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:02:16 --> Database Driver Class Initialized
INFO - 2021-04-06 10:02:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:02:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:02:16 --> Final output sent to browser
DEBUG - 2021-04-06 10:02:16 --> Total execution time: 0.2744
INFO - 2021-04-06 10:02:17 --> Config Class Initialized
INFO - 2021-04-06 10:02:17 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:02:17 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:02:17 --> Utf8 Class Initialized
INFO - 2021-04-06 10:02:17 --> URI Class Initialized
INFO - 2021-04-06 10:02:17 --> Router Class Initialized
INFO - 2021-04-06 10:02:17 --> Output Class Initialized
INFO - 2021-04-06 10:02:17 --> Security Class Initialized
DEBUG - 2021-04-06 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:02:17 --> Input Class Initialized
INFO - 2021-04-06 10:02:17 --> Language Class Initialized
ERROR - 2021-04-06 10:02:17 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:02:17 --> Config Class Initialized
INFO - 2021-04-06 10:02:17 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:02:17 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:02:17 --> Utf8 Class Initialized
INFO - 2021-04-06 10:02:17 --> URI Class Initialized
INFO - 2021-04-06 10:02:17 --> Router Class Initialized
INFO - 2021-04-06 10:02:17 --> Output Class Initialized
INFO - 2021-04-06 10:02:17 --> Security Class Initialized
DEBUG - 2021-04-06 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:02:17 --> Input Class Initialized
INFO - 2021-04-06 10:02:17 --> Language Class Initialized
INFO - 2021-04-06 10:02:17 --> Loader Class Initialized
INFO - 2021-04-06 10:02:17 --> Helper loaded: url_helper
INFO - 2021-04-06 10:02:17 --> Helper loaded: file_helper
INFO - 2021-04-06 10:02:17 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:02:17 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:02:17 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:02:17 --> Database Driver Class Initialized
INFO - 2021-04-06 10:02:17 --> Email Class Initialized
DEBUG - 2021-04-06 10:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:02:17 --> Helper loaded: form_helper
INFO - 2021-04-06 10:02:17 --> Form Validation Class Initialized
INFO - 2021-04-06 10:02:17 --> Controller Class Initialized
INFO - 2021-04-06 10:02:17 --> Model "Common_model" initialized
INFO - 2021-04-06 10:02:17 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:02:17 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:02:17 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:02:18 --> Config Class Initialized
INFO - 2021-04-06 10:02:18 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:02:18 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:02:18 --> Utf8 Class Initialized
INFO - 2021-04-06 10:02:18 --> URI Class Initialized
INFO - 2021-04-06 10:02:18 --> Router Class Initialized
INFO - 2021-04-06 10:02:18 --> Output Class Initialized
INFO - 2021-04-06 10:02:18 --> Security Class Initialized
DEBUG - 2021-04-06 10:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:02:18 --> Input Class Initialized
INFO - 2021-04-06 10:02:18 --> Language Class Initialized
INFO - 2021-04-06 10:02:18 --> Loader Class Initialized
INFO - 2021-04-06 10:02:18 --> Helper loaded: url_helper
INFO - 2021-04-06 10:02:18 --> Helper loaded: file_helper
INFO - 2021-04-06 10:02:18 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:02:18 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:02:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:02:18 --> Database Driver Class Initialized
INFO - 2021-04-06 10:02:18 --> Email Class Initialized
DEBUG - 2021-04-06 10:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:02:18 --> Helper loaded: form_helper
INFO - 2021-04-06 10:02:18 --> Form Validation Class Initialized
INFO - 2021-04-06 10:02:18 --> Controller Class Initialized
INFO - 2021-04-06 10:02:18 --> Model "Common_model" initialized
INFO - 2021-04-06 10:02:18 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:02:18 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:02:18 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:02:18 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:02:18 --> Database Driver Class Initialized
INFO - 2021-04-06 10:02:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:02:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:02:18 --> Final output sent to browser
DEBUG - 2021-04-06 10:02:18 --> Total execution time: 0.0829
INFO - 2021-04-06 10:23:36 --> Config Class Initialized
INFO - 2021-04-06 10:23:36 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:23:36 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:36 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:36 --> URI Class Initialized
INFO - 2021-04-06 10:23:36 --> Router Class Initialized
INFO - 2021-04-06 10:23:36 --> Output Class Initialized
INFO - 2021-04-06 10:23:36 --> Security Class Initialized
DEBUG - 2021-04-06 10:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:37 --> Input Class Initialized
INFO - 2021-04-06 10:23:37 --> Language Class Initialized
INFO - 2021-04-06 10:23:37 --> Loader Class Initialized
INFO - 2021-04-06 10:23:37 --> Helper loaded: url_helper
INFO - 2021-04-06 10:23:37 --> Helper loaded: file_helper
INFO - 2021-04-06 10:23:37 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:23:37 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:23:37 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:23:37 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:37 --> Email Class Initialized
DEBUG - 2021-04-06 10:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:23:37 --> Helper loaded: form_helper
INFO - 2021-04-06 10:23:37 --> Form Validation Class Initialized
INFO - 2021-04-06 10:23:37 --> Controller Class Initialized
INFO - 2021-04-06 10:23:37 --> Model "Common_model" initialized
INFO - 2021-04-06 10:23:37 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:23:37 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:23:37 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:23:39 --> Config Class Initialized
INFO - 2021-04-06 10:23:39 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:23:39 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:39 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:39 --> URI Class Initialized
INFO - 2021-04-06 10:23:39 --> Router Class Initialized
INFO - 2021-04-06 10:23:39 --> Output Class Initialized
INFO - 2021-04-06 10:23:39 --> Security Class Initialized
DEBUG - 2021-04-06 10:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:39 --> Input Class Initialized
INFO - 2021-04-06 10:23:39 --> Language Class Initialized
INFO - 2021-04-06 10:23:39 --> Loader Class Initialized
INFO - 2021-04-06 10:23:39 --> Helper loaded: url_helper
INFO - 2021-04-06 10:23:39 --> Helper loaded: file_helper
INFO - 2021-04-06 10:23:39 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:23:39 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:23:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:23:39 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:39 --> Email Class Initialized
DEBUG - 2021-04-06 10:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:23:39 --> Helper loaded: form_helper
INFO - 2021-04-06 10:23:39 --> Form Validation Class Initialized
INFO - 2021-04-06 10:23:39 --> Controller Class Initialized
INFO - 2021-04-06 10:23:39 --> Model "Common_model" initialized
INFO - 2021-04-06 10:23:39 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:23:39 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:23:39 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:23:39 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:23:39 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:23:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:23:40 --> Final output sent to browser
DEBUG - 2021-04-06 10:23:40 --> Total execution time: 0.9051
INFO - 2021-04-06 10:23:43 --> Config Class Initialized
INFO - 2021-04-06 10:23:43 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:23:43 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:43 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:43 --> URI Class Initialized
INFO - 2021-04-06 10:23:43 --> Router Class Initialized
INFO - 2021-04-06 10:23:43 --> Output Class Initialized
INFO - 2021-04-06 10:23:43 --> Security Class Initialized
DEBUG - 2021-04-06 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:43 --> Input Class Initialized
INFO - 2021-04-06 10:23:43 --> Language Class Initialized
INFO - 2021-04-06 10:23:43 --> Loader Class Initialized
INFO - 2021-04-06 10:23:43 --> Helper loaded: url_helper
INFO - 2021-04-06 10:23:43 --> Helper loaded: file_helper
INFO - 2021-04-06 10:23:43 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:23:43 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:23:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:23:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:43 --> Email Class Initialized
DEBUG - 2021-04-06 10:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:23:43 --> Helper loaded: form_helper
INFO - 2021-04-06 10:23:43 --> Form Validation Class Initialized
INFO - 2021-04-06 10:23:43 --> Controller Class Initialized
INFO - 2021-04-06 10:23:43 --> Model "Common_model" initialized
INFO - 2021-04-06 10:23:43 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:23:43 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:23:43 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:23:43 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:23:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:44 --> Config Class Initialized
INFO - 2021-04-06 10:23:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:23:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:44 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:44 --> URI Class Initialized
INFO - 2021-04-06 10:23:44 --> Router Class Initialized
INFO - 2021-04-06 10:23:44 --> Output Class Initialized
INFO - 2021-04-06 10:23:44 --> Security Class Initialized
DEBUG - 2021-04-06 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:44 --> Input Class Initialized
INFO - 2021-04-06 10:23:44 --> Language Class Initialized
INFO - 2021-04-06 10:23:44 --> Config Class Initialized
INFO - 2021-04-06 10:23:44 --> Hooks Class Initialized
INFO - 2021-04-06 10:23:44 --> Loader Class Initialized
INFO - 2021-04-06 10:23:44 --> Helper loaded: url_helper
INFO - 2021-04-06 10:23:44 --> Helper loaded: file_helper
DEBUG - 2021-04-06 10:23:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:44 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:23:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:23:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:23:44 --> URI Class Initialized
INFO - 2021-04-06 10:23:44 --> Router Class Initialized
INFO - 2021-04-06 10:23:44 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:44 --> Output Class Initialized
INFO - 2021-04-06 10:23:44 --> Security Class Initialized
INFO - 2021-04-06 10:23:44 --> Email Class Initialized
DEBUG - 2021-04-06 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:44 --> Input Class Initialized
INFO - 2021-04-06 10:23:44 --> Language Class Initialized
DEBUG - 2021-04-06 10:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:23:44 --> Loader Class Initialized
INFO - 2021-04-06 10:23:44 --> Helper loaded: url_helper
INFO - 2021-04-06 10:23:44 --> Helper loaded: file_helper
INFO - 2021-04-06 10:23:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:23:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:23:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:23:44 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:44 --> Email Class Initialized
DEBUG - 2021-04-06 10:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:23:45 --> Config Class Initialized
INFO - 2021-04-06 10:23:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:23:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:45 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:45 --> URI Class Initialized
INFO - 2021-04-06 10:23:45 --> Router Class Initialized
INFO - 2021-04-06 10:23:45 --> Output Class Initialized
INFO - 2021-04-06 10:23:45 --> Security Class Initialized
DEBUG - 2021-04-06 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:45 --> Input Class Initialized
INFO - 2021-04-06 10:23:45 --> Language Class Initialized
ERROR - 2021-04-06 10:23:45 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:23:46 --> Config Class Initialized
INFO - 2021-04-06 10:23:46 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:23:46 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:46 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:46 --> URI Class Initialized
INFO - 2021-04-06 10:23:46 --> Router Class Initialized
INFO - 2021-04-06 10:23:46 --> Output Class Initialized
INFO - 2021-04-06 10:23:46 --> Security Class Initialized
DEBUG - 2021-04-06 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:46 --> Input Class Initialized
INFO - 2021-04-06 10:23:46 --> Language Class Initialized
INFO - 2021-04-06 10:23:46 --> Loader Class Initialized
INFO - 2021-04-06 10:23:46 --> Helper loaded: url_helper
INFO - 2021-04-06 10:23:46 --> Helper loaded: file_helper
INFO - 2021-04-06 10:23:46 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:23:46 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:23:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:23:46 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:46 --> Email Class Initialized
DEBUG - 2021-04-06 10:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:23:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:23:46 --> Final output sent to browser
DEBUG - 2021-04-06 10:23:46 --> Total execution time: 3.8459
INFO - 2021-04-06 10:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:23:46 --> Helper loaded: form_helper
INFO - 2021-04-06 10:23:46 --> Form Validation Class Initialized
INFO - 2021-04-06 10:23:46 --> Controller Class Initialized
INFO - 2021-04-06 10:23:46 --> Model "Common_model" initialized
INFO - 2021-04-06 10:23:46 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:23:46 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:23:46 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:23:46 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:23:46 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:23:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:23:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:23:47 --> Final output sent to browser
DEBUG - 2021-04-06 10:23:47 --> Total execution time: 2.6928
INFO - 2021-04-06 10:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:23:47 --> Helper loaded: form_helper
INFO - 2021-04-06 10:23:47 --> Form Validation Class Initialized
INFO - 2021-04-06 10:23:47 --> Controller Class Initialized
INFO - 2021-04-06 10:23:47 --> Model "Common_model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:23:47 --> Helper loaded: form_helper
INFO - 2021-04-06 10:23:47 --> Form Validation Class Initialized
INFO - 2021-04-06 10:23:47 --> Controller Class Initialized
INFO - 2021-04-06 10:23:47 --> Model "Common_model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:23:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:23:47 --> Final output sent to browser
DEBUG - 2021-04-06 10:23:47 --> Total execution time: 2.7218
INFO - 2021-04-06 10:23:47 --> Config Class Initialized
INFO - 2021-04-06 10:23:47 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:23:47 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:23:47 --> Utf8 Class Initialized
INFO - 2021-04-06 10:23:47 --> URI Class Initialized
INFO - 2021-04-06 10:23:47 --> Router Class Initialized
INFO - 2021-04-06 10:23:47 --> Output Class Initialized
INFO - 2021-04-06 10:23:47 --> Security Class Initialized
DEBUG - 2021-04-06 10:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:23:47 --> Input Class Initialized
INFO - 2021-04-06 10:23:47 --> Language Class Initialized
INFO - 2021-04-06 10:23:47 --> Loader Class Initialized
INFO - 2021-04-06 10:23:47 --> Helper loaded: url_helper
INFO - 2021-04-06 10:23:47 --> Helper loaded: file_helper
INFO - 2021-04-06 10:23:47 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:23:47 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:23:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:23:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:47 --> Email Class Initialized
DEBUG - 2021-04-06 10:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:23:47 --> Helper loaded: form_helper
INFO - 2021-04-06 10:23:47 --> Form Validation Class Initialized
INFO - 2021-04-06 10:23:47 --> Controller Class Initialized
INFO - 2021-04-06 10:23:47 --> Model "Common_model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:23:47 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:23:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:23:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:23:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:23:47 --> Final output sent to browser
DEBUG - 2021-04-06 10:23:47 --> Total execution time: 0.1054
INFO - 2021-04-06 10:24:12 --> Config Class Initialized
INFO - 2021-04-06 10:24:12 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:12 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:12 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:12 --> URI Class Initialized
INFO - 2021-04-06 10:24:12 --> Router Class Initialized
INFO - 2021-04-06 10:24:12 --> Output Class Initialized
INFO - 2021-04-06 10:24:12 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:12 --> Input Class Initialized
INFO - 2021-04-06 10:24:12 --> Language Class Initialized
INFO - 2021-04-06 10:24:12 --> Loader Class Initialized
INFO - 2021-04-06 10:24:12 --> Helper loaded: url_helper
INFO - 2021-04-06 10:24:12 --> Helper loaded: file_helper
INFO - 2021-04-06 10:24:12 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:24:12 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:24:12 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:24:12 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:12 --> Email Class Initialized
DEBUG - 2021-04-06 10:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:24:12 --> Helper loaded: form_helper
INFO - 2021-04-06 10:24:12 --> Form Validation Class Initialized
INFO - 2021-04-06 10:24:12 --> Controller Class Initialized
INFO - 2021-04-06 10:24:12 --> Model "Common_model" initialized
INFO - 2021-04-06 10:24:12 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:24:12 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:24:12 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:24:12 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:12 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:24:12 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:24:12 --> Final output sent to browser
DEBUG - 2021-04-06 10:24:12 --> Total execution time: 0.1073
INFO - 2021-04-06 10:24:13 --> Config Class Initialized
INFO - 2021-04-06 10:24:13 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:13 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:13 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:13 --> URI Class Initialized
INFO - 2021-04-06 10:24:13 --> Router Class Initialized
INFO - 2021-04-06 10:24:13 --> Output Class Initialized
INFO - 2021-04-06 10:24:13 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:13 --> Input Class Initialized
INFO - 2021-04-06 10:24:13 --> Language Class Initialized
ERROR - 2021-04-06 10:24:13 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:24:14 --> Config Class Initialized
INFO - 2021-04-06 10:24:14 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:14 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:14 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:14 --> URI Class Initialized
INFO - 2021-04-06 10:24:14 --> Router Class Initialized
INFO - 2021-04-06 10:24:14 --> Output Class Initialized
INFO - 2021-04-06 10:24:14 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:14 --> Input Class Initialized
INFO - 2021-04-06 10:24:14 --> Language Class Initialized
INFO - 2021-04-06 10:24:14 --> Loader Class Initialized
INFO - 2021-04-06 10:24:14 --> Helper loaded: url_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: file_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:24:14 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:14 --> Email Class Initialized
DEBUG - 2021-04-06 10:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:24:14 --> Helper loaded: form_helper
INFO - 2021-04-06 10:24:14 --> Form Validation Class Initialized
INFO - 2021-04-06 10:24:14 --> Controller Class Initialized
INFO - 2021-04-06 10:24:14 --> Model "Common_model" initialized
INFO - 2021-04-06 10:24:14 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:24:14 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:24:14 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:24:14 --> Config Class Initialized
INFO - 2021-04-06 10:24:14 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:14 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:14 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:14 --> URI Class Initialized
INFO - 2021-04-06 10:24:14 --> Router Class Initialized
INFO - 2021-04-06 10:24:14 --> Output Class Initialized
INFO - 2021-04-06 10:24:14 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:14 --> Input Class Initialized
INFO - 2021-04-06 10:24:14 --> Language Class Initialized
INFO - 2021-04-06 10:24:14 --> Loader Class Initialized
INFO - 2021-04-06 10:24:14 --> Helper loaded: url_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: file_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:24:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:24:14 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:14 --> Email Class Initialized
DEBUG - 2021-04-06 10:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:24:14 --> Helper loaded: form_helper
INFO - 2021-04-06 10:24:14 --> Form Validation Class Initialized
INFO - 2021-04-06 10:24:14 --> Controller Class Initialized
INFO - 2021-04-06 10:24:14 --> Model "Common_model" initialized
INFO - 2021-04-06 10:24:14 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:24:14 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:24:14 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:24:14 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:24:14 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:14 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:24:14 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:24:14 --> Final output sent to browser
DEBUG - 2021-04-06 10:24:14 --> Total execution time: 0.0816
INFO - 2021-04-06 10:24:54 --> Config Class Initialized
INFO - 2021-04-06 10:24:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:54 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:54 --> URI Class Initialized
INFO - 2021-04-06 10:24:54 --> Router Class Initialized
INFO - 2021-04-06 10:24:54 --> Output Class Initialized
INFO - 2021-04-06 10:24:54 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:54 --> Input Class Initialized
INFO - 2021-04-06 10:24:54 --> Language Class Initialized
INFO - 2021-04-06 10:24:54 --> Loader Class Initialized
INFO - 2021-04-06 10:24:54 --> Helper loaded: url_helper
INFO - 2021-04-06 10:24:54 --> Helper loaded: file_helper
INFO - 2021-04-06 10:24:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:24:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:24:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:24:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:54 --> Email Class Initialized
DEBUG - 2021-04-06 10:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:24:54 --> Helper loaded: form_helper
INFO - 2021-04-06 10:24:54 --> Form Validation Class Initialized
INFO - 2021-04-06 10:24:54 --> Controller Class Initialized
INFO - 2021-04-06 10:24:54 --> Model "Common_model" initialized
INFO - 2021-04-06 10:24:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:24:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:24:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:24:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:24:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:24:55 --> Final output sent to browser
DEBUG - 2021-04-06 10:24:55 --> Total execution time: 0.4303
INFO - 2021-04-06 10:24:55 --> Config Class Initialized
INFO - 2021-04-06 10:24:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:55 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:55 --> URI Class Initialized
INFO - 2021-04-06 10:24:55 --> Router Class Initialized
INFO - 2021-04-06 10:24:55 --> Output Class Initialized
INFO - 2021-04-06 10:24:55 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:55 --> Input Class Initialized
INFO - 2021-04-06 10:24:55 --> Language Class Initialized
ERROR - 2021-04-06 10:24:55 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:24:56 --> Config Class Initialized
INFO - 2021-04-06 10:24:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:56 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:56 --> URI Class Initialized
INFO - 2021-04-06 10:24:56 --> Router Class Initialized
INFO - 2021-04-06 10:24:56 --> Output Class Initialized
INFO - 2021-04-06 10:24:56 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:56 --> Input Class Initialized
INFO - 2021-04-06 10:24:56 --> Language Class Initialized
INFO - 2021-04-06 10:24:56 --> Loader Class Initialized
INFO - 2021-04-06 10:24:56 --> Helper loaded: url_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: file_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:24:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:56 --> Email Class Initialized
DEBUG - 2021-04-06 10:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:24:56 --> Helper loaded: form_helper
INFO - 2021-04-06 10:24:56 --> Form Validation Class Initialized
INFO - 2021-04-06 10:24:56 --> Controller Class Initialized
INFO - 2021-04-06 10:24:56 --> Model "Common_model" initialized
INFO - 2021-04-06 10:24:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:24:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:24:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:24:56 --> Config Class Initialized
INFO - 2021-04-06 10:24:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:24:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:24:56 --> Utf8 Class Initialized
INFO - 2021-04-06 10:24:56 --> URI Class Initialized
INFO - 2021-04-06 10:24:56 --> Router Class Initialized
INFO - 2021-04-06 10:24:56 --> Output Class Initialized
INFO - 2021-04-06 10:24:56 --> Security Class Initialized
DEBUG - 2021-04-06 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:24:56 --> Input Class Initialized
INFO - 2021-04-06 10:24:56 --> Language Class Initialized
INFO - 2021-04-06 10:24:56 --> Loader Class Initialized
INFO - 2021-04-06 10:24:56 --> Helper loaded: url_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: file_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:24:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:24:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:56 --> Email Class Initialized
DEBUG - 2021-04-06 10:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:24:56 --> Helper loaded: form_helper
INFO - 2021-04-06 10:24:56 --> Form Validation Class Initialized
INFO - 2021-04-06 10:24:56 --> Controller Class Initialized
INFO - 2021-04-06 10:24:56 --> Model "Common_model" initialized
INFO - 2021-04-06 10:24:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:24:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:24:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:24:56 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:24:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:24:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:24:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:24:56 --> Final output sent to browser
DEBUG - 2021-04-06 10:24:56 --> Total execution time: 0.0787
INFO - 2021-04-06 10:29:25 --> Config Class Initialized
INFO - 2021-04-06 10:29:25 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:25 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:25 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:25 --> URI Class Initialized
INFO - 2021-04-06 10:29:25 --> Router Class Initialized
INFO - 2021-04-06 10:29:25 --> Output Class Initialized
INFO - 2021-04-06 10:29:25 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:25 --> Input Class Initialized
INFO - 2021-04-06 10:29:25 --> Language Class Initialized
INFO - 2021-04-06 10:29:25 --> Loader Class Initialized
INFO - 2021-04-06 10:29:25 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:25 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:25 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:25 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:25 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:25 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:25 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:25 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:25 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:25 --> Controller Class Initialized
INFO - 2021-04-06 10:29:25 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:25 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:25 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:25 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:25 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:25 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 10:29:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 10:29:27 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:27 --> Total execution time: 1.6504
INFO - 2021-04-06 10:29:27 --> Config Class Initialized
INFO - 2021-04-06 10:29:27 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:27 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:27 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:27 --> URI Class Initialized
INFO - 2021-04-06 10:29:27 --> Router Class Initialized
INFO - 2021-04-06 10:29:27 --> Output Class Initialized
INFO - 2021-04-06 10:29:27 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:27 --> Input Class Initialized
INFO - 2021-04-06 10:29:27 --> Language Class Initialized
ERROR - 2021-04-06 10:29:27 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:29:27 --> Config Class Initialized
INFO - 2021-04-06 10:29:27 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:27 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:27 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:27 --> URI Class Initialized
INFO - 2021-04-06 10:29:27 --> Router Class Initialized
INFO - 2021-04-06 10:29:27 --> Output Class Initialized
INFO - 2021-04-06 10:29:27 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:27 --> Input Class Initialized
INFO - 2021-04-06 10:29:27 --> Language Class Initialized
INFO - 2021-04-06 10:29:27 --> Loader Class Initialized
INFO - 2021-04-06 10:29:27 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:27 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:27 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:27 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:27 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:27 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:27 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:27 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:27 --> Controller Class Initialized
INFO - 2021-04-06 10:29:27 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:27 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:27 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:27 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:27 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:27 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:29:27 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:27 --> Total execution time: 0.0428
INFO - 2021-04-06 10:29:28 --> Config Class Initialized
INFO - 2021-04-06 10:29:28 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:28 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:28 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:28 --> URI Class Initialized
INFO - 2021-04-06 10:29:28 --> Router Class Initialized
INFO - 2021-04-06 10:29:28 --> Output Class Initialized
INFO - 2021-04-06 10:29:28 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:28 --> Input Class Initialized
INFO - 2021-04-06 10:29:28 --> Language Class Initialized
INFO - 2021-04-06 10:29:28 --> Loader Class Initialized
INFO - 2021-04-06 10:29:28 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:28 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:28 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:28 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:28 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:28 --> Controller Class Initialized
INFO - 2021-04-06 10:29:28 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:28 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:28 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:28 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:28 --> Config Class Initialized
INFO - 2021-04-06 10:29:28 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:28 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:28 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:28 --> URI Class Initialized
INFO - 2021-04-06 10:29:28 --> Router Class Initialized
INFO - 2021-04-06 10:29:28 --> Output Class Initialized
INFO - 2021-04-06 10:29:28 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:28 --> Input Class Initialized
INFO - 2021-04-06 10:29:28 --> Language Class Initialized
INFO - 2021-04-06 10:29:28 --> Loader Class Initialized
INFO - 2021-04-06 10:29:28 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:28 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:28 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:28 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:28 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:28 --> Controller Class Initialized
INFO - 2021-04-06 10:29:28 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:28 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:28 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:28 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:28 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:28 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:28 --> Config Class Initialized
INFO - 2021-04-06 10:29:28 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:28 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:28 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:28 --> URI Class Initialized
INFO - 2021-04-06 10:29:28 --> Router Class Initialized
INFO - 2021-04-06 10:29:28 --> Output Class Initialized
INFO - 2021-04-06 10:29:28 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:28 --> Input Class Initialized
INFO - 2021-04-06 10:29:28 --> Language Class Initialized
INFO - 2021-04-06 10:29:28 --> Loader Class Initialized
INFO - 2021-04-06 10:29:28 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:28 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:28 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:28 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:29 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:29:29 --> Config Class Initialized
INFO - 2021-04-06 10:29:29 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:29 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:29 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:29 --> URI Class Initialized
INFO - 2021-04-06 10:29:29 --> Router Class Initialized
INFO - 2021-04-06 10:29:29 --> Output Class Initialized
INFO - 2021-04-06 10:29:29 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:29 --> Input Class Initialized
INFO - 2021-04-06 10:29:29 --> Language Class Initialized
INFO - 2021-04-06 10:29:29 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:29 --> Loader Class Initialized
INFO - 2021-04-06 10:29:29 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:29 --> Total execution time: 0.7195
INFO - 2021-04-06 10:29:29 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:29 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:29 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:29 --> Controller Class Initialized
INFO - 2021-04-06 10:29:29 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:29 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:29 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:29 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:29 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:29 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:29 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:29 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:29 --> Config Class Initialized
INFO - 2021-04-06 10:29:29 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:29 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:29 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:29 --> URI Class Initialized
INFO - 2021-04-06 10:29:29 --> Router Class Initialized
INFO - 2021-04-06 10:29:29 --> Output Class Initialized
INFO - 2021-04-06 10:29:29 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:29 --> Input Class Initialized
INFO - 2021-04-06 10:29:29 --> Language Class Initialized
INFO - 2021-04-06 10:29:29 --> Loader Class Initialized
INFO - 2021-04-06 10:29:29 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:29 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:29 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:29 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:30 --> Config Class Initialized
INFO - 2021-04-06 10:29:30 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:30 --> URI Class Initialized
INFO - 2021-04-06 10:29:30 --> Router Class Initialized
INFO - 2021-04-06 10:29:30 --> Output Class Initialized
INFO - 2021-04-06 10:29:30 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:30 --> Input Class Initialized
INFO - 2021-04-06 10:29:30 --> Language Class Initialized
INFO - 2021-04-06 10:29:30 --> Loader Class Initialized
INFO - 2021-04-06 10:29:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:30 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:30 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:29:32 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:32 --> Total execution time: 3.1876
INFO - 2021-04-06 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:32 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:32 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:32 --> Controller Class Initialized
INFO - 2021-04-06 10:29:32 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:29:32 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:32 --> Total execution time: 3.0678
INFO - 2021-04-06 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:32 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:32 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:32 --> Controller Class Initialized
INFO - 2021-04-06 10:29:32 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:32 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:32 --> Total execution time: 2.5160
INFO - 2021-04-06 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:32 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:32 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:32 --> Controller Class Initialized
INFO - 2021-04-06 10:29:32 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:32 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:32 --> Total execution time: 2.1148
INFO - 2021-04-06 10:29:32 --> Config Class Initialized
INFO - 2021-04-06 10:29:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:32 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:32 --> URI Class Initialized
INFO - 2021-04-06 10:29:32 --> Router Class Initialized
INFO - 2021-04-06 10:29:32 --> Output Class Initialized
INFO - 2021-04-06 10:29:32 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:32 --> Input Class Initialized
INFO - 2021-04-06 10:29:32 --> Language Class Initialized
ERROR - 2021-04-06 10:29:32 --> 404 Page Not Found: Estiaenterprise_rc/DistributorDashboard
INFO - 2021-04-06 10:29:32 --> Config Class Initialized
INFO - 2021-04-06 10:29:32 --> Config Class Initialized
INFO - 2021-04-06 10:29:32 --> Hooks Class Initialized
INFO - 2021-04-06 10:29:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 10:29:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:32 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:32 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:32 --> URI Class Initialized
INFO - 2021-04-06 10:29:32 --> URI Class Initialized
INFO - 2021-04-06 10:29:32 --> Config Class Initialized
INFO - 2021-04-06 10:29:32 --> Hooks Class Initialized
INFO - 2021-04-06 10:29:32 --> Router Class Initialized
INFO - 2021-04-06 10:29:32 --> Router Class Initialized
DEBUG - 2021-04-06 10:29:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:32 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:32 --> Output Class Initialized
INFO - 2021-04-06 10:29:32 --> Output Class Initialized
INFO - 2021-04-06 10:29:32 --> URI Class Initialized
INFO - 2021-04-06 10:29:32 --> Security Class Initialized
INFO - 2021-04-06 10:29:32 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:32 --> Router Class Initialized
DEBUG - 2021-04-06 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:32 --> Input Class Initialized
INFO - 2021-04-06 10:29:32 --> Input Class Initialized
INFO - 2021-04-06 10:29:32 --> Language Class Initialized
INFO - 2021-04-06 10:29:32 --> Language Class Initialized
INFO - 2021-04-06 10:29:32 --> Output Class Initialized
INFO - 2021-04-06 10:29:32 --> Security Class Initialized
INFO - 2021-04-06 10:29:32 --> Loader Class Initialized
INFO - 2021-04-06 10:29:32 --> Loader Class Initialized
DEBUG - 2021-04-06 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:32 --> Input Class Initialized
INFO - 2021-04-06 10:29:32 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:32 --> Language Class Initialized
INFO - 2021-04-06 10:29:32 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:32 --> Loader Class Initialized
INFO - 2021-04-06 10:29:32 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:32 --> Email Class Initialized
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:32 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 10:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:32 --> Email Class Initialized
INFO - 2021-04-06 10:29:32 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:32 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:32 --> Controller Class Initialized
DEBUG - 2021-04-06 10:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:32 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:29:32 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:32 --> Total execution time: 0.0411
INFO - 2021-04-06 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:32 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:32 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:32 --> Controller Class Initialized
INFO - 2021-04-06 10:29:32 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:32 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:29:32 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:32 --> Total execution time: 0.1448
INFO - 2021-04-06 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:33 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:33 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:33 --> Controller Class Initialized
INFO - 2021-04-06 10:29:33 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:33 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:29:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:29:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:29:33 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:33 --> Total execution time: 0.1627
INFO - 2021-04-06 10:29:33 --> Config Class Initialized
INFO - 2021-04-06 10:29:33 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:33 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:33 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:33 --> URI Class Initialized
INFO - 2021-04-06 10:29:33 --> Router Class Initialized
INFO - 2021-04-06 10:29:33 --> Output Class Initialized
INFO - 2021-04-06 10:29:33 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:33 --> Input Class Initialized
INFO - 2021-04-06 10:29:33 --> Language Class Initialized
INFO - 2021-04-06 10:29:33 --> Loader Class Initialized
INFO - 2021-04-06 10:29:33 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:33 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:33 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:33 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:33 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:33 --> Controller Class Initialized
INFO - 2021-04-06 10:29:33 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:33 --> Config Class Initialized
INFO - 2021-04-06 10:29:33 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:33 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:33 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:33 --> URI Class Initialized
INFO - 2021-04-06 10:29:33 --> Router Class Initialized
INFO - 2021-04-06 10:29:33 --> Output Class Initialized
INFO - 2021-04-06 10:29:33 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:33 --> Input Class Initialized
INFO - 2021-04-06 10:29:33 --> Language Class Initialized
INFO - 2021-04-06 10:29:33 --> Loader Class Initialized
INFO - 2021-04-06 10:29:33 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:33 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:33 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:33 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:33 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:33 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:33 --> Controller Class Initialized
INFO - 2021-04-06 10:29:33 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:33 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:33 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:29:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:33 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:33 --> Total execution time: 0.0706
INFO - 2021-04-06 10:29:34 --> Config Class Initialized
INFO - 2021-04-06 10:29:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:34 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:34 --> URI Class Initialized
INFO - 2021-04-06 10:29:34 --> Router Class Initialized
INFO - 2021-04-06 10:29:34 --> Output Class Initialized
INFO - 2021-04-06 10:29:34 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:34 --> Input Class Initialized
INFO - 2021-04-06 10:29:34 --> Language Class Initialized
INFO - 2021-04-06 10:29:34 --> Loader Class Initialized
INFO - 2021-04-06 10:29:34 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:34 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:34 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:34 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:34 --> Controller Class Initialized
INFO - 2021-04-06 10:29:34 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/sales/saleInvoice/saleList.php
INFO - 2021-04-06 10:29:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:34 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:34 --> Total execution time: 0.0685
INFO - 2021-04-06 10:29:34 --> Config Class Initialized
INFO - 2021-04-06 10:29:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:34 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:34 --> URI Class Initialized
INFO - 2021-04-06 10:29:34 --> Router Class Initialized
INFO - 2021-04-06 10:29:34 --> Output Class Initialized
INFO - 2021-04-06 10:29:34 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:34 --> Input Class Initialized
INFO - 2021-04-06 10:29:34 --> Language Class Initialized
INFO - 2021-04-06 10:29:34 --> Loader Class Initialized
INFO - 2021-04-06 10:29:34 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:34 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:34 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:34 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:34 --> Controller Class Initialized
INFO - 2021-04-06 10:29:34 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:34 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/sales/saleInvoice/saleList.php
INFO - 2021-04-06 10:29:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:34 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:34 --> Total execution time: 0.0701
INFO - 2021-04-06 10:29:34 --> Config Class Initialized
INFO - 2021-04-06 10:29:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:34 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:34 --> URI Class Initialized
INFO - 2021-04-06 10:29:34 --> Router Class Initialized
INFO - 2021-04-06 10:29:34 --> Output Class Initialized
INFO - 2021-04-06 10:29:34 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:34 --> Input Class Initialized
INFO - 2021-04-06 10:29:34 --> Language Class Initialized
ERROR - 2021-04-06 10:29:34 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:29:35 --> Config Class Initialized
INFO - 2021-04-06 10:29:35 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:35 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:35 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:35 --> URI Class Initialized
INFO - 2021-04-06 10:29:35 --> Router Class Initialized
INFO - 2021-04-06 10:29:35 --> Output Class Initialized
INFO - 2021-04-06 10:29:35 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:35 --> Input Class Initialized
INFO - 2021-04-06 10:29:35 --> Language Class Initialized
INFO - 2021-04-06 10:29:35 --> Loader Class Initialized
INFO - 2021-04-06 10:29:35 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:35 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:35 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:35 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:35 --> Controller Class Initialized
INFO - 2021-04-06 10:29:35 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:35 --> Config Class Initialized
INFO - 2021-04-06 10:29:35 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:35 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:35 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:35 --> URI Class Initialized
INFO - 2021-04-06 10:29:35 --> Router Class Initialized
INFO - 2021-04-06 10:29:35 --> Output Class Initialized
INFO - 2021-04-06 10:29:35 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:35 --> Input Class Initialized
INFO - 2021-04-06 10:29:35 --> Language Class Initialized
INFO - 2021-04-06 10:29:35 --> Loader Class Initialized
INFO - 2021-04-06 10:29:35 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:35 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:35 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:35 --> Total execution time: 0.4018
INFO - 2021-04-06 10:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:35 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:35 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:35 --> Controller Class Initialized
INFO - 2021-04-06 10:29:35 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:35 --> Config Class Initialized
INFO - 2021-04-06 10:29:35 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:35 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:35 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:35 --> URI Class Initialized
INFO - 2021-04-06 10:29:35 --> Router Class Initialized
INFO - 2021-04-06 10:29:35 --> Output Class Initialized
INFO - 2021-04-06 10:29:35 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:35 --> Input Class Initialized
INFO - 2021-04-06 10:29:35 --> Language Class Initialized
INFO - 2021-04-06 10:29:35 --> Loader Class Initialized
INFO - 2021-04-06 10:29:35 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:35 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:35 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:35 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:35 --> Controller Class Initialized
INFO - 2021-04-06 10:29:35 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:35 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:35 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:29:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:35 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:36 --> Total execution time: 0.0762
INFO - 2021-04-06 10:29:38 --> Config Class Initialized
INFO - 2021-04-06 10:29:38 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:38 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:38 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:38 --> URI Class Initialized
INFO - 2021-04-06 10:29:38 --> Router Class Initialized
INFO - 2021-04-06 10:29:38 --> Output Class Initialized
INFO - 2021-04-06 10:29:38 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:38 --> Input Class Initialized
INFO - 2021-04-06 10:29:38 --> Language Class Initialized
INFO - 2021-04-06 10:29:38 --> Loader Class Initialized
INFO - 2021-04-06 10:29:38 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:38 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:38 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:38 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:38 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:38 --> Controller Class Initialized
INFO - 2021-04-06 10:29:38 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:38 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:38 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:38 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:38 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:38 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:38 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:38 --> Total execution time: 0.1425
INFO - 2021-04-06 10:29:38 --> Config Class Initialized
INFO - 2021-04-06 10:29:38 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:38 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:38 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:38 --> URI Class Initialized
INFO - 2021-04-06 10:29:38 --> Router Class Initialized
INFO - 2021-04-06 10:29:38 --> Output Class Initialized
INFO - 2021-04-06 10:29:38 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:38 --> Input Class Initialized
INFO - 2021-04-06 10:29:38 --> Language Class Initialized
INFO - 2021-04-06 10:29:38 --> Loader Class Initialized
INFO - 2021-04-06 10:29:38 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:38 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:38 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:38 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:38 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:38 --> Controller Class Initialized
INFO - 2021-04-06 10:29:38 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:38 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:38 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:38 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:38 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:38 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:39 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:39 --> Total execution time: 0.2900
INFO - 2021-04-06 10:29:39 --> Config Class Initialized
INFO - 2021-04-06 10:29:39 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:39 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:39 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:39 --> URI Class Initialized
INFO - 2021-04-06 10:29:39 --> Router Class Initialized
INFO - 2021-04-06 10:29:39 --> Output Class Initialized
INFO - 2021-04-06 10:29:39 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:39 --> Input Class Initialized
INFO - 2021-04-06 10:29:39 --> Language Class Initialized
INFO - 2021-04-06 10:29:39 --> Loader Class Initialized
INFO - 2021-04-06 10:29:39 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:39 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:39 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:39 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:39 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:39 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:39 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:39 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:39 --> Controller Class Initialized
INFO - 2021-04-06 10:29:39 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:39 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:39 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:39 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:39 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:39 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:39 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:39 --> Total execution time: 0.1524
INFO - 2021-04-06 10:29:40 --> Config Class Initialized
INFO - 2021-04-06 10:29:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:40 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:40 --> URI Class Initialized
INFO - 2021-04-06 10:29:40 --> Router Class Initialized
INFO - 2021-04-06 10:29:40 --> Output Class Initialized
INFO - 2021-04-06 10:29:40 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:40 --> Input Class Initialized
INFO - 2021-04-06 10:29:40 --> Language Class Initialized
INFO - 2021-04-06 10:29:40 --> Loader Class Initialized
INFO - 2021-04-06 10:29:40 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:40 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:40 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:40 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:40 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:40 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:40 --> Controller Class Initialized
INFO - 2021-04-06 10:29:40 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:40 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:40 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:40 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:40 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:40 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:40 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:40 --> Total execution time: 0.2153
INFO - 2021-04-06 10:29:41 --> Config Class Initialized
INFO - 2021-04-06 10:29:41 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:41 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:41 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:41 --> URI Class Initialized
INFO - 2021-04-06 10:29:41 --> Router Class Initialized
INFO - 2021-04-06 10:29:41 --> Output Class Initialized
INFO - 2021-04-06 10:29:41 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:41 --> Input Class Initialized
INFO - 2021-04-06 10:29:41 --> Language Class Initialized
INFO - 2021-04-06 10:29:41 --> Loader Class Initialized
INFO - 2021-04-06 10:29:41 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:41 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:41 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:41 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:41 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:41 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:41 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:41 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:41 --> Controller Class Initialized
INFO - 2021-04-06 10:29:41 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:41 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:41 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:41 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:41 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:41 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:41 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:41 --> Total execution time: 0.1482
INFO - 2021-04-06 10:29:44 --> Config Class Initialized
INFO - 2021-04-06 10:29:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:44 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:44 --> URI Class Initialized
INFO - 2021-04-06 10:29:44 --> Router Class Initialized
INFO - 2021-04-06 10:29:44 --> Output Class Initialized
INFO - 2021-04-06 10:29:44 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:44 --> Input Class Initialized
INFO - 2021-04-06 10:29:44 --> Language Class Initialized
INFO - 2021-04-06 10:29:44 --> Loader Class Initialized
INFO - 2021-04-06 10:29:44 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:44 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:44 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:44 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:44 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:44 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:44 --> Controller Class Initialized
INFO - 2021-04-06 10:29:44 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:44 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:44 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:44 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:44 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:44 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:44 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:44 --> Total execution time: 0.2115
INFO - 2021-04-06 10:29:48 --> Config Class Initialized
INFO - 2021-04-06 10:29:48 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:48 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:48 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:48 --> URI Class Initialized
INFO - 2021-04-06 10:29:48 --> Router Class Initialized
INFO - 2021-04-06 10:29:48 --> Output Class Initialized
INFO - 2021-04-06 10:29:48 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:48 --> Input Class Initialized
INFO - 2021-04-06 10:29:48 --> Language Class Initialized
INFO - 2021-04-06 10:29:48 --> Loader Class Initialized
INFO - 2021-04-06 10:29:48 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:48 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:48 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:48 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:48 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:48 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:48 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:48 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:48 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:48 --> Controller Class Initialized
INFO - 2021-04-06 10:29:48 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:48 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:48 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:48 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:48 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:29:48 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:48 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:48 --> Total execution time: 0.8460
INFO - 2021-04-06 10:29:55 --> Config Class Initialized
INFO - 2021-04-06 10:29:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:55 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:55 --> URI Class Initialized
INFO - 2021-04-06 10:29:55 --> Router Class Initialized
INFO - 2021-04-06 10:29:55 --> Output Class Initialized
INFO - 2021-04-06 10:29:55 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:55 --> Input Class Initialized
INFO - 2021-04-06 10:29:55 --> Language Class Initialized
INFO - 2021-04-06 10:29:55 --> Loader Class Initialized
INFO - 2021-04-06 10:29:55 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:55 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:55 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:55 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:55 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:55 --> Controller Class Initialized
INFO - 2021-04-06 10:29:55 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/sales/saleInvoice/editInvoice.php
INFO - 2021-04-06 10:29:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:55 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:55 --> Total execution time: 0.2267
INFO - 2021-04-06 10:29:56 --> Config Class Initialized
INFO - 2021-04-06 10:29:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:56 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:56 --> URI Class Initialized
INFO - 2021-04-06 10:29:56 --> Router Class Initialized
INFO - 2021-04-06 10:29:56 --> Output Class Initialized
INFO - 2021-04-06 10:29:56 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:56 --> Input Class Initialized
INFO - 2021-04-06 10:29:56 --> Language Class Initialized
ERROR - 2021-04-06 10:29:56 --> 404 Page Not Found: Estiaenterprise_rc/salesInvoice_edit
INFO - 2021-04-06 10:29:56 --> Config Class Initialized
INFO - 2021-04-06 10:29:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:56 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:56 --> URI Class Initialized
INFO - 2021-04-06 10:29:56 --> Router Class Initialized
INFO - 2021-04-06 10:29:56 --> Output Class Initialized
INFO - 2021-04-06 10:29:56 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:56 --> Input Class Initialized
INFO - 2021-04-06 10:29:56 --> Language Class Initialized
INFO - 2021-04-06 10:29:56 --> Config Class Initialized
INFO - 2021-04-06 10:29:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:56 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:56 --> URI Class Initialized
INFO - 2021-04-06 10:29:56 --> Router Class Initialized
INFO - 2021-04-06 10:29:56 --> Output Class Initialized
INFO - 2021-04-06 10:29:56 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:56 --> Input Class Initialized
INFO - 2021-04-06 10:29:56 --> Language Class Initialized
INFO - 2021-04-06 10:29:56 --> Loader Class Initialized
INFO - 2021-04-06 10:29:56 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:56 --> Loader Class Initialized
INFO - 2021-04-06 10:29:56 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:56 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:56 --> Email Class Initialized
INFO - 2021-04-06 10:29:56 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:56 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:56 --> Controller Class Initialized
DEBUG - 2021-04-06 10:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:56 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/loadCusSup.php
INFO - 2021-04-06 10:29:56 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:56 --> Total execution time: 0.0531
INFO - 2021-04-06 10:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:56 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:56 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:56 --> Controller Class Initialized
INFO - 2021-04-06 10:29:56 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:56 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:56 --> Total execution time: 0.0853
INFO - 2021-04-06 10:29:56 --> Config Class Initialized
INFO - 2021-04-06 10:29:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:56 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:56 --> URI Class Initialized
INFO - 2021-04-06 10:29:56 --> Router Class Initialized
INFO - 2021-04-06 10:29:56 --> Output Class Initialized
INFO - 2021-04-06 10:29:56 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:56 --> Input Class Initialized
INFO - 2021-04-06 10:29:56 --> Language Class Initialized
INFO - 2021-04-06 10:29:57 --> Loader Class Initialized
INFO - 2021-04-06 10:29:57 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:57 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:57 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:57 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:57 --> Controller Class Initialized
INFO - 2021-04-06 10:29:57 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:57 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:57 --> Total execution time: 0.0458
INFO - 2021-04-06 10:29:57 --> Config Class Initialized
INFO - 2021-04-06 10:29:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:57 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:57 --> URI Class Initialized
INFO - 2021-04-06 10:29:57 --> Router Class Initialized
INFO - 2021-04-06 10:29:57 --> Output Class Initialized
INFO - 2021-04-06 10:29:57 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:57 --> Input Class Initialized
INFO - 2021-04-06 10:29:57 --> Language Class Initialized
INFO - 2021-04-06 10:29:57 --> Loader Class Initialized
INFO - 2021-04-06 10:29:57 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:57 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:57 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:57 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:57 --> Controller Class Initialized
INFO - 2021-04-06 10:29:57 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:57 --> Config Class Initialized
INFO - 2021-04-06 10:29:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:29:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:29:57 --> Utf8 Class Initialized
INFO - 2021-04-06 10:29:57 --> URI Class Initialized
INFO - 2021-04-06 10:29:57 --> Router Class Initialized
INFO - 2021-04-06 10:29:57 --> Output Class Initialized
INFO - 2021-04-06 10:29:57 --> Security Class Initialized
DEBUG - 2021-04-06 10:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:29:57 --> Input Class Initialized
INFO - 2021-04-06 10:29:57 --> Language Class Initialized
INFO - 2021-04-06 10:29:57 --> Loader Class Initialized
INFO - 2021-04-06 10:29:57 --> Helper loaded: url_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: file_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:29:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:29:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:57 --> Email Class Initialized
DEBUG - 2021-04-06 10:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:29:57 --> Helper loaded: form_helper
INFO - 2021-04-06 10:29:57 --> Form Validation Class Initialized
INFO - 2021-04-06 10:29:57 --> Controller Class Initialized
INFO - 2021-04-06 10:29:57 --> Model "Common_model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:29:57 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:29:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:29:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:29:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:29:57 --> Final output sent to browser
DEBUG - 2021-04-06 10:29:57 --> Total execution time: 0.0905
INFO - 2021-04-06 10:30:13 --> Config Class Initialized
INFO - 2021-04-06 10:30:13 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:13 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:13 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:13 --> URI Class Initialized
INFO - 2021-04-06 10:30:13 --> Router Class Initialized
INFO - 2021-04-06 10:30:13 --> Output Class Initialized
INFO - 2021-04-06 10:30:13 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:13 --> Input Class Initialized
INFO - 2021-04-06 10:30:13 --> Language Class Initialized
INFO - 2021-04-06 10:30:13 --> Loader Class Initialized
INFO - 2021-04-06 10:30:13 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:13 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:13 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:13 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:13 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:13 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:13 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:13 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:13 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:13 --> Controller Class Initialized
INFO - 2021-04-06 10:30:13 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:13 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:13 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:13 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:13 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:13 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:13 --> Total execution time: 0.0535
INFO - 2021-04-06 10:30:14 --> Config Class Initialized
INFO - 2021-04-06 10:30:14 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:14 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:14 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:14 --> URI Class Initialized
INFO - 2021-04-06 10:30:14 --> Router Class Initialized
INFO - 2021-04-06 10:30:14 --> Output Class Initialized
INFO - 2021-04-06 10:30:14 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:14 --> Input Class Initialized
INFO - 2021-04-06 10:30:14 --> Language Class Initialized
INFO - 2021-04-06 10:30:14 --> Loader Class Initialized
INFO - 2021-04-06 10:30:14 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:14 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:14 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:14 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:14 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:14 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:14 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:14 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:14 --> Controller Class Initialized
INFO - 2021-04-06 10:30:14 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:14 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:14 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:14 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:14 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:14 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:14 --> Total execution time: 0.0531
INFO - 2021-04-06 10:30:19 --> Config Class Initialized
INFO - 2021-04-06 10:30:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:19 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:19 --> URI Class Initialized
INFO - 2021-04-06 10:30:19 --> Router Class Initialized
INFO - 2021-04-06 10:30:19 --> Output Class Initialized
INFO - 2021-04-06 10:30:19 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:19 --> Input Class Initialized
INFO - 2021-04-06 10:30:19 --> Language Class Initialized
INFO - 2021-04-06 10:30:19 --> Loader Class Initialized
INFO - 2021-04-06 10:30:19 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:19 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:19 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:19 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:19 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:19 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:19 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:19 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:19 --> Controller Class Initialized
INFO - 2021-04-06 10:30:19 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:19 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:19 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:19 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:19 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:19 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:19 --> Total execution time: 0.0472
INFO - 2021-04-06 10:30:20 --> Config Class Initialized
INFO - 2021-04-06 10:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:20 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:20 --> URI Class Initialized
INFO - 2021-04-06 10:30:20 --> Router Class Initialized
INFO - 2021-04-06 10:30:20 --> Output Class Initialized
INFO - 2021-04-06 10:30:20 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:20 --> Input Class Initialized
INFO - 2021-04-06 10:30:20 --> Language Class Initialized
INFO - 2021-04-06 10:30:20 --> Loader Class Initialized
INFO - 2021-04-06 10:30:20 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:20 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:20 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:20 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:20 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:20 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:20 --> Controller Class Initialized
INFO - 2021-04-06 10:30:20 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:20 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:20 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:20 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:20 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:20 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:20 --> Total execution time: 0.0569
INFO - 2021-04-06 10:30:24 --> Config Class Initialized
INFO - 2021-04-06 10:30:24 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:24 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:24 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:24 --> URI Class Initialized
INFO - 2021-04-06 10:30:24 --> Router Class Initialized
INFO - 2021-04-06 10:30:24 --> Output Class Initialized
INFO - 2021-04-06 10:30:24 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:24 --> Input Class Initialized
INFO - 2021-04-06 10:30:24 --> Language Class Initialized
INFO - 2021-04-06 10:30:24 --> Loader Class Initialized
INFO - 2021-04-06 10:30:24 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:24 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:24 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:24 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:24 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:24 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:24 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:24 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:24 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:24 --> Controller Class Initialized
INFO - 2021-04-06 10:30:24 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:24 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:24 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:24 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:24 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-06 10:30:24 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/aelbfopi/amarcement.com/application/controllers/SalesController.php 1379
INFO - 2021-04-06 10:30:25 --> Config Class Initialized
INFO - 2021-04-06 10:30:25 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:25 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:25 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:25 --> URI Class Initialized
INFO - 2021-04-06 10:30:25 --> Router Class Initialized
INFO - 2021-04-06 10:30:25 --> Output Class Initialized
INFO - 2021-04-06 10:30:25 --> Config Class Initialized
INFO - 2021-04-06 10:30:25 --> Hooks Class Initialized
INFO - 2021-04-06 10:30:25 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 10:30:25 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:25 --> Input Class Initialized
INFO - 2021-04-06 10:30:25 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:25 --> Language Class Initialized
INFO - 2021-04-06 10:30:25 --> URI Class Initialized
INFO - 2021-04-06 10:30:25 --> Router Class Initialized
INFO - 2021-04-06 10:30:25 --> Output Class Initialized
INFO - 2021-04-06 10:30:25 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:25 --> Input Class Initialized
INFO - 2021-04-06 10:30:25 --> Language Class Initialized
INFO - 2021-04-06 10:30:25 --> Loader Class Initialized
INFO - 2021-04-06 10:30:25 --> Loader Class Initialized
INFO - 2021-04-06 10:30:25 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:25 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:25 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:25 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:25 --> Email Class Initialized
INFO - 2021-04-06 10:30:25 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-04-06 10:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:25 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:25 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:25 --> Controller Class Initialized
INFO - 2021-04-06 10:30:25 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:25 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:25 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:25 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:25 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:25 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/sales/saleInvoice/salesNewFormate.php
INFO - 2021-04-06 10:30:25 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:30:25 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:25 --> Total execution time: 0.1044
INFO - 2021-04-06 10:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:25 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:25 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:25 --> Controller Class Initialized
INFO - 2021-04-06 10:30:25 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:25 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:25 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:25 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:26 --> Config Class Initialized
INFO - 2021-04-06 10:30:26 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:26 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:26 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:26 --> URI Class Initialized
INFO - 2021-04-06 10:30:26 --> Router Class Initialized
INFO - 2021-04-06 10:30:26 --> Output Class Initialized
INFO - 2021-04-06 10:30:26 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:26 --> Input Class Initialized
INFO - 2021-04-06 10:30:26 --> Language Class Initialized
ERROR - 2021-04-06 10:30:26 --> 404 Page Not Found: Estiaenterprise_rc/salesInvoice_view
INFO - 2021-04-06 10:30:27 --> Config Class Initialized
INFO - 2021-04-06 10:30:27 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:27 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:27 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:27 --> URI Class Initialized
INFO - 2021-04-06 10:30:27 --> Router Class Initialized
INFO - 2021-04-06 10:30:27 --> Output Class Initialized
INFO - 2021-04-06 10:30:27 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:27 --> Input Class Initialized
INFO - 2021-04-06 10:30:27 --> Language Class Initialized
INFO - 2021-04-06 10:30:27 --> Loader Class Initialized
INFO - 2021-04-06 10:30:27 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:27 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:27 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:27 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:27 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:27 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:27 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:27 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:27 --> Controller Class Initialized
INFO - 2021-04-06 10:30:27 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:27 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:27 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:27 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:27 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:27 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:27 --> Total execution time: 0.0745
INFO - 2021-04-06 10:30:28 --> Config Class Initialized
INFO - 2021-04-06 10:30:28 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:28 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:28 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:28 --> URI Class Initialized
INFO - 2021-04-06 10:30:28 --> Router Class Initialized
INFO - 2021-04-06 10:30:28 --> Output Class Initialized
INFO - 2021-04-06 10:30:28 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:28 --> Input Class Initialized
INFO - 2021-04-06 10:30:28 --> Language Class Initialized
INFO - 2021-04-06 10:30:28 --> Loader Class Initialized
INFO - 2021-04-06 10:30:28 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:28 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:28 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:28 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:28 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:28 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:28 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:28 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:28 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:28 --> Controller Class Initialized
INFO - 2021-04-06 10:30:28 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:28 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:28 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:28 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:28 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:30:28 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 10:30:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 10:30:30 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:30 --> Total execution time: 1.3947
INFO - 2021-04-06 10:30:30 --> Config Class Initialized
INFO - 2021-04-06 10:30:30 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:30 --> URI Class Initialized
INFO - 2021-04-06 10:30:30 --> Router Class Initialized
INFO - 2021-04-06 10:30:30 --> Output Class Initialized
INFO - 2021-04-06 10:30:30 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:30 --> Input Class Initialized
INFO - 2021-04-06 10:30:30 --> Language Class Initialized
ERROR - 2021-04-06 10:30:30 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:30:30 --> Config Class Initialized
INFO - 2021-04-06 10:30:30 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:30 --> URI Class Initialized
INFO - 2021-04-06 10:30:30 --> Router Class Initialized
INFO - 2021-04-06 10:30:30 --> Output Class Initialized
INFO - 2021-04-06 10:30:30 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:30 --> Input Class Initialized
INFO - 2021-04-06 10:30:30 --> Language Class Initialized
INFO - 2021-04-06 10:30:30 --> Loader Class Initialized
INFO - 2021-04-06 10:30:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:30 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:30 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:30 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:30 --> Controller Class Initialized
INFO - 2021-04-06 10:30:30 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:30 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:30 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:30 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:30 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:30:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:30 --> Config Class Initialized
INFO - 2021-04-06 10:30:30 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:30 --> Config Class Initialized
INFO - 2021-04-06 10:30:30 --> Hooks Class Initialized
INFO - 2021-04-06 10:30:30 --> URI Class Initialized
DEBUG - 2021-04-06 10:30:30 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:30 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:30 --> Router Class Initialized
INFO - 2021-04-06 10:30:30 --> URI Class Initialized
INFO - 2021-04-06 10:30:30 --> Output Class Initialized
INFO - 2021-04-06 10:30:30 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:30 --> Input Class Initialized
INFO - 2021-04-06 10:30:30 --> Language Class Initialized
INFO - 2021-04-06 10:30:30 --> Router Class Initialized
INFO - 2021-04-06 10:30:30 --> Loader Class Initialized
INFO - 2021-04-06 10:30:30 --> Output Class Initialized
INFO - 2021-04-06 10:30:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:30 --> Security Class Initialized
INFO - 2021-04-06 10:30:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: db_dinamic_helper
DEBUG - 2021-04-06 10:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:30 --> Input Class Initialized
INFO - 2021-04-06 10:30:30 --> Language Class Initialized
INFO - 2021-04-06 10:30:30 --> Loader Class Initialized
INFO - 2021-04-06 10:30:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:30 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:30 --> Email Class Initialized
INFO - 2021-04-06 10:30:30 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:30 --> Helper loaded: db_dinamic_helper
DEBUG - 2021-04-06 10:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:30 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:30 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:31 --> Config Class Initialized
INFO - 2021-04-06 10:30:31 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:31 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:31 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:31 --> URI Class Initialized
INFO - 2021-04-06 10:30:31 --> Router Class Initialized
INFO - 2021-04-06 10:30:31 --> Output Class Initialized
INFO - 2021-04-06 10:30:31 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:31 --> Input Class Initialized
INFO - 2021-04-06 10:30:31 --> Language Class Initialized
INFO - 2021-04-06 10:30:31 --> Loader Class Initialized
INFO - 2021-04-06 10:30:31 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:31 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:31 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:31 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:31 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:31 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:30:33 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:33 --> Total execution time: 2.3816
INFO - 2021-04-06 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:33 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:33 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:33 --> Controller Class Initialized
INFO - 2021-04-06 10:30:33 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:30:33 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:30:33 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:33 --> Total execution time: 2.1581
INFO - 2021-04-06 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:33 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:33 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:33 --> Controller Class Initialized
INFO - 2021-04-06 10:30:33 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:33 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:33 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:33 --> Controller Class Initialized
INFO - 2021-04-06 10:30:33 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:30:33 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:30:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:30:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:30:33 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:33 --> Total execution time: 2.2983
INFO - 2021-04-06 10:30:33 --> Config Class Initialized
INFO - 2021-04-06 10:30:33 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:30:33 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:30:33 --> Utf8 Class Initialized
INFO - 2021-04-06 10:30:33 --> URI Class Initialized
INFO - 2021-04-06 10:30:33 --> Router Class Initialized
INFO - 2021-04-06 10:30:33 --> Output Class Initialized
INFO - 2021-04-06 10:30:33 --> Security Class Initialized
DEBUG - 2021-04-06 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:30:33 --> Input Class Initialized
INFO - 2021-04-06 10:30:33 --> Language Class Initialized
INFO - 2021-04-06 10:30:33 --> Loader Class Initialized
INFO - 2021-04-06 10:30:33 --> Helper loaded: url_helper
INFO - 2021-04-06 10:30:33 --> Helper loaded: file_helper
INFO - 2021-04-06 10:30:33 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:30:33 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:30:33 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:30:33 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:33 --> Email Class Initialized
DEBUG - 2021-04-06 10:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:30:33 --> Helper loaded: form_helper
INFO - 2021-04-06 10:30:33 --> Form Validation Class Initialized
INFO - 2021-04-06 10:30:33 --> Controller Class Initialized
INFO - 2021-04-06 10:30:33 --> Model "Common_model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:30:33 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:30:33 --> Database Driver Class Initialized
INFO - 2021-04-06 10:30:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:30:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:30:33 --> Final output sent to browser
DEBUG - 2021-04-06 10:30:33 --> Total execution time: 0.3288
INFO - 2021-04-06 10:31:03 --> Config Class Initialized
INFO - 2021-04-06 10:31:03 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:03 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:03 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:03 --> URI Class Initialized
INFO - 2021-04-06 10:31:03 --> Router Class Initialized
INFO - 2021-04-06 10:31:03 --> Output Class Initialized
INFO - 2021-04-06 10:31:03 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:03 --> Input Class Initialized
INFO - 2021-04-06 10:31:03 --> Language Class Initialized
INFO - 2021-04-06 10:31:03 --> Loader Class Initialized
INFO - 2021-04-06 10:31:03 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:03 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:03 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:03 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:03 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:03 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:03 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:03 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:03 --> Controller Class Initialized
INFO - 2021-04-06 10:31:03 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:03 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:03 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:03 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:03 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:03 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:03 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:03 --> Total execution time: 0.1636
INFO - 2021-04-06 10:31:03 --> Config Class Initialized
INFO - 2021-04-06 10:31:03 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:03 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:03 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:03 --> URI Class Initialized
INFO - 2021-04-06 10:31:03 --> Router Class Initialized
INFO - 2021-04-06 10:31:03 --> Output Class Initialized
INFO - 2021-04-06 10:31:03 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:03 --> Input Class Initialized
INFO - 2021-04-06 10:31:03 --> Language Class Initialized
ERROR - 2021-04-06 10:31:03 --> 404 Page Not Found: Estiaenterprise_rc/DistributorDashboard
INFO - 2021-04-06 10:31:04 --> Config Class Initialized
INFO - 2021-04-06 10:31:04 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:04 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:04 --> URI Class Initialized
INFO - 2021-04-06 10:31:04 --> Router Class Initialized
INFO - 2021-04-06 10:31:04 --> Output Class Initialized
INFO - 2021-04-06 10:31:04 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:04 --> Input Class Initialized
INFO - 2021-04-06 10:31:04 --> Language Class Initialized
INFO - 2021-04-06 10:31:04 --> Loader Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:04 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:04 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:04 --> Controller Class Initialized
INFO - 2021-04-06 10:31:04 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> Config Class Initialized
INFO - 2021-04-06 10:31:04 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:04 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:04 --> URI Class Initialized
INFO - 2021-04-06 10:31:04 --> Router Class Initialized
INFO - 2021-04-06 10:31:04 --> Output Class Initialized
INFO - 2021-04-06 10:31:04 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:04 --> Input Class Initialized
INFO - 2021-04-06 10:31:04 --> Language Class Initialized
INFO - 2021-04-06 10:31:04 --> Loader Class Initialized
INFO - 2021-04-06 10:31:04 --> Config Class Initialized
INFO - 2021-04-06 10:31:04 --> Hooks Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: file_helper
DEBUG - 2021-04-06 10:31:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:04 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:04 --> URI Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:04 --> Router Class Initialized
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> Output Class Initialized
INFO - 2021-04-06 10:31:04 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:04 --> Input Class Initialized
INFO - 2021-04-06 10:31:04 --> Language Class Initialized
INFO - 2021-04-06 10:31:04 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:04 --> Loader Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:31:04 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:04 --> Total execution time: 0.2224
INFO - 2021-04-06 10:31:04 --> Config Class Initialized
INFO - 2021-04-06 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:04 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:04 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:04 --> URI Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:04 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:04 --> Controller Class Initialized
INFO - 2021-04-06 10:31:04 --> Router Class Initialized
INFO - 2021-04-06 10:31:04 --> Output Class Initialized
INFO - 2021-04-06 10:31:04 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:04 --> Input Class Initialized
INFO - 2021-04-06 10:31:04 --> Language Class Initialized
INFO - 2021-04-06 10:31:04 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:04 --> Loader Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> Email Class Initialized
INFO - 2021-04-06 10:31:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:31:04 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:04 --> Total execution time: 0.1724
INFO - 2021-04-06 10:31:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-04-06 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:04 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:04 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:04 --> Controller Class Initialized
INFO - 2021-04-06 10:31:04 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:31:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:31:04 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:04 --> Total execution time: 0.2174
INFO - 2021-04-06 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:04 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:04 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:04 --> Controller Class Initialized
INFO - 2021-04-06 10:31:04 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:04 --> Config Class Initialized
INFO - 2021-04-06 10:31:04 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:04 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:04 --> URI Class Initialized
INFO - 2021-04-06 10:31:04 --> Router Class Initialized
INFO - 2021-04-06 10:31:04 --> Output Class Initialized
INFO - 2021-04-06 10:31:04 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:04 --> Input Class Initialized
INFO - 2021-04-06 10:31:04 --> Language Class Initialized
INFO - 2021-04-06 10:31:04 --> Loader Class Initialized
INFO - 2021-04-06 10:31:04 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:04 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:04 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:04 --> Controller Class Initialized
INFO - 2021-04-06 10:31:04 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:04 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:04 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:04 --> Total execution time: 0.1194
INFO - 2021-04-06 10:31:08 --> Config Class Initialized
INFO - 2021-04-06 10:31:08 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:08 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:08 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:08 --> URI Class Initialized
INFO - 2021-04-06 10:31:08 --> Router Class Initialized
INFO - 2021-04-06 10:31:08 --> Output Class Initialized
INFO - 2021-04-06 10:31:08 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:08 --> Input Class Initialized
INFO - 2021-04-06 10:31:08 --> Language Class Initialized
INFO - 2021-04-06 10:31:08 --> Loader Class Initialized
INFO - 2021-04-06 10:31:08 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:08 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:08 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:08 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:08 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:08 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:08 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:08 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:08 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:08 --> Controller Class Initialized
INFO - 2021-04-06 10:31:08 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:08 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:08 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:08 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:08 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:08 --> Config Class Initialized
INFO - 2021-04-06 10:31:08 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:08 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:08 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:08 --> URI Class Initialized
INFO - 2021-04-06 10:31:08 --> Router Class Initialized
INFO - 2021-04-06 10:31:08 --> Output Class Initialized
INFO - 2021-04-06 10:31:08 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:08 --> Input Class Initialized
INFO - 2021-04-06 10:31:08 --> Language Class Initialized
INFO - 2021-04-06 10:31:08 --> Loader Class Initialized
INFO - 2021-04-06 10:31:08 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:31:08 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:08 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:08 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:08 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:08 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:08 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:08 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:08 --> Total execution time: 0.1316
INFO - 2021-04-06 10:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:08 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:08 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:08 --> Controller Class Initialized
INFO - 2021-04-06 10:31:08 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:08 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:08 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:08 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:08 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:31:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:08 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:08 --> Total execution time: 0.1764
INFO - 2021-04-06 10:31:08 --> Config Class Initialized
INFO - 2021-04-06 10:31:08 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:08 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:08 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:08 --> URI Class Initialized
INFO - 2021-04-06 10:31:08 --> Router Class Initialized
INFO - 2021-04-06 10:31:08 --> Output Class Initialized
INFO - 2021-04-06 10:31:08 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:08 --> Input Class Initialized
INFO - 2021-04-06 10:31:08 --> Language Class Initialized
ERROR - 2021-04-06 10:31:08 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:31:09 --> Config Class Initialized
INFO - 2021-04-06 10:31:09 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:09 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:09 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:09 --> URI Class Initialized
INFO - 2021-04-06 10:31:09 --> Router Class Initialized
INFO - 2021-04-06 10:31:09 --> Output Class Initialized
INFO - 2021-04-06 10:31:09 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:09 --> Input Class Initialized
INFO - 2021-04-06 10:31:09 --> Language Class Initialized
INFO - 2021-04-06 10:31:09 --> Loader Class Initialized
INFO - 2021-04-06 10:31:09 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:09 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:09 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:09 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:09 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:09 --> Controller Class Initialized
INFO - 2021-04-06 10:31:09 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:09 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:09 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:09 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:09 --> Config Class Initialized
INFO - 2021-04-06 10:31:09 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:09 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:09 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:09 --> URI Class Initialized
INFO - 2021-04-06 10:31:09 --> Router Class Initialized
INFO - 2021-04-06 10:31:09 --> Output Class Initialized
INFO - 2021-04-06 10:31:09 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:09 --> Input Class Initialized
INFO - 2021-04-06 10:31:09 --> Language Class Initialized
INFO - 2021-04-06 10:31:09 --> Loader Class Initialized
INFO - 2021-04-06 10:31:09 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:09 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:09 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:09 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:09 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:09 --> Controller Class Initialized
INFO - 2021-04-06 10:31:09 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:09 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:09 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:09 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:09 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:09 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:09 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:09 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:09 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:09 --> Total execution time: 0.0939
INFO - 2021-04-06 10:31:19 --> Config Class Initialized
INFO - 2021-04-06 10:31:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:19 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:19 --> URI Class Initialized
INFO - 2021-04-06 10:31:19 --> Router Class Initialized
INFO - 2021-04-06 10:31:19 --> Output Class Initialized
INFO - 2021-04-06 10:31:19 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:19 --> Input Class Initialized
INFO - 2021-04-06 10:31:19 --> Language Class Initialized
INFO - 2021-04-06 10:31:19 --> Loader Class Initialized
INFO - 2021-04-06 10:31:19 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:19 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:19 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:19 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:19 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:19 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:19 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:19 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:19 --> Controller Class Initialized
INFO - 2021-04-06 10:31:19 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:19 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:19 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:19 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:19 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:31:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:19 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:19 --> Total execution time: 0.3130
INFO - 2021-04-06 10:31:20 --> Config Class Initialized
INFO - 2021-04-06 10:31:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:20 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:20 --> URI Class Initialized
INFO - 2021-04-06 10:31:20 --> Router Class Initialized
INFO - 2021-04-06 10:31:20 --> Output Class Initialized
INFO - 2021-04-06 10:31:20 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:20 --> Input Class Initialized
INFO - 2021-04-06 10:31:20 --> Language Class Initialized
ERROR - 2021-04-06 10:31:20 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:31:20 --> Config Class Initialized
INFO - 2021-04-06 10:31:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:20 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:20 --> URI Class Initialized
INFO - 2021-04-06 10:31:20 --> Router Class Initialized
INFO - 2021-04-06 10:31:20 --> Output Class Initialized
INFO - 2021-04-06 10:31:20 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:20 --> Input Class Initialized
INFO - 2021-04-06 10:31:20 --> Language Class Initialized
INFO - 2021-04-06 10:31:20 --> Loader Class Initialized
INFO - 2021-04-06 10:31:20 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:20 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:20 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:20 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:20 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:20 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:20 --> Controller Class Initialized
INFO - 2021-04-06 10:31:20 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:20 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:20 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:20 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:21 --> Config Class Initialized
INFO - 2021-04-06 10:31:21 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:21 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:21 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:21 --> URI Class Initialized
INFO - 2021-04-06 10:31:21 --> Router Class Initialized
INFO - 2021-04-06 10:31:21 --> Output Class Initialized
INFO - 2021-04-06 10:31:21 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:21 --> Input Class Initialized
INFO - 2021-04-06 10:31:21 --> Language Class Initialized
INFO - 2021-04-06 10:31:21 --> Loader Class Initialized
INFO - 2021-04-06 10:31:21 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:21 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:21 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:21 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:21 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:21 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:21 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:21 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:21 --> Controller Class Initialized
INFO - 2021-04-06 10:31:21 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:21 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:21 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:21 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:21 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:21 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:21 --> Total execution time: 0.1134
INFO - 2021-04-06 10:31:51 --> Config Class Initialized
INFO - 2021-04-06 10:31:51 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:51 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:51 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:51 --> URI Class Initialized
INFO - 2021-04-06 10:31:51 --> Router Class Initialized
INFO - 2021-04-06 10:31:51 --> Output Class Initialized
INFO - 2021-04-06 10:31:51 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:51 --> Input Class Initialized
INFO - 2021-04-06 10:31:51 --> Language Class Initialized
INFO - 2021-04-06 10:31:51 --> Loader Class Initialized
INFO - 2021-04-06 10:31:51 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:51 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:51 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:51 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:51 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:51 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:51 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:51 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:51 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:51 --> Controller Class Initialized
INFO - 2021-04-06 10:31:51 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:51 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:51 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:51 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:51 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:51 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 10:31:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 10:31:51 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:51 --> Total execution time: 0.1025
INFO - 2021-04-06 10:31:52 --> Config Class Initialized
INFO - 2021-04-06 10:31:52 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:52 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:52 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:52 --> URI Class Initialized
INFO - 2021-04-06 10:31:52 --> Router Class Initialized
INFO - 2021-04-06 10:31:52 --> Output Class Initialized
INFO - 2021-04-06 10:31:52 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:52 --> Input Class Initialized
INFO - 2021-04-06 10:31:52 --> Language Class Initialized
ERROR - 2021-04-06 10:31:52 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:31:52 --> Config Class Initialized
INFO - 2021-04-06 10:31:52 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:52 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:52 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:52 --> URI Class Initialized
INFO - 2021-04-06 10:31:52 --> Router Class Initialized
INFO - 2021-04-06 10:31:52 --> Output Class Initialized
INFO - 2021-04-06 10:31:52 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:52 --> Input Class Initialized
INFO - 2021-04-06 10:31:52 --> Language Class Initialized
INFO - 2021-04-06 10:31:52 --> Loader Class Initialized
INFO - 2021-04-06 10:31:52 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:52 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:52 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:52 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:52 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:52 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:52 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:52 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:52 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:52 --> Controller Class Initialized
INFO - 2021-04-06 10:31:52 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:52 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:52 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:52 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:52 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:52 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:52 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:31:52 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:52 --> Total execution time: 0.1355
INFO - 2021-04-06 10:31:53 --> Config Class Initialized
INFO - 2021-04-06 10:31:53 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:53 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:53 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:53 --> URI Class Initialized
INFO - 2021-04-06 10:31:53 --> Router Class Initialized
INFO - 2021-04-06 10:31:53 --> Output Class Initialized
INFO - 2021-04-06 10:31:53 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:53 --> Input Class Initialized
INFO - 2021-04-06 10:31:53 --> Language Class Initialized
INFO - 2021-04-06 10:31:53 --> Loader Class Initialized
INFO - 2021-04-06 10:31:53 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:53 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:53 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:53 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:53 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:53 --> Controller Class Initialized
INFO - 2021-04-06 10:31:53 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:53 --> Config Class Initialized
INFO - 2021-04-06 10:31:53 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:53 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:53 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:53 --> URI Class Initialized
INFO - 2021-04-06 10:31:53 --> Router Class Initialized
INFO - 2021-04-06 10:31:53 --> Output Class Initialized
INFO - 2021-04-06 10:31:53 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:53 --> Input Class Initialized
INFO - 2021-04-06 10:31:53 --> Language Class Initialized
INFO - 2021-04-06 10:31:53 --> Loader Class Initialized
INFO - 2021-04-06 10:31:53 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:53 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:53 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:53 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:53 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:53 --> Controller Class Initialized
INFO - 2021-04-06 10:31:53 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:53 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:53 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:53 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:53 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:53 --> Total execution time: 0.1000
INFO - 2021-04-06 10:31:53 --> Config Class Initialized
INFO - 2021-04-06 10:31:53 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:53 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:53 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:53 --> URI Class Initialized
INFO - 2021-04-06 10:31:53 --> Router Class Initialized
INFO - 2021-04-06 10:31:53 --> Output Class Initialized
INFO - 2021-04-06 10:31:53 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:53 --> Input Class Initialized
INFO - 2021-04-06 10:31:53 --> Language Class Initialized
INFO - 2021-04-06 10:31:53 --> Loader Class Initialized
INFO - 2021-04-06 10:31:53 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:53 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:53 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:53 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:53 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:53 --> Controller Class Initialized
INFO - 2021-04-06 10:31:53 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:53 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:53 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:31:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:31:53 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:31:53 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:53 --> Total execution time: 0.0450
INFO - 2021-04-06 10:31:54 --> Config Class Initialized
INFO - 2021-04-06 10:31:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:54 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:54 --> URI Class Initialized
INFO - 2021-04-06 10:31:54 --> Router Class Initialized
INFO - 2021-04-06 10:31:54 --> Output Class Initialized
INFO - 2021-04-06 10:31:54 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:54 --> Input Class Initialized
INFO - 2021-04-06 10:31:54 --> Language Class Initialized
INFO - 2021-04-06 10:31:54 --> Loader Class Initialized
INFO - 2021-04-06 10:31:54 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:54 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:54 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:54 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:54 --> Controller Class Initialized
INFO - 2021-04-06 10:31:54 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:31:54 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:54 --> Total execution time: 0.0531
INFO - 2021-04-06 10:31:54 --> Config Class Initialized
INFO - 2021-04-06 10:31:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:54 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:54 --> URI Class Initialized
INFO - 2021-04-06 10:31:54 --> Router Class Initialized
INFO - 2021-04-06 10:31:54 --> Output Class Initialized
INFO - 2021-04-06 10:31:54 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:54 --> Input Class Initialized
INFO - 2021-04-06 10:31:54 --> Language Class Initialized
INFO - 2021-04-06 10:31:54 --> Loader Class Initialized
INFO - 2021-04-06 10:31:54 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:54 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:54 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:54 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:54 --> Controller Class Initialized
INFO - 2021-04-06 10:31:54 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:54 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:54 --> Total execution time: 0.1012
INFO - 2021-04-06 10:31:54 --> Config Class Initialized
INFO - 2021-04-06 10:31:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:54 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:54 --> URI Class Initialized
INFO - 2021-04-06 10:31:54 --> Router Class Initialized
INFO - 2021-04-06 10:31:54 --> Output Class Initialized
INFO - 2021-04-06 10:31:54 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:54 --> Input Class Initialized
INFO - 2021-04-06 10:31:54 --> Language Class Initialized
ERROR - 2021-04-06 10:31:54 --> 404 Page Not Found: Estiaenterprise_rc/DistributorDashboard
INFO - 2021-04-06 10:31:54 --> Config Class Initialized
INFO - 2021-04-06 10:31:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:54 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:54 --> URI Class Initialized
INFO - 2021-04-06 10:31:54 --> Router Class Initialized
INFO - 2021-04-06 10:31:54 --> Config Class Initialized
INFO - 2021-04-06 10:31:54 --> Hooks Class Initialized
INFO - 2021-04-06 10:31:54 --> Output Class Initialized
INFO - 2021-04-06 10:31:54 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:54 --> Utf8 Class Initialized
DEBUG - 2021-04-06 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:54 --> Input Class Initialized
INFO - 2021-04-06 10:31:54 --> URI Class Initialized
INFO - 2021-04-06 10:31:54 --> Language Class Initialized
INFO - 2021-04-06 10:31:54 --> Router Class Initialized
INFO - 2021-04-06 10:31:54 --> Loader Class Initialized
INFO - 2021-04-06 10:31:54 --> Output Class Initialized
INFO - 2021-04-06 10:31:54 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:54 --> Security Class Initialized
INFO - 2021-04-06 10:31:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: unit_helper
DEBUG - 2021-04-06 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:54 --> Input Class Initialized
INFO - 2021-04-06 10:31:54 --> Language Class Initialized
INFO - 2021-04-06 10:31:54 --> Loader Class Initialized
INFO - 2021-04-06 10:31:54 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:54 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:54 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:54 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:54 --> Controller Class Initialized
INFO - 2021-04-06 10:31:54 --> Email Class Initialized
INFO - 2021-04-06 10:31:54 --> Model "Common_model" initialized
DEBUG - 2021-04-06 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:31:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:31:54 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:54 --> Total execution time: 0.0474
INFO - 2021-04-06 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:54 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:54 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:54 --> Controller Class Initialized
INFO - 2021-04-06 10:31:54 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:54 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:31:54 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:54 --> Total execution time: 0.0582
INFO - 2021-04-06 10:31:55 --> Config Class Initialized
INFO - 2021-04-06 10:31:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:55 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:55 --> URI Class Initialized
INFO - 2021-04-06 10:31:55 --> Router Class Initialized
INFO - 2021-04-06 10:31:55 --> Output Class Initialized
INFO - 2021-04-06 10:31:55 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:55 --> Input Class Initialized
INFO - 2021-04-06 10:31:55 --> Language Class Initialized
INFO - 2021-04-06 10:31:55 --> Loader Class Initialized
INFO - 2021-04-06 10:31:55 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:55 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:55 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:55 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:55 --> Controller Class Initialized
INFO - 2021-04-06 10:31:55 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:55 --> Config Class Initialized
INFO - 2021-04-06 10:31:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:55 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:55 --> URI Class Initialized
INFO - 2021-04-06 10:31:55 --> Router Class Initialized
INFO - 2021-04-06 10:31:55 --> Output Class Initialized
INFO - 2021-04-06 10:31:55 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:55 --> Input Class Initialized
INFO - 2021-04-06 10:31:55 --> Language Class Initialized
INFO - 2021-04-06 10:31:55 --> Loader Class Initialized
INFO - 2021-04-06 10:31:55 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:55 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:55 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:55 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:55 --> Controller Class Initialized
INFO - 2021-04-06 10:31:55 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:55 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:55 --> Total execution time: 0.0753
INFO - 2021-04-06 10:31:55 --> Config Class Initialized
INFO - 2021-04-06 10:31:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:55 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:55 --> URI Class Initialized
INFO - 2021-04-06 10:31:55 --> Router Class Initialized
INFO - 2021-04-06 10:31:55 --> Output Class Initialized
INFO - 2021-04-06 10:31:55 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:55 --> Input Class Initialized
INFO - 2021-04-06 10:31:55 --> Language Class Initialized
INFO - 2021-04-06 10:31:55 --> Loader Class Initialized
INFO - 2021-04-06 10:31:55 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:55 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:55 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:55 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:55 --> Controller Class Initialized
INFO - 2021-04-06 10:31:55 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:55 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:31:55 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:55 --> Total execution time: 0.1354
INFO - 2021-04-06 10:31:56 --> Config Class Initialized
INFO - 2021-04-06 10:31:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:56 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:56 --> URI Class Initialized
INFO - 2021-04-06 10:31:56 --> Router Class Initialized
INFO - 2021-04-06 10:31:56 --> Output Class Initialized
INFO - 2021-04-06 10:31:56 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:56 --> Input Class Initialized
INFO - 2021-04-06 10:31:56 --> Language Class Initialized
INFO - 2021-04-06 10:31:56 --> Loader Class Initialized
INFO - 2021-04-06 10:31:56 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:56 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:56 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:56 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:56 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:56 --> Controller Class Initialized
INFO - 2021-04-06 10:31:56 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:56 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/sales/saleInvoice/saleList.php
INFO - 2021-04-06 10:31:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:56 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:56 --> Total execution time: 0.0938
INFO - 2021-04-06 10:31:57 --> Config Class Initialized
INFO - 2021-04-06 10:31:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:57 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:57 --> URI Class Initialized
INFO - 2021-04-06 10:31:57 --> Router Class Initialized
INFO - 2021-04-06 10:31:57 --> Output Class Initialized
INFO - 2021-04-06 10:31:57 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:57 --> Input Class Initialized
INFO - 2021-04-06 10:31:57 --> Language Class Initialized
ERROR - 2021-04-06 10:31:57 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:31:57 --> Config Class Initialized
INFO - 2021-04-06 10:31:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:57 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:57 --> URI Class Initialized
INFO - 2021-04-06 10:31:57 --> Router Class Initialized
INFO - 2021-04-06 10:31:57 --> Output Class Initialized
INFO - 2021-04-06 10:31:57 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:57 --> Input Class Initialized
INFO - 2021-04-06 10:31:57 --> Language Class Initialized
INFO - 2021-04-06 10:31:57 --> Loader Class Initialized
INFO - 2021-04-06 10:31:57 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:57 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:57 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:57 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:57 --> Controller Class Initialized
INFO - 2021-04-06 10:31:57 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:57 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:31:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:57 --> Config Class Initialized
INFO - 2021-04-06 10:31:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:57 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:57 --> URI Class Initialized
INFO - 2021-04-06 10:31:57 --> Router Class Initialized
INFO - 2021-04-06 10:31:57 --> Output Class Initialized
INFO - 2021-04-06 10:31:57 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:57 --> Input Class Initialized
INFO - 2021-04-06 10:31:57 --> Language Class Initialized
INFO - 2021-04-06 10:31:57 --> Loader Class Initialized
INFO - 2021-04-06 10:31:57 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:57 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:57 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:58 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:58 --> Total execution time: 0.6177
INFO - 2021-04-06 10:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:58 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:58 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:58 --> Controller Class Initialized
INFO - 2021-04-06 10:31:58 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:58 --> Config Class Initialized
INFO - 2021-04-06 10:31:58 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:31:58 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:31:58 --> Utf8 Class Initialized
INFO - 2021-04-06 10:31:58 --> URI Class Initialized
INFO - 2021-04-06 10:31:58 --> Router Class Initialized
INFO - 2021-04-06 10:31:58 --> Output Class Initialized
INFO - 2021-04-06 10:31:58 --> Security Class Initialized
DEBUG - 2021-04-06 10:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:31:58 --> Input Class Initialized
INFO - 2021-04-06 10:31:58 --> Language Class Initialized
INFO - 2021-04-06 10:31:58 --> Loader Class Initialized
INFO - 2021-04-06 10:31:58 --> Helper loaded: url_helper
INFO - 2021-04-06 10:31:58 --> Helper loaded: file_helper
INFO - 2021-04-06 10:31:58 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:31:58 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:31:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:31:58 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:58 --> Email Class Initialized
DEBUG - 2021-04-06 10:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:31:58 --> Helper loaded: form_helper
INFO - 2021-04-06 10:31:58 --> Form Validation Class Initialized
INFO - 2021-04-06 10:31:58 --> Controller Class Initialized
INFO - 2021-04-06 10:31:58 --> Model "Common_model" initialized
INFO - 2021-04-06 10:31:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:31:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:31:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:31:58 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:31:58 --> Database Driver Class Initialized
INFO - 2021-04-06 10:31:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:31:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:31:58 --> Final output sent to browser
DEBUG - 2021-04-06 10:31:58 --> Total execution time: 0.0821
INFO - 2021-04-06 10:32:00 --> Config Class Initialized
INFO - 2021-04-06 10:32:00 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:00 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:00 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:00 --> URI Class Initialized
INFO - 2021-04-06 10:32:00 --> Router Class Initialized
INFO - 2021-04-06 10:32:00 --> Output Class Initialized
INFO - 2021-04-06 10:32:00 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:00 --> Input Class Initialized
INFO - 2021-04-06 10:32:00 --> Language Class Initialized
INFO - 2021-04-06 10:32:00 --> Loader Class Initialized
INFO - 2021-04-06 10:32:00 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:00 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:00 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:00 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:01 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:01 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:01 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:01 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:01 --> Controller Class Initialized
INFO - 2021-04-06 10:32:01 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:01 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:01 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:01 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:01 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:32:01 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:01 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:01 --> Total execution time: 0.1622
INFO - 2021-04-06 10:32:01 --> Config Class Initialized
INFO - 2021-04-06 10:32:01 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:01 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:01 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:01 --> URI Class Initialized
INFO - 2021-04-06 10:32:01 --> Router Class Initialized
INFO - 2021-04-06 10:32:01 --> Output Class Initialized
INFO - 2021-04-06 10:32:01 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:01 --> Input Class Initialized
INFO - 2021-04-06 10:32:01 --> Language Class Initialized
INFO - 2021-04-06 10:32:01 --> Loader Class Initialized
INFO - 2021-04-06 10:32:01 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:01 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:01 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:01 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:01 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:01 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:01 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:01 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:01 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:01 --> Controller Class Initialized
INFO - 2021-04-06 10:32:01 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:01 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:01 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:01 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:01 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:32:01 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:01 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:01 --> Total execution time: 0.2595
INFO - 2021-04-06 10:32:02 --> Config Class Initialized
INFO - 2021-04-06 10:32:02 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:02 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:02 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:02 --> URI Class Initialized
INFO - 2021-04-06 10:32:02 --> Router Class Initialized
INFO - 2021-04-06 10:32:02 --> Output Class Initialized
INFO - 2021-04-06 10:32:02 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:02 --> Input Class Initialized
INFO - 2021-04-06 10:32:02 --> Language Class Initialized
INFO - 2021-04-06 10:32:02 --> Loader Class Initialized
INFO - 2021-04-06 10:32:02 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:02 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:02 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:02 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:02 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:02 --> Controller Class Initialized
INFO - 2021-04-06 10:32:02 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:02 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:02 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:02 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:02 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:32:02 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:02 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:02 --> Total execution time: 0.1541
INFO - 2021-04-06 10:32:02 --> Config Class Initialized
INFO - 2021-04-06 10:32:02 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:02 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:02 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:02 --> URI Class Initialized
INFO - 2021-04-06 10:32:02 --> Router Class Initialized
INFO - 2021-04-06 10:32:02 --> Output Class Initialized
INFO - 2021-04-06 10:32:02 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:02 --> Input Class Initialized
INFO - 2021-04-06 10:32:02 --> Language Class Initialized
INFO - 2021-04-06 10:32:02 --> Loader Class Initialized
INFO - 2021-04-06 10:32:02 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:02 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:02 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:02 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:02 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:02 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:02 --> Controller Class Initialized
INFO - 2021-04-06 10:32:02 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:02 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:02 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:02 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:02 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:32:02 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:02 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:02 --> Total execution time: 0.1853
INFO - 2021-04-06 10:32:03 --> Config Class Initialized
INFO - 2021-04-06 10:32:03 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:03 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:03 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:03 --> URI Class Initialized
INFO - 2021-04-06 10:32:03 --> Router Class Initialized
INFO - 2021-04-06 10:32:03 --> Output Class Initialized
INFO - 2021-04-06 10:32:03 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:03 --> Input Class Initialized
INFO - 2021-04-06 10:32:03 --> Language Class Initialized
INFO - 2021-04-06 10:32:03 --> Loader Class Initialized
INFO - 2021-04-06 10:32:03 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:03 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:03 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:03 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:03 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:03 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:03 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:03 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:03 --> Controller Class Initialized
INFO - 2021-04-06 10:32:03 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:03 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:03 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:03 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:03 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:32:03 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:03 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:03 --> Total execution time: 0.1570
INFO - 2021-04-06 10:32:09 --> Config Class Initialized
INFO - 2021-04-06 10:32:09 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:09 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:09 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:09 --> URI Class Initialized
INFO - 2021-04-06 10:32:09 --> Router Class Initialized
INFO - 2021-04-06 10:32:09 --> Output Class Initialized
INFO - 2021-04-06 10:32:09 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:09 --> Input Class Initialized
INFO - 2021-04-06 10:32:09 --> Language Class Initialized
INFO - 2021-04-06 10:32:09 --> Loader Class Initialized
INFO - 2021-04-06 10:32:09 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:09 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:09 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:09 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:09 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:09 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:09 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:09 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:09 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:09 --> Controller Class Initialized
INFO - 2021-04-06 10:32:09 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:09 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:09 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:09 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:09 --> Model "ServerFilterModel" initialized
INFO - 2021-04-06 10:32:09 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:11 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:11 --> Total execution time: 1.6982
INFO - 2021-04-06 10:32:21 --> Config Class Initialized
INFO - 2021-04-06 10:32:21 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:21 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:21 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:21 --> URI Class Initialized
INFO - 2021-04-06 10:32:21 --> Router Class Initialized
INFO - 2021-04-06 10:32:21 --> Output Class Initialized
INFO - 2021-04-06 10:32:21 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:21 --> Input Class Initialized
INFO - 2021-04-06 10:32:21 --> Language Class Initialized
INFO - 2021-04-06 10:32:21 --> Loader Class Initialized
INFO - 2021-04-06 10:32:21 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:21 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:21 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:21 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:21 --> Controller Class Initialized
INFO - 2021-04-06 10:32:21 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/sales/saleInvoice/editInvoice.php
INFO - 2021-04-06 10:32:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:21 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:21 --> Total execution time: 0.2278
INFO - 2021-04-06 10:32:21 --> Config Class Initialized
INFO - 2021-04-06 10:32:21 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:21 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:21 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:21 --> URI Class Initialized
INFO - 2021-04-06 10:32:21 --> Router Class Initialized
INFO - 2021-04-06 10:32:21 --> Output Class Initialized
INFO - 2021-04-06 10:32:21 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:21 --> Input Class Initialized
INFO - 2021-04-06 10:32:21 --> Language Class Initialized
ERROR - 2021-04-06 10:32:21 --> 404 Page Not Found: Estiaenterprise_rc/salesInvoice_edit
INFO - 2021-04-06 10:32:21 --> Config Class Initialized
INFO - 2021-04-06 10:32:21 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:21 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:21 --> Config Class Initialized
INFO - 2021-04-06 10:32:21 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:21 --> Hooks Class Initialized
INFO - 2021-04-06 10:32:21 --> URI Class Initialized
DEBUG - 2021-04-06 10:32:21 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:21 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:21 --> URI Class Initialized
INFO - 2021-04-06 10:32:21 --> Router Class Initialized
INFO - 2021-04-06 10:32:21 --> Output Class Initialized
INFO - 2021-04-06 10:32:21 --> Router Class Initialized
INFO - 2021-04-06 10:32:21 --> Security Class Initialized
INFO - 2021-04-06 10:32:21 --> Output Class Initialized
DEBUG - 2021-04-06 10:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:21 --> Input Class Initialized
INFO - 2021-04-06 10:32:21 --> Language Class Initialized
INFO - 2021-04-06 10:32:21 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:21 --> Input Class Initialized
INFO - 2021-04-06 10:32:21 --> Language Class Initialized
INFO - 2021-04-06 10:32:21 --> Loader Class Initialized
INFO - 2021-04-06 10:32:21 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:21 --> Loader Class Initialized
INFO - 2021-04-06 10:32:21 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:21 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:21 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:21 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:21 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:21 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:21 --> Controller Class Initialized
INFO - 2021-04-06 10:32:21 --> Email Class Initialized
INFO - 2021-04-06 10:32:21 --> Model "Common_model" initialized
DEBUG - 2021-04-06 10:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:21 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:21 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:21 --> Total execution time: 0.0473
INFO - 2021-04-06 10:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:21 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:21 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:21 --> Controller Class Initialized
INFO - 2021-04-06 10:32:21 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:21 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:21 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/loadCusSup.php
INFO - 2021-04-06 10:32:21 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:21 --> Total execution time: 0.0624
INFO - 2021-04-06 10:32:22 --> Config Class Initialized
INFO - 2021-04-06 10:32:22 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:22 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:22 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:22 --> URI Class Initialized
INFO - 2021-04-06 10:32:22 --> Router Class Initialized
INFO - 2021-04-06 10:32:22 --> Output Class Initialized
INFO - 2021-04-06 10:32:22 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:22 --> Input Class Initialized
INFO - 2021-04-06 10:32:22 --> Language Class Initialized
INFO - 2021-04-06 10:32:22 --> Loader Class Initialized
INFO - 2021-04-06 10:32:22 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:22 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:22 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:22 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:22 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:22 --> Controller Class Initialized
INFO - 2021-04-06 10:32:22 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:22 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:22 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:22 --> Total execution time: 0.0513
INFO - 2021-04-06 10:32:22 --> Config Class Initialized
INFO - 2021-04-06 10:32:22 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:22 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:22 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:22 --> URI Class Initialized
INFO - 2021-04-06 10:32:22 --> Router Class Initialized
INFO - 2021-04-06 10:32:22 --> Output Class Initialized
INFO - 2021-04-06 10:32:22 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:22 --> Input Class Initialized
INFO - 2021-04-06 10:32:22 --> Language Class Initialized
INFO - 2021-04-06 10:32:22 --> Loader Class Initialized
INFO - 2021-04-06 10:32:22 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:22 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:22 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:22 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:22 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:22 --> Controller Class Initialized
INFO - 2021-04-06 10:32:22 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:22 --> Config Class Initialized
INFO - 2021-04-06 10:32:22 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:22 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:22 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:22 --> URI Class Initialized
INFO - 2021-04-06 10:32:22 --> Router Class Initialized
INFO - 2021-04-06 10:32:22 --> Output Class Initialized
INFO - 2021-04-06 10:32:22 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:22 --> Input Class Initialized
INFO - 2021-04-06 10:32:22 --> Language Class Initialized
INFO - 2021-04-06 10:32:22 --> Loader Class Initialized
INFO - 2021-04-06 10:32:22 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:22 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:22 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:22 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:22 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:22 --> Controller Class Initialized
INFO - 2021-04-06 10:32:22 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:22 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:22 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:32:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:22 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:22 --> Total execution time: 0.0781
INFO - 2021-04-06 10:32:31 --> Config Class Initialized
INFO - 2021-04-06 10:32:31 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:31 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:31 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:31 --> URI Class Initialized
INFO - 2021-04-06 10:32:31 --> Router Class Initialized
INFO - 2021-04-06 10:32:31 --> Output Class Initialized
INFO - 2021-04-06 10:32:31 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:31 --> Input Class Initialized
INFO - 2021-04-06 10:32:31 --> Language Class Initialized
INFO - 2021-04-06 10:32:31 --> Loader Class Initialized
INFO - 2021-04-06 10:32:31 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:31 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:31 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:31 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:31 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:31 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:31 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:31 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:31 --> Controller Class Initialized
INFO - 2021-04-06 10:32:31 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:31 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:31 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:31 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:31 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:31 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:31 --> Total execution time: 0.0520
INFO - 2021-04-06 10:32:32 --> Config Class Initialized
INFO - 2021-04-06 10:32:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:32 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:32 --> URI Class Initialized
INFO - 2021-04-06 10:32:32 --> Router Class Initialized
INFO - 2021-04-06 10:32:32 --> Output Class Initialized
INFO - 2021-04-06 10:32:32 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:32 --> Input Class Initialized
INFO - 2021-04-06 10:32:32 --> Language Class Initialized
INFO - 2021-04-06 10:32:32 --> Loader Class Initialized
INFO - 2021-04-06 10:32:32 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:32 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:32 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:32 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:32 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:32 --> Controller Class Initialized
INFO - 2021-04-06 10:32:32 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:32 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:32 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:32 --> Total execution time: 0.0461
INFO - 2021-04-06 10:32:41 --> Config Class Initialized
INFO - 2021-04-06 10:32:41 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:41 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:41 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:41 --> URI Class Initialized
INFO - 2021-04-06 10:32:41 --> Router Class Initialized
INFO - 2021-04-06 10:32:41 --> Output Class Initialized
INFO - 2021-04-06 10:32:41 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:41 --> Input Class Initialized
INFO - 2021-04-06 10:32:41 --> Language Class Initialized
INFO - 2021-04-06 10:32:41 --> Loader Class Initialized
INFO - 2021-04-06 10:32:41 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:41 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:41 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:41 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:41 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:41 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:41 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:41 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:41 --> Controller Class Initialized
INFO - 2021-04-06 10:32:41 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:41 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:41 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:41 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:41 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-06 10:32:41 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/aelbfopi/amarcement.com/application/controllers/SalesController.php 1379
INFO - 2021-04-06 10:32:42 --> Config Class Initialized
INFO - 2021-04-06 10:32:42 --> Config Class Initialized
INFO - 2021-04-06 10:32:42 --> Hooks Class Initialized
INFO - 2021-04-06 10:32:42 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 10:32:42 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:42 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:42 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:42 --> URI Class Initialized
INFO - 2021-04-06 10:32:42 --> URI Class Initialized
INFO - 2021-04-06 10:32:42 --> Router Class Initialized
INFO - 2021-04-06 10:32:42 --> Router Class Initialized
INFO - 2021-04-06 10:32:42 --> Output Class Initialized
INFO - 2021-04-06 10:32:42 --> Output Class Initialized
INFO - 2021-04-06 10:32:42 --> Security Class Initialized
INFO - 2021-04-06 10:32:42 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:42 --> Input Class Initialized
DEBUG - 2021-04-06 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:42 --> Input Class Initialized
INFO - 2021-04-06 10:32:42 --> Language Class Initialized
INFO - 2021-04-06 10:32:42 --> Language Class Initialized
INFO - 2021-04-06 10:32:42 --> Loader Class Initialized
INFO - 2021-04-06 10:32:42 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:42 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:42 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:42 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:42 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:42 --> Loader Class Initialized
INFO - 2021-04-06 10:32:42 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:42 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:42 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:42 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:42 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:42 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:42 --> Email Class Initialized
INFO - 2021-04-06 10:32:42 --> Database Driver Class Initialized
DEBUG - 2021-04-06 10:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:42 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:42 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:42 --> Email Class Initialized
INFO - 2021-04-06 10:32:42 --> Controller Class Initialized
DEBUG - 2021-04-06 10:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:42 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:42 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:42 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:42 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:42 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:42 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:42 --> Controller Class Initialized
INFO - 2021-04-06 10:32:42 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:42 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:42 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:42 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:42 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:42 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/sales/saleInvoice/salesNewFormate.php
INFO - 2021-04-06 10:32:42 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:42 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:42 --> Total execution time: 0.0990
INFO - 2021-04-06 10:32:43 --> Config Class Initialized
INFO - 2021-04-06 10:32:43 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:43 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:43 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:43 --> URI Class Initialized
INFO - 2021-04-06 10:32:43 --> Router Class Initialized
INFO - 2021-04-06 10:32:43 --> Output Class Initialized
INFO - 2021-04-06 10:32:43 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:43 --> Input Class Initialized
INFO - 2021-04-06 10:32:43 --> Language Class Initialized
INFO - 2021-04-06 10:32:43 --> Loader Class Initialized
INFO - 2021-04-06 10:32:43 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:43 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:43 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:43 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:43 --> Controller Class Initialized
INFO - 2021-04-06 10:32:43 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:43 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:43 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:43 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:43 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:43 --> Config Class Initialized
INFO - 2021-04-06 10:32:43 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:43 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:43 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:43 --> URI Class Initialized
INFO - 2021-04-06 10:32:43 --> Router Class Initialized
INFO - 2021-04-06 10:32:43 --> Output Class Initialized
INFO - 2021-04-06 10:32:43 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:43 --> Input Class Initialized
INFO - 2021-04-06 10:32:43 --> Language Class Initialized
ERROR - 2021-04-06 10:32:43 --> 404 Page Not Found: Estiaenterprise_rc/salesInvoice_view
INFO - 2021-04-06 10:32:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:32:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:43 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:43 --> Total execution time: 0.4382
INFO - 2021-04-06 10:32:43 --> Config Class Initialized
INFO - 2021-04-06 10:32:43 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:43 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:43 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:43 --> URI Class Initialized
INFO - 2021-04-06 10:32:43 --> Router Class Initialized
INFO - 2021-04-06 10:32:43 --> Output Class Initialized
INFO - 2021-04-06 10:32:43 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:43 --> Input Class Initialized
INFO - 2021-04-06 10:32:43 --> Language Class Initialized
INFO - 2021-04-06 10:32:43 --> Loader Class Initialized
INFO - 2021-04-06 10:32:43 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:43 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:43 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:43 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:43 --> Controller Class Initialized
INFO - 2021-04-06 10:32:43 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:43 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:43 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:43 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:43 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:43 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:43 --> Total execution time: 0.0858
INFO - 2021-04-06 10:32:45 --> Config Class Initialized
INFO - 2021-04-06 10:32:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:45 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:45 --> URI Class Initialized
INFO - 2021-04-06 10:32:45 --> Router Class Initialized
INFO - 2021-04-06 10:32:45 --> Output Class Initialized
INFO - 2021-04-06 10:32:45 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:45 --> Input Class Initialized
INFO - 2021-04-06 10:32:45 --> Language Class Initialized
INFO - 2021-04-06 10:32:45 --> Loader Class Initialized
INFO - 2021-04-06 10:32:45 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:45 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:45 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:45 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:45 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:45 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:45 --> Controller Class Initialized
INFO - 2021-04-06 10:32:45 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:45 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:45 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 10:32:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 10:32:46 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:46 --> Total execution time: 1.1861
INFO - 2021-04-06 10:32:47 --> Config Class Initialized
INFO - 2021-04-06 10:32:47 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:47 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:47 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:47 --> URI Class Initialized
INFO - 2021-04-06 10:32:47 --> Router Class Initialized
INFO - 2021-04-06 10:32:47 --> Output Class Initialized
INFO - 2021-04-06 10:32:47 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:47 --> Input Class Initialized
INFO - 2021-04-06 10:32:47 --> Language Class Initialized
ERROR - 2021-04-06 10:32:47 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:32:47 --> Config Class Initialized
INFO - 2021-04-06 10:32:47 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:47 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:47 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:47 --> URI Class Initialized
INFO - 2021-04-06 10:32:47 --> Router Class Initialized
INFO - 2021-04-06 10:32:47 --> Output Class Initialized
INFO - 2021-04-06 10:32:47 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:47 --> Input Class Initialized
INFO - 2021-04-06 10:32:47 --> Language Class Initialized
INFO - 2021-04-06 10:32:47 --> Loader Class Initialized
INFO - 2021-04-06 10:32:47 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:47 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:47 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:47 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:47 --> Controller Class Initialized
INFO - 2021-04-06 10:32:47 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:47 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:47 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:47 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:47 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:47 --> Config Class Initialized
INFO - 2021-04-06 10:32:47 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:47 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:47 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:47 --> URI Class Initialized
INFO - 2021-04-06 10:32:47 --> Router Class Initialized
INFO - 2021-04-06 10:32:47 --> Output Class Initialized
INFO - 2021-04-06 10:32:47 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:47 --> Input Class Initialized
INFO - 2021-04-06 10:32:47 --> Language Class Initialized
INFO - 2021-04-06 10:32:47 --> Loader Class Initialized
INFO - 2021-04-06 10:32:47 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:47 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:48 --> Config Class Initialized
INFO - 2021-04-06 10:32:48 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:48 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:48 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:48 --> URI Class Initialized
INFO - 2021-04-06 10:32:48 --> Router Class Initialized
INFO - 2021-04-06 10:32:48 --> Output Class Initialized
INFO - 2021-04-06 10:32:48 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:48 --> Input Class Initialized
INFO - 2021-04-06 10:32:48 --> Language Class Initialized
INFO - 2021-04-06 10:32:48 --> Loader Class Initialized
INFO - 2021-04-06 10:32:48 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:48 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:48 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:48 --> Config Class Initialized
INFO - 2021-04-06 10:32:48 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:48 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:48 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:48 --> URI Class Initialized
INFO - 2021-04-06 10:32:48 --> Router Class Initialized
INFO - 2021-04-06 10:32:48 --> Output Class Initialized
INFO - 2021-04-06 10:32:48 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:48 --> Input Class Initialized
INFO - 2021-04-06 10:32:48 --> Language Class Initialized
INFO - 2021-04-06 10:32:48 --> Loader Class Initialized
INFO - 2021-04-06 10:32:48 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:48 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:48 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:48 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:32:49 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:49 --> Total execution time: 1.9485
INFO - 2021-04-06 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:49 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:49 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:49 --> Controller Class Initialized
INFO - 2021-04-06 10:32:49 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:49 --> Database Driver Class Initialized
ERROR - 2021-04-06 10:32:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:32:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:32:49 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:49 --> Total execution time: 1.8664
INFO - 2021-04-06 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:49 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:49 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:49 --> Controller Class Initialized
INFO - 2021-04-06 10:32:49 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:49 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:32:49 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:49 --> Total execution time: 0.6264
INFO - 2021-04-06 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:49 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:49 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:49 --> Controller Class Initialized
INFO - 2021-04-06 10:32:49 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:49 --> Config Class Initialized
INFO - 2021-04-06 10:32:49 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:49 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:49 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:49 --> URI Class Initialized
INFO - 2021-04-06 10:32:49 --> Router Class Initialized
INFO - 2021-04-06 10:32:49 --> Output Class Initialized
INFO - 2021-04-06 10:32:49 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:49 --> Input Class Initialized
INFO - 2021-04-06 10:32:49 --> Language Class Initialized
INFO - 2021-04-06 10:32:49 --> Loader Class Initialized
INFO - 2021-04-06 10:32:49 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:49 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:49 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:49 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:49 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:49 --> Controller Class Initialized
INFO - 2021-04-06 10:32:49 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:49 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:32:49 --> Config Class Initialized
INFO - 2021-04-06 10:32:49 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:49 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:49 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:49 --> URI Class Initialized
INFO - 2021-04-06 10:32:49 --> Router Class Initialized
INFO - 2021-04-06 10:32:49 --> Output Class Initialized
INFO - 2021-04-06 10:32:49 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:49 --> Input Class Initialized
INFO - 2021-04-06 10:32:49 --> Language Class Initialized
INFO - 2021-04-06 10:32:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:49 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:49 --> Total execution time: 0.0832
INFO - 2021-04-06 10:32:49 --> Loader Class Initialized
INFO - 2021-04-06 10:32:49 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:49 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:49 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:49 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:49 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:49 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:49 --> Controller Class Initialized
INFO - 2021-04-06 10:32:49 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:49 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:49 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:32:49 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:49 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:49 --> Total execution time: 0.0839
INFO - 2021-04-06 10:32:50 --> Config Class Initialized
INFO - 2021-04-06 10:32:50 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:50 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:50 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:50 --> URI Class Initialized
INFO - 2021-04-06 10:32:50 --> Router Class Initialized
INFO - 2021-04-06 10:32:50 --> Output Class Initialized
INFO - 2021-04-06 10:32:50 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:50 --> Input Class Initialized
INFO - 2021-04-06 10:32:50 --> Language Class Initialized
ERROR - 2021-04-06 10:32:50 --> 404 Page Not Found: Estiaenterprise_rc/DistributorDashboard
INFO - 2021-04-06 10:32:50 --> Config Class Initialized
INFO - 2021-04-06 10:32:50 --> Config Class Initialized
INFO - 2021-04-06 10:32:50 --> Hooks Class Initialized
INFO - 2021-04-06 10:32:50 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 10:32:50 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:50 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:50 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:50 --> URI Class Initialized
INFO - 2021-04-06 10:32:50 --> URI Class Initialized
INFO - 2021-04-06 10:32:50 --> Router Class Initialized
INFO - 2021-04-06 10:32:50 --> Router Class Initialized
INFO - 2021-04-06 10:32:50 --> Output Class Initialized
INFO - 2021-04-06 10:32:50 --> Output Class Initialized
INFO - 2021-04-06 10:32:50 --> Security Class Initialized
INFO - 2021-04-06 10:32:50 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:50 --> Input Class Initialized
INFO - 2021-04-06 10:32:50 --> Language Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:50 --> Input Class Initialized
INFO - 2021-04-06 10:32:50 --> Language Class Initialized
INFO - 2021-04-06 10:32:50 --> Loader Class Initialized
INFO - 2021-04-06 10:32:50 --> Loader Class Initialized
INFO - 2021-04-06 10:32:50 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:50 --> Config Class Initialized
INFO - 2021-04-06 10:32:50 --> Hooks Class Initialized
INFO - 2021-04-06 10:32:50 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: file_helper
DEBUG - 2021-04-06 10:32:50 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:50 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:50 --> URI Class Initialized
INFO - 2021-04-06 10:32:50 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:50 --> Router Class Initialized
INFO - 2021-04-06 10:32:50 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:50 --> Output Class Initialized
INFO - 2021-04-06 10:32:50 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:50 --> Input Class Initialized
INFO - 2021-04-06 10:32:50 --> Language Class Initialized
INFO - 2021-04-06 10:32:50 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:50 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:50 --> Loader Class Initialized
INFO - 2021-04-06 10:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:50 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:50 --> Email Class Initialized
INFO - 2021-04-06 10:32:50 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:50 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:50 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:50 --> Controller Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:50 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:50 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:50 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:50 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:50 --> Email Class Initialized
INFO - 2021-04-06 10:32:50 --> Database Driver Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-04-06 10:32:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 10:32:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 10:32:50 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:50 --> Total execution time: 0.0482
INFO - 2021-04-06 10:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:50 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:50 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:50 --> Controller Class Initialized
INFO - 2021-04-06 10:32:50 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:50 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 10:32:50 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:50 --> Total execution time: 0.0647
INFO - 2021-04-06 10:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:50 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:50 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:50 --> Controller Class Initialized
INFO - 2021-04-06 10:32:50 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:50 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 10:32:50 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:50 --> Total execution time: 0.1712
INFO - 2021-04-06 10:32:50 --> Config Class Initialized
INFO - 2021-04-06 10:32:50 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:50 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:50 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:50 --> URI Class Initialized
INFO - 2021-04-06 10:32:50 --> Router Class Initialized
INFO - 2021-04-06 10:32:50 --> Output Class Initialized
INFO - 2021-04-06 10:32:50 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:50 --> Input Class Initialized
INFO - 2021-04-06 10:32:50 --> Language Class Initialized
INFO - 2021-04-06 10:32:50 --> Loader Class Initialized
INFO - 2021-04-06 10:32:50 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:50 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:50 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:50 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:50 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:50 --> Controller Class Initialized
INFO - 2021-04-06 10:32:50 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:50 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:50 --> Config Class Initialized
INFO - 2021-04-06 10:32:50 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:50 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:50 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:51 --> URI Class Initialized
INFO - 2021-04-06 10:32:51 --> Router Class Initialized
INFO - 2021-04-06 10:32:51 --> Output Class Initialized
INFO - 2021-04-06 10:32:51 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:51 --> Input Class Initialized
INFO - 2021-04-06 10:32:51 --> Language Class Initialized
INFO - 2021-04-06 10:32:51 --> Loader Class Initialized
INFO - 2021-04-06 10:32:51 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:51 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:51 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:51 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:51 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:51 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:51 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:51 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:51 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:51 --> Controller Class Initialized
INFO - 2021-04-06 10:32:51 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:51 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:51 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:51 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:51 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:51 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:32:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:51 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:51 --> Total execution time: 0.0719
INFO - 2021-04-06 10:32:54 --> Config Class Initialized
INFO - 2021-04-06 10:32:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:54 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:54 --> URI Class Initialized
INFO - 2021-04-06 10:32:54 --> Router Class Initialized
INFO - 2021-04-06 10:32:54 --> Output Class Initialized
INFO - 2021-04-06 10:32:54 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:54 --> Input Class Initialized
INFO - 2021-04-06 10:32:54 --> Language Class Initialized
INFO - 2021-04-06 10:32:54 --> Loader Class Initialized
INFO - 2021-04-06 10:32:54 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:54 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:54 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:54 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:54 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:54 --> Controller Class Initialized
INFO - 2021-04-06 10:32:54 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:54 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:32:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:54 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:54 --> Total execution time: 0.0814
INFO - 2021-04-06 10:32:54 --> Config Class Initialized
INFO - 2021-04-06 10:32:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:54 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:54 --> URI Class Initialized
INFO - 2021-04-06 10:32:54 --> Router Class Initialized
INFO - 2021-04-06 10:32:54 --> Output Class Initialized
INFO - 2021-04-06 10:32:54 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:54 --> Input Class Initialized
INFO - 2021-04-06 10:32:54 --> Language Class Initialized
ERROR - 2021-04-06 10:32:54 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:32:55 --> Config Class Initialized
INFO - 2021-04-06 10:32:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:55 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:55 --> URI Class Initialized
INFO - 2021-04-06 10:32:55 --> Router Class Initialized
INFO - 2021-04-06 10:32:55 --> Output Class Initialized
INFO - 2021-04-06 10:32:55 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:55 --> Input Class Initialized
INFO - 2021-04-06 10:32:55 --> Language Class Initialized
INFO - 2021-04-06 10:32:55 --> Loader Class Initialized
INFO - 2021-04-06 10:32:55 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:55 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:55 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:55 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:55 --> Controller Class Initialized
INFO - 2021-04-06 10:32:55 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:55 --> Config Class Initialized
INFO - 2021-04-06 10:32:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:32:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:32:55 --> Utf8 Class Initialized
INFO - 2021-04-06 10:32:55 --> URI Class Initialized
INFO - 2021-04-06 10:32:55 --> Router Class Initialized
INFO - 2021-04-06 10:32:55 --> Output Class Initialized
INFO - 2021-04-06 10:32:55 --> Security Class Initialized
DEBUG - 2021-04-06 10:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:32:55 --> Input Class Initialized
INFO - 2021-04-06 10:32:55 --> Language Class Initialized
INFO - 2021-04-06 10:32:55 --> Loader Class Initialized
INFO - 2021-04-06 10:32:55 --> Helper loaded: url_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: file_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:32:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:32:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:55 --> Email Class Initialized
DEBUG - 2021-04-06 10:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:32:55 --> Helper loaded: form_helper
INFO - 2021-04-06 10:32:55 --> Form Validation Class Initialized
INFO - 2021-04-06 10:32:55 --> Controller Class Initialized
INFO - 2021-04-06 10:32:55 --> Model "Common_model" initialized
INFO - 2021-04-06 10:32:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:32:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:32:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:32:55 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:32:55 --> Database Driver Class Initialized
INFO - 2021-04-06 10:32:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:32:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:32:55 --> Final output sent to browser
DEBUG - 2021-04-06 10:32:55 --> Total execution time: 0.0860
INFO - 2021-04-06 10:33:04 --> Config Class Initialized
INFO - 2021-04-06 10:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:33:04 --> Utf8 Class Initialized
INFO - 2021-04-06 10:33:04 --> URI Class Initialized
INFO - 2021-04-06 10:33:04 --> Router Class Initialized
INFO - 2021-04-06 10:33:04 --> Output Class Initialized
INFO - 2021-04-06 10:33:04 --> Security Class Initialized
DEBUG - 2021-04-06 10:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:33:04 --> Input Class Initialized
INFO - 2021-04-06 10:33:04 --> Language Class Initialized
INFO - 2021-04-06 10:33:04 --> Loader Class Initialized
INFO - 2021-04-06 10:33:04 --> Helper loaded: url_helper
INFO - 2021-04-06 10:33:04 --> Helper loaded: file_helper
INFO - 2021-04-06 10:33:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:33:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:33:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:33:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:33:04 --> Email Class Initialized
DEBUG - 2021-04-06 10:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:33:04 --> Helper loaded: form_helper
INFO - 2021-04-06 10:33:04 --> Form Validation Class Initialized
INFO - 2021-04-06 10:33:04 --> Controller Class Initialized
INFO - 2021-04-06 10:33:04 --> Model "Common_model" initialized
INFO - 2021-04-06 10:33:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:33:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:33:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:33:04 --> Database Driver Class Initialized
INFO - 2021-04-06 10:33:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:33:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:33:04 --> Final output sent to browser
DEBUG - 2021-04-06 10:33:04 --> Total execution time: 0.3980
INFO - 2021-04-06 10:33:05 --> Config Class Initialized
INFO - 2021-04-06 10:33:05 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:33:05 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:33:05 --> Utf8 Class Initialized
INFO - 2021-04-06 10:33:05 --> URI Class Initialized
INFO - 2021-04-06 10:33:05 --> Router Class Initialized
INFO - 2021-04-06 10:33:05 --> Output Class Initialized
INFO - 2021-04-06 10:33:05 --> Security Class Initialized
DEBUG - 2021-04-06 10:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:33:05 --> Input Class Initialized
INFO - 2021-04-06 10:33:05 --> Language Class Initialized
ERROR - 2021-04-06 10:33:05 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:33:06 --> Config Class Initialized
INFO - 2021-04-06 10:33:06 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:33:06 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:33:06 --> Utf8 Class Initialized
INFO - 2021-04-06 10:33:06 --> URI Class Initialized
INFO - 2021-04-06 10:33:06 --> Router Class Initialized
INFO - 2021-04-06 10:33:06 --> Output Class Initialized
INFO - 2021-04-06 10:33:06 --> Security Class Initialized
DEBUG - 2021-04-06 10:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:33:06 --> Input Class Initialized
INFO - 2021-04-06 10:33:06 --> Language Class Initialized
INFO - 2021-04-06 10:33:06 --> Loader Class Initialized
INFO - 2021-04-06 10:33:06 --> Helper loaded: url_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: file_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:33:06 --> Database Driver Class Initialized
INFO - 2021-04-06 10:33:06 --> Email Class Initialized
DEBUG - 2021-04-06 10:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:33:06 --> Helper loaded: form_helper
INFO - 2021-04-06 10:33:06 --> Form Validation Class Initialized
INFO - 2021-04-06 10:33:06 --> Controller Class Initialized
INFO - 2021-04-06 10:33:06 --> Model "Common_model" initialized
INFO - 2021-04-06 10:33:06 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:33:06 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:33:06 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:33:06 --> Config Class Initialized
INFO - 2021-04-06 10:33:06 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:33:06 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:33:06 --> Utf8 Class Initialized
INFO - 2021-04-06 10:33:06 --> URI Class Initialized
INFO - 2021-04-06 10:33:06 --> Router Class Initialized
INFO - 2021-04-06 10:33:06 --> Output Class Initialized
INFO - 2021-04-06 10:33:06 --> Security Class Initialized
DEBUG - 2021-04-06 10:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:33:06 --> Input Class Initialized
INFO - 2021-04-06 10:33:06 --> Language Class Initialized
INFO - 2021-04-06 10:33:06 --> Loader Class Initialized
INFO - 2021-04-06 10:33:06 --> Helper loaded: url_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: file_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:33:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:33:06 --> Database Driver Class Initialized
INFO - 2021-04-06 10:33:06 --> Email Class Initialized
DEBUG - 2021-04-06 10:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:33:06 --> Helper loaded: form_helper
INFO - 2021-04-06 10:33:06 --> Form Validation Class Initialized
INFO - 2021-04-06 10:33:06 --> Controller Class Initialized
INFO - 2021-04-06 10:33:06 --> Model "Common_model" initialized
INFO - 2021-04-06 10:33:06 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:33:06 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:33:06 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:33:06 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:33:06 --> Database Driver Class Initialized
INFO - 2021-04-06 10:33:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:33:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:33:06 --> Final output sent to browser
DEBUG - 2021-04-06 10:33:06 --> Total execution time: 0.0970
INFO - 2021-04-06 10:35:23 --> Config Class Initialized
INFO - 2021-04-06 10:35:23 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:35:23 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:35:23 --> Utf8 Class Initialized
INFO - 2021-04-06 10:35:23 --> URI Class Initialized
INFO - 2021-04-06 10:35:23 --> Router Class Initialized
INFO - 2021-04-06 10:35:23 --> Output Class Initialized
INFO - 2021-04-06 10:35:23 --> Security Class Initialized
DEBUG - 2021-04-06 10:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:35:23 --> Input Class Initialized
INFO - 2021-04-06 10:35:23 --> Language Class Initialized
INFO - 2021-04-06 10:35:23 --> Loader Class Initialized
INFO - 2021-04-06 10:35:23 --> Helper loaded: url_helper
INFO - 2021-04-06 10:35:23 --> Helper loaded: file_helper
INFO - 2021-04-06 10:35:23 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:35:23 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:35:23 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:35:23 --> Database Driver Class Initialized
INFO - 2021-04-06 10:35:23 --> Email Class Initialized
DEBUG - 2021-04-06 10:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:35:23 --> Helper loaded: form_helper
INFO - 2021-04-06 10:35:23 --> Form Validation Class Initialized
INFO - 2021-04-06 10:35:23 --> Controller Class Initialized
INFO - 2021-04-06 10:35:23 --> Model "Common_model" initialized
INFO - 2021-04-06 10:35:23 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:35:23 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:35:23 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:35:23 --> Database Driver Class Initialized
INFO - 2021-04-06 10:35:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:35:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:35:23 --> Final output sent to browser
DEBUG - 2021-04-06 10:35:23 --> Total execution time: 0.3996
INFO - 2021-04-06 10:35:24 --> Config Class Initialized
INFO - 2021-04-06 10:35:24 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:35:24 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:35:24 --> Utf8 Class Initialized
INFO - 2021-04-06 10:35:24 --> URI Class Initialized
INFO - 2021-04-06 10:35:24 --> Router Class Initialized
INFO - 2021-04-06 10:35:24 --> Output Class Initialized
INFO - 2021-04-06 10:35:24 --> Security Class Initialized
DEBUG - 2021-04-06 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:35:24 --> Input Class Initialized
INFO - 2021-04-06 10:35:24 --> Language Class Initialized
ERROR - 2021-04-06 10:35:24 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:35:24 --> Config Class Initialized
INFO - 2021-04-06 10:35:24 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:35:24 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:35:24 --> Utf8 Class Initialized
INFO - 2021-04-06 10:35:24 --> URI Class Initialized
INFO - 2021-04-06 10:35:24 --> Router Class Initialized
INFO - 2021-04-06 10:35:24 --> Output Class Initialized
INFO - 2021-04-06 10:35:24 --> Security Class Initialized
DEBUG - 2021-04-06 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:35:24 --> Input Class Initialized
INFO - 2021-04-06 10:35:24 --> Language Class Initialized
INFO - 2021-04-06 10:35:24 --> Loader Class Initialized
INFO - 2021-04-06 10:35:24 --> Helper loaded: url_helper
INFO - 2021-04-06 10:35:24 --> Helper loaded: file_helper
INFO - 2021-04-06 10:35:24 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:35:24 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:35:24 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:35:24 --> Database Driver Class Initialized
INFO - 2021-04-06 10:35:24 --> Email Class Initialized
DEBUG - 2021-04-06 10:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:35:24 --> Helper loaded: form_helper
INFO - 2021-04-06 10:35:24 --> Form Validation Class Initialized
INFO - 2021-04-06 10:35:24 --> Controller Class Initialized
INFO - 2021-04-06 10:35:24 --> Model "Common_model" initialized
INFO - 2021-04-06 10:35:24 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:35:24 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:35:24 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:35:25 --> Config Class Initialized
INFO - 2021-04-06 10:35:25 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:35:25 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:35:25 --> Utf8 Class Initialized
INFO - 2021-04-06 10:35:25 --> URI Class Initialized
INFO - 2021-04-06 10:35:25 --> Router Class Initialized
INFO - 2021-04-06 10:35:25 --> Output Class Initialized
INFO - 2021-04-06 10:35:25 --> Security Class Initialized
DEBUG - 2021-04-06 10:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:35:25 --> Input Class Initialized
INFO - 2021-04-06 10:35:25 --> Language Class Initialized
INFO - 2021-04-06 10:35:25 --> Loader Class Initialized
INFO - 2021-04-06 10:35:25 --> Helper loaded: url_helper
INFO - 2021-04-06 10:35:25 --> Helper loaded: file_helper
INFO - 2021-04-06 10:35:25 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:35:25 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:35:25 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:35:25 --> Database Driver Class Initialized
INFO - 2021-04-06 10:35:25 --> Email Class Initialized
DEBUG - 2021-04-06 10:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:35:25 --> Helper loaded: form_helper
INFO - 2021-04-06 10:35:25 --> Form Validation Class Initialized
INFO - 2021-04-06 10:35:25 --> Controller Class Initialized
INFO - 2021-04-06 10:35:25 --> Model "Common_model" initialized
INFO - 2021-04-06 10:35:25 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:35:25 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:35:25 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:35:25 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:35:25 --> Database Driver Class Initialized
INFO - 2021-04-06 10:35:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:35:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:35:26 --> Final output sent to browser
DEBUG - 2021-04-06 10:35:26 --> Total execution time: 1.8670
INFO - 2021-04-06 10:52:06 --> Config Class Initialized
INFO - 2021-04-06 10:52:06 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:06 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:06 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:06 --> URI Class Initialized
INFO - 2021-04-06 10:52:06 --> Router Class Initialized
INFO - 2021-04-06 10:52:06 --> Output Class Initialized
INFO - 2021-04-06 10:52:06 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:06 --> Input Class Initialized
INFO - 2021-04-06 10:52:06 --> Language Class Initialized
INFO - 2021-04-06 10:52:06 --> Loader Class Initialized
INFO - 2021-04-06 10:52:06 --> Helper loaded: url_helper
INFO - 2021-04-06 10:52:06 --> Helper loaded: file_helper
INFO - 2021-04-06 10:52:06 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:52:06 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:52:06 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:52:06 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:06 --> Email Class Initialized
DEBUG - 2021-04-06 10:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:52:06 --> Helper loaded: form_helper
INFO - 2021-04-06 10:52:06 --> Form Validation Class Initialized
INFO - 2021-04-06 10:52:06 --> Controller Class Initialized
INFO - 2021-04-06 10:52:06 --> Model "Common_model" initialized
INFO - 2021-04-06 10:52:06 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:52:06 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:52:06 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:52:06 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:52:06 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:52:06 --> Final output sent to browser
DEBUG - 2021-04-06 10:52:06 --> Total execution time: 0.2112
INFO - 2021-04-06 10:52:06 --> Config Class Initialized
INFO - 2021-04-06 10:52:06 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:06 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:06 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:06 --> URI Class Initialized
INFO - 2021-04-06 10:52:06 --> Router Class Initialized
INFO - 2021-04-06 10:52:06 --> Output Class Initialized
INFO - 2021-04-06 10:52:06 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:06 --> Input Class Initialized
INFO - 2021-04-06 10:52:06 --> Language Class Initialized
ERROR - 2021-04-06 10:52:06 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:52:07 --> Config Class Initialized
INFO - 2021-04-06 10:52:07 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:07 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:07 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:07 --> URI Class Initialized
INFO - 2021-04-06 10:52:07 --> Router Class Initialized
INFO - 2021-04-06 10:52:07 --> Output Class Initialized
INFO - 2021-04-06 10:52:07 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:07 --> Input Class Initialized
INFO - 2021-04-06 10:52:07 --> Language Class Initialized
INFO - 2021-04-06 10:52:07 --> Loader Class Initialized
INFO - 2021-04-06 10:52:07 --> Helper loaded: url_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: file_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:52:07 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:07 --> Email Class Initialized
DEBUG - 2021-04-06 10:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:52:07 --> Helper loaded: form_helper
INFO - 2021-04-06 10:52:07 --> Form Validation Class Initialized
INFO - 2021-04-06 10:52:07 --> Controller Class Initialized
INFO - 2021-04-06 10:52:07 --> Model "Common_model" initialized
INFO - 2021-04-06 10:52:07 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:52:07 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:52:07 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:52:07 --> Config Class Initialized
INFO - 2021-04-06 10:52:07 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:07 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:07 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:07 --> URI Class Initialized
INFO - 2021-04-06 10:52:07 --> Router Class Initialized
INFO - 2021-04-06 10:52:07 --> Output Class Initialized
INFO - 2021-04-06 10:52:07 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:07 --> Input Class Initialized
INFO - 2021-04-06 10:52:07 --> Language Class Initialized
INFO - 2021-04-06 10:52:07 --> Loader Class Initialized
INFO - 2021-04-06 10:52:07 --> Helper loaded: url_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: file_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:52:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:52:07 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:07 --> Email Class Initialized
DEBUG - 2021-04-06 10:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:52:07 --> Helper loaded: form_helper
INFO - 2021-04-06 10:52:07 --> Form Validation Class Initialized
INFO - 2021-04-06 10:52:07 --> Controller Class Initialized
INFO - 2021-04-06 10:52:07 --> Model "Common_model" initialized
INFO - 2021-04-06 10:52:07 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:52:07 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:52:07 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:52:07 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:52:07 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:52:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:52:08 --> Final output sent to browser
DEBUG - 2021-04-06 10:52:08 --> Total execution time: 0.5842
INFO - 2021-04-06 10:52:45 --> Config Class Initialized
INFO - 2021-04-06 10:52:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:45 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:45 --> URI Class Initialized
INFO - 2021-04-06 10:52:45 --> Router Class Initialized
INFO - 2021-04-06 10:52:45 --> Output Class Initialized
INFO - 2021-04-06 10:52:45 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:45 --> Input Class Initialized
INFO - 2021-04-06 10:52:45 --> Language Class Initialized
INFO - 2021-04-06 10:52:45 --> Loader Class Initialized
INFO - 2021-04-06 10:52:45 --> Helper loaded: url_helper
INFO - 2021-04-06 10:52:45 --> Helper loaded: file_helper
INFO - 2021-04-06 10:52:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:52:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:52:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:52:45 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:45 --> Email Class Initialized
DEBUG - 2021-04-06 10:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:52:45 --> Helper loaded: form_helper
INFO - 2021-04-06 10:52:45 --> Form Validation Class Initialized
INFO - 2021-04-06 10:52:45 --> Controller Class Initialized
INFO - 2021-04-06 10:52:45 --> Model "Common_model" initialized
INFO - 2021-04-06 10:52:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:52:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:52:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:52:45 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:52:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:52:45 --> Final output sent to browser
DEBUG - 2021-04-06 10:52:45 --> Total execution time: 0.1903
INFO - 2021-04-06 10:52:46 --> Config Class Initialized
INFO - 2021-04-06 10:52:46 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:46 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:46 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:46 --> URI Class Initialized
INFO - 2021-04-06 10:52:46 --> Router Class Initialized
INFO - 2021-04-06 10:52:46 --> Output Class Initialized
INFO - 2021-04-06 10:52:46 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:46 --> Input Class Initialized
INFO - 2021-04-06 10:52:46 --> Language Class Initialized
ERROR - 2021-04-06 10:52:46 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:52:46 --> Config Class Initialized
INFO - 2021-04-06 10:52:46 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:46 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:46 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:46 --> URI Class Initialized
INFO - 2021-04-06 10:52:46 --> Router Class Initialized
INFO - 2021-04-06 10:52:46 --> Output Class Initialized
INFO - 2021-04-06 10:52:46 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:46 --> Input Class Initialized
INFO - 2021-04-06 10:52:46 --> Language Class Initialized
INFO - 2021-04-06 10:52:46 --> Loader Class Initialized
INFO - 2021-04-06 10:52:47 --> Helper loaded: url_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: file_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:52:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:47 --> Email Class Initialized
DEBUG - 2021-04-06 10:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:52:47 --> Helper loaded: form_helper
INFO - 2021-04-06 10:52:47 --> Form Validation Class Initialized
INFO - 2021-04-06 10:52:47 --> Controller Class Initialized
INFO - 2021-04-06 10:52:47 --> Model "Common_model" initialized
INFO - 2021-04-06 10:52:47 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:52:47 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:52:47 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:52:47 --> Config Class Initialized
INFO - 2021-04-06 10:52:47 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:52:47 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:52:47 --> Utf8 Class Initialized
INFO - 2021-04-06 10:52:47 --> URI Class Initialized
INFO - 2021-04-06 10:52:47 --> Router Class Initialized
INFO - 2021-04-06 10:52:47 --> Output Class Initialized
INFO - 2021-04-06 10:52:47 --> Security Class Initialized
DEBUG - 2021-04-06 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:52:47 --> Input Class Initialized
INFO - 2021-04-06 10:52:47 --> Language Class Initialized
INFO - 2021-04-06 10:52:47 --> Loader Class Initialized
INFO - 2021-04-06 10:52:47 --> Helper loaded: url_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: file_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:52:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:52:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:47 --> Email Class Initialized
DEBUG - 2021-04-06 10:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:52:47 --> Helper loaded: form_helper
INFO - 2021-04-06 10:52:47 --> Form Validation Class Initialized
INFO - 2021-04-06 10:52:47 --> Controller Class Initialized
INFO - 2021-04-06 10:52:47 --> Model "Common_model" initialized
INFO - 2021-04-06 10:52:47 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:52:47 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:52:47 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:52:47 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:52:47 --> Database Driver Class Initialized
INFO - 2021-04-06 10:52:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:52:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:52:47 --> Final output sent to browser
DEBUG - 2021-04-06 10:52:47 --> Total execution time: 0.0864
INFO - 2021-04-06 10:57:13 --> Config Class Initialized
INFO - 2021-04-06 10:57:13 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:57:13 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:57:13 --> Utf8 Class Initialized
INFO - 2021-04-06 10:57:13 --> URI Class Initialized
INFO - 2021-04-06 10:57:13 --> Router Class Initialized
INFO - 2021-04-06 10:57:13 --> Output Class Initialized
INFO - 2021-04-06 10:57:13 --> Security Class Initialized
DEBUG - 2021-04-06 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:57:13 --> Input Class Initialized
INFO - 2021-04-06 10:57:13 --> Language Class Initialized
INFO - 2021-04-06 10:57:13 --> Loader Class Initialized
INFO - 2021-04-06 10:57:13 --> Helper loaded: url_helper
INFO - 2021-04-06 10:57:13 --> Helper loaded: file_helper
INFO - 2021-04-06 10:57:13 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:57:13 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:57:13 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:57:13 --> Database Driver Class Initialized
INFO - 2021-04-06 10:57:13 --> Email Class Initialized
DEBUG - 2021-04-06 10:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:57:13 --> Helper loaded: form_helper
INFO - 2021-04-06 10:57:13 --> Form Validation Class Initialized
INFO - 2021-04-06 10:57:13 --> Controller Class Initialized
INFO - 2021-04-06 10:57:13 --> Model "Common_model" initialized
INFO - 2021-04-06 10:57:13 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:57:13 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:57:13 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:57:13 --> Database Driver Class Initialized
INFO - 2021-04-06 10:57:13 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 10:57:13 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:57:13 --> Final output sent to browser
DEBUG - 2021-04-06 10:57:13 --> Total execution time: 0.3387
INFO - 2021-04-06 10:57:14 --> Config Class Initialized
INFO - 2021-04-06 10:57:14 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:57:14 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:57:14 --> Utf8 Class Initialized
INFO - 2021-04-06 10:57:14 --> URI Class Initialized
INFO - 2021-04-06 10:57:14 --> Router Class Initialized
INFO - 2021-04-06 10:57:14 --> Output Class Initialized
INFO - 2021-04-06 10:57:14 --> Security Class Initialized
DEBUG - 2021-04-06 10:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:57:14 --> Input Class Initialized
INFO - 2021-04-06 10:57:14 --> Language Class Initialized
ERROR - 2021-04-06 10:57:14 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 10:57:15 --> Config Class Initialized
INFO - 2021-04-06 10:57:15 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:57:15 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:57:15 --> Utf8 Class Initialized
INFO - 2021-04-06 10:57:15 --> URI Class Initialized
INFO - 2021-04-06 10:57:15 --> Router Class Initialized
INFO - 2021-04-06 10:57:15 --> Output Class Initialized
INFO - 2021-04-06 10:57:15 --> Security Class Initialized
DEBUG - 2021-04-06 10:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:57:15 --> Input Class Initialized
INFO - 2021-04-06 10:57:15 --> Language Class Initialized
INFO - 2021-04-06 10:57:15 --> Loader Class Initialized
INFO - 2021-04-06 10:57:15 --> Helper loaded: url_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: file_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:57:15 --> Database Driver Class Initialized
INFO - 2021-04-06 10:57:15 --> Email Class Initialized
DEBUG - 2021-04-06 10:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:57:15 --> Helper loaded: form_helper
INFO - 2021-04-06 10:57:15 --> Form Validation Class Initialized
INFO - 2021-04-06 10:57:15 --> Controller Class Initialized
INFO - 2021-04-06 10:57:15 --> Model "Common_model" initialized
INFO - 2021-04-06 10:57:15 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:57:15 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:57:15 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:57:15 --> Config Class Initialized
INFO - 2021-04-06 10:57:15 --> Hooks Class Initialized
DEBUG - 2021-04-06 10:57:15 --> UTF-8 Support Enabled
INFO - 2021-04-06 10:57:15 --> Utf8 Class Initialized
INFO - 2021-04-06 10:57:15 --> URI Class Initialized
INFO - 2021-04-06 10:57:15 --> Router Class Initialized
INFO - 2021-04-06 10:57:15 --> Output Class Initialized
INFO - 2021-04-06 10:57:15 --> Security Class Initialized
DEBUG - 2021-04-06 10:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 10:57:15 --> Input Class Initialized
INFO - 2021-04-06 10:57:15 --> Language Class Initialized
INFO - 2021-04-06 10:57:15 --> Loader Class Initialized
INFO - 2021-04-06 10:57:15 --> Helper loaded: url_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: file_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: utility_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: unit_helper
INFO - 2021-04-06 10:57:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 10:57:15 --> Database Driver Class Initialized
INFO - 2021-04-06 10:57:15 --> Email Class Initialized
DEBUG - 2021-04-06 10:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 10:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 10:57:15 --> Helper loaded: form_helper
INFO - 2021-04-06 10:57:15 --> Form Validation Class Initialized
INFO - 2021-04-06 10:57:15 --> Controller Class Initialized
INFO - 2021-04-06 10:57:15 --> Model "Common_model" initialized
INFO - 2021-04-06 10:57:15 --> Model "Finane_Model" initialized
INFO - 2021-04-06 10:57:15 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 10:57:15 --> Model "Sales_Model" initialized
INFO - 2021-04-06 10:57:15 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 10:57:15 --> Database Driver Class Initialized
INFO - 2021-04-06 10:57:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 10:57:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 10:57:16 --> Final output sent to browser
DEBUG - 2021-04-06 10:57:16 --> Total execution time: 0.7860
INFO - 2021-04-06 11:05:12 --> Config Class Initialized
INFO - 2021-04-06 11:05:12 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:05:12 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:05:12 --> Utf8 Class Initialized
INFO - 2021-04-06 11:05:12 --> URI Class Initialized
INFO - 2021-04-06 11:05:12 --> Router Class Initialized
INFO - 2021-04-06 11:05:12 --> Output Class Initialized
INFO - 2021-04-06 11:05:12 --> Security Class Initialized
DEBUG - 2021-04-06 11:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:05:12 --> Input Class Initialized
INFO - 2021-04-06 11:05:12 --> Language Class Initialized
INFO - 2021-04-06 11:05:12 --> Loader Class Initialized
INFO - 2021-04-06 11:05:12 --> Helper loaded: url_helper
INFO - 2021-04-06 11:05:12 --> Helper loaded: file_helper
INFO - 2021-04-06 11:05:12 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:05:12 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:05:12 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:05:12 --> Database Driver Class Initialized
INFO - 2021-04-06 11:05:12 --> Email Class Initialized
DEBUG - 2021-04-06 11:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:05:12 --> Helper loaded: form_helper
INFO - 2021-04-06 11:05:12 --> Form Validation Class Initialized
INFO - 2021-04-06 11:05:12 --> Controller Class Initialized
INFO - 2021-04-06 11:05:12 --> Model "Common_model" initialized
INFO - 2021-04-06 11:05:12 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:05:12 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:05:12 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:05:12 --> Database Driver Class Initialized
INFO - 2021-04-06 11:05:12 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:05:12 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:05:12 --> Final output sent to browser
DEBUG - 2021-04-06 11:05:12 --> Total execution time: 0.3707
INFO - 2021-04-06 11:05:13 --> Config Class Initialized
INFO - 2021-04-06 11:05:13 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:05:13 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:05:13 --> Utf8 Class Initialized
INFO - 2021-04-06 11:05:13 --> URI Class Initialized
INFO - 2021-04-06 11:05:13 --> Router Class Initialized
INFO - 2021-04-06 11:05:13 --> Output Class Initialized
INFO - 2021-04-06 11:05:13 --> Security Class Initialized
DEBUG - 2021-04-06 11:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:05:13 --> Input Class Initialized
INFO - 2021-04-06 11:05:13 --> Language Class Initialized
ERROR - 2021-04-06 11:05:13 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:05:13 --> Config Class Initialized
INFO - 2021-04-06 11:05:13 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:05:13 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:05:13 --> Utf8 Class Initialized
INFO - 2021-04-06 11:05:13 --> URI Class Initialized
INFO - 2021-04-06 11:05:13 --> Router Class Initialized
INFO - 2021-04-06 11:05:13 --> Output Class Initialized
INFO - 2021-04-06 11:05:13 --> Security Class Initialized
DEBUG - 2021-04-06 11:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:05:13 --> Input Class Initialized
INFO - 2021-04-06 11:05:13 --> Language Class Initialized
INFO - 2021-04-06 11:05:13 --> Loader Class Initialized
INFO - 2021-04-06 11:05:13 --> Helper loaded: url_helper
INFO - 2021-04-06 11:05:13 --> Helper loaded: file_helper
INFO - 2021-04-06 11:05:13 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:05:13 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:05:13 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:05:13 --> Database Driver Class Initialized
INFO - 2021-04-06 11:05:13 --> Email Class Initialized
DEBUG - 2021-04-06 11:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:05:13 --> Helper loaded: form_helper
INFO - 2021-04-06 11:05:13 --> Form Validation Class Initialized
INFO - 2021-04-06 11:05:13 --> Controller Class Initialized
INFO - 2021-04-06 11:05:13 --> Model "Common_model" initialized
INFO - 2021-04-06 11:05:13 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:05:13 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:05:13 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:05:14 --> Config Class Initialized
INFO - 2021-04-06 11:05:14 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:05:14 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:05:14 --> Utf8 Class Initialized
INFO - 2021-04-06 11:05:14 --> URI Class Initialized
INFO - 2021-04-06 11:05:14 --> Router Class Initialized
INFO - 2021-04-06 11:05:14 --> Output Class Initialized
INFO - 2021-04-06 11:05:14 --> Security Class Initialized
DEBUG - 2021-04-06 11:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:05:14 --> Input Class Initialized
INFO - 2021-04-06 11:05:14 --> Language Class Initialized
INFO - 2021-04-06 11:05:14 --> Loader Class Initialized
INFO - 2021-04-06 11:05:14 --> Helper loaded: url_helper
INFO - 2021-04-06 11:05:14 --> Helper loaded: file_helper
INFO - 2021-04-06 11:05:14 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:05:14 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:05:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:05:14 --> Database Driver Class Initialized
INFO - 2021-04-06 11:05:14 --> Email Class Initialized
DEBUG - 2021-04-06 11:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:05:14 --> Helper loaded: form_helper
INFO - 2021-04-06 11:05:14 --> Form Validation Class Initialized
INFO - 2021-04-06 11:05:14 --> Controller Class Initialized
INFO - 2021-04-06 11:05:14 --> Model "Common_model" initialized
INFO - 2021-04-06 11:05:14 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:05:14 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:05:14 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:05:14 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:05:14 --> Database Driver Class Initialized
INFO - 2021-04-06 11:05:14 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:05:14 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:05:14 --> Final output sent to browser
DEBUG - 2021-04-06 11:05:14 --> Total execution time: 0.6268
INFO - 2021-04-06 11:09:57 --> Config Class Initialized
INFO - 2021-04-06 11:09:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:09:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:09:57 --> Utf8 Class Initialized
INFO - 2021-04-06 11:09:57 --> URI Class Initialized
INFO - 2021-04-06 11:09:57 --> Router Class Initialized
INFO - 2021-04-06 11:09:57 --> Output Class Initialized
INFO - 2021-04-06 11:09:57 --> Security Class Initialized
DEBUG - 2021-04-06 11:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:09:57 --> Input Class Initialized
INFO - 2021-04-06 11:09:57 --> Language Class Initialized
ERROR - 2021-04-06 11:09:57 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-04-06 11:09:57 --> Config Class Initialized
INFO - 2021-04-06 11:09:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:09:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:09:57 --> Utf8 Class Initialized
INFO - 2021-04-06 11:09:57 --> URI Class Initialized
INFO - 2021-04-06 11:09:57 --> Router Class Initialized
INFO - 2021-04-06 11:09:57 --> Output Class Initialized
INFO - 2021-04-06 11:09:57 --> Security Class Initialized
DEBUG - 2021-04-06 11:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:09:57 --> Input Class Initialized
INFO - 2021-04-06 11:09:57 --> Language Class Initialized
ERROR - 2021-04-06 11:09:57 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-04-06 11:09:57 --> Config Class Initialized
INFO - 2021-04-06 11:09:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:09:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:09:57 --> Utf8 Class Initialized
INFO - 2021-04-06 11:09:57 --> URI Class Initialized
INFO - 2021-04-06 11:09:57 --> Router Class Initialized
INFO - 2021-04-06 11:09:57 --> Output Class Initialized
INFO - 2021-04-06 11:09:57 --> Security Class Initialized
DEBUG - 2021-04-06 11:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:09:57 --> Input Class Initialized
INFO - 2021-04-06 11:09:57 --> Language Class Initialized
ERROR - 2021-04-06 11:09:57 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-04-06 11:10:44 --> Config Class Initialized
INFO - 2021-04-06 11:10:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:10:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:10:44 --> Utf8 Class Initialized
INFO - 2021-04-06 11:10:44 --> URI Class Initialized
INFO - 2021-04-06 11:10:44 --> Router Class Initialized
INFO - 2021-04-06 11:10:44 --> Output Class Initialized
INFO - 2021-04-06 11:10:44 --> Security Class Initialized
DEBUG - 2021-04-06 11:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:10:44 --> Input Class Initialized
INFO - 2021-04-06 11:10:44 --> Language Class Initialized
INFO - 2021-04-06 11:10:44 --> Loader Class Initialized
INFO - 2021-04-06 11:10:44 --> Helper loaded: url_helper
INFO - 2021-04-06 11:10:44 --> Helper loaded: file_helper
INFO - 2021-04-06 11:10:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:10:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:10:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:10:44 --> Database Driver Class Initialized
INFO - 2021-04-06 11:10:44 --> Email Class Initialized
DEBUG - 2021-04-06 11:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:10:44 --> Helper loaded: form_helper
INFO - 2021-04-06 11:10:44 --> Form Validation Class Initialized
INFO - 2021-04-06 11:10:44 --> Controller Class Initialized
INFO - 2021-04-06 11:10:44 --> Model "Common_model" initialized
INFO - 2021-04-06 11:10:44 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:10:44 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:10:44 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:10:44 --> Database Driver Class Initialized
INFO - 2021-04-06 11:10:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:10:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:10:44 --> Final output sent to browser
DEBUG - 2021-04-06 11:10:44 --> Total execution time: 0.2077
INFO - 2021-04-06 11:10:44 --> Config Class Initialized
INFO - 2021-04-06 11:10:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:10:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:10:44 --> Utf8 Class Initialized
INFO - 2021-04-06 11:10:44 --> URI Class Initialized
INFO - 2021-04-06 11:10:44 --> Router Class Initialized
INFO - 2021-04-06 11:10:44 --> Output Class Initialized
INFO - 2021-04-06 11:10:44 --> Security Class Initialized
DEBUG - 2021-04-06 11:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:10:44 --> Input Class Initialized
INFO - 2021-04-06 11:10:44 --> Language Class Initialized
ERROR - 2021-04-06 11:10:44 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:10:45 --> Config Class Initialized
INFO - 2021-04-06 11:10:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:10:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:10:45 --> Utf8 Class Initialized
INFO - 2021-04-06 11:10:45 --> URI Class Initialized
INFO - 2021-04-06 11:10:45 --> Router Class Initialized
INFO - 2021-04-06 11:10:45 --> Output Class Initialized
INFO - 2021-04-06 11:10:45 --> Security Class Initialized
DEBUG - 2021-04-06 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:10:45 --> Input Class Initialized
INFO - 2021-04-06 11:10:45 --> Language Class Initialized
INFO - 2021-04-06 11:10:45 --> Loader Class Initialized
INFO - 2021-04-06 11:10:45 --> Helper loaded: url_helper
INFO - 2021-04-06 11:10:45 --> Helper loaded: file_helper
INFO - 2021-04-06 11:10:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:10:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:10:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:10:45 --> Database Driver Class Initialized
INFO - 2021-04-06 11:10:45 --> Email Class Initialized
DEBUG - 2021-04-06 11:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:10:45 --> Helper loaded: form_helper
INFO - 2021-04-06 11:10:45 --> Form Validation Class Initialized
INFO - 2021-04-06 11:10:45 --> Controller Class Initialized
INFO - 2021-04-06 11:10:45 --> Model "Common_model" initialized
INFO - 2021-04-06 11:10:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:10:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:10:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:10:46 --> Config Class Initialized
INFO - 2021-04-06 11:10:46 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:10:46 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:10:46 --> Utf8 Class Initialized
INFO - 2021-04-06 11:10:46 --> URI Class Initialized
INFO - 2021-04-06 11:10:46 --> Router Class Initialized
INFO - 2021-04-06 11:10:46 --> Output Class Initialized
INFO - 2021-04-06 11:10:46 --> Security Class Initialized
DEBUG - 2021-04-06 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:10:46 --> Input Class Initialized
INFO - 2021-04-06 11:10:46 --> Language Class Initialized
INFO - 2021-04-06 11:10:46 --> Loader Class Initialized
INFO - 2021-04-06 11:10:46 --> Helper loaded: url_helper
INFO - 2021-04-06 11:10:46 --> Helper loaded: file_helper
INFO - 2021-04-06 11:10:46 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:10:46 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:10:46 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:10:46 --> Database Driver Class Initialized
INFO - 2021-04-06 11:10:46 --> Email Class Initialized
DEBUG - 2021-04-06 11:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:10:46 --> Helper loaded: form_helper
INFO - 2021-04-06 11:10:46 --> Form Validation Class Initialized
INFO - 2021-04-06 11:10:46 --> Controller Class Initialized
INFO - 2021-04-06 11:10:46 --> Model "Common_model" initialized
INFO - 2021-04-06 11:10:46 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:10:46 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:10:46 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:10:46 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:10:46 --> Database Driver Class Initialized
INFO - 2021-04-06 11:10:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:10:46 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:10:46 --> Final output sent to browser
DEBUG - 2021-04-06 11:10:46 --> Total execution time: 0.6302
INFO - 2021-04-06 11:11:18 --> Config Class Initialized
INFO - 2021-04-06 11:11:18 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:11:18 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:11:18 --> Utf8 Class Initialized
INFO - 2021-04-06 11:11:18 --> URI Class Initialized
INFO - 2021-04-06 11:11:18 --> Router Class Initialized
INFO - 2021-04-06 11:11:18 --> Output Class Initialized
INFO - 2021-04-06 11:11:18 --> Security Class Initialized
DEBUG - 2021-04-06 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:11:18 --> Input Class Initialized
INFO - 2021-04-06 11:11:18 --> Language Class Initialized
INFO - 2021-04-06 11:11:18 --> Loader Class Initialized
INFO - 2021-04-06 11:11:18 --> Helper loaded: url_helper
INFO - 2021-04-06 11:11:18 --> Helper loaded: file_helper
INFO - 2021-04-06 11:11:18 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:11:18 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:11:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:11:18 --> Database Driver Class Initialized
INFO - 2021-04-06 11:11:18 --> Email Class Initialized
DEBUG - 2021-04-06 11:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:11:18 --> Helper loaded: form_helper
INFO - 2021-04-06 11:11:18 --> Form Validation Class Initialized
INFO - 2021-04-06 11:11:18 --> Controller Class Initialized
INFO - 2021-04-06 11:11:18 --> Model "Common_model" initialized
INFO - 2021-04-06 11:11:18 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:11:18 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:11:18 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:11:18 --> Database Driver Class Initialized
INFO - 2021-04-06 11:11:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:11:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:11:18 --> Final output sent to browser
DEBUG - 2021-04-06 11:11:18 --> Total execution time: 0.1874
INFO - 2021-04-06 11:11:19 --> Config Class Initialized
INFO - 2021-04-06 11:11:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:11:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:11:19 --> Utf8 Class Initialized
INFO - 2021-04-06 11:11:19 --> URI Class Initialized
INFO - 2021-04-06 11:11:19 --> Router Class Initialized
INFO - 2021-04-06 11:11:19 --> Output Class Initialized
INFO - 2021-04-06 11:11:19 --> Security Class Initialized
DEBUG - 2021-04-06 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:11:19 --> Input Class Initialized
INFO - 2021-04-06 11:11:19 --> Language Class Initialized
ERROR - 2021-04-06 11:11:19 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:11:19 --> Config Class Initialized
INFO - 2021-04-06 11:11:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:11:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:11:19 --> Utf8 Class Initialized
INFO - 2021-04-06 11:11:19 --> URI Class Initialized
INFO - 2021-04-06 11:11:19 --> Router Class Initialized
INFO - 2021-04-06 11:11:19 --> Output Class Initialized
INFO - 2021-04-06 11:11:19 --> Security Class Initialized
DEBUG - 2021-04-06 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:11:19 --> Input Class Initialized
INFO - 2021-04-06 11:11:19 --> Language Class Initialized
INFO - 2021-04-06 11:11:19 --> Loader Class Initialized
INFO - 2021-04-06 11:11:19 --> Helper loaded: url_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: file_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:11:19 --> Database Driver Class Initialized
INFO - 2021-04-06 11:11:19 --> Email Class Initialized
DEBUG - 2021-04-06 11:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:11:19 --> Helper loaded: form_helper
INFO - 2021-04-06 11:11:19 --> Form Validation Class Initialized
INFO - 2021-04-06 11:11:19 --> Controller Class Initialized
INFO - 2021-04-06 11:11:19 --> Model "Common_model" initialized
INFO - 2021-04-06 11:11:19 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:11:19 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:11:19 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:11:19 --> Config Class Initialized
INFO - 2021-04-06 11:11:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:11:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:11:19 --> Utf8 Class Initialized
INFO - 2021-04-06 11:11:19 --> URI Class Initialized
INFO - 2021-04-06 11:11:19 --> Router Class Initialized
INFO - 2021-04-06 11:11:19 --> Output Class Initialized
INFO - 2021-04-06 11:11:19 --> Security Class Initialized
DEBUG - 2021-04-06 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:11:19 --> Input Class Initialized
INFO - 2021-04-06 11:11:19 --> Language Class Initialized
INFO - 2021-04-06 11:11:19 --> Loader Class Initialized
INFO - 2021-04-06 11:11:19 --> Helper loaded: url_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: file_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:11:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:11:19 --> Database Driver Class Initialized
INFO - 2021-04-06 11:11:19 --> Email Class Initialized
DEBUG - 2021-04-06 11:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:11:19 --> Helper loaded: form_helper
INFO - 2021-04-06 11:11:19 --> Form Validation Class Initialized
INFO - 2021-04-06 11:11:19 --> Controller Class Initialized
INFO - 2021-04-06 11:11:19 --> Model "Common_model" initialized
INFO - 2021-04-06 11:11:19 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:11:19 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:11:19 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:11:19 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:11:19 --> Database Driver Class Initialized
INFO - 2021-04-06 11:11:20 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:11:20 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:11:20 --> Final output sent to browser
DEBUG - 2021-04-06 11:11:20 --> Total execution time: 0.0839
INFO - 2021-04-06 11:12:56 --> Config Class Initialized
INFO - 2021-04-06 11:12:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:12:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:12:56 --> Utf8 Class Initialized
INFO - 2021-04-06 11:12:56 --> URI Class Initialized
INFO - 2021-04-06 11:12:56 --> Router Class Initialized
INFO - 2021-04-06 11:12:56 --> Output Class Initialized
INFO - 2021-04-06 11:12:56 --> Security Class Initialized
DEBUG - 2021-04-06 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:12:56 --> Input Class Initialized
INFO - 2021-04-06 11:12:56 --> Language Class Initialized
INFO - 2021-04-06 11:12:56 --> Loader Class Initialized
INFO - 2021-04-06 11:12:56 --> Helper loaded: url_helper
INFO - 2021-04-06 11:12:56 --> Helper loaded: file_helper
INFO - 2021-04-06 11:12:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:12:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:12:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:12:56 --> Database Driver Class Initialized
INFO - 2021-04-06 11:12:56 --> Email Class Initialized
DEBUG - 2021-04-06 11:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:12:56 --> Helper loaded: form_helper
INFO - 2021-04-06 11:12:56 --> Form Validation Class Initialized
INFO - 2021-04-06 11:12:56 --> Controller Class Initialized
INFO - 2021-04-06 11:12:56 --> Model "Common_model" initialized
INFO - 2021-04-06 11:12:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:12:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:12:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:12:56 --> Database Driver Class Initialized
INFO - 2021-04-06 11:12:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:12:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:12:56 --> Final output sent to browser
DEBUG - 2021-04-06 11:12:56 --> Total execution time: 0.2164
INFO - 2021-04-06 11:12:56 --> Config Class Initialized
INFO - 2021-04-06 11:12:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:12:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:12:56 --> Utf8 Class Initialized
INFO - 2021-04-06 11:12:56 --> URI Class Initialized
INFO - 2021-04-06 11:12:56 --> Router Class Initialized
INFO - 2021-04-06 11:12:56 --> Output Class Initialized
INFO - 2021-04-06 11:12:56 --> Security Class Initialized
DEBUG - 2021-04-06 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:12:56 --> Input Class Initialized
INFO - 2021-04-06 11:12:56 --> Language Class Initialized
ERROR - 2021-04-06 11:12:56 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:12:57 --> Config Class Initialized
INFO - 2021-04-06 11:12:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:12:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:12:57 --> Utf8 Class Initialized
INFO - 2021-04-06 11:12:57 --> URI Class Initialized
INFO - 2021-04-06 11:12:57 --> Router Class Initialized
INFO - 2021-04-06 11:12:57 --> Output Class Initialized
INFO - 2021-04-06 11:12:57 --> Security Class Initialized
DEBUG - 2021-04-06 11:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:12:57 --> Input Class Initialized
INFO - 2021-04-06 11:12:57 --> Language Class Initialized
INFO - 2021-04-06 11:12:57 --> Loader Class Initialized
INFO - 2021-04-06 11:12:57 --> Helper loaded: url_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: file_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:12:57 --> Database Driver Class Initialized
INFO - 2021-04-06 11:12:57 --> Email Class Initialized
DEBUG - 2021-04-06 11:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:12:57 --> Helper loaded: form_helper
INFO - 2021-04-06 11:12:57 --> Form Validation Class Initialized
INFO - 2021-04-06 11:12:57 --> Controller Class Initialized
INFO - 2021-04-06 11:12:57 --> Model "Common_model" initialized
INFO - 2021-04-06 11:12:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:12:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:12:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:12:57 --> Config Class Initialized
INFO - 2021-04-06 11:12:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:12:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:12:57 --> Utf8 Class Initialized
INFO - 2021-04-06 11:12:57 --> URI Class Initialized
INFO - 2021-04-06 11:12:57 --> Router Class Initialized
INFO - 2021-04-06 11:12:57 --> Output Class Initialized
INFO - 2021-04-06 11:12:57 --> Security Class Initialized
DEBUG - 2021-04-06 11:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:12:57 --> Input Class Initialized
INFO - 2021-04-06 11:12:57 --> Language Class Initialized
INFO - 2021-04-06 11:12:57 --> Loader Class Initialized
INFO - 2021-04-06 11:12:57 --> Helper loaded: url_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: file_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:12:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:12:57 --> Database Driver Class Initialized
INFO - 2021-04-06 11:12:57 --> Email Class Initialized
DEBUG - 2021-04-06 11:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:12:57 --> Helper loaded: form_helper
INFO - 2021-04-06 11:12:57 --> Form Validation Class Initialized
INFO - 2021-04-06 11:12:57 --> Controller Class Initialized
INFO - 2021-04-06 11:12:57 --> Model "Common_model" initialized
INFO - 2021-04-06 11:12:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:12:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:12:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:12:57 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:12:57 --> Database Driver Class Initialized
INFO - 2021-04-06 11:12:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:12:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:12:57 --> Final output sent to browser
DEBUG - 2021-04-06 11:12:57 --> Total execution time: 0.0932
INFO - 2021-04-06 11:15:14 --> Config Class Initialized
INFO - 2021-04-06 11:15:14 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:15:14 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:15:14 --> Utf8 Class Initialized
INFO - 2021-04-06 11:15:14 --> URI Class Initialized
INFO - 2021-04-06 11:15:14 --> Router Class Initialized
INFO - 2021-04-06 11:15:14 --> Output Class Initialized
INFO - 2021-04-06 11:15:14 --> Security Class Initialized
DEBUG - 2021-04-06 11:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:15:14 --> Input Class Initialized
INFO - 2021-04-06 11:15:14 --> Language Class Initialized
INFO - 2021-04-06 11:15:14 --> Loader Class Initialized
INFO - 2021-04-06 11:15:14 --> Helper loaded: url_helper
INFO - 2021-04-06 11:15:14 --> Helper loaded: file_helper
INFO - 2021-04-06 11:15:14 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:15:14 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:15:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:15:14 --> Database Driver Class Initialized
INFO - 2021-04-06 11:15:14 --> Email Class Initialized
DEBUG - 2021-04-06 11:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:15:14 --> Helper loaded: form_helper
INFO - 2021-04-06 11:15:14 --> Form Validation Class Initialized
INFO - 2021-04-06 11:15:14 --> Controller Class Initialized
INFO - 2021-04-06 11:15:14 --> Model "Common_model" initialized
INFO - 2021-04-06 11:15:14 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:15:14 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:15:14 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:15:14 --> Database Driver Class Initialized
INFO - 2021-04-06 11:15:14 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:15:14 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:15:14 --> Final output sent to browser
DEBUG - 2021-04-06 11:15:14 --> Total execution time: 0.2701
INFO - 2021-04-06 11:15:15 --> Config Class Initialized
INFO - 2021-04-06 11:15:15 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:15:15 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:15:15 --> Utf8 Class Initialized
INFO - 2021-04-06 11:15:15 --> URI Class Initialized
INFO - 2021-04-06 11:15:15 --> Router Class Initialized
INFO - 2021-04-06 11:15:15 --> Output Class Initialized
INFO - 2021-04-06 11:15:15 --> Security Class Initialized
DEBUG - 2021-04-06 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:15:15 --> Input Class Initialized
INFO - 2021-04-06 11:15:15 --> Language Class Initialized
ERROR - 2021-04-06 11:15:15 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:15:15 --> Config Class Initialized
INFO - 2021-04-06 11:15:15 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:15:15 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:15:15 --> Utf8 Class Initialized
INFO - 2021-04-06 11:15:15 --> URI Class Initialized
INFO - 2021-04-06 11:15:15 --> Router Class Initialized
INFO - 2021-04-06 11:15:15 --> Output Class Initialized
INFO - 2021-04-06 11:15:15 --> Security Class Initialized
DEBUG - 2021-04-06 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:15:15 --> Input Class Initialized
INFO - 2021-04-06 11:15:15 --> Language Class Initialized
INFO - 2021-04-06 11:15:15 --> Loader Class Initialized
INFO - 2021-04-06 11:15:15 --> Helper loaded: url_helper
INFO - 2021-04-06 11:15:15 --> Helper loaded: file_helper
INFO - 2021-04-06 11:15:15 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:15:15 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:15:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:15:15 --> Database Driver Class Initialized
INFO - 2021-04-06 11:15:15 --> Email Class Initialized
DEBUG - 2021-04-06 11:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:15:15 --> Helper loaded: form_helper
INFO - 2021-04-06 11:15:15 --> Form Validation Class Initialized
INFO - 2021-04-06 11:15:15 --> Controller Class Initialized
INFO - 2021-04-06 11:15:15 --> Model "Common_model" initialized
INFO - 2021-04-06 11:15:15 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:15:15 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:15:15 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:15:16 --> Config Class Initialized
INFO - 2021-04-06 11:15:16 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:15:16 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:15:16 --> Utf8 Class Initialized
INFO - 2021-04-06 11:15:16 --> URI Class Initialized
INFO - 2021-04-06 11:15:16 --> Router Class Initialized
INFO - 2021-04-06 11:15:16 --> Output Class Initialized
INFO - 2021-04-06 11:15:16 --> Security Class Initialized
DEBUG - 2021-04-06 11:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:15:16 --> Input Class Initialized
INFO - 2021-04-06 11:15:16 --> Language Class Initialized
INFO - 2021-04-06 11:15:16 --> Loader Class Initialized
INFO - 2021-04-06 11:15:16 --> Helper loaded: url_helper
INFO - 2021-04-06 11:15:16 --> Helper loaded: file_helper
INFO - 2021-04-06 11:15:16 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:15:16 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:15:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:15:16 --> Database Driver Class Initialized
INFO - 2021-04-06 11:15:16 --> Email Class Initialized
DEBUG - 2021-04-06 11:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:15:16 --> Helper loaded: form_helper
INFO - 2021-04-06 11:15:16 --> Form Validation Class Initialized
INFO - 2021-04-06 11:15:16 --> Controller Class Initialized
INFO - 2021-04-06 11:15:16 --> Model "Common_model" initialized
INFO - 2021-04-06 11:15:16 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:15:16 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:15:16 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:15:16 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:15:16 --> Database Driver Class Initialized
INFO - 2021-04-06 11:15:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:15:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:15:16 --> Final output sent to browser
DEBUG - 2021-04-06 11:15:16 --> Total execution time: 0.1148
INFO - 2021-04-06 11:25:23 --> Config Class Initialized
INFO - 2021-04-06 11:25:23 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:25:23 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:25:23 --> Utf8 Class Initialized
INFO - 2021-04-06 11:25:23 --> URI Class Initialized
INFO - 2021-04-06 11:25:23 --> Router Class Initialized
INFO - 2021-04-06 11:25:23 --> Output Class Initialized
INFO - 2021-04-06 11:25:23 --> Security Class Initialized
DEBUG - 2021-04-06 11:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:25:23 --> Input Class Initialized
INFO - 2021-04-06 11:25:23 --> Language Class Initialized
INFO - 2021-04-06 11:25:23 --> Loader Class Initialized
INFO - 2021-04-06 11:25:23 --> Helper loaded: url_helper
INFO - 2021-04-06 11:25:23 --> Helper loaded: file_helper
INFO - 2021-04-06 11:25:23 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:25:23 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:25:23 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:25:23 --> Database Driver Class Initialized
INFO - 2021-04-06 11:25:23 --> Email Class Initialized
DEBUG - 2021-04-06 11:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:25:23 --> Helper loaded: form_helper
INFO - 2021-04-06 11:25:23 --> Form Validation Class Initialized
INFO - 2021-04-06 11:25:23 --> Controller Class Initialized
INFO - 2021-04-06 11:25:23 --> Model "Common_model" initialized
INFO - 2021-04-06 11:25:23 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:25:23 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:25:23 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:25:23 --> Database Driver Class Initialized
INFO - 2021-04-06 11:25:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:25:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:25:23 --> Final output sent to browser
DEBUG - 2021-04-06 11:25:23 --> Total execution time: 0.2382
INFO - 2021-04-06 11:25:25 --> Config Class Initialized
INFO - 2021-04-06 11:25:25 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:25:25 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:25:25 --> Utf8 Class Initialized
INFO - 2021-04-06 11:25:25 --> URI Class Initialized
INFO - 2021-04-06 11:25:25 --> Router Class Initialized
INFO - 2021-04-06 11:25:25 --> Output Class Initialized
INFO - 2021-04-06 11:25:25 --> Security Class Initialized
DEBUG - 2021-04-06 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:25:25 --> Input Class Initialized
INFO - 2021-04-06 11:25:25 --> Language Class Initialized
ERROR - 2021-04-06 11:25:25 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:25:25 --> Config Class Initialized
INFO - 2021-04-06 11:25:25 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:25:25 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:25:25 --> Utf8 Class Initialized
INFO - 2021-04-06 11:25:25 --> URI Class Initialized
INFO - 2021-04-06 11:25:25 --> Router Class Initialized
INFO - 2021-04-06 11:25:25 --> Output Class Initialized
INFO - 2021-04-06 11:25:25 --> Security Class Initialized
DEBUG - 2021-04-06 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:25:25 --> Input Class Initialized
INFO - 2021-04-06 11:25:25 --> Language Class Initialized
INFO - 2021-04-06 11:25:25 --> Loader Class Initialized
INFO - 2021-04-06 11:25:25 --> Helper loaded: url_helper
INFO - 2021-04-06 11:25:25 --> Helper loaded: file_helper
INFO - 2021-04-06 11:25:25 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:25:25 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:25:25 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:25:25 --> Database Driver Class Initialized
INFO - 2021-04-06 11:25:25 --> Email Class Initialized
DEBUG - 2021-04-06 11:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:25:25 --> Helper loaded: form_helper
INFO - 2021-04-06 11:25:25 --> Form Validation Class Initialized
INFO - 2021-04-06 11:25:25 --> Controller Class Initialized
INFO - 2021-04-06 11:25:25 --> Model "Common_model" initialized
INFO - 2021-04-06 11:25:25 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:25:25 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:25:25 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:25:26 --> Config Class Initialized
INFO - 2021-04-06 11:25:26 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:25:26 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:25:26 --> Utf8 Class Initialized
INFO - 2021-04-06 11:25:26 --> URI Class Initialized
INFO - 2021-04-06 11:25:26 --> Router Class Initialized
INFO - 2021-04-06 11:25:26 --> Output Class Initialized
INFO - 2021-04-06 11:25:26 --> Security Class Initialized
DEBUG - 2021-04-06 11:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:25:26 --> Input Class Initialized
INFO - 2021-04-06 11:25:26 --> Language Class Initialized
INFO - 2021-04-06 11:25:26 --> Loader Class Initialized
INFO - 2021-04-06 11:25:26 --> Helper loaded: url_helper
INFO - 2021-04-06 11:25:26 --> Helper loaded: file_helper
INFO - 2021-04-06 11:25:26 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:25:26 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:25:26 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:25:26 --> Database Driver Class Initialized
INFO - 2021-04-06 11:25:26 --> Email Class Initialized
DEBUG - 2021-04-06 11:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:25:26 --> Helper loaded: form_helper
INFO - 2021-04-06 11:25:26 --> Form Validation Class Initialized
INFO - 2021-04-06 11:25:26 --> Controller Class Initialized
INFO - 2021-04-06 11:25:26 --> Model "Common_model" initialized
INFO - 2021-04-06 11:25:26 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:25:26 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:25:26 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:25:26 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:25:26 --> Database Driver Class Initialized
INFO - 2021-04-06 11:25:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:25:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:25:26 --> Final output sent to browser
DEBUG - 2021-04-06 11:25:26 --> Total execution time: 0.6617
INFO - 2021-04-06 11:26:41 --> Config Class Initialized
INFO - 2021-04-06 11:26:41 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:26:41 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:26:41 --> Utf8 Class Initialized
INFO - 2021-04-06 11:26:41 --> URI Class Initialized
INFO - 2021-04-06 11:26:41 --> Router Class Initialized
INFO - 2021-04-06 11:26:41 --> Output Class Initialized
INFO - 2021-04-06 11:26:41 --> Security Class Initialized
DEBUG - 2021-04-06 11:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:26:41 --> Input Class Initialized
INFO - 2021-04-06 11:26:41 --> Language Class Initialized
INFO - 2021-04-06 11:26:41 --> Loader Class Initialized
INFO - 2021-04-06 11:26:41 --> Helper loaded: url_helper
INFO - 2021-04-06 11:26:41 --> Helper loaded: file_helper
INFO - 2021-04-06 11:26:41 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:26:41 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:26:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:26:41 --> Database Driver Class Initialized
INFO - 2021-04-06 11:26:41 --> Email Class Initialized
DEBUG - 2021-04-06 11:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:26:41 --> Helper loaded: form_helper
INFO - 2021-04-06 11:26:41 --> Form Validation Class Initialized
INFO - 2021-04-06 11:26:41 --> Controller Class Initialized
INFO - 2021-04-06 11:26:41 --> Model "Common_model" initialized
INFO - 2021-04-06 11:26:41 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:26:41 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:26:41 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:26:41 --> Database Driver Class Initialized
INFO - 2021-04-06 11:26:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:26:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:26:41 --> Final output sent to browser
DEBUG - 2021-04-06 11:26:41 --> Total execution time: 0.2287
INFO - 2021-04-06 11:26:42 --> Config Class Initialized
INFO - 2021-04-06 11:26:42 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:26:42 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:26:42 --> Utf8 Class Initialized
INFO - 2021-04-06 11:26:42 --> URI Class Initialized
INFO - 2021-04-06 11:26:42 --> Router Class Initialized
INFO - 2021-04-06 11:26:42 --> Output Class Initialized
INFO - 2021-04-06 11:26:42 --> Security Class Initialized
DEBUG - 2021-04-06 11:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:26:42 --> Input Class Initialized
INFO - 2021-04-06 11:26:42 --> Language Class Initialized
ERROR - 2021-04-06 11:26:42 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:26:42 --> Config Class Initialized
INFO - 2021-04-06 11:26:42 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:26:42 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:26:42 --> Utf8 Class Initialized
INFO - 2021-04-06 11:26:42 --> URI Class Initialized
INFO - 2021-04-06 11:26:42 --> Router Class Initialized
INFO - 2021-04-06 11:26:42 --> Output Class Initialized
INFO - 2021-04-06 11:26:42 --> Security Class Initialized
DEBUG - 2021-04-06 11:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:26:42 --> Input Class Initialized
INFO - 2021-04-06 11:26:42 --> Language Class Initialized
INFO - 2021-04-06 11:26:42 --> Loader Class Initialized
INFO - 2021-04-06 11:26:42 --> Helper loaded: url_helper
INFO - 2021-04-06 11:26:42 --> Helper loaded: file_helper
INFO - 2021-04-06 11:26:42 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:26:42 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:26:42 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:26:42 --> Database Driver Class Initialized
INFO - 2021-04-06 11:26:42 --> Email Class Initialized
DEBUG - 2021-04-06 11:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:26:42 --> Helper loaded: form_helper
INFO - 2021-04-06 11:26:42 --> Form Validation Class Initialized
INFO - 2021-04-06 11:26:42 --> Controller Class Initialized
INFO - 2021-04-06 11:26:42 --> Model "Common_model" initialized
INFO - 2021-04-06 11:26:42 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:26:42 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:26:42 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:26:43 --> Config Class Initialized
INFO - 2021-04-06 11:26:43 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:26:43 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:26:43 --> Utf8 Class Initialized
INFO - 2021-04-06 11:26:43 --> URI Class Initialized
INFO - 2021-04-06 11:26:43 --> Router Class Initialized
INFO - 2021-04-06 11:26:43 --> Output Class Initialized
INFO - 2021-04-06 11:26:43 --> Security Class Initialized
DEBUG - 2021-04-06 11:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:26:43 --> Input Class Initialized
INFO - 2021-04-06 11:26:43 --> Language Class Initialized
INFO - 2021-04-06 11:26:43 --> Loader Class Initialized
INFO - 2021-04-06 11:26:43 --> Helper loaded: url_helper
INFO - 2021-04-06 11:26:43 --> Helper loaded: file_helper
INFO - 2021-04-06 11:26:43 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:26:43 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:26:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:26:43 --> Database Driver Class Initialized
INFO - 2021-04-06 11:26:43 --> Email Class Initialized
DEBUG - 2021-04-06 11:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:26:43 --> Helper loaded: form_helper
INFO - 2021-04-06 11:26:43 --> Form Validation Class Initialized
INFO - 2021-04-06 11:26:43 --> Controller Class Initialized
INFO - 2021-04-06 11:26:43 --> Model "Common_model" initialized
INFO - 2021-04-06 11:26:43 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:26:43 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:26:43 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:26:43 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:26:43 --> Database Driver Class Initialized
INFO - 2021-04-06 11:26:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:26:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:26:43 --> Final output sent to browser
DEBUG - 2021-04-06 11:26:43 --> Total execution time: 0.0758
INFO - 2021-04-06 11:28:18 --> Config Class Initialized
INFO - 2021-04-06 11:28:18 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:28:18 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:28:18 --> Utf8 Class Initialized
INFO - 2021-04-06 11:28:18 --> URI Class Initialized
INFO - 2021-04-06 11:28:18 --> Router Class Initialized
INFO - 2021-04-06 11:28:18 --> Output Class Initialized
INFO - 2021-04-06 11:28:18 --> Security Class Initialized
DEBUG - 2021-04-06 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:28:18 --> Input Class Initialized
INFO - 2021-04-06 11:28:18 --> Language Class Initialized
INFO - 2021-04-06 11:28:18 --> Loader Class Initialized
INFO - 2021-04-06 11:28:18 --> Helper loaded: url_helper
INFO - 2021-04-06 11:28:18 --> Helper loaded: file_helper
INFO - 2021-04-06 11:28:18 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:28:18 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:28:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:28:18 --> Database Driver Class Initialized
INFO - 2021-04-06 11:28:18 --> Email Class Initialized
DEBUG - 2021-04-06 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:28:18 --> Helper loaded: form_helper
INFO - 2021-04-06 11:28:18 --> Form Validation Class Initialized
INFO - 2021-04-06 11:28:18 --> Controller Class Initialized
INFO - 2021-04-06 11:28:18 --> Model "Common_model" initialized
INFO - 2021-04-06 11:28:18 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:28:18 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:28:18 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:28:18 --> Database Driver Class Initialized
INFO - 2021-04-06 11:28:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 11:28:19 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:28:19 --> Final output sent to browser
DEBUG - 2021-04-06 11:28:19 --> Total execution time: 0.1877
INFO - 2021-04-06 11:28:19 --> Config Class Initialized
INFO - 2021-04-06 11:28:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:28:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:28:19 --> Utf8 Class Initialized
INFO - 2021-04-06 11:28:19 --> URI Class Initialized
INFO - 2021-04-06 11:28:19 --> Router Class Initialized
INFO - 2021-04-06 11:28:19 --> Output Class Initialized
INFO - 2021-04-06 11:28:19 --> Security Class Initialized
DEBUG - 2021-04-06 11:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:28:19 --> Input Class Initialized
INFO - 2021-04-06 11:28:19 --> Language Class Initialized
ERROR - 2021-04-06 11:28:19 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:28:20 --> Config Class Initialized
INFO - 2021-04-06 11:28:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:28:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:28:20 --> Utf8 Class Initialized
INFO - 2021-04-06 11:28:20 --> URI Class Initialized
INFO - 2021-04-06 11:28:20 --> Router Class Initialized
INFO - 2021-04-06 11:28:20 --> Output Class Initialized
INFO - 2021-04-06 11:28:20 --> Security Class Initialized
DEBUG - 2021-04-06 11:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:28:20 --> Input Class Initialized
INFO - 2021-04-06 11:28:20 --> Language Class Initialized
INFO - 2021-04-06 11:28:20 --> Loader Class Initialized
INFO - 2021-04-06 11:28:20 --> Helper loaded: url_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: file_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:28:20 --> Database Driver Class Initialized
INFO - 2021-04-06 11:28:20 --> Email Class Initialized
DEBUG - 2021-04-06 11:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:28:20 --> Helper loaded: form_helper
INFO - 2021-04-06 11:28:20 --> Form Validation Class Initialized
INFO - 2021-04-06 11:28:20 --> Controller Class Initialized
INFO - 2021-04-06 11:28:20 --> Model "Common_model" initialized
INFO - 2021-04-06 11:28:20 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:28:20 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:28:20 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:28:20 --> Config Class Initialized
INFO - 2021-04-06 11:28:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:28:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:28:20 --> Utf8 Class Initialized
INFO - 2021-04-06 11:28:20 --> URI Class Initialized
INFO - 2021-04-06 11:28:20 --> Router Class Initialized
INFO - 2021-04-06 11:28:20 --> Output Class Initialized
INFO - 2021-04-06 11:28:20 --> Security Class Initialized
DEBUG - 2021-04-06 11:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:28:20 --> Input Class Initialized
INFO - 2021-04-06 11:28:20 --> Language Class Initialized
INFO - 2021-04-06 11:28:20 --> Loader Class Initialized
INFO - 2021-04-06 11:28:20 --> Helper loaded: url_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: file_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:28:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:28:20 --> Database Driver Class Initialized
INFO - 2021-04-06 11:28:20 --> Email Class Initialized
DEBUG - 2021-04-06 11:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:28:20 --> Helper loaded: form_helper
INFO - 2021-04-06 11:28:20 --> Form Validation Class Initialized
INFO - 2021-04-06 11:28:20 --> Controller Class Initialized
INFO - 2021-04-06 11:28:20 --> Model "Common_model" initialized
INFO - 2021-04-06 11:28:20 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:28:20 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:28:20 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:28:20 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:28:20 --> Database Driver Class Initialized
INFO - 2021-04-06 11:28:20 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:28:20 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:28:20 --> Final output sent to browser
DEBUG - 2021-04-06 11:28:20 --> Total execution time: 0.0863
INFO - 2021-04-06 11:29:41 --> Config Class Initialized
INFO - 2021-04-06 11:29:41 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:29:41 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:29:41 --> Utf8 Class Initialized
INFO - 2021-04-06 11:29:41 --> URI Class Initialized
DEBUG - 2021-04-06 11:29:41 --> No URI present. Default controller set.
INFO - 2021-04-06 11:29:41 --> Router Class Initialized
INFO - 2021-04-06 11:29:41 --> Output Class Initialized
INFO - 2021-04-06 11:29:41 --> Security Class Initialized
DEBUG - 2021-04-06 11:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:29:41 --> Input Class Initialized
INFO - 2021-04-06 11:29:41 --> Language Class Initialized
INFO - 2021-04-06 11:29:41 --> Loader Class Initialized
INFO - 2021-04-06 11:29:41 --> Helper loaded: url_helper
INFO - 2021-04-06 11:29:41 --> Helper loaded: file_helper
INFO - 2021-04-06 11:29:41 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:29:41 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:29:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:29:41 --> Database Driver Class Initialized
INFO - 2021-04-06 11:29:41 --> Email Class Initialized
DEBUG - 2021-04-06 11:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:29:41 --> Helper loaded: form_helper
INFO - 2021-04-06 11:29:41 --> Form Validation Class Initialized
INFO - 2021-04-06 11:29:41 --> Controller Class Initialized
INFO - 2021-04-06 11:29:41 --> Model "Common_model" initialized
INFO - 2021-04-06 11:29:41 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:29:41 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:29:41 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:29:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 11:29:41 --> Final output sent to browser
DEBUG - 2021-04-06 11:29:41 --> Total execution time: 0.0419
INFO - 2021-04-06 11:30:16 --> Config Class Initialized
INFO - 2021-04-06 11:30:16 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:30:16 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:30:16 --> Utf8 Class Initialized
INFO - 2021-04-06 11:30:16 --> URI Class Initialized
INFO - 2021-04-06 11:30:16 --> Router Class Initialized
INFO - 2021-04-06 11:30:16 --> Output Class Initialized
INFO - 2021-04-06 11:30:16 --> Security Class Initialized
DEBUG - 2021-04-06 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:30:16 --> Input Class Initialized
INFO - 2021-04-06 11:30:16 --> Language Class Initialized
INFO - 2021-04-06 11:30:16 --> Loader Class Initialized
INFO - 2021-04-06 11:30:16 --> Helper loaded: url_helper
INFO - 2021-04-06 11:30:16 --> Helper loaded: file_helper
INFO - 2021-04-06 11:30:16 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:30:16 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:30:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:30:16 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:16 --> Email Class Initialized
DEBUG - 2021-04-06 11:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:30:16 --> Helper loaded: form_helper
INFO - 2021-04-06 11:30:16 --> Form Validation Class Initialized
INFO - 2021-04-06 11:30:16 --> Controller Class Initialized
INFO - 2021-04-06 11:30:16 --> Model "Common_model" initialized
INFO - 2021-04-06 11:30:16 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:30:16 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:30:16 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:30:16 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:30:16 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 11:30:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 11:30:18 --> Final output sent to browser
DEBUG - 2021-04-06 11:30:18 --> Total execution time: 1.7742
INFO - 2021-04-06 11:30:19 --> Config Class Initialized
INFO - 2021-04-06 11:30:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:30:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:30:19 --> Utf8 Class Initialized
INFO - 2021-04-06 11:30:19 --> URI Class Initialized
INFO - 2021-04-06 11:30:19 --> Router Class Initialized
INFO - 2021-04-06 11:30:19 --> Output Class Initialized
INFO - 2021-04-06 11:30:19 --> Security Class Initialized
DEBUG - 2021-04-06 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:30:19 --> Input Class Initialized
INFO - 2021-04-06 11:30:19 --> Language Class Initialized
ERROR - 2021-04-06 11:30:19 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:30:19 --> Config Class Initialized
INFO - 2021-04-06 11:30:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:30:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:30:19 --> Utf8 Class Initialized
INFO - 2021-04-06 11:30:19 --> URI Class Initialized
INFO - 2021-04-06 11:30:19 --> Router Class Initialized
INFO - 2021-04-06 11:30:19 --> Output Class Initialized
INFO - 2021-04-06 11:30:19 --> Security Class Initialized
DEBUG - 2021-04-06 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:30:19 --> Input Class Initialized
INFO - 2021-04-06 11:30:19 --> Language Class Initialized
INFO - 2021-04-06 11:30:19 --> Loader Class Initialized
INFO - 2021-04-06 11:30:19 --> Helper loaded: url_helper
INFO - 2021-04-06 11:30:19 --> Helper loaded: file_helper
INFO - 2021-04-06 11:30:19 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:30:19 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:30:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:30:19 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:19 --> Email Class Initialized
DEBUG - 2021-04-06 11:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:30:19 --> Helper loaded: form_helper
INFO - 2021-04-06 11:30:19 --> Form Validation Class Initialized
INFO - 2021-04-06 11:30:19 --> Controller Class Initialized
INFO - 2021-04-06 11:30:19 --> Model "Common_model" initialized
INFO - 2021-04-06 11:30:19 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:30:19 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:30:19 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:30:19 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:30:19 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:20 --> Config Class Initialized
INFO - 2021-04-06 11:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:30:20 --> Utf8 Class Initialized
INFO - 2021-04-06 11:30:20 --> URI Class Initialized
INFO - 2021-04-06 11:30:20 --> Router Class Initialized
INFO - 2021-04-06 11:30:20 --> Output Class Initialized
INFO - 2021-04-06 11:30:20 --> Security Class Initialized
DEBUG - 2021-04-06 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:30:20 --> Input Class Initialized
INFO - 2021-04-06 11:30:20 --> Language Class Initialized
INFO - 2021-04-06 11:30:20 --> Loader Class Initialized
INFO - 2021-04-06 11:30:20 --> Helper loaded: url_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: file_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:30:20 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:20 --> Email Class Initialized
DEBUG - 2021-04-06 11:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:30:20 --> Config Class Initialized
INFO - 2021-04-06 11:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:30:20 --> Utf8 Class Initialized
INFO - 2021-04-06 11:30:20 --> URI Class Initialized
INFO - 2021-04-06 11:30:20 --> Router Class Initialized
INFO - 2021-04-06 11:30:20 --> Output Class Initialized
INFO - 2021-04-06 11:30:20 --> Security Class Initialized
DEBUG - 2021-04-06 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:30:20 --> Input Class Initialized
INFO - 2021-04-06 11:30:20 --> Language Class Initialized
INFO - 2021-04-06 11:30:20 --> Loader Class Initialized
INFO - 2021-04-06 11:30:20 --> Helper loaded: url_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: file_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:30:20 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:20 --> Email Class Initialized
DEBUG - 2021-04-06 11:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:30:20 --> Config Class Initialized
INFO - 2021-04-06 11:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:30:20 --> Utf8 Class Initialized
INFO - 2021-04-06 11:30:20 --> URI Class Initialized
INFO - 2021-04-06 11:30:20 --> Router Class Initialized
INFO - 2021-04-06 11:30:20 --> Output Class Initialized
INFO - 2021-04-06 11:30:20 --> Security Class Initialized
DEBUG - 2021-04-06 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:30:20 --> Input Class Initialized
INFO - 2021-04-06 11:30:20 --> Language Class Initialized
INFO - 2021-04-06 11:30:20 --> Loader Class Initialized
INFO - 2021-04-06 11:30:20 --> Helper loaded: url_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: file_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:30:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:30:20 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:20 --> Email Class Initialized
DEBUG - 2021-04-06 11:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:30:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 11:30:21 --> Final output sent to browser
DEBUG - 2021-04-06 11:30:21 --> Total execution time: 2.4755
INFO - 2021-04-06 11:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:30:21 --> Helper loaded: form_helper
INFO - 2021-04-06 11:30:21 --> Form Validation Class Initialized
INFO - 2021-04-06 11:30:21 --> Controller Class Initialized
INFO - 2021-04-06 11:30:21 --> Model "Common_model" initialized
INFO - 2021-04-06 11:30:21 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:30:21 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:30:21 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:30:21 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:30:21 --> Database Driver Class Initialized
ERROR - 2021-04-06 11:30:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 11:30:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 11:30:22 --> Final output sent to browser
DEBUG - 2021-04-06 11:30:22 --> Total execution time: 1.7738
INFO - 2021-04-06 11:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:30:22 --> Helper loaded: form_helper
INFO - 2021-04-06 11:30:22 --> Form Validation Class Initialized
INFO - 2021-04-06 11:30:22 --> Controller Class Initialized
INFO - 2021-04-06 11:30:22 --> Model "Common_model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:30:22 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 11:30:22 --> Final output sent to browser
DEBUG - 2021-04-06 11:30:22 --> Total execution time: 1.5249
INFO - 2021-04-06 11:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:30:22 --> Helper loaded: form_helper
INFO - 2021-04-06 11:30:22 --> Form Validation Class Initialized
INFO - 2021-04-06 11:30:22 --> Controller Class Initialized
INFO - 2021-04-06 11:30:22 --> Model "Common_model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:30:22 --> Config Class Initialized
INFO - 2021-04-06 11:30:22 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:30:22 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:30:22 --> Utf8 Class Initialized
INFO - 2021-04-06 11:30:22 --> URI Class Initialized
INFO - 2021-04-06 11:30:22 --> Router Class Initialized
INFO - 2021-04-06 11:30:22 --> Output Class Initialized
INFO - 2021-04-06 11:30:22 --> Security Class Initialized
DEBUG - 2021-04-06 11:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:30:22 --> Input Class Initialized
INFO - 2021-04-06 11:30:22 --> Language Class Initialized
INFO - 2021-04-06 11:30:22 --> Loader Class Initialized
INFO - 2021-04-06 11:30:22 --> Helper loaded: url_helper
INFO - 2021-04-06 11:30:22 --> Helper loaded: file_helper
INFO - 2021-04-06 11:30:22 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:30:22 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:30:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:30:22 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:22 --> Email Class Initialized
DEBUG - 2021-04-06 11:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:30:22 --> Helper loaded: form_helper
INFO - 2021-04-06 11:30:22 --> Form Validation Class Initialized
INFO - 2021-04-06 11:30:22 --> Controller Class Initialized
INFO - 2021-04-06 11:30:22 --> Model "Common_model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:30:22 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:30:22 --> Database Driver Class Initialized
INFO - 2021-04-06 11:30:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:30:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:30:22 --> Final output sent to browser
DEBUG - 2021-04-06 11:30:22 --> Total execution time: 0.1086
INFO - 2021-04-06 11:32:34 --> Config Class Initialized
INFO - 2021-04-06 11:32:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:32:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:32:34 --> Utf8 Class Initialized
INFO - 2021-04-06 11:32:34 --> URI Class Initialized
INFO - 2021-04-06 11:32:34 --> Router Class Initialized
INFO - 2021-04-06 11:32:34 --> Output Class Initialized
INFO - 2021-04-06 11:32:34 --> Security Class Initialized
DEBUG - 2021-04-06 11:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:32:34 --> Input Class Initialized
INFO - 2021-04-06 11:32:34 --> Language Class Initialized
INFO - 2021-04-06 11:32:34 --> Loader Class Initialized
INFO - 2021-04-06 11:32:34 --> Helper loaded: url_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: file_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:32:34 --> Database Driver Class Initialized
INFO - 2021-04-06 11:32:34 --> Email Class Initialized
DEBUG - 2021-04-06 11:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:32:34 --> Helper loaded: form_helper
INFO - 2021-04-06 11:32:34 --> Form Validation Class Initialized
INFO - 2021-04-06 11:32:34 --> Controller Class Initialized
INFO - 2021-04-06 11:32:34 --> Model "Common_model" initialized
INFO - 2021-04-06 11:32:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:32:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:32:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:32:34 --> Config Class Initialized
INFO - 2021-04-06 11:32:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:32:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:32:34 --> Utf8 Class Initialized
INFO - 2021-04-06 11:32:34 --> URI Class Initialized
INFO - 2021-04-06 11:32:34 --> Router Class Initialized
INFO - 2021-04-06 11:32:34 --> Output Class Initialized
INFO - 2021-04-06 11:32:34 --> Security Class Initialized
DEBUG - 2021-04-06 11:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:32:34 --> Input Class Initialized
INFO - 2021-04-06 11:32:34 --> Language Class Initialized
INFO - 2021-04-06 11:32:34 --> Loader Class Initialized
INFO - 2021-04-06 11:32:34 --> Helper loaded: url_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: file_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:32:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:32:34 --> Database Driver Class Initialized
INFO - 2021-04-06 11:32:34 --> Email Class Initialized
DEBUG - 2021-04-06 11:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:32:34 --> Helper loaded: form_helper
INFO - 2021-04-06 11:32:34 --> Form Validation Class Initialized
INFO - 2021-04-06 11:32:34 --> Controller Class Initialized
INFO - 2021-04-06 11:32:34 --> Model "Common_model" initialized
INFO - 2021-04-06 11:32:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:32:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:32:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:32:34 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:32:34 --> Database Driver Class Initialized
INFO - 2021-04-06 11:32:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 11:32:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 11:32:34 --> Final output sent to browser
DEBUG - 2021-04-06 11:32:34 --> Total execution time: 0.0760
INFO - 2021-04-06 11:32:34 --> Config Class Initialized
INFO - 2021-04-06 11:32:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:32:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:32:34 --> Utf8 Class Initialized
INFO - 2021-04-06 11:32:34 --> URI Class Initialized
INFO - 2021-04-06 11:32:34 --> Router Class Initialized
INFO - 2021-04-06 11:32:34 --> Output Class Initialized
INFO - 2021-04-06 11:32:34 --> Security Class Initialized
DEBUG - 2021-04-06 11:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:32:34 --> Input Class Initialized
INFO - 2021-04-06 11:32:34 --> Language Class Initialized
ERROR - 2021-04-06 11:32:34 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 11:33:53 --> Config Class Initialized
INFO - 2021-04-06 11:33:53 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:33:53 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:33:53 --> Utf8 Class Initialized
INFO - 2021-04-06 11:33:53 --> URI Class Initialized
INFO - 2021-04-06 11:33:53 --> Router Class Initialized
INFO - 2021-04-06 11:33:53 --> Output Class Initialized
INFO - 2021-04-06 11:33:53 --> Security Class Initialized
DEBUG - 2021-04-06 11:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:33:53 --> Input Class Initialized
INFO - 2021-04-06 11:33:53 --> Language Class Initialized
INFO - 2021-04-06 11:33:53 --> Loader Class Initialized
INFO - 2021-04-06 11:33:53 --> Helper loaded: url_helper
INFO - 2021-04-06 11:33:53 --> Helper loaded: file_helper
INFO - 2021-04-06 11:33:53 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:33:53 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:33:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:33:53 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:53 --> Email Class Initialized
DEBUG - 2021-04-06 11:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:33:53 --> Helper loaded: form_helper
INFO - 2021-04-06 11:33:53 --> Form Validation Class Initialized
INFO - 2021-04-06 11:33:53 --> Controller Class Initialized
INFO - 2021-04-06 11:33:53 --> Model "Common_model" initialized
INFO - 2021-04-06 11:33:53 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:33:53 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:33:53 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:33:53 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:33:53 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 11:33:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 11:33:55 --> Final output sent to browser
DEBUG - 2021-04-06 11:33:55 --> Total execution time: 1.6336
INFO - 2021-04-06 11:33:55 --> Config Class Initialized
INFO - 2021-04-06 11:33:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:33:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:33:55 --> Utf8 Class Initialized
INFO - 2021-04-06 11:33:55 --> URI Class Initialized
INFO - 2021-04-06 11:33:55 --> Router Class Initialized
INFO - 2021-04-06 11:33:55 --> Output Class Initialized
INFO - 2021-04-06 11:33:55 --> Security Class Initialized
DEBUG - 2021-04-06 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:33:55 --> Input Class Initialized
INFO - 2021-04-06 11:33:55 --> Language Class Initialized
INFO - 2021-04-06 11:33:56 --> Loader Class Initialized
INFO - 2021-04-06 11:33:56 --> Helper loaded: url_helper
INFO - 2021-04-06 11:33:56 --> Helper loaded: file_helper
INFO - 2021-04-06 11:33:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:33:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:33:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:33:56 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:56 --> Email Class Initialized
DEBUG - 2021-04-06 11:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:33:56 --> Helper loaded: form_helper
INFO - 2021-04-06 11:33:56 --> Form Validation Class Initialized
INFO - 2021-04-06 11:33:56 --> Controller Class Initialized
INFO - 2021-04-06 11:33:56 --> Model "Common_model" initialized
INFO - 2021-04-06 11:33:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:33:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:33:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:33:56 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:33:56 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:57 --> Config Class Initialized
INFO - 2021-04-06 11:33:57 --> Hooks Class Initialized
INFO - 2021-04-06 11:33:57 --> Config Class Initialized
INFO - 2021-04-06 11:33:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:33:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:33:57 --> Utf8 Class Initialized
DEBUG - 2021-04-06 11:33:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:33:57 --> Utf8 Class Initialized
INFO - 2021-04-06 11:33:57 --> URI Class Initialized
INFO - 2021-04-06 11:33:57 --> URI Class Initialized
INFO - 2021-04-06 11:33:57 --> Router Class Initialized
INFO - 2021-04-06 11:33:57 --> Router Class Initialized
INFO - 2021-04-06 11:33:57 --> Output Class Initialized
INFO - 2021-04-06 11:33:57 --> Output Class Initialized
INFO - 2021-04-06 11:33:57 --> Security Class Initialized
INFO - 2021-04-06 11:33:57 --> Security Class Initialized
DEBUG - 2021-04-06 11:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:33:57 --> Input Class Initialized
INFO - 2021-04-06 11:33:57 --> Input Class Initialized
INFO - 2021-04-06 11:33:57 --> Language Class Initialized
INFO - 2021-04-06 11:33:57 --> Language Class Initialized
INFO - 2021-04-06 11:33:57 --> Loader Class Initialized
INFO - 2021-04-06 11:33:57 --> Loader Class Initialized
INFO - 2021-04-06 11:33:57 --> Helper loaded: url_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: url_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: file_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: file_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:33:57 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:57 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:57 --> Email Class Initialized
INFO - 2021-04-06 11:33:57 --> Email Class Initialized
DEBUG - 2021-04-06 11:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 11:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:33:57 --> Config Class Initialized
INFO - 2021-04-06 11:33:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 11:33:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 11:33:57 --> Utf8 Class Initialized
INFO - 2021-04-06 11:33:57 --> URI Class Initialized
INFO - 2021-04-06 11:33:57 --> Router Class Initialized
INFO - 2021-04-06 11:33:57 --> Output Class Initialized
INFO - 2021-04-06 11:33:57 --> Security Class Initialized
DEBUG - 2021-04-06 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 11:33:57 --> Input Class Initialized
INFO - 2021-04-06 11:33:57 --> Language Class Initialized
INFO - 2021-04-06 11:33:57 --> Loader Class Initialized
INFO - 2021-04-06 11:33:57 --> Helper loaded: url_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: file_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 11:33:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 11:33:57 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:57 --> Email Class Initialized
DEBUG - 2021-04-06 11:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 11:33:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 11:33:58 --> Final output sent to browser
DEBUG - 2021-04-06 11:33:58 --> Total execution time: 2.0564
INFO - 2021-04-06 11:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:33:58 --> Helper loaded: form_helper
INFO - 2021-04-06 11:33:58 --> Form Validation Class Initialized
INFO - 2021-04-06 11:33:58 --> Controller Class Initialized
INFO - 2021-04-06 11:33:58 --> Model "Common_model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:33:58 --> Database Driver Class Initialized
INFO - 2021-04-06 11:33:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 11:33:58 --> Final output sent to browser
DEBUG - 2021-04-06 11:33:58 --> Total execution time: 0.8589
INFO - 2021-04-06 11:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:33:58 --> Helper loaded: form_helper
INFO - 2021-04-06 11:33:58 --> Form Validation Class Initialized
INFO - 2021-04-06 11:33:58 --> Controller Class Initialized
INFO - 2021-04-06 11:33:58 --> Model "Common_model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 11:33:58 --> Database Driver Class Initialized
ERROR - 2021-04-06 11:33:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 11:33:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 11:33:58 --> Final output sent to browser
DEBUG - 2021-04-06 11:33:58 --> Total execution time: 1.4383
INFO - 2021-04-06 11:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 11:33:58 --> Helper loaded: form_helper
INFO - 2021-04-06 11:33:58 --> Form Validation Class Initialized
INFO - 2021-04-06 11:33:58 --> Controller Class Initialized
INFO - 2021-04-06 11:33:58 --> Model "Common_model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 11:33:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 12:57:50 --> Config Class Initialized
INFO - 2021-04-06 12:57:50 --> Hooks Class Initialized
DEBUG - 2021-04-06 12:57:50 --> UTF-8 Support Enabled
INFO - 2021-04-06 12:57:50 --> Utf8 Class Initialized
INFO - 2021-04-06 12:57:50 --> URI Class Initialized
INFO - 2021-04-06 12:57:50 --> Router Class Initialized
INFO - 2021-04-06 12:57:50 --> Output Class Initialized
INFO - 2021-04-06 12:57:50 --> Security Class Initialized
DEBUG - 2021-04-06 12:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 12:57:50 --> Input Class Initialized
INFO - 2021-04-06 12:57:50 --> Language Class Initialized
ERROR - 2021-04-06 12:57:50 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-06 14:36:54 --> Config Class Initialized
INFO - 2021-04-06 14:36:54 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:36:54 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:36:54 --> Utf8 Class Initialized
INFO - 2021-04-06 14:36:54 --> URI Class Initialized
INFO - 2021-04-06 14:36:54 --> Router Class Initialized
INFO - 2021-04-06 14:36:54 --> Output Class Initialized
INFO - 2021-04-06 14:36:54 --> Security Class Initialized
DEBUG - 2021-04-06 14:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:36:54 --> Input Class Initialized
INFO - 2021-04-06 14:36:54 --> Language Class Initialized
INFO - 2021-04-06 14:36:54 --> Loader Class Initialized
INFO - 2021-04-06 14:36:54 --> Helper loaded: url_helper
INFO - 2021-04-06 14:36:54 --> Helper loaded: file_helper
INFO - 2021-04-06 14:36:54 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:36:54 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:36:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:36:54 --> Database Driver Class Initialized
INFO - 2021-04-06 14:36:54 --> Email Class Initialized
DEBUG - 2021-04-06 14:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:36:54 --> Helper loaded: form_helper
INFO - 2021-04-06 14:36:54 --> Form Validation Class Initialized
INFO - 2021-04-06 14:36:54 --> Controller Class Initialized
INFO - 2021-04-06 14:36:54 --> Model "Common_model" initialized
INFO - 2021-04-06 14:36:54 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:36:54 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:36:54 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:36:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 14:36:54 --> Final output sent to browser
DEBUG - 2021-04-06 14:36:54 --> Total execution time: 0.0821
INFO - 2021-04-06 14:37:15 --> Config Class Initialized
INFO - 2021-04-06 14:37:15 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:15 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:15 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:15 --> URI Class Initialized
INFO - 2021-04-06 14:37:15 --> Router Class Initialized
INFO - 2021-04-06 14:37:15 --> Output Class Initialized
INFO - 2021-04-06 14:37:15 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:15 --> Input Class Initialized
INFO - 2021-04-06 14:37:15 --> Language Class Initialized
INFO - 2021-04-06 14:37:15 --> Loader Class Initialized
INFO - 2021-04-06 14:37:15 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:15 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:15 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:15 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:15 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:15 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:15 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:15 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:15 --> Controller Class Initialized
INFO - 2021-04-06 14:37:15 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:15 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:15 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:15 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:16 --> Config Class Initialized
INFO - 2021-04-06 14:37:16 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:16 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:16 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:16 --> URI Class Initialized
INFO - 2021-04-06 14:37:16 --> Router Class Initialized
INFO - 2021-04-06 14:37:16 --> Output Class Initialized
INFO - 2021-04-06 14:37:16 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:16 --> Input Class Initialized
INFO - 2021-04-06 14:37:16 --> Language Class Initialized
INFO - 2021-04-06 14:37:16 --> Loader Class Initialized
INFO - 2021-04-06 14:37:16 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:16 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:16 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:16 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:16 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:16 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:16 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:16 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:16 --> Controller Class Initialized
INFO - 2021-04-06 14:37:16 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:16 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:16 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:16 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:16 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:16 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:17 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/module.php
INFO - 2021-04-06 14:37:17 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterTemplate.php
INFO - 2021-04-06 14:37:17 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:17 --> Total execution time: 1.8084
INFO - 2021-04-06 14:37:18 --> Config Class Initialized
INFO - 2021-04-06 14:37:18 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:18 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:18 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:18 --> URI Class Initialized
INFO - 2021-04-06 14:37:18 --> Router Class Initialized
INFO - 2021-04-06 14:37:18 --> Output Class Initialized
INFO - 2021-04-06 14:37:18 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:18 --> Input Class Initialized
INFO - 2021-04-06 14:37:18 --> Language Class Initialized
ERROR - 2021-04-06 14:37:18 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 14:37:18 --> Config Class Initialized
INFO - 2021-04-06 14:37:18 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:18 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:18 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:18 --> URI Class Initialized
INFO - 2021-04-06 14:37:18 --> Router Class Initialized
INFO - 2021-04-06 14:37:18 --> Output Class Initialized
INFO - 2021-04-06 14:37:18 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:18 --> Input Class Initialized
INFO - 2021-04-06 14:37:18 --> Language Class Initialized
INFO - 2021-04-06 14:37:18 --> Loader Class Initialized
INFO - 2021-04-06 14:37:18 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:18 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:18 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:18 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:18 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:18 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:18 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:18 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:18 --> Controller Class Initialized
INFO - 2021-04-06 14:37:18 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:18 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:18 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:18 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:18 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:18 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:19 --> Config Class Initialized
INFO - 2021-04-06 14:37:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:19 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:19 --> URI Class Initialized
INFO - 2021-04-06 14:37:19 --> Router Class Initialized
INFO - 2021-04-06 14:37:19 --> Output Class Initialized
INFO - 2021-04-06 14:37:19 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:19 --> Input Class Initialized
INFO - 2021-04-06 14:37:19 --> Language Class Initialized
INFO - 2021-04-06 14:37:19 --> Loader Class Initialized
INFO - 2021-04-06 14:37:19 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:19 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:19 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:19 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:19 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:19 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:19 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:20 --> Config Class Initialized
INFO - 2021-04-06 14:37:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:20 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:20 --> URI Class Initialized
INFO - 2021-04-06 14:37:20 --> Router Class Initialized
INFO - 2021-04-06 14:37:20 --> Output Class Initialized
INFO - 2021-04-06 14:37:20 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:20 --> Input Class Initialized
INFO - 2021-04-06 14:37:20 --> Language Class Initialized
INFO - 2021-04-06 14:37:20 --> Loader Class Initialized
INFO - 2021-04-06 14:37:20 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:20 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:20 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:20 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 14:37:21 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:21 --> Total execution time: 2.2330
INFO - 2021-04-06 14:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:21 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:21 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:21 --> Controller Class Initialized
INFO - 2021-04-06 14:37:21 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:21 --> Database Driver Class Initialized
ERROR - 2021-04-06 14:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 14:37:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 14:37:21 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:21 --> Total execution time: 2.1879
INFO - 2021-04-06 14:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:21 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:21 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:21 --> Controller Class Initialized
INFO - 2021-04-06 14:37:21 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:21 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:21 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 14:37:21 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:21 --> Total execution time: 0.8977
INFO - 2021-04-06 14:37:22 --> Config Class Initialized
INFO - 2021-04-06 14:37:22 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:22 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:22 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:22 --> URI Class Initialized
INFO - 2021-04-06 14:37:22 --> Router Class Initialized
INFO - 2021-04-06 14:37:22 --> Output Class Initialized
INFO - 2021-04-06 14:37:22 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:22 --> Input Class Initialized
INFO - 2021-04-06 14:37:22 --> Language Class Initialized
INFO - 2021-04-06 14:37:22 --> Loader Class Initialized
INFO - 2021-04-06 14:37:22 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:22 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:22 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:22 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:22 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:22 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:22 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:22 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:22 --> Controller Class Initialized
INFO - 2021-04-06 14:37:22 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:23 --> Config Class Initialized
INFO - 2021-04-06 14:37:23 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:23 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:23 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:23 --> URI Class Initialized
INFO - 2021-04-06 14:37:23 --> Router Class Initialized
INFO - 2021-04-06 14:37:23 --> Output Class Initialized
INFO - 2021-04-06 14:37:23 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:23 --> Input Class Initialized
INFO - 2021-04-06 14:37:23 --> Language Class Initialized
INFO - 2021-04-06 14:37:23 --> Loader Class Initialized
INFO - 2021-04-06 14:37:23 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:23 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:23 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:23 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:23 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:23 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:23 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:23 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:23 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:23 --> Controller Class Initialized
INFO - 2021-04-06 14:37:23 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:23 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:23 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:23 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:23 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:23 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:37:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:37:23 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:23 --> Total execution time: 0.3682
INFO - 2021-04-06 14:37:55 --> Config Class Initialized
INFO - 2021-04-06 14:37:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:55 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:55 --> URI Class Initialized
INFO - 2021-04-06 14:37:55 --> Router Class Initialized
INFO - 2021-04-06 14:37:55 --> Output Class Initialized
INFO - 2021-04-06 14:37:55 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:55 --> Input Class Initialized
INFO - 2021-04-06 14:37:55 --> Language Class Initialized
INFO - 2021-04-06 14:37:55 --> Loader Class Initialized
INFO - 2021-04-06 14:37:55 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:55 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:55 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:55 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:55 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:55 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:55 --> Controller Class Initialized
INFO - 2021-04-06 14:37:55 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:55 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:55 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:37:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:37:55 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:55 --> Total execution time: 0.0889
INFO - 2021-04-06 14:37:56 --> Config Class Initialized
INFO - 2021-04-06 14:37:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:56 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:56 --> URI Class Initialized
INFO - 2021-04-06 14:37:56 --> Router Class Initialized
INFO - 2021-04-06 14:37:56 --> Output Class Initialized
INFO - 2021-04-06 14:37:56 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:56 --> Input Class Initialized
INFO - 2021-04-06 14:37:56 --> Language Class Initialized
ERROR - 2021-04-06 14:37:56 --> 404 Page Not Found: Estiaenterprise_rc/DistributorDashboard
INFO - 2021-04-06 14:37:56 --> Config Class Initialized
INFO - 2021-04-06 14:37:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:56 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:56 --> URI Class Initialized
INFO - 2021-04-06 14:37:56 --> Router Class Initialized
INFO - 2021-04-06 14:37:56 --> Output Class Initialized
INFO - 2021-04-06 14:37:56 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:56 --> Input Class Initialized
INFO - 2021-04-06 14:37:56 --> Language Class Initialized
INFO - 2021-04-06 14:37:56 --> Loader Class Initialized
INFO - 2021-04-06 14:37:56 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:56 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:56 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:56 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:56 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:56 --> Controller Class Initialized
INFO - 2021-04-06 14:37:56 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:56 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/companySummary.php
INFO - 2021-04-06 14:37:56 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:56 --> Total execution time: 0.1789
INFO - 2021-04-06 14:37:56 --> Config Class Initialized
INFO - 2021-04-06 14:37:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:56 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:56 --> URI Class Initialized
INFO - 2021-04-06 14:37:56 --> Router Class Initialized
INFO - 2021-04-06 14:37:56 --> Output Class Initialized
INFO - 2021-04-06 14:37:56 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:56 --> Input Class Initialized
INFO - 2021-04-06 14:37:56 --> Language Class Initialized
INFO - 2021-04-06 14:37:56 --> Loader Class Initialized
INFO - 2021-04-06 14:37:56 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:56 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:56 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:56 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:56 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:56 --> Controller Class Initialized
INFO - 2021-04-06 14:37:56 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:56 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:56 --> Config Class Initialized
INFO - 2021-04-06 14:37:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:56 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:56 --> URI Class Initialized
INFO - 2021-04-06 14:37:56 --> Router Class Initialized
INFO - 2021-04-06 14:37:56 --> Output Class Initialized
INFO - 2021-04-06 14:37:56 --> Security Class Initialized
ERROR - 2021-04-06 14:37:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php 224
INFO - 2021-04-06 14:37:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/showTodaySummary.php
INFO - 2021-04-06 14:37:56 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 14:37:56 --> Total execution time: 0.0554
INFO - 2021-04-06 14:37:56 --> Input Class Initialized
INFO - 2021-04-06 14:37:56 --> Language Class Initialized
INFO - 2021-04-06 14:37:56 --> Loader Class Initialized
INFO - 2021-04-06 14:37:56 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:56 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:56 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:56 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:56 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:56 --> Controller Class Initialized
INFO - 2021-04-06 14:37:56 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:56 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:56 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/ajax/incentive.php
INFO - 2021-04-06 14:37:56 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:56 --> Total execution time: 0.0484
INFO - 2021-04-06 14:37:57 --> Config Class Initialized
INFO - 2021-04-06 14:37:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:57 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:57 --> URI Class Initialized
INFO - 2021-04-06 14:37:57 --> Router Class Initialized
INFO - 2021-04-06 14:37:57 --> Output Class Initialized
INFO - 2021-04-06 14:37:57 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:57 --> Input Class Initialized
INFO - 2021-04-06 14:37:57 --> Language Class Initialized
INFO - 2021-04-06 14:37:57 --> Loader Class Initialized
INFO - 2021-04-06 14:37:57 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:57 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:57 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:57 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:57 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:57 --> Controller Class Initialized
INFO - 2021-04-06 14:37:57 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:57 --> Config Class Initialized
INFO - 2021-04-06 14:37:57 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:57 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:57 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:57 --> URI Class Initialized
INFO - 2021-04-06 14:37:57 --> Router Class Initialized
INFO - 2021-04-06 14:37:57 --> Output Class Initialized
INFO - 2021-04-06 14:37:57 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:57 --> Input Class Initialized
INFO - 2021-04-06 14:37:57 --> Language Class Initialized
INFO - 2021-04-06 14:37:57 --> Loader Class Initialized
INFO - 2021-04-06 14:37:57 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:57 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:57 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:57 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:57 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:57 --> Controller Class Initialized
INFO - 2021-04-06 14:37:57 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:57 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:57 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:57 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:57 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:57 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:37:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:37:58 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:58 --> Total execution time: 0.0833
INFO - 2021-04-06 14:37:58 --> Config Class Initialized
INFO - 2021-04-06 14:37:58 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:58 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:58 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:58 --> URI Class Initialized
INFO - 2021-04-06 14:37:58 --> Router Class Initialized
INFO - 2021-04-06 14:37:58 --> Output Class Initialized
INFO - 2021-04-06 14:37:58 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:58 --> Input Class Initialized
INFO - 2021-04-06 14:37:58 --> Language Class Initialized
INFO - 2021-04-06 14:37:58 --> Loader Class Initialized
INFO - 2021-04-06 14:37:58 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:58 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:58 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:58 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:58 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:58 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:58 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:58 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:58 --> Controller Class Initialized
INFO - 2021-04-06 14:37:58 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:58 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:58 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:58 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:58 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:37:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:37:58 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:58 --> Total execution time: 0.1027
INFO - 2021-04-06 14:37:58 --> Config Class Initialized
INFO - 2021-04-06 14:37:58 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:58 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:58 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:58 --> URI Class Initialized
INFO - 2021-04-06 14:37:58 --> Router Class Initialized
INFO - 2021-04-06 14:37:58 --> Output Class Initialized
INFO - 2021-04-06 14:37:58 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:58 --> Input Class Initialized
INFO - 2021-04-06 14:37:58 --> Language Class Initialized
ERROR - 2021-04-06 14:37:58 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 14:37:59 --> Config Class Initialized
INFO - 2021-04-06 14:37:59 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:59 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:59 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:59 --> URI Class Initialized
INFO - 2021-04-06 14:37:59 --> Router Class Initialized
INFO - 2021-04-06 14:37:59 --> Output Class Initialized
INFO - 2021-04-06 14:37:59 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:59 --> Input Class Initialized
INFO - 2021-04-06 14:37:59 --> Language Class Initialized
INFO - 2021-04-06 14:37:59 --> Loader Class Initialized
INFO - 2021-04-06 14:37:59 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:59 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:59 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:59 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:59 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:59 --> Controller Class Initialized
INFO - 2021-04-06 14:37:59 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:59 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:59 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:59 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:59 --> Config Class Initialized
INFO - 2021-04-06 14:37:59 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:37:59 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:37:59 --> Utf8 Class Initialized
INFO - 2021-04-06 14:37:59 --> URI Class Initialized
INFO - 2021-04-06 14:37:59 --> Router Class Initialized
INFO - 2021-04-06 14:37:59 --> Output Class Initialized
INFO - 2021-04-06 14:37:59 --> Security Class Initialized
DEBUG - 2021-04-06 14:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:37:59 --> Input Class Initialized
INFO - 2021-04-06 14:37:59 --> Language Class Initialized
INFO - 2021-04-06 14:37:59 --> Loader Class Initialized
INFO - 2021-04-06 14:37:59 --> Helper loaded: url_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: file_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:37:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:37:59 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:59 --> Email Class Initialized
DEBUG - 2021-04-06 14:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:37:59 --> Helper loaded: form_helper
INFO - 2021-04-06 14:37:59 --> Form Validation Class Initialized
INFO - 2021-04-06 14:37:59 --> Controller Class Initialized
INFO - 2021-04-06 14:37:59 --> Model "Common_model" initialized
INFO - 2021-04-06 14:37:59 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:37:59 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:37:59 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:37:59 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:37:59 --> Database Driver Class Initialized
INFO - 2021-04-06 14:37:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:37:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:37:59 --> Final output sent to browser
DEBUG - 2021-04-06 14:37:59 --> Total execution time: 0.0825
INFO - 2021-04-06 14:38:05 --> Config Class Initialized
INFO - 2021-04-06 14:38:05 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:05 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:05 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:05 --> URI Class Initialized
INFO - 2021-04-06 14:38:05 --> Router Class Initialized
INFO - 2021-04-06 14:38:05 --> Output Class Initialized
INFO - 2021-04-06 14:38:05 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:05 --> Input Class Initialized
INFO - 2021-04-06 14:38:05 --> Language Class Initialized
INFO - 2021-04-06 14:38:05 --> Loader Class Initialized
INFO - 2021-04-06 14:38:05 --> Helper loaded: url_helper
INFO - 2021-04-06 14:38:05 --> Helper loaded: file_helper
INFO - 2021-04-06 14:38:05 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:38:05 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:38:05 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:38:05 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:05 --> Email Class Initialized
DEBUG - 2021-04-06 14:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:38:05 --> Helper loaded: form_helper
INFO - 2021-04-06 14:38:05 --> Form Validation Class Initialized
INFO - 2021-04-06 14:38:05 --> Controller Class Initialized
INFO - 2021-04-06 14:38:05 --> Model "Common_model" initialized
INFO - 2021-04-06 14:38:05 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:38:05 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:38:05 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:38:05 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:05 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:38:05 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:38:05 --> Final output sent to browser
DEBUG - 2021-04-06 14:38:05 --> Total execution time: 0.1286
INFO - 2021-04-06 14:38:06 --> Config Class Initialized
INFO - 2021-04-06 14:38:06 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:06 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:06 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:06 --> URI Class Initialized
INFO - 2021-04-06 14:38:06 --> Router Class Initialized
INFO - 2021-04-06 14:38:06 --> Output Class Initialized
INFO - 2021-04-06 14:38:06 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:06 --> Input Class Initialized
INFO - 2021-04-06 14:38:06 --> Language Class Initialized
ERROR - 2021-04-06 14:38:06 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 14:38:07 --> Config Class Initialized
INFO - 2021-04-06 14:38:07 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:07 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:07 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:07 --> URI Class Initialized
INFO - 2021-04-06 14:38:07 --> Router Class Initialized
INFO - 2021-04-06 14:38:07 --> Output Class Initialized
INFO - 2021-04-06 14:38:07 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:07 --> Input Class Initialized
INFO - 2021-04-06 14:38:07 --> Language Class Initialized
INFO - 2021-04-06 14:38:07 --> Loader Class Initialized
INFO - 2021-04-06 14:38:07 --> Helper loaded: url_helper
INFO - 2021-04-06 14:38:07 --> Helper loaded: file_helper
INFO - 2021-04-06 14:38:07 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:38:07 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:38:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:38:07 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:07 --> Email Class Initialized
DEBUG - 2021-04-06 14:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:38:07 --> Helper loaded: form_helper
INFO - 2021-04-06 14:38:07 --> Form Validation Class Initialized
INFO - 2021-04-06 14:38:07 --> Controller Class Initialized
INFO - 2021-04-06 14:38:07 --> Model "Common_model" initialized
INFO - 2021-04-06 14:38:07 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:38:07 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:38:07 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:38:08 --> Config Class Initialized
INFO - 2021-04-06 14:38:08 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:08 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:08 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:08 --> URI Class Initialized
INFO - 2021-04-06 14:38:08 --> Router Class Initialized
INFO - 2021-04-06 14:38:08 --> Output Class Initialized
INFO - 2021-04-06 14:38:08 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:08 --> Input Class Initialized
INFO - 2021-04-06 14:38:08 --> Language Class Initialized
INFO - 2021-04-06 14:38:08 --> Loader Class Initialized
INFO - 2021-04-06 14:38:08 --> Helper loaded: url_helper
INFO - 2021-04-06 14:38:08 --> Helper loaded: file_helper
INFO - 2021-04-06 14:38:08 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:38:08 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:38:08 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:38:08 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:08 --> Email Class Initialized
DEBUG - 2021-04-06 14:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:38:08 --> Helper loaded: form_helper
INFO - 2021-04-06 14:38:08 --> Form Validation Class Initialized
INFO - 2021-04-06 14:38:08 --> Controller Class Initialized
INFO - 2021-04-06 14:38:08 --> Model "Common_model" initialized
INFO - 2021-04-06 14:38:08 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:38:08 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:38:08 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:38:08 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:38:08 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:38:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:38:08 --> Final output sent to browser
DEBUG - 2021-04-06 14:38:08 --> Total execution time: 0.0885
INFO - 2021-04-06 14:38:32 --> Config Class Initialized
INFO - 2021-04-06 14:38:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:32 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:32 --> URI Class Initialized
INFO - 2021-04-06 14:38:32 --> Router Class Initialized
INFO - 2021-04-06 14:38:32 --> Output Class Initialized
INFO - 2021-04-06 14:38:32 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:32 --> Input Class Initialized
INFO - 2021-04-06 14:38:32 --> Language Class Initialized
INFO - 2021-04-06 14:38:32 --> Loader Class Initialized
INFO - 2021-04-06 14:38:32 --> Helper loaded: url_helper
INFO - 2021-04-06 14:38:32 --> Helper loaded: file_helper
INFO - 2021-04-06 14:38:32 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:38:32 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:38:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:38:32 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:32 --> Email Class Initialized
DEBUG - 2021-04-06 14:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:38:32 --> Helper loaded: form_helper
INFO - 2021-04-06 14:38:32 --> Form Validation Class Initialized
INFO - 2021-04-06 14:38:32 --> Controller Class Initialized
INFO - 2021-04-06 14:38:32 --> Model "Common_model" initialized
INFO - 2021-04-06 14:38:32 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:38:32 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:38:32 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:38:32 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:38:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:38:32 --> Final output sent to browser
DEBUG - 2021-04-06 14:38:32 --> Total execution time: 0.2420
INFO - 2021-04-06 14:38:32 --> Config Class Initialized
INFO - 2021-04-06 14:38:32 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:32 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:32 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:32 --> URI Class Initialized
INFO - 2021-04-06 14:38:32 --> Router Class Initialized
INFO - 2021-04-06 14:38:32 --> Output Class Initialized
INFO - 2021-04-06 14:38:32 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:32 --> Input Class Initialized
INFO - 2021-04-06 14:38:32 --> Language Class Initialized
INFO - 2021-04-06 14:38:32 --> Loader Class Initialized
INFO - 2021-04-06 14:38:32 --> Helper loaded: url_helper
INFO - 2021-04-06 14:38:32 --> Helper loaded: file_helper
INFO - 2021-04-06 14:38:33 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:38:33 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:38:33 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:38:33 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:33 --> Email Class Initialized
DEBUG - 2021-04-06 14:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:38:33 --> Helper loaded: form_helper
INFO - 2021-04-06 14:38:33 --> Form Validation Class Initialized
INFO - 2021-04-06 14:38:33 --> Controller Class Initialized
INFO - 2021-04-06 14:38:33 --> Model "Common_model" initialized
INFO - 2021-04-06 14:38:33 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:38:33 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:38:33 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:38:33 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:38:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:38:33 --> Final output sent to browser
DEBUG - 2021-04-06 14:38:33 --> Total execution time: 0.1094
INFO - 2021-04-06 14:38:33 --> Config Class Initialized
INFO - 2021-04-06 14:38:33 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:33 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:33 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:33 --> URI Class Initialized
INFO - 2021-04-06 14:38:33 --> Router Class Initialized
INFO - 2021-04-06 14:38:33 --> Output Class Initialized
INFO - 2021-04-06 14:38:33 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:33 --> Input Class Initialized
INFO - 2021-04-06 14:38:33 --> Language Class Initialized
ERROR - 2021-04-06 14:38:33 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 14:38:34 --> Config Class Initialized
INFO - 2021-04-06 14:38:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:34 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:34 --> URI Class Initialized
INFO - 2021-04-06 14:38:34 --> Router Class Initialized
INFO - 2021-04-06 14:38:34 --> Output Class Initialized
INFO - 2021-04-06 14:38:34 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:34 --> Input Class Initialized
INFO - 2021-04-06 14:38:34 --> Language Class Initialized
INFO - 2021-04-06 14:38:34 --> Loader Class Initialized
INFO - 2021-04-06 14:38:34 --> Helper loaded: url_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: file_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:38:34 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:34 --> Email Class Initialized
DEBUG - 2021-04-06 14:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:38:34 --> Helper loaded: form_helper
INFO - 2021-04-06 14:38:34 --> Form Validation Class Initialized
INFO - 2021-04-06 14:38:34 --> Controller Class Initialized
INFO - 2021-04-06 14:38:34 --> Model "Common_model" initialized
INFO - 2021-04-06 14:38:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:38:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:38:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:38:34 --> Config Class Initialized
INFO - 2021-04-06 14:38:34 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:38:34 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:38:34 --> Utf8 Class Initialized
INFO - 2021-04-06 14:38:34 --> URI Class Initialized
INFO - 2021-04-06 14:38:34 --> Router Class Initialized
INFO - 2021-04-06 14:38:34 --> Output Class Initialized
INFO - 2021-04-06 14:38:34 --> Security Class Initialized
DEBUG - 2021-04-06 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:38:34 --> Input Class Initialized
INFO - 2021-04-06 14:38:34 --> Language Class Initialized
INFO - 2021-04-06 14:38:34 --> Loader Class Initialized
INFO - 2021-04-06 14:38:34 --> Helper loaded: url_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: file_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:38:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:38:34 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:34 --> Email Class Initialized
DEBUG - 2021-04-06 14:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:38:34 --> Helper loaded: form_helper
INFO - 2021-04-06 14:38:34 --> Form Validation Class Initialized
INFO - 2021-04-06 14:38:34 --> Controller Class Initialized
INFO - 2021-04-06 14:38:34 --> Model "Common_model" initialized
INFO - 2021-04-06 14:38:34 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:38:34 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:38:34 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:38:34 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:38:34 --> Database Driver Class Initialized
INFO - 2021-04-06 14:38:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:38:34 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:38:34 --> Final output sent to browser
DEBUG - 2021-04-06 14:38:34 --> Total execution time: 0.1053
INFO - 2021-04-06 14:39:13 --> Config Class Initialized
INFO - 2021-04-06 14:39:13 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:39:13 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:39:13 --> Utf8 Class Initialized
INFO - 2021-04-06 14:39:13 --> URI Class Initialized
INFO - 2021-04-06 14:39:13 --> Router Class Initialized
INFO - 2021-04-06 14:39:13 --> Output Class Initialized
INFO - 2021-04-06 14:39:13 --> Security Class Initialized
DEBUG - 2021-04-06 14:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:39:13 --> Input Class Initialized
INFO - 2021-04-06 14:39:13 --> Language Class Initialized
INFO - 2021-04-06 14:39:13 --> Loader Class Initialized
INFO - 2021-04-06 14:39:13 --> Helper loaded: url_helper
INFO - 2021-04-06 14:39:13 --> Helper loaded: file_helper
INFO - 2021-04-06 14:39:13 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:39:13 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:39:13 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:39:13 --> Database Driver Class Initialized
INFO - 2021-04-06 14:39:13 --> Email Class Initialized
DEBUG - 2021-04-06 14:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:39:13 --> Helper loaded: form_helper
INFO - 2021-04-06 14:39:13 --> Form Validation Class Initialized
INFO - 2021-04-06 14:39:13 --> Controller Class Initialized
INFO - 2021-04-06 14:39:13 --> Model "Common_model" initialized
INFO - 2021-04-06 14:39:13 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:39:13 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:39:13 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:39:13 --> Database Driver Class Initialized
INFO - 2021-04-06 14:39:13 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:39:13 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:39:13 --> Final output sent to browser
DEBUG - 2021-04-06 14:39:13 --> Total execution time: 0.1916
INFO - 2021-04-06 14:39:13 --> Config Class Initialized
INFO - 2021-04-06 14:39:13 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:39:13 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:39:13 --> Utf8 Class Initialized
INFO - 2021-04-06 14:39:13 --> URI Class Initialized
INFO - 2021-04-06 14:39:13 --> Router Class Initialized
INFO - 2021-04-06 14:39:13 --> Output Class Initialized
INFO - 2021-04-06 14:39:13 --> Security Class Initialized
DEBUG - 2021-04-06 14:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:39:13 --> Input Class Initialized
INFO - 2021-04-06 14:39:13 --> Language Class Initialized
ERROR - 2021-04-06 14:39:13 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 14:39:14 --> Config Class Initialized
INFO - 2021-04-06 14:39:14 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:39:14 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:39:14 --> Utf8 Class Initialized
INFO - 2021-04-06 14:39:14 --> URI Class Initialized
INFO - 2021-04-06 14:39:14 --> Router Class Initialized
INFO - 2021-04-06 14:39:14 --> Output Class Initialized
INFO - 2021-04-06 14:39:14 --> Security Class Initialized
DEBUG - 2021-04-06 14:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:39:14 --> Input Class Initialized
INFO - 2021-04-06 14:39:14 --> Language Class Initialized
INFO - 2021-04-06 14:39:14 --> Loader Class Initialized
INFO - 2021-04-06 14:39:14 --> Helper loaded: url_helper
INFO - 2021-04-06 14:39:14 --> Helper loaded: file_helper
INFO - 2021-04-06 14:39:14 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:39:14 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:39:14 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:39:14 --> Database Driver Class Initialized
INFO - 2021-04-06 14:39:14 --> Email Class Initialized
DEBUG - 2021-04-06 14:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:39:14 --> Helper loaded: form_helper
INFO - 2021-04-06 14:39:14 --> Form Validation Class Initialized
INFO - 2021-04-06 14:39:14 --> Controller Class Initialized
INFO - 2021-04-06 14:39:14 --> Model "Common_model" initialized
INFO - 2021-04-06 14:39:14 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:39:14 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:39:14 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:39:15 --> Config Class Initialized
INFO - 2021-04-06 14:39:15 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:39:15 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:39:15 --> Utf8 Class Initialized
INFO - 2021-04-06 14:39:15 --> URI Class Initialized
INFO - 2021-04-06 14:39:15 --> Router Class Initialized
INFO - 2021-04-06 14:39:15 --> Output Class Initialized
INFO - 2021-04-06 14:39:15 --> Security Class Initialized
DEBUG - 2021-04-06 14:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:39:15 --> Input Class Initialized
INFO - 2021-04-06 14:39:15 --> Language Class Initialized
INFO - 2021-04-06 14:39:15 --> Loader Class Initialized
INFO - 2021-04-06 14:39:15 --> Helper loaded: url_helper
INFO - 2021-04-06 14:39:15 --> Helper loaded: file_helper
INFO - 2021-04-06 14:39:15 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:39:15 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:39:15 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:39:15 --> Database Driver Class Initialized
INFO - 2021-04-06 14:39:15 --> Email Class Initialized
DEBUG - 2021-04-06 14:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:39:15 --> Helper loaded: form_helper
INFO - 2021-04-06 14:39:15 --> Form Validation Class Initialized
INFO - 2021-04-06 14:39:15 --> Controller Class Initialized
INFO - 2021-04-06 14:39:15 --> Model "Common_model" initialized
INFO - 2021-04-06 14:39:15 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:39:15 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:39:15 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:39:15 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:39:15 --> Database Driver Class Initialized
INFO - 2021-04-06 14:39:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:39:15 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:39:15 --> Final output sent to browser
DEBUG - 2021-04-06 14:39:15 --> Total execution time: 0.0760
INFO - 2021-04-06 14:40:20 --> Config Class Initialized
INFO - 2021-04-06 14:40:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:20 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:20 --> URI Class Initialized
INFO - 2021-04-06 14:40:20 --> Router Class Initialized
INFO - 2021-04-06 14:40:20 --> Output Class Initialized
INFO - 2021-04-06 14:40:20 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:20 --> Input Class Initialized
INFO - 2021-04-06 14:40:20 --> Language Class Initialized
INFO - 2021-04-06 14:40:20 --> Loader Class Initialized
INFO - 2021-04-06 14:40:20 --> Helper loaded: url_helper
INFO - 2021-04-06 14:40:20 --> Helper loaded: file_helper
INFO - 2021-04-06 14:40:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:40:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:40:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:40:20 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:20 --> Email Class Initialized
DEBUG - 2021-04-06 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:40:20 --> Helper loaded: form_helper
INFO - 2021-04-06 14:40:20 --> Form Validation Class Initialized
INFO - 2021-04-06 14:40:20 --> Controller Class Initialized
INFO - 2021-04-06 14:40:20 --> Model "Common_model" initialized
INFO - 2021-04-06 14:40:20 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:40:20 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:40:20 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:40:20 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:40:21 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:40:21 --> Final output sent to browser
DEBUG - 2021-04-06 14:40:21 --> Total execution time: 0.2361
INFO - 2021-04-06 14:40:21 --> Config Class Initialized
INFO - 2021-04-06 14:40:21 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:21 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:21 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:21 --> URI Class Initialized
INFO - 2021-04-06 14:40:21 --> Router Class Initialized
INFO - 2021-04-06 14:40:21 --> Output Class Initialized
INFO - 2021-04-06 14:40:21 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:21 --> Input Class Initialized
INFO - 2021-04-06 14:40:21 --> Language Class Initialized
ERROR - 2021-04-06 14:40:21 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 14:40:22 --> Config Class Initialized
INFO - 2021-04-06 14:40:22 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:22 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:22 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:22 --> URI Class Initialized
INFO - 2021-04-06 14:40:22 --> Router Class Initialized
INFO - 2021-04-06 14:40:22 --> Output Class Initialized
INFO - 2021-04-06 14:40:22 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:22 --> Input Class Initialized
INFO - 2021-04-06 14:40:22 --> Language Class Initialized
INFO - 2021-04-06 14:40:22 --> Loader Class Initialized
INFO - 2021-04-06 14:40:22 --> Helper loaded: url_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: file_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:40:22 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:22 --> Email Class Initialized
DEBUG - 2021-04-06 14:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:40:22 --> Helper loaded: form_helper
INFO - 2021-04-06 14:40:22 --> Form Validation Class Initialized
INFO - 2021-04-06 14:40:22 --> Controller Class Initialized
INFO - 2021-04-06 14:40:22 --> Model "Common_model" initialized
INFO - 2021-04-06 14:40:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:40:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:40:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:40:22 --> Config Class Initialized
INFO - 2021-04-06 14:40:22 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:22 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:22 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:22 --> URI Class Initialized
INFO - 2021-04-06 14:40:22 --> Router Class Initialized
INFO - 2021-04-06 14:40:22 --> Output Class Initialized
INFO - 2021-04-06 14:40:22 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:22 --> Input Class Initialized
INFO - 2021-04-06 14:40:22 --> Language Class Initialized
INFO - 2021-04-06 14:40:22 --> Loader Class Initialized
INFO - 2021-04-06 14:40:22 --> Helper loaded: url_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: file_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:40:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:40:22 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:22 --> Email Class Initialized
DEBUG - 2021-04-06 14:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:40:22 --> Helper loaded: form_helper
INFO - 2021-04-06 14:40:22 --> Form Validation Class Initialized
INFO - 2021-04-06 14:40:22 --> Controller Class Initialized
INFO - 2021-04-06 14:40:22 --> Model "Common_model" initialized
INFO - 2021-04-06 14:40:22 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:40:22 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:40:22 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:40:22 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:40:22 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:40:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:40:22 --> Final output sent to browser
DEBUG - 2021-04-06 14:40:22 --> Total execution time: 0.0785
INFO - 2021-04-06 14:40:36 --> Config Class Initialized
INFO - 2021-04-06 14:40:36 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:36 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:36 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:36 --> URI Class Initialized
INFO - 2021-04-06 14:40:36 --> Router Class Initialized
INFO - 2021-04-06 14:40:36 --> Output Class Initialized
INFO - 2021-04-06 14:40:36 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:36 --> Input Class Initialized
INFO - 2021-04-06 14:40:36 --> Language Class Initialized
INFO - 2021-04-06 14:40:36 --> Loader Class Initialized
INFO - 2021-04-06 14:40:36 --> Helper loaded: url_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: file_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:40:36 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:36 --> Email Class Initialized
DEBUG - 2021-04-06 14:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:40:36 --> Helper loaded: form_helper
INFO - 2021-04-06 14:40:36 --> Form Validation Class Initialized
INFO - 2021-04-06 14:40:36 --> Controller Class Initialized
INFO - 2021-04-06 14:40:36 --> Model "Common_model" initialized
INFO - 2021-04-06 14:40:36 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:40:36 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:40:36 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:40:36 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:36 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:40:36 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:40:36 --> Final output sent to browser
DEBUG - 2021-04-06 14:40:36 --> Total execution time: 0.2060
INFO - 2021-04-06 14:40:36 --> Config Class Initialized
INFO - 2021-04-06 14:40:36 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:36 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:36 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:36 --> URI Class Initialized
INFO - 2021-04-06 14:40:36 --> Router Class Initialized
INFO - 2021-04-06 14:40:36 --> Output Class Initialized
INFO - 2021-04-06 14:40:36 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:36 --> Input Class Initialized
INFO - 2021-04-06 14:40:36 --> Language Class Initialized
INFO - 2021-04-06 14:40:36 --> Loader Class Initialized
INFO - 2021-04-06 14:40:36 --> Helper loaded: url_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: file_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:40:36 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:40:36 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:37 --> Email Class Initialized
DEBUG - 2021-04-06 14:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:40:37 --> Helper loaded: form_helper
INFO - 2021-04-06 14:40:37 --> Form Validation Class Initialized
INFO - 2021-04-06 14:40:37 --> Controller Class Initialized
INFO - 2021-04-06 14:40:37 --> Model "Common_model" initialized
INFO - 2021-04-06 14:40:37 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:40:37 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:40:37 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:40:37 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/customerLedgerDetails.php
INFO - 2021-04-06 14:40:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:40:37 --> Final output sent to browser
DEBUG - 2021-04-06 14:40:37 --> Total execution time: 0.1047
INFO - 2021-04-06 14:40:37 --> Config Class Initialized
INFO - 2021-04-06 14:40:37 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:37 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:37 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:37 --> URI Class Initialized
INFO - 2021-04-06 14:40:37 --> Router Class Initialized
INFO - 2021-04-06 14:40:37 --> Output Class Initialized
INFO - 2021-04-06 14:40:37 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:37 --> Input Class Initialized
INFO - 2021-04-06 14:40:37 --> Language Class Initialized
ERROR - 2021-04-06 14:40:37 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 14:40:38 --> Config Class Initialized
INFO - 2021-04-06 14:40:38 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:38 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:38 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:38 --> URI Class Initialized
INFO - 2021-04-06 14:40:38 --> Router Class Initialized
INFO - 2021-04-06 14:40:38 --> Output Class Initialized
INFO - 2021-04-06 14:40:38 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:38 --> Input Class Initialized
INFO - 2021-04-06 14:40:38 --> Language Class Initialized
INFO - 2021-04-06 14:40:38 --> Loader Class Initialized
INFO - 2021-04-06 14:40:38 --> Helper loaded: url_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: file_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:40:38 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:38 --> Email Class Initialized
DEBUG - 2021-04-06 14:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:40:38 --> Helper loaded: form_helper
INFO - 2021-04-06 14:40:38 --> Form Validation Class Initialized
INFO - 2021-04-06 14:40:38 --> Controller Class Initialized
INFO - 2021-04-06 14:40:38 --> Model "Common_model" initialized
INFO - 2021-04-06 14:40:38 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:40:38 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:40:38 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:40:38 --> Config Class Initialized
INFO - 2021-04-06 14:40:38 --> Hooks Class Initialized
DEBUG - 2021-04-06 14:40:38 --> UTF-8 Support Enabled
INFO - 2021-04-06 14:40:38 --> Utf8 Class Initialized
INFO - 2021-04-06 14:40:38 --> URI Class Initialized
INFO - 2021-04-06 14:40:38 --> Router Class Initialized
INFO - 2021-04-06 14:40:38 --> Output Class Initialized
INFO - 2021-04-06 14:40:38 --> Security Class Initialized
DEBUG - 2021-04-06 14:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 14:40:38 --> Input Class Initialized
INFO - 2021-04-06 14:40:38 --> Language Class Initialized
INFO - 2021-04-06 14:40:38 --> Loader Class Initialized
INFO - 2021-04-06 14:40:38 --> Helper loaded: url_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: file_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: utility_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: unit_helper
INFO - 2021-04-06 14:40:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 14:40:38 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:38 --> Email Class Initialized
DEBUG - 2021-04-06 14:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 14:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 14:40:38 --> Helper loaded: form_helper
INFO - 2021-04-06 14:40:38 --> Form Validation Class Initialized
INFO - 2021-04-06 14:40:38 --> Controller Class Initialized
INFO - 2021-04-06 14:40:38 --> Model "Common_model" initialized
INFO - 2021-04-06 14:40:38 --> Model "Finane_Model" initialized
INFO - 2021-04-06 14:40:38 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 14:40:38 --> Model "Sales_Model" initialized
INFO - 2021-04-06 14:40:38 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 14:40:38 --> Database Driver Class Initialized
INFO - 2021-04-06 14:40:38 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 14:40:38 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 14:40:38 --> Final output sent to browser
DEBUG - 2021-04-06 14:40:38 --> Total execution time: 0.0774
INFO - 2021-04-06 15:05:50 --> Config Class Initialized
INFO - 2021-04-06 15:05:50 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:05:50 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:05:50 --> Utf8 Class Initialized
INFO - 2021-04-06 15:05:50 --> URI Class Initialized
INFO - 2021-04-06 15:05:50 --> Router Class Initialized
INFO - 2021-04-06 15:05:50 --> Output Class Initialized
INFO - 2021-04-06 15:05:50 --> Security Class Initialized
DEBUG - 2021-04-06 15:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:05:50 --> Input Class Initialized
INFO - 2021-04-06 15:05:50 --> Language Class Initialized
INFO - 2021-04-06 15:05:50 --> Loader Class Initialized
INFO - 2021-04-06 15:05:50 --> Helper loaded: url_helper
INFO - 2021-04-06 15:05:50 --> Helper loaded: file_helper
INFO - 2021-04-06 15:05:50 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:05:50 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:05:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:05:50 --> Database Driver Class Initialized
INFO - 2021-04-06 15:05:50 --> Email Class Initialized
DEBUG - 2021-04-06 15:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:05:50 --> Helper loaded: form_helper
INFO - 2021-04-06 15:05:50 --> Form Validation Class Initialized
INFO - 2021-04-06 15:05:50 --> Controller Class Initialized
INFO - 2021-04-06 15:05:50 --> Model "Common_model" initialized
INFO - 2021-04-06 15:05:50 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:05:50 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:05:50 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:05:50 --> Database Driver Class Initialized
INFO - 2021-04-06 15:05:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-04-06 15:05:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 15:05:50 --> Final output sent to browser
DEBUG - 2021-04-06 15:05:50 --> Total execution time: 0.1959
INFO - 2021-04-06 15:05:51 --> Config Class Initialized
INFO - 2021-04-06 15:05:51 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:05:51 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:05:51 --> Utf8 Class Initialized
INFO - 2021-04-06 15:05:51 --> URI Class Initialized
INFO - 2021-04-06 15:05:51 --> Router Class Initialized
INFO - 2021-04-06 15:05:51 --> Output Class Initialized
INFO - 2021-04-06 15:05:51 --> Security Class Initialized
DEBUG - 2021-04-06 15:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:05:51 --> Input Class Initialized
INFO - 2021-04-06 15:05:51 --> Language Class Initialized
ERROR - 2021-04-06 15:05:51 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 15:05:51 --> Config Class Initialized
INFO - 2021-04-06 15:05:51 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:05:51 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:05:51 --> Utf8 Class Initialized
INFO - 2021-04-06 15:05:51 --> URI Class Initialized
INFO - 2021-04-06 15:05:51 --> Router Class Initialized
INFO - 2021-04-06 15:05:51 --> Output Class Initialized
INFO - 2021-04-06 15:05:51 --> Security Class Initialized
DEBUG - 2021-04-06 15:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:05:51 --> Input Class Initialized
INFO - 2021-04-06 15:05:51 --> Language Class Initialized
INFO - 2021-04-06 15:05:51 --> Loader Class Initialized
INFO - 2021-04-06 15:05:51 --> Helper loaded: url_helper
INFO - 2021-04-06 15:05:51 --> Helper loaded: file_helper
INFO - 2021-04-06 15:05:51 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:05:51 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:05:51 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:05:51 --> Database Driver Class Initialized
INFO - 2021-04-06 15:05:51 --> Email Class Initialized
DEBUG - 2021-04-06 15:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:05:51 --> Helper loaded: form_helper
INFO - 2021-04-06 15:05:51 --> Form Validation Class Initialized
INFO - 2021-04-06 15:05:51 --> Controller Class Initialized
INFO - 2021-04-06 15:05:51 --> Model "Common_model" initialized
INFO - 2021-04-06 15:05:51 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:05:51 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:05:51 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:05:52 --> Config Class Initialized
INFO - 2021-04-06 15:05:52 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:05:52 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:05:52 --> Utf8 Class Initialized
INFO - 2021-04-06 15:05:52 --> URI Class Initialized
INFO - 2021-04-06 15:05:52 --> Router Class Initialized
INFO - 2021-04-06 15:05:52 --> Output Class Initialized
INFO - 2021-04-06 15:05:52 --> Security Class Initialized
DEBUG - 2021-04-06 15:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:05:52 --> Input Class Initialized
INFO - 2021-04-06 15:05:52 --> Language Class Initialized
INFO - 2021-04-06 15:05:52 --> Loader Class Initialized
INFO - 2021-04-06 15:05:52 --> Helper loaded: url_helper
INFO - 2021-04-06 15:05:52 --> Helper loaded: file_helper
INFO - 2021-04-06 15:05:52 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:05:52 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:05:52 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:05:52 --> Database Driver Class Initialized
INFO - 2021-04-06 15:05:52 --> Email Class Initialized
DEBUG - 2021-04-06 15:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:05:52 --> Helper loaded: form_helper
INFO - 2021-04-06 15:05:52 --> Form Validation Class Initialized
INFO - 2021-04-06 15:05:52 --> Controller Class Initialized
INFO - 2021-04-06 15:05:52 --> Model "Common_model" initialized
INFO - 2021-04-06 15:05:52 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:05:52 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:05:52 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:05:52 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 15:05:52 --> Database Driver Class Initialized
INFO - 2021-04-06 15:05:52 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 15:05:53 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 15:05:53 --> Final output sent to browser
DEBUG - 2021-04-06 15:05:53 --> Total execution time: 0.7506
INFO - 2021-04-06 15:06:03 --> Config Class Initialized
INFO - 2021-04-06 15:06:03 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:06:03 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:06:03 --> Utf8 Class Initialized
INFO - 2021-04-06 15:06:03 --> URI Class Initialized
INFO - 2021-04-06 15:06:03 --> Router Class Initialized
INFO - 2021-04-06 15:06:03 --> Output Class Initialized
INFO - 2021-04-06 15:06:03 --> Security Class Initialized
DEBUG - 2021-04-06 15:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:06:03 --> Input Class Initialized
INFO - 2021-04-06 15:06:03 --> Language Class Initialized
INFO - 2021-04-06 15:06:03 --> Loader Class Initialized
INFO - 2021-04-06 15:06:03 --> Helper loaded: url_helper
INFO - 2021-04-06 15:06:03 --> Helper loaded: file_helper
INFO - 2021-04-06 15:06:03 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:06:03 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:06:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:06:03 --> Database Driver Class Initialized
INFO - 2021-04-06 15:06:03 --> Email Class Initialized
DEBUG - 2021-04-06 15:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:06:03 --> Helper loaded: form_helper
INFO - 2021-04-06 15:06:03 --> Form Validation Class Initialized
INFO - 2021-04-06 15:06:03 --> Controller Class Initialized
INFO - 2021-04-06 15:06:03 --> Model "Common_model" initialized
INFO - 2021-04-06 15:06:03 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:06:03 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:06:03 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:06:03 --> Database Driver Class Initialized
INFO - 2021-04-06 15:06:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-04-06 15:06:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 15:06:03 --> Final output sent to browser
DEBUG - 2021-04-06 15:06:03 --> Total execution time: 0.2004
INFO - 2021-04-06 15:06:03 --> Config Class Initialized
INFO - 2021-04-06 15:06:03 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:06:03 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:06:03 --> Utf8 Class Initialized
INFO - 2021-04-06 15:06:03 --> URI Class Initialized
INFO - 2021-04-06 15:06:03 --> Router Class Initialized
INFO - 2021-04-06 15:06:03 --> Output Class Initialized
INFO - 2021-04-06 15:06:03 --> Security Class Initialized
DEBUG - 2021-04-06 15:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:06:03 --> Input Class Initialized
INFO - 2021-04-06 15:06:03 --> Language Class Initialized
ERROR - 2021-04-06 15:06:03 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 15:06:04 --> Config Class Initialized
INFO - 2021-04-06 15:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:06:04 --> Utf8 Class Initialized
INFO - 2021-04-06 15:06:04 --> URI Class Initialized
INFO - 2021-04-06 15:06:04 --> Router Class Initialized
INFO - 2021-04-06 15:06:04 --> Output Class Initialized
INFO - 2021-04-06 15:06:04 --> Security Class Initialized
DEBUG - 2021-04-06 15:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:06:04 --> Input Class Initialized
INFO - 2021-04-06 15:06:04 --> Language Class Initialized
INFO - 2021-04-06 15:06:04 --> Loader Class Initialized
INFO - 2021-04-06 15:06:04 --> Helper loaded: url_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: file_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:06:04 --> Database Driver Class Initialized
INFO - 2021-04-06 15:06:04 --> Email Class Initialized
DEBUG - 2021-04-06 15:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:06:04 --> Helper loaded: form_helper
INFO - 2021-04-06 15:06:04 --> Form Validation Class Initialized
INFO - 2021-04-06 15:06:04 --> Controller Class Initialized
INFO - 2021-04-06 15:06:04 --> Model "Common_model" initialized
INFO - 2021-04-06 15:06:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:06:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:06:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:06:04 --> Config Class Initialized
INFO - 2021-04-06 15:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:06:04 --> Utf8 Class Initialized
INFO - 2021-04-06 15:06:04 --> URI Class Initialized
INFO - 2021-04-06 15:06:04 --> Router Class Initialized
INFO - 2021-04-06 15:06:04 --> Output Class Initialized
INFO - 2021-04-06 15:06:04 --> Security Class Initialized
DEBUG - 2021-04-06 15:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:06:04 --> Input Class Initialized
INFO - 2021-04-06 15:06:04 --> Language Class Initialized
INFO - 2021-04-06 15:06:04 --> Loader Class Initialized
INFO - 2021-04-06 15:06:04 --> Helper loaded: url_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: file_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:06:04 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:06:04 --> Database Driver Class Initialized
INFO - 2021-04-06 15:06:04 --> Email Class Initialized
DEBUG - 2021-04-06 15:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:06:04 --> Helper loaded: form_helper
INFO - 2021-04-06 15:06:04 --> Form Validation Class Initialized
INFO - 2021-04-06 15:06:04 --> Controller Class Initialized
INFO - 2021-04-06 15:06:04 --> Model "Common_model" initialized
INFO - 2021-04-06 15:06:04 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:06:04 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:06:04 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:06:04 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 15:06:04 --> Database Driver Class Initialized
INFO - 2021-04-06 15:06:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 15:06:04 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 15:06:04 --> Final output sent to browser
DEBUG - 2021-04-06 15:06:04 --> Total execution time: 0.0778
INFO - 2021-04-06 15:06:45 --> Config Class Initialized
INFO - 2021-04-06 15:06:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:06:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:06:45 --> Utf8 Class Initialized
INFO - 2021-04-06 15:06:45 --> URI Class Initialized
DEBUG - 2021-04-06 15:06:45 --> No URI present. Default controller set.
INFO - 2021-04-06 15:06:45 --> Router Class Initialized
INFO - 2021-04-06 15:06:45 --> Output Class Initialized
INFO - 2021-04-06 15:06:45 --> Security Class Initialized
DEBUG - 2021-04-06 15:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:06:45 --> Input Class Initialized
INFO - 2021-04-06 15:06:45 --> Language Class Initialized
INFO - 2021-04-06 15:06:45 --> Loader Class Initialized
INFO - 2021-04-06 15:06:45 --> Helper loaded: url_helper
INFO - 2021-04-06 15:06:45 --> Helper loaded: file_helper
INFO - 2021-04-06 15:06:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:06:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:06:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:06:45 --> Database Driver Class Initialized
INFO - 2021-04-06 15:06:45 --> Email Class Initialized
DEBUG - 2021-04-06 15:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:06:45 --> Helper loaded: form_helper
INFO - 2021-04-06 15:06:45 --> Form Validation Class Initialized
INFO - 2021-04-06 15:06:45 --> Controller Class Initialized
INFO - 2021-04-06 15:06:45 --> Model "Common_model" initialized
INFO - 2021-04-06 15:06:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:06:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:06:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:06:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:06:45 --> Final output sent to browser
DEBUG - 2021-04-06 15:06:45 --> Total execution time: 0.0422
INFO - 2021-04-06 15:07:18 --> Config Class Initialized
INFO - 2021-04-06 15:07:18 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:07:18 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:07:18 --> Utf8 Class Initialized
INFO - 2021-04-06 15:07:18 --> URI Class Initialized
INFO - 2021-04-06 15:07:18 --> Router Class Initialized
INFO - 2021-04-06 15:07:18 --> Output Class Initialized
INFO - 2021-04-06 15:07:18 --> Security Class Initialized
DEBUG - 2021-04-06 15:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:07:18 --> Input Class Initialized
INFO - 2021-04-06 15:07:18 --> Language Class Initialized
INFO - 2021-04-06 15:07:18 --> Loader Class Initialized
INFO - 2021-04-06 15:07:18 --> Helper loaded: url_helper
INFO - 2021-04-06 15:07:18 --> Helper loaded: file_helper
INFO - 2021-04-06 15:07:18 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:07:18 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:07:18 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:07:18 --> Database Driver Class Initialized
INFO - 2021-04-06 15:07:18 --> Email Class Initialized
DEBUG - 2021-04-06 15:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:07:18 --> Helper loaded: form_helper
INFO - 2021-04-06 15:07:18 --> Form Validation Class Initialized
INFO - 2021-04-06 15:07:18 --> Controller Class Initialized
INFO - 2021-04-06 15:07:18 --> Model "Common_model" initialized
INFO - 2021-04-06 15:07:18 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:07:18 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:07:18 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:07:18 --> Database Driver Class Initialized
INFO - 2021-04-06 15:07:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/finance/report/generalLedger.php
INFO - 2021-04-06 15:07:18 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 15:07:18 --> Final output sent to browser
DEBUG - 2021-04-06 15:07:18 --> Total execution time: 0.3565
INFO - 2021-04-06 15:07:19 --> Config Class Initialized
INFO - 2021-04-06 15:07:19 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:07:19 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:07:19 --> Utf8 Class Initialized
INFO - 2021-04-06 15:07:19 --> URI Class Initialized
INFO - 2021-04-06 15:07:19 --> Router Class Initialized
INFO - 2021-04-06 15:07:19 --> Output Class Initialized
INFO - 2021-04-06 15:07:19 --> Security Class Initialized
DEBUG - 2021-04-06 15:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:07:19 --> Input Class Initialized
INFO - 2021-04-06 15:07:19 --> Language Class Initialized
ERROR - 2021-04-06 15:07:19 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-04-06 15:07:20 --> Config Class Initialized
INFO - 2021-04-06 15:07:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:07:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:07:20 --> Utf8 Class Initialized
INFO - 2021-04-06 15:07:20 --> URI Class Initialized
INFO - 2021-04-06 15:07:20 --> Router Class Initialized
INFO - 2021-04-06 15:07:20 --> Output Class Initialized
INFO - 2021-04-06 15:07:20 --> Security Class Initialized
DEBUG - 2021-04-06 15:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:07:20 --> Input Class Initialized
INFO - 2021-04-06 15:07:20 --> Language Class Initialized
INFO - 2021-04-06 15:07:20 --> Loader Class Initialized
INFO - 2021-04-06 15:07:20 --> Helper loaded: url_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: file_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:07:20 --> Database Driver Class Initialized
INFO - 2021-04-06 15:07:20 --> Email Class Initialized
DEBUG - 2021-04-06 15:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:07:20 --> Helper loaded: form_helper
INFO - 2021-04-06 15:07:20 --> Form Validation Class Initialized
INFO - 2021-04-06 15:07:20 --> Controller Class Initialized
INFO - 2021-04-06 15:07:20 --> Model "Common_model" initialized
INFO - 2021-04-06 15:07:20 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:07:20 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:07:20 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:07:20 --> Config Class Initialized
INFO - 2021-04-06 15:07:20 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:07:20 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:07:20 --> Utf8 Class Initialized
INFO - 2021-04-06 15:07:20 --> URI Class Initialized
INFO - 2021-04-06 15:07:20 --> Router Class Initialized
INFO - 2021-04-06 15:07:20 --> Output Class Initialized
INFO - 2021-04-06 15:07:20 --> Security Class Initialized
DEBUG - 2021-04-06 15:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:07:20 --> Input Class Initialized
INFO - 2021-04-06 15:07:20 --> Language Class Initialized
INFO - 2021-04-06 15:07:20 --> Loader Class Initialized
INFO - 2021-04-06 15:07:20 --> Helper loaded: url_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: file_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:07:20 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:07:20 --> Database Driver Class Initialized
INFO - 2021-04-06 15:07:20 --> Email Class Initialized
DEBUG - 2021-04-06 15:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:07:20 --> Helper loaded: form_helper
INFO - 2021-04-06 15:07:20 --> Form Validation Class Initialized
INFO - 2021-04-06 15:07:20 --> Controller Class Initialized
INFO - 2021-04-06 15:07:20 --> Model "Common_model" initialized
INFO - 2021-04-06 15:07:20 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:07:20 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:07:20 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:07:20 --> Model "Dashboard_Model" initialized
INFO - 2021-04-06 15:07:20 --> Database Driver Class Initialized
INFO - 2021-04-06 15:07:20 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/dashboard.php
INFO - 2021-04-06 15:07:20 --> File loaded: /home/aelbfopi/amarcement.com/application/views/distributor/masterDashboard.php
INFO - 2021-04-06 15:07:20 --> Final output sent to browser
DEBUG - 2021-04-06 15:07:20 --> Total execution time: 0.1073
INFO - 2021-04-06 15:17:16 --> Config Class Initialized
INFO - 2021-04-06 15:17:16 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:17:16 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:17:16 --> Utf8 Class Initialized
INFO - 2021-04-06 15:17:16 --> URI Class Initialized
DEBUG - 2021-04-06 15:17:16 --> No URI present. Default controller set.
INFO - 2021-04-06 15:17:16 --> Router Class Initialized
INFO - 2021-04-06 15:17:16 --> Output Class Initialized
INFO - 2021-04-06 15:17:16 --> Security Class Initialized
DEBUG - 2021-04-06 15:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:17:16 --> Input Class Initialized
INFO - 2021-04-06 15:17:16 --> Language Class Initialized
INFO - 2021-04-06 15:17:16 --> Loader Class Initialized
INFO - 2021-04-06 15:17:16 --> Helper loaded: url_helper
INFO - 2021-04-06 15:17:16 --> Helper loaded: file_helper
INFO - 2021-04-06 15:17:16 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:17:16 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:17:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:17:16 --> Database Driver Class Initialized
INFO - 2021-04-06 15:17:16 --> Email Class Initialized
DEBUG - 2021-04-06 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:17:16 --> Helper loaded: form_helper
INFO - 2021-04-06 15:17:16 --> Form Validation Class Initialized
INFO - 2021-04-06 15:17:16 --> Controller Class Initialized
INFO - 2021-04-06 15:17:16 --> Model "Common_model" initialized
INFO - 2021-04-06 15:17:16 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:17:16 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:17:16 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:17:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:17:16 --> Final output sent to browser
DEBUG - 2021-04-06 15:17:16 --> Total execution time: 0.0465
INFO - 2021-04-06 15:31:39 --> Config Class Initialized
INFO - 2021-04-06 15:31:39 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:31:39 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:31:39 --> Utf8 Class Initialized
INFO - 2021-04-06 15:31:39 --> URI Class Initialized
INFO - 2021-04-06 15:31:39 --> Router Class Initialized
INFO - 2021-04-06 15:31:39 --> Output Class Initialized
INFO - 2021-04-06 15:31:39 --> Security Class Initialized
DEBUG - 2021-04-06 15:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:31:39 --> Input Class Initialized
INFO - 2021-04-06 15:31:39 --> Language Class Initialized
INFO - 2021-04-06 15:31:39 --> Loader Class Initialized
INFO - 2021-04-06 15:31:39 --> Helper loaded: url_helper
INFO - 2021-04-06 15:31:39 --> Helper loaded: file_helper
INFO - 2021-04-06 15:31:39 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:31:39 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:31:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:31:39 --> Database Driver Class Initialized
INFO - 2021-04-06 15:31:39 --> Email Class Initialized
DEBUG - 2021-04-06 15:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:31:39 --> Helper loaded: form_helper
INFO - 2021-04-06 15:31:39 --> Form Validation Class Initialized
INFO - 2021-04-06 15:31:39 --> Controller Class Initialized
INFO - 2021-04-06 15:31:39 --> Model "Common_model" initialized
INFO - 2021-04-06 15:31:39 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:31:39 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:31:39 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:31:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:31:39 --> Final output sent to browser
DEBUG - 2021-04-06 15:31:39 --> Total execution time: 0.0511
INFO - 2021-04-06 15:31:40 --> Config Class Initialized
INFO - 2021-04-06 15:31:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:31:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:31:40 --> Utf8 Class Initialized
INFO - 2021-04-06 15:31:40 --> URI Class Initialized
INFO - 2021-04-06 15:31:40 --> Router Class Initialized
INFO - 2021-04-06 15:31:40 --> Output Class Initialized
INFO - 2021-04-06 15:31:40 --> Security Class Initialized
DEBUG - 2021-04-06 15:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:31:40 --> Input Class Initialized
INFO - 2021-04-06 15:31:40 --> Language Class Initialized
INFO - 2021-04-06 15:31:40 --> Loader Class Initialized
INFO - 2021-04-06 15:31:40 --> Helper loaded: url_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: file_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:31:40 --> Database Driver Class Initialized
INFO - 2021-04-06 15:31:40 --> Email Class Initialized
DEBUG - 2021-04-06 15:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:31:40 --> Helper loaded: form_helper
INFO - 2021-04-06 15:31:40 --> Form Validation Class Initialized
INFO - 2021-04-06 15:31:40 --> Controller Class Initialized
INFO - 2021-04-06 15:31:40 --> Model "Common_model" initialized
INFO - 2021-04-06 15:31:40 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:31:40 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:31:40 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:31:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:31:40 --> Final output sent to browser
DEBUG - 2021-04-06 15:31:40 --> Total execution time: 0.0547
INFO - 2021-04-06 15:31:40 --> Config Class Initialized
INFO - 2021-04-06 15:31:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:31:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:31:40 --> Utf8 Class Initialized
INFO - 2021-04-06 15:31:40 --> URI Class Initialized
INFO - 2021-04-06 15:31:40 --> Router Class Initialized
INFO - 2021-04-06 15:31:40 --> Output Class Initialized
INFO - 2021-04-06 15:31:40 --> Security Class Initialized
DEBUG - 2021-04-06 15:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:31:40 --> Input Class Initialized
INFO - 2021-04-06 15:31:40 --> Language Class Initialized
INFO - 2021-04-06 15:31:40 --> Loader Class Initialized
INFO - 2021-04-06 15:31:40 --> Helper loaded: url_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: file_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:31:40 --> Database Driver Class Initialized
INFO - 2021-04-06 15:31:40 --> Email Class Initialized
DEBUG - 2021-04-06 15:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:31:40 --> Helper loaded: form_helper
INFO - 2021-04-06 15:31:40 --> Form Validation Class Initialized
INFO - 2021-04-06 15:31:40 --> Controller Class Initialized
INFO - 2021-04-06 15:31:40 --> Model "Common_model" initialized
INFO - 2021-04-06 15:31:40 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:31:40 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:31:40 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:31:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:31:40 --> Final output sent to browser
DEBUG - 2021-04-06 15:31:40 --> Total execution time: 0.0486
INFO - 2021-04-06 15:31:40 --> Config Class Initialized
INFO - 2021-04-06 15:31:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:31:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:31:40 --> Utf8 Class Initialized
INFO - 2021-04-06 15:31:40 --> URI Class Initialized
INFO - 2021-04-06 15:31:40 --> Router Class Initialized
INFO - 2021-04-06 15:31:40 --> Output Class Initialized
INFO - 2021-04-06 15:31:40 --> Security Class Initialized
DEBUG - 2021-04-06 15:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:31:40 --> Input Class Initialized
INFO - 2021-04-06 15:31:40 --> Language Class Initialized
INFO - 2021-04-06 15:31:40 --> Loader Class Initialized
INFO - 2021-04-06 15:31:40 --> Helper loaded: url_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: file_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:31:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:31:40 --> Database Driver Class Initialized
INFO - 2021-04-06 15:31:41 --> Email Class Initialized
DEBUG - 2021-04-06 15:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:31:41 --> Helper loaded: form_helper
INFO - 2021-04-06 15:31:41 --> Form Validation Class Initialized
INFO - 2021-04-06 15:31:41 --> Controller Class Initialized
INFO - 2021-04-06 15:31:41 --> Model "Common_model" initialized
INFO - 2021-04-06 15:31:41 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:31:41 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:31:41 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:31:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:31:41 --> Final output sent to browser
DEBUG - 2021-04-06 15:31:41 --> Total execution time: 0.0569
INFO - 2021-04-06 15:31:41 --> Config Class Initialized
INFO - 2021-04-06 15:31:41 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:31:41 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:31:41 --> Utf8 Class Initialized
INFO - 2021-04-06 15:31:41 --> URI Class Initialized
DEBUG - 2021-04-06 15:31:41 --> No URI present. Default controller set.
INFO - 2021-04-06 15:31:41 --> Router Class Initialized
INFO - 2021-04-06 15:31:41 --> Output Class Initialized
INFO - 2021-04-06 15:31:41 --> Security Class Initialized
DEBUG - 2021-04-06 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:31:41 --> Input Class Initialized
INFO - 2021-04-06 15:31:41 --> Language Class Initialized
INFO - 2021-04-06 15:31:41 --> Loader Class Initialized
INFO - 2021-04-06 15:31:41 --> Helper loaded: url_helper
INFO - 2021-04-06 15:31:41 --> Helper loaded: file_helper
INFO - 2021-04-06 15:31:41 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:31:41 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:31:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:31:41 --> Database Driver Class Initialized
INFO - 2021-04-06 15:31:41 --> Email Class Initialized
DEBUG - 2021-04-06 15:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:31:41 --> Helper loaded: form_helper
INFO - 2021-04-06 15:31:41 --> Form Validation Class Initialized
INFO - 2021-04-06 15:31:41 --> Controller Class Initialized
INFO - 2021-04-06 15:31:41 --> Model "Common_model" initialized
INFO - 2021-04-06 15:31:41 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:31:41 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:31:41 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:31:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:31:41 --> Final output sent to browser
DEBUG - 2021-04-06 15:31:41 --> Total execution time: 0.0514
INFO - 2021-04-06 15:45:53 --> Config Class Initialized
INFO - 2021-04-06 15:45:53 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:45:53 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:45:53 --> Utf8 Class Initialized
INFO - 2021-04-06 15:45:53 --> URI Class Initialized
DEBUG - 2021-04-06 15:45:53 --> No URI present. Default controller set.
INFO - 2021-04-06 15:45:53 --> Router Class Initialized
INFO - 2021-04-06 15:45:53 --> Output Class Initialized
INFO - 2021-04-06 15:45:53 --> Security Class Initialized
DEBUG - 2021-04-06 15:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:45:53 --> Input Class Initialized
INFO - 2021-04-06 15:45:53 --> Language Class Initialized
INFO - 2021-04-06 15:45:53 --> Loader Class Initialized
INFO - 2021-04-06 15:45:53 --> Helper loaded: url_helper
INFO - 2021-04-06 15:45:53 --> Helper loaded: file_helper
INFO - 2021-04-06 15:45:53 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:45:53 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:45:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:45:53 --> Database Driver Class Initialized
INFO - 2021-04-06 15:45:53 --> Email Class Initialized
DEBUG - 2021-04-06 15:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:45:53 --> Helper loaded: form_helper
INFO - 2021-04-06 15:45:53 --> Form Validation Class Initialized
INFO - 2021-04-06 15:45:53 --> Controller Class Initialized
INFO - 2021-04-06 15:45:53 --> Model "Common_model" initialized
INFO - 2021-04-06 15:45:53 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:45:53 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:45:53 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:45:53 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:45:53 --> Final output sent to browser
DEBUG - 2021-04-06 15:45:53 --> Total execution time: 0.0640
INFO - 2021-04-06 15:47:44 --> Config Class Initialized
INFO - 2021-04-06 15:47:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:47:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:47:44 --> Utf8 Class Initialized
INFO - 2021-04-06 15:47:44 --> URI Class Initialized
INFO - 2021-04-06 15:47:44 --> Router Class Initialized
INFO - 2021-04-06 15:47:44 --> Output Class Initialized
INFO - 2021-04-06 15:47:44 --> Security Class Initialized
DEBUG - 2021-04-06 15:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:47:44 --> Input Class Initialized
INFO - 2021-04-06 15:47:44 --> Language Class Initialized
INFO - 2021-04-06 15:47:44 --> Loader Class Initialized
INFO - 2021-04-06 15:47:44 --> Helper loaded: url_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: file_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:47:44 --> Database Driver Class Initialized
INFO - 2021-04-06 15:47:44 --> Email Class Initialized
DEBUG - 2021-04-06 15:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:47:44 --> Helper loaded: form_helper
INFO - 2021-04-06 15:47:44 --> Form Validation Class Initialized
INFO - 2021-04-06 15:47:44 --> Controller Class Initialized
INFO - 2021-04-06 15:47:44 --> Model "Common_model" initialized
INFO - 2021-04-06 15:47:44 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:47:44 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:47:44 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:47:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:47:44 --> Final output sent to browser
DEBUG - 2021-04-06 15:47:44 --> Total execution time: 0.0558
INFO - 2021-04-06 15:47:44 --> Config Class Initialized
INFO - 2021-04-06 15:47:44 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:47:44 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:47:44 --> Utf8 Class Initialized
INFO - 2021-04-06 15:47:44 --> URI Class Initialized
INFO - 2021-04-06 15:47:44 --> Router Class Initialized
INFO - 2021-04-06 15:47:44 --> Output Class Initialized
INFO - 2021-04-06 15:47:44 --> Security Class Initialized
DEBUG - 2021-04-06 15:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:47:44 --> Input Class Initialized
INFO - 2021-04-06 15:47:44 --> Language Class Initialized
INFO - 2021-04-06 15:47:44 --> Loader Class Initialized
INFO - 2021-04-06 15:47:44 --> Helper loaded: url_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: file_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:47:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:47:44 --> Database Driver Class Initialized
INFO - 2021-04-06 15:47:44 --> Email Class Initialized
DEBUG - 2021-04-06 15:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:47:44 --> Helper loaded: form_helper
INFO - 2021-04-06 15:47:44 --> Form Validation Class Initialized
INFO - 2021-04-06 15:47:44 --> Controller Class Initialized
INFO - 2021-04-06 15:47:44 --> Model "Common_model" initialized
INFO - 2021-04-06 15:47:44 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:47:44 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:47:44 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:47:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:47:44 --> Final output sent to browser
DEBUG - 2021-04-06 15:47:44 --> Total execution time: 0.0645
INFO - 2021-04-06 15:47:45 --> Config Class Initialized
INFO - 2021-04-06 15:47:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:47:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:47:45 --> Utf8 Class Initialized
INFO - 2021-04-06 15:47:45 --> URI Class Initialized
INFO - 2021-04-06 15:47:45 --> Router Class Initialized
INFO - 2021-04-06 15:47:45 --> Output Class Initialized
INFO - 2021-04-06 15:47:45 --> Security Class Initialized
DEBUG - 2021-04-06 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:47:45 --> Input Class Initialized
INFO - 2021-04-06 15:47:45 --> Language Class Initialized
INFO - 2021-04-06 15:47:45 --> Loader Class Initialized
INFO - 2021-04-06 15:47:45 --> Helper loaded: url_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: file_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:47:45 --> Database Driver Class Initialized
INFO - 2021-04-06 15:47:45 --> Email Class Initialized
DEBUG - 2021-04-06 15:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:47:45 --> Helper loaded: form_helper
INFO - 2021-04-06 15:47:45 --> Form Validation Class Initialized
INFO - 2021-04-06 15:47:45 --> Controller Class Initialized
INFO - 2021-04-06 15:47:45 --> Model "Common_model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:47:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:47:45 --> Final output sent to browser
DEBUG - 2021-04-06 15:47:45 --> Total execution time: 0.0670
INFO - 2021-04-06 15:47:45 --> Config Class Initialized
INFO - 2021-04-06 15:47:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:47:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:47:45 --> Utf8 Class Initialized
INFO - 2021-04-06 15:47:45 --> URI Class Initialized
INFO - 2021-04-06 15:47:45 --> Router Class Initialized
INFO - 2021-04-06 15:47:45 --> Output Class Initialized
INFO - 2021-04-06 15:47:45 --> Security Class Initialized
DEBUG - 2021-04-06 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:47:45 --> Input Class Initialized
INFO - 2021-04-06 15:47:45 --> Language Class Initialized
INFO - 2021-04-06 15:47:45 --> Loader Class Initialized
INFO - 2021-04-06 15:47:45 --> Helper loaded: url_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: file_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:47:45 --> Database Driver Class Initialized
INFO - 2021-04-06 15:47:45 --> Email Class Initialized
DEBUG - 2021-04-06 15:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:47:45 --> Helper loaded: form_helper
INFO - 2021-04-06 15:47:45 --> Form Validation Class Initialized
INFO - 2021-04-06 15:47:45 --> Controller Class Initialized
INFO - 2021-04-06 15:47:45 --> Model "Common_model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:47:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:47:45 --> Final output sent to browser
DEBUG - 2021-04-06 15:47:45 --> Total execution time: 0.0655
INFO - 2021-04-06 15:47:45 --> Config Class Initialized
INFO - 2021-04-06 15:47:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:47:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:47:45 --> Utf8 Class Initialized
INFO - 2021-04-06 15:47:45 --> URI Class Initialized
DEBUG - 2021-04-06 15:47:45 --> No URI present. Default controller set.
INFO - 2021-04-06 15:47:45 --> Router Class Initialized
INFO - 2021-04-06 15:47:45 --> Output Class Initialized
INFO - 2021-04-06 15:47:45 --> Security Class Initialized
DEBUG - 2021-04-06 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:47:45 --> Input Class Initialized
INFO - 2021-04-06 15:47:45 --> Language Class Initialized
INFO - 2021-04-06 15:47:45 --> Loader Class Initialized
INFO - 2021-04-06 15:47:45 --> Helper loaded: url_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: file_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:47:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:47:45 --> Database Driver Class Initialized
INFO - 2021-04-06 15:47:45 --> Email Class Initialized
DEBUG - 2021-04-06 15:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:47:45 --> Helper loaded: form_helper
INFO - 2021-04-06 15:47:45 --> Form Validation Class Initialized
INFO - 2021-04-06 15:47:45 --> Controller Class Initialized
INFO - 2021-04-06 15:47:45 --> Model "Common_model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:47:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:47:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:47:45 --> Final output sent to browser
DEBUG - 2021-04-06 15:47:45 --> Total execution time: 0.0676
INFO - 2021-04-06 15:49:39 --> Config Class Initialized
INFO - 2021-04-06 15:49:39 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:49:39 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:49:39 --> Utf8 Class Initialized
INFO - 2021-04-06 15:49:39 --> URI Class Initialized
INFO - 2021-04-06 15:49:39 --> Router Class Initialized
INFO - 2021-04-06 15:49:39 --> Output Class Initialized
INFO - 2021-04-06 15:49:39 --> Security Class Initialized
DEBUG - 2021-04-06 15:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:49:39 --> Input Class Initialized
INFO - 2021-04-06 15:49:39 --> Language Class Initialized
INFO - 2021-04-06 15:49:39 --> Loader Class Initialized
INFO - 2021-04-06 15:49:39 --> Helper loaded: url_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: file_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:49:39 --> Database Driver Class Initialized
INFO - 2021-04-06 15:49:39 --> Email Class Initialized
DEBUG - 2021-04-06 15:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:49:39 --> Helper loaded: form_helper
INFO - 2021-04-06 15:49:39 --> Form Validation Class Initialized
INFO - 2021-04-06 15:49:39 --> Controller Class Initialized
INFO - 2021-04-06 15:49:39 --> Model "Common_model" initialized
INFO - 2021-04-06 15:49:39 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:49:39 --> Config Class Initialized
INFO - 2021-04-06 15:49:39 --> Hooks Class Initialized
INFO - 2021-04-06 15:49:39 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:49:39 --> Model "Sales_Model" initialized
DEBUG - 2021-04-06 15:49:39 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:49:39 --> Utf8 Class Initialized
INFO - 2021-04-06 15:49:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:49:39 --> Final output sent to browser
DEBUG - 2021-04-06 15:49:39 --> Total execution time: 0.0517
INFO - 2021-04-06 15:49:39 --> URI Class Initialized
INFO - 2021-04-06 15:49:39 --> Router Class Initialized
INFO - 2021-04-06 15:49:39 --> Output Class Initialized
INFO - 2021-04-06 15:49:39 --> Security Class Initialized
DEBUG - 2021-04-06 15:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:49:39 --> Input Class Initialized
INFO - 2021-04-06 15:49:39 --> Language Class Initialized
INFO - 2021-04-06 15:49:39 --> Loader Class Initialized
INFO - 2021-04-06 15:49:39 --> Helper loaded: url_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: file_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:49:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:49:39 --> Database Driver Class Initialized
INFO - 2021-04-06 15:49:39 --> Email Class Initialized
DEBUG - 2021-04-06 15:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:49:39 --> Helper loaded: form_helper
INFO - 2021-04-06 15:49:39 --> Form Validation Class Initialized
INFO - 2021-04-06 15:49:39 --> Controller Class Initialized
INFO - 2021-04-06 15:49:39 --> Model "Common_model" initialized
INFO - 2021-04-06 15:49:39 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:49:39 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:49:39 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:49:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:49:39 --> Final output sent to browser
DEBUG - 2021-04-06 15:49:39 --> Total execution time: 0.0703
INFO - 2021-04-06 15:49:40 --> Config Class Initialized
INFO - 2021-04-06 15:49:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:49:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:49:40 --> Utf8 Class Initialized
INFO - 2021-04-06 15:49:40 --> URI Class Initialized
INFO - 2021-04-06 15:49:40 --> Router Class Initialized
INFO - 2021-04-06 15:49:40 --> Output Class Initialized
INFO - 2021-04-06 15:49:40 --> Security Class Initialized
DEBUG - 2021-04-06 15:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:49:40 --> Input Class Initialized
INFO - 2021-04-06 15:49:40 --> Language Class Initialized
INFO - 2021-04-06 15:49:40 --> Loader Class Initialized
INFO - 2021-04-06 15:49:40 --> Helper loaded: url_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: file_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:49:40 --> Config Class Initialized
INFO - 2021-04-06 15:49:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:49:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:49:40 --> Utf8 Class Initialized
INFO - 2021-04-06 15:49:40 --> URI Class Initialized
INFO - 2021-04-06 15:49:40 --> Database Driver Class Initialized
INFO - 2021-04-06 15:49:40 --> Router Class Initialized
INFO - 2021-04-06 15:49:40 --> Output Class Initialized
INFO - 2021-04-06 15:49:40 --> Email Class Initialized
INFO - 2021-04-06 15:49:40 --> Security Class Initialized
DEBUG - 2021-04-06 15:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:49:40 --> Input Class Initialized
INFO - 2021-04-06 15:49:40 --> Language Class Initialized
DEBUG - 2021-04-06 15:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:49:40 --> Loader Class Initialized
INFO - 2021-04-06 15:49:40 --> Helper loaded: url_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: form_helper
INFO - 2021-04-06 15:49:40 --> Form Validation Class Initialized
INFO - 2021-04-06 15:49:40 --> Controller Class Initialized
INFO - 2021-04-06 15:49:40 --> Helper loaded: file_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:49:40 --> Model "Common_model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:49:40 --> Database Driver Class Initialized
INFO - 2021-04-06 15:49:40 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:49:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:49:40 --> Final output sent to browser
DEBUG - 2021-04-06 15:49:40 --> Total execution time: 0.0426
INFO - 2021-04-06 15:49:40 --> Email Class Initialized
DEBUG - 2021-04-06 15:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:49:40 --> Helper loaded: form_helper
INFO - 2021-04-06 15:49:40 --> Form Validation Class Initialized
INFO - 2021-04-06 15:49:40 --> Controller Class Initialized
INFO - 2021-04-06 15:49:40 --> Model "Common_model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:49:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:49:40 --> Final output sent to browser
DEBUG - 2021-04-06 15:49:40 --> Total execution time: 0.0483
INFO - 2021-04-06 15:49:40 --> Config Class Initialized
INFO - 2021-04-06 15:49:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:49:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:49:40 --> Utf8 Class Initialized
INFO - 2021-04-06 15:49:40 --> URI Class Initialized
DEBUG - 2021-04-06 15:49:40 --> No URI present. Default controller set.
INFO - 2021-04-06 15:49:40 --> Router Class Initialized
INFO - 2021-04-06 15:49:40 --> Output Class Initialized
INFO - 2021-04-06 15:49:40 --> Security Class Initialized
DEBUG - 2021-04-06 15:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:49:40 --> Input Class Initialized
INFO - 2021-04-06 15:49:40 --> Language Class Initialized
INFO - 2021-04-06 15:49:40 --> Loader Class Initialized
INFO - 2021-04-06 15:49:40 --> Helper loaded: url_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: file_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:49:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:49:40 --> Database Driver Class Initialized
INFO - 2021-04-06 15:49:40 --> Email Class Initialized
DEBUG - 2021-04-06 15:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:49:40 --> Helper loaded: form_helper
INFO - 2021-04-06 15:49:40 --> Form Validation Class Initialized
INFO - 2021-04-06 15:49:40 --> Controller Class Initialized
INFO - 2021-04-06 15:49:40 --> Model "Common_model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:49:40 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:49:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:49:40 --> Final output sent to browser
DEBUG - 2021-04-06 15:49:40 --> Total execution time: 0.0626
INFO - 2021-04-06 15:53:55 --> Config Class Initialized
INFO - 2021-04-06 15:53:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:53:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:53:55 --> Utf8 Class Initialized
INFO - 2021-04-06 15:53:55 --> URI Class Initialized
INFO - 2021-04-06 15:53:55 --> Router Class Initialized
INFO - 2021-04-06 15:53:55 --> Output Class Initialized
INFO - 2021-04-06 15:53:55 --> Security Class Initialized
DEBUG - 2021-04-06 15:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:53:55 --> Input Class Initialized
INFO - 2021-04-06 15:53:55 --> Language Class Initialized
INFO - 2021-04-06 15:53:55 --> Loader Class Initialized
INFO - 2021-04-06 15:53:55 --> Helper loaded: url_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: file_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:53:55 --> Database Driver Class Initialized
INFO - 2021-04-06 15:53:55 --> Email Class Initialized
DEBUG - 2021-04-06 15:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:53:55 --> Helper loaded: form_helper
INFO - 2021-04-06 15:53:55 --> Form Validation Class Initialized
INFO - 2021-04-06 15:53:55 --> Controller Class Initialized
INFO - 2021-04-06 15:53:55 --> Model "Common_model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:53:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:53:55 --> Final output sent to browser
DEBUG - 2021-04-06 15:53:55 --> Total execution time: 0.0479
INFO - 2021-04-06 15:53:55 --> Config Class Initialized
INFO - 2021-04-06 15:53:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:53:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:53:55 --> Utf8 Class Initialized
INFO - 2021-04-06 15:53:55 --> URI Class Initialized
INFO - 2021-04-06 15:53:55 --> Router Class Initialized
INFO - 2021-04-06 15:53:55 --> Output Class Initialized
INFO - 2021-04-06 15:53:55 --> Security Class Initialized
DEBUG - 2021-04-06 15:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:53:55 --> Input Class Initialized
INFO - 2021-04-06 15:53:55 --> Language Class Initialized
INFO - 2021-04-06 15:53:55 --> Loader Class Initialized
INFO - 2021-04-06 15:53:55 --> Helper loaded: url_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: file_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:53:55 --> Database Driver Class Initialized
INFO - 2021-04-06 15:53:55 --> Email Class Initialized
DEBUG - 2021-04-06 15:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:53:55 --> Helper loaded: form_helper
INFO - 2021-04-06 15:53:55 --> Form Validation Class Initialized
INFO - 2021-04-06 15:53:55 --> Controller Class Initialized
INFO - 2021-04-06 15:53:55 --> Model "Common_model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:53:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:53:55 --> Final output sent to browser
DEBUG - 2021-04-06 15:53:55 --> Total execution time: 0.0460
INFO - 2021-04-06 15:53:55 --> Config Class Initialized
INFO - 2021-04-06 15:53:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:53:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:53:55 --> Utf8 Class Initialized
INFO - 2021-04-06 15:53:55 --> URI Class Initialized
INFO - 2021-04-06 15:53:55 --> Router Class Initialized
INFO - 2021-04-06 15:53:55 --> Output Class Initialized
INFO - 2021-04-06 15:53:55 --> Security Class Initialized
DEBUG - 2021-04-06 15:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:53:55 --> Input Class Initialized
INFO - 2021-04-06 15:53:55 --> Language Class Initialized
INFO - 2021-04-06 15:53:55 --> Loader Class Initialized
INFO - 2021-04-06 15:53:55 --> Helper loaded: url_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: file_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:53:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:53:55 --> Database Driver Class Initialized
INFO - 2021-04-06 15:53:55 --> Email Class Initialized
DEBUG - 2021-04-06 15:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:53:55 --> Helper loaded: form_helper
INFO - 2021-04-06 15:53:55 --> Form Validation Class Initialized
INFO - 2021-04-06 15:53:55 --> Controller Class Initialized
INFO - 2021-04-06 15:53:55 --> Model "Common_model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:53:55 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:53:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:53:55 --> Final output sent to browser
DEBUG - 2021-04-06 15:53:55 --> Total execution time: 0.0384
INFO - 2021-04-06 15:53:56 --> Config Class Initialized
INFO - 2021-04-06 15:53:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:53:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:53:56 --> Utf8 Class Initialized
INFO - 2021-04-06 15:53:56 --> URI Class Initialized
INFO - 2021-04-06 15:53:56 --> Router Class Initialized
INFO - 2021-04-06 15:53:56 --> Output Class Initialized
INFO - 2021-04-06 15:53:56 --> Security Class Initialized
DEBUG - 2021-04-06 15:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:53:56 --> Input Class Initialized
INFO - 2021-04-06 15:53:56 --> Language Class Initialized
INFO - 2021-04-06 15:53:56 --> Loader Class Initialized
INFO - 2021-04-06 15:53:56 --> Helper loaded: url_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: file_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:53:56 --> Database Driver Class Initialized
INFO - 2021-04-06 15:53:56 --> Email Class Initialized
DEBUG - 2021-04-06 15:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:53:56 --> Helper loaded: form_helper
INFO - 2021-04-06 15:53:56 --> Form Validation Class Initialized
INFO - 2021-04-06 15:53:56 --> Controller Class Initialized
INFO - 2021-04-06 15:53:56 --> Model "Common_model" initialized
INFO - 2021-04-06 15:53:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:53:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:53:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:53:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:53:56 --> Final output sent to browser
DEBUG - 2021-04-06 15:53:56 --> Total execution time: 0.0486
INFO - 2021-04-06 15:53:56 --> Config Class Initialized
INFO - 2021-04-06 15:53:56 --> Hooks Class Initialized
DEBUG - 2021-04-06 15:53:56 --> UTF-8 Support Enabled
INFO - 2021-04-06 15:53:56 --> Utf8 Class Initialized
INFO - 2021-04-06 15:53:56 --> URI Class Initialized
DEBUG - 2021-04-06 15:53:56 --> No URI present. Default controller set.
INFO - 2021-04-06 15:53:56 --> Router Class Initialized
INFO - 2021-04-06 15:53:56 --> Output Class Initialized
INFO - 2021-04-06 15:53:56 --> Security Class Initialized
DEBUG - 2021-04-06 15:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 15:53:56 --> Input Class Initialized
INFO - 2021-04-06 15:53:56 --> Language Class Initialized
INFO - 2021-04-06 15:53:56 --> Loader Class Initialized
INFO - 2021-04-06 15:53:56 --> Helper loaded: url_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: file_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: utility_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: unit_helper
INFO - 2021-04-06 15:53:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 15:53:56 --> Database Driver Class Initialized
INFO - 2021-04-06 15:53:56 --> Email Class Initialized
DEBUG - 2021-04-06 15:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 15:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 15:53:56 --> Helper loaded: form_helper
INFO - 2021-04-06 15:53:56 --> Form Validation Class Initialized
INFO - 2021-04-06 15:53:56 --> Controller Class Initialized
INFO - 2021-04-06 15:53:56 --> Model "Common_model" initialized
INFO - 2021-04-06 15:53:56 --> Model "Finane_Model" initialized
INFO - 2021-04-06 15:53:56 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 15:53:56 --> Model "Sales_Model" initialized
INFO - 2021-04-06 15:53:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 15:53:56 --> Final output sent to browser
DEBUG - 2021-04-06 15:53:56 --> Total execution time: 0.0431
INFO - 2021-04-06 18:41:39 --> Config Class Initialized
INFO - 2021-04-06 18:41:39 --> Hooks Class Initialized
DEBUG - 2021-04-06 18:41:39 --> UTF-8 Support Enabled
INFO - 2021-04-06 18:41:39 --> Utf8 Class Initialized
INFO - 2021-04-06 18:41:39 --> URI Class Initialized
DEBUG - 2021-04-06 18:41:39 --> No URI present. Default controller set.
INFO - 2021-04-06 18:41:39 --> Router Class Initialized
INFO - 2021-04-06 18:41:39 --> Output Class Initialized
INFO - 2021-04-06 18:41:39 --> Security Class Initialized
DEBUG - 2021-04-06 18:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 18:41:39 --> Input Class Initialized
INFO - 2021-04-06 18:41:39 --> Language Class Initialized
INFO - 2021-04-06 18:41:39 --> Loader Class Initialized
INFO - 2021-04-06 18:41:39 --> Helper loaded: url_helper
INFO - 2021-04-06 18:41:39 --> Helper loaded: file_helper
INFO - 2021-04-06 18:41:39 --> Helper loaded: utility_helper
INFO - 2021-04-06 18:41:39 --> Helper loaded: unit_helper
INFO - 2021-04-06 18:41:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 18:41:39 --> Database Driver Class Initialized
INFO - 2021-04-06 18:41:39 --> Email Class Initialized
DEBUG - 2021-04-06 18:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 18:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 18:41:39 --> Helper loaded: form_helper
INFO - 2021-04-06 18:41:39 --> Form Validation Class Initialized
INFO - 2021-04-06 18:41:39 --> Controller Class Initialized
INFO - 2021-04-06 18:41:39 --> Model "Common_model" initialized
INFO - 2021-04-06 18:41:39 --> Model "Finane_Model" initialized
INFO - 2021-04-06 18:41:39 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 18:41:39 --> Model "Sales_Model" initialized
INFO - 2021-04-06 18:41:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 18:41:39 --> Final output sent to browser
DEBUG - 2021-04-06 18:41:39 --> Total execution time: 0.0996
INFO - 2021-04-06 20:35:55 --> Config Class Initialized
INFO - 2021-04-06 20:35:55 --> Hooks Class Initialized
DEBUG - 2021-04-06 20:35:55 --> UTF-8 Support Enabled
INFO - 2021-04-06 20:35:55 --> Utf8 Class Initialized
INFO - 2021-04-06 20:35:55 --> URI Class Initialized
INFO - 2021-04-06 20:35:55 --> Router Class Initialized
INFO - 2021-04-06 20:35:55 --> Output Class Initialized
INFO - 2021-04-06 20:35:55 --> Security Class Initialized
DEBUG - 2021-04-06 20:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 20:35:55 --> Input Class Initialized
INFO - 2021-04-06 20:35:55 --> Language Class Initialized
ERROR - 2021-04-06 20:35:55 --> 404 Page Not Found: Assets/global
INFO - 2021-04-06 21:30:40 --> Config Class Initialized
INFO - 2021-04-06 21:30:40 --> Hooks Class Initialized
DEBUG - 2021-04-06 21:30:40 --> UTF-8 Support Enabled
INFO - 2021-04-06 21:30:40 --> Utf8 Class Initialized
INFO - 2021-04-06 21:30:40 --> URI Class Initialized
DEBUG - 2021-04-06 21:30:40 --> No URI present. Default controller set.
INFO - 2021-04-06 21:30:40 --> Router Class Initialized
INFO - 2021-04-06 21:30:40 --> Output Class Initialized
INFO - 2021-04-06 21:30:40 --> Security Class Initialized
DEBUG - 2021-04-06 21:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 21:30:40 --> Input Class Initialized
INFO - 2021-04-06 21:30:40 --> Language Class Initialized
INFO - 2021-04-06 21:30:40 --> Loader Class Initialized
INFO - 2021-04-06 21:30:40 --> Helper loaded: url_helper
INFO - 2021-04-06 21:30:40 --> Helper loaded: file_helper
INFO - 2021-04-06 21:30:40 --> Helper loaded: utility_helper
INFO - 2021-04-06 21:30:40 --> Helper loaded: unit_helper
INFO - 2021-04-06 21:30:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 21:30:40 --> Database Driver Class Initialized
INFO - 2021-04-06 21:30:40 --> Email Class Initialized
DEBUG - 2021-04-06 21:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 21:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 21:30:40 --> Helper loaded: form_helper
INFO - 2021-04-06 21:30:40 --> Form Validation Class Initialized
INFO - 2021-04-06 21:30:40 --> Controller Class Initialized
INFO - 2021-04-06 21:30:40 --> Model "Common_model" initialized
INFO - 2021-04-06 21:30:40 --> Model "Finane_Model" initialized
INFO - 2021-04-06 21:30:40 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 21:30:40 --> Model "Sales_Model" initialized
INFO - 2021-04-06 21:30:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 21:30:40 --> Final output sent to browser
DEBUG - 2021-04-06 21:30:40 --> Total execution time: 0.0696
INFO - 2021-04-06 22:38:45 --> Config Class Initialized
INFO - 2021-04-06 22:38:45 --> Hooks Class Initialized
DEBUG - 2021-04-06 22:38:45 --> UTF-8 Support Enabled
INFO - 2021-04-06 22:38:45 --> Utf8 Class Initialized
INFO - 2021-04-06 22:38:45 --> URI Class Initialized
DEBUG - 2021-04-06 22:38:45 --> No URI present. Default controller set.
INFO - 2021-04-06 22:38:45 --> Router Class Initialized
INFO - 2021-04-06 22:38:45 --> Output Class Initialized
INFO - 2021-04-06 22:38:45 --> Security Class Initialized
DEBUG - 2021-04-06 22:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 22:38:45 --> Input Class Initialized
INFO - 2021-04-06 22:38:45 --> Language Class Initialized
INFO - 2021-04-06 22:38:45 --> Loader Class Initialized
INFO - 2021-04-06 22:38:45 --> Helper loaded: url_helper
INFO - 2021-04-06 22:38:45 --> Helper loaded: file_helper
INFO - 2021-04-06 22:38:45 --> Helper loaded: utility_helper
INFO - 2021-04-06 22:38:45 --> Helper loaded: unit_helper
INFO - 2021-04-06 22:38:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 22:38:45 --> Database Driver Class Initialized
INFO - 2021-04-06 22:38:45 --> Email Class Initialized
DEBUG - 2021-04-06 22:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 22:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 22:38:45 --> Helper loaded: form_helper
INFO - 2021-04-06 22:38:45 --> Form Validation Class Initialized
INFO - 2021-04-06 22:38:45 --> Controller Class Initialized
INFO - 2021-04-06 22:38:45 --> Model "Common_model" initialized
INFO - 2021-04-06 22:38:45 --> Model "Finane_Model" initialized
INFO - 2021-04-06 22:38:45 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 22:38:45 --> Model "Sales_Model" initialized
INFO - 2021-04-06 22:38:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 22:38:45 --> Final output sent to browser
DEBUG - 2021-04-06 22:38:45 --> Total execution time: 0.0681
INFO - 2021-04-06 22:39:08 --> Config Class Initialized
INFO - 2021-04-06 22:39:08 --> Hooks Class Initialized
DEBUG - 2021-04-06 22:39:08 --> UTF-8 Support Enabled
INFO - 2021-04-06 22:39:08 --> Utf8 Class Initialized
INFO - 2021-04-06 22:39:08 --> URI Class Initialized
INFO - 2021-04-06 22:39:08 --> Router Class Initialized
INFO - 2021-04-06 22:39:08 --> Output Class Initialized
INFO - 2021-04-06 22:39:08 --> Security Class Initialized
DEBUG - 2021-04-06 22:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-06 22:39:08 --> Input Class Initialized
INFO - 2021-04-06 22:39:08 --> Language Class Initialized
INFO - 2021-04-06 22:39:08 --> Loader Class Initialized
INFO - 2021-04-06 22:39:08 --> Helper loaded: url_helper
INFO - 2021-04-06 22:39:08 --> Helper loaded: file_helper
INFO - 2021-04-06 22:39:08 --> Helper loaded: utility_helper
INFO - 2021-04-06 22:39:08 --> Helper loaded: unit_helper
INFO - 2021-04-06 22:39:08 --> Helper loaded: db_dinamic_helper
INFO - 2021-04-06 22:39:08 --> Database Driver Class Initialized
INFO - 2021-04-06 22:39:08 --> Email Class Initialized
DEBUG - 2021-04-06 22:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-06 22:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-06 22:39:08 --> Helper loaded: form_helper
INFO - 2021-04-06 22:39:08 --> Form Validation Class Initialized
INFO - 2021-04-06 22:39:08 --> Controller Class Initialized
INFO - 2021-04-06 22:39:08 --> Model "Common_model" initialized
INFO - 2021-04-06 22:39:08 --> Model "Finane_Model" initialized
INFO - 2021-04-06 22:39:08 --> Model "Inventory_Model" initialized
INFO - 2021-04-06 22:39:08 --> Model "Sales_Model" initialized
INFO - 2021-04-06 22:39:08 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-04-06 22:39:08 --> Final output sent to browser
DEBUG - 2021-04-06 22:39:08 --> Total execution time: 0.0384
