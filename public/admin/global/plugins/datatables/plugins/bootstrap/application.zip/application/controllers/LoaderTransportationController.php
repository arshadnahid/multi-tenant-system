<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class LoaderTransportationController extends CI_Controller {

    private $timestamp;
    private $admin_id;
    public $dist_id;
    public $project;
    public function __construct() {
        parent::__construct();

        $this->output->set_header("HTTP/1.0 200 OK");
        $this->output->set_header("HTTP/1.1 200 OK");
        $this->output->set_header('Expires: Sat, 26 Jul 2018 05:00:00 GMT');
        $this->output->set_header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");

        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        //$this->load->model('Datatable');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->dist_id = $this->session->userdata('dis_id');
        $this->project = $this->session->userdata('project');
        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url());
        }
        $this->db_hostname = $this->session->userdata('db_hostname');
        $this->db_username = $this->session->userdata('db_username');
        $this->db_password = $this->session->userdata('db_password');
        $this->db_name = $this->session->userdata('db_name');
        $this->db->close();
        $config_app = switch_db_dinamico($this->db_username, $this->db_password, $this->db_name);
        $this->db = $this->load->database($config_app, TRUE);




    }

    public function employeeList() {
        $condition = array(
            'dist_id' => $this->dist_id,
            'isActive' => 'Y',
            'isDelete' => 'N',
        );
        $data['title'] = 'Employee List';
        $data['employeeList'] = $this->Common_model->get_data_list_by_many_columns('employee', $condition);
        $data['mainContent'] = $this->load->view('distributor/setup/employee/employeeLisst', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function employeeAdd() {
        if (isPostBack()) {
            $profileName = $_FILES['profile']['name'];
            if (!empty($profileName)) {
                $profilename1 = explode(".", $profileName);
                $extension = end($profilename1);
                $base_name = $profilename1[0];
                if (file_exists("uploads/employee/" . $_FILES['profile']['name'])) {
                    $profileName = $base_name . "_" . time() . "." . $extension;
                }
                move_uploaded_file($_FILES['profile']['tmp_name'], "uploads/employee/" . $profileName);
                $data['profile'] = $profileName;
            } else {
                $data['profile'] = '';
            }
            $data['name'] = $this->input->post('name');
            $data['employeeId'] = $this->input->post('employeeId');
            $data['fathersName'] = $this->input->post('fathersName');
            $data['mothersName'] = $this->input->post('mothersName');
            $data['presentAddress'] = $this->input->post('presentAddress');
            $data['permanentAddress'] = $this->input->post('permanentAddress');
            $data['dateOfBirth'] = date('Y-m-d', strtotime($this->input->post('dateOfBirth')));
            $data['gender'] = $this->input->post('gender');
            $data['nationalId'] = $this->input->post('nationalId');
            $data['religion'] = $this->input->post('religion');
            $data['emailAddress'] = $this->input->post('emailAddress');
            $data['homeDistrict'] = $this->input->post('homeDistrict');
            $data['personalMobile'] = $this->input->post('personalMobile');
            $data['maritalStatus'] = $this->input->post('maritalStatus');
            $data['officeMobile'] = $this->input->post('officeMobile');
            $data['bloodGroup'] = $this->input->post('bloodGroup');
            $data['joiningDate'] = date('Y-m-d', strtotime($this->input->post('joiningDate')));
            $data['employeeType'] = $this->input->post('employeeType');
            $data['salary'] = $this->input->post('salary');
            $data['empStatus'] = $this->input->post('empStatus');
            $data['createdBy'] = $this->admin_id;
            $data['isActive'] = 'Y';
            $data['isDelete'] = 'N';
            $data['dist_id'] = $this->dist_id;
            $this->Common_model->insert_data('employee', $data);
            message("Your Data successfully inserted into database.");
            redirect(site_url($this->project . '/employeeList'));
        }

        $condition = array(
            'isActive' => 'Y',
            'isDelete' => 'N',
        );
        $data['title'] = 'Employee Add';
        $data['religion'] = $this->Common_model->get_data_list_by_many_columns('religion', $condition);
        $data['districts'] = $this->Common_model->get_data_list('districts', 'name', 'ASC');
        $data['bloodGroup'] = $this->Common_model->get_data_list('blood_group', 'bloodName', 'ASC');
        $data['mainContent'] = $this->load->view('distributor/setup/employee/addNewEmployee', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }
    function employeeEdit($editId) {
        if (isPostBack()) {
            $profileName = $_FILES['profile']['name'];
            if (!empty($profileName)) {
                $profilename1 = explode(".", $profileName);
                $extension = end($profilename1);
                $base_name = $profilename1[0];
                if (file_exists("uploads/employee/" . $_FILES['profile']['name'])) {
                    $profileName = $base_name . "_" . time() . "." . $extension;
                }
                move_uploaded_file($_FILES['profile']['tmp_name'], "uploads/employee/" . $profileName);
                $data['profile'] = $profileName;
            } else {
                $data['profile'] = $this->input->post('oldImage');
            }
            $data['name'] = $this->input->post('name');
            $data['employeeId'] = $this->input->post('employeeId');
            $data['fathersName'] = $this->input->post('fathersName');
            $data['mothersName'] = $this->input->post('mothersName');
            $data['presentAddress'] = $this->input->post('presentAddress');
            $data['permanentAddress'] = $this->input->post('permanentAddress');
            $data['dateOfBirth'] = date('Y-m-d', strtotime($this->input->post('dateOfBirth')));
            $data['gender'] = $this->input->post('gender');
            $data['nationalId'] = $this->input->post('nationalId');
            $data['religion'] = $this->input->post('religion');
            $data['emailAddress'] = $this->input->post('emailAddress');
            $data['homeDistrict'] = $this->input->post('homeDistrict');
            $data['personalMobile'] = $this->input->post('personalMobile');
            $data['maritalStatus'] = $this->input->post('maritalStatus');
            $data['officeMobile'] = $this->input->post('officeMobile');
            $data['bloodGroup'] = $this->input->post('bloodGroup');
            $data['joiningDate'] = date('Y-m-d', strtotime($this->input->post('joiningDate')));
            $data['employeeType'] = $this->input->post('employeeType');
            $data['salary'] = $this->input->post('salary');
            $data['empStatus'] = $this->input->post('empStatus');
            $data['createdBy'] = $this->admin_id;
            $data['isActive'] = 'Y';
            $data['isDelete'] = 'N';
            $data['dist_id'] = $this->dist_id;
            $this->Common_model->update_data('employee', $data, 'id', $editId);
            message("Your Data successfully updated into database.");
            redirect(site_url($this->project . '/employeeList'));
        }
        $condition = array(
            'isActive' => 'Y',
            'isDelete' => 'N',
        );
        $data['title'] = 'Employee Edit';
        $data['editEmp'] = $this->Common_model->get_single_data_by_single_column('employee', 'id', $editId);
        $data['religion'] = $this->Common_model->get_data_list_by_many_columns('religion', $condition);
        $data['districts'] = $this->Common_model->get_data_list('districts', 'name', 'ASC');
        $data['bloodGroup'] = $this->Common_model->get_data_list('blood_group', 'bloodName', 'ASC');
        $data['mainContent'] = $this->load->view('distributor/setup/employee/editEmployee', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function employeeDelete($deleteId) {
        $data['isDelete'] = 'Y';
        $data['deletedAt'] = $this->timestamp;
        $data['deletedBy'] = $this->admin_id;
        $this->Common_model->update_data('employee', $data, 'id', $deleteId);
        message("Your data successfully deleted from database");
        redirect(site_url($this->project . '/employeeList'));
    }

    public function vehicleList() {
        $condition = array(
            'dist_id' => $this->dist_id,
            'isActive' => 'Y',
            'isDelete' => 'N',
        );
        $data['title'] = 'Vehicle List';
        $data['vehicleList'] = $this->Common_model->get_data_list_by_many_columns('vehicle', $condition);
        $data['mainContent'] = $this->load->view('distributor/setup/vehicle/vehicleList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function vehicleAdd() {
        if (isPostBack()) {
            $data['vehicleName'] = $this->input->post('vehicleName');
            $data['vehicleModel'] = $this->input->post('vehicleModel');
            $data['chassisNumber'] = $this->input->post('chassisNumber');
            $data['numberPlate'] = $this->input->post('numberPlate');
            $data['createdBy'] = $this->admin_id;
            $data['dist_id'] = $this->dist_id;
            $data['isActive'] = 'Y';
            $data['isDelete'] = 'N';
            $this->Common_model->insert_data('vehicle', $data);
            message("Your data successfully inserted into database.");
            redirect(site_url($this->project . '/vehicleList'));
        }
        $data['title'] = 'Vehicle List';
        $data['mainContent'] = $this->load->view('distributor/setup/vehicle/addNew', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    public function vehicleEdit($editId) {
        if (isPostBack()) {
            $data['vehicleName'] = $this->input->post('vehicleName');
            $data['vehicleModel'] = $this->input->post('vehicleModel');
            $data['chassisNumber'] = $this->input->post('chassisNumber');
            $data['numberPlate'] = $this->input->post('numberPlate');
            $this->Common_model->update_data('vehicle', $data, 'id', $editId);
            message("Your data successfully Updated into database.");
            redirect(site_url($this->project . '/vehicleList'));
        }
        $data['title'] = 'Vehicle Update';
        $data['vehicleList'] = $this->Common_model->get_single_data_by_single_column('vehicle', 'id', $editId);
        $data['mainContent'] = $this->load->view('distributor/setup/vehicle/editVehicle', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

    function vehicleDelete($vehicleId) {
        $data['isDelete'] = 'Y';
        $data['deletedBy'] = $this->admin_id;
        $data['deletedAt'] = $this->timestamp;
        $this->Common_model->update_data('vehicle', $data, 'id', $vehicleId);
        message("Your data successfylly deleted from database.");
        redirect(site_url($this->project . '/vehicleList'));
    }

}
