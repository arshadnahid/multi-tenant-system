
<?php
if (isset($_POST['start_date'])):
    $supplierId = $this->input->post('supplierId');
    $from_date = $this->input->post('start_date');
    $to_date = $this->input->post('end_date');
endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Account</a>
                </li>
                <li>Account Report</li>
                <li class="active">Supplier Ledger</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li class="active">
                    <i class="ace-icon fa fa-list"></i>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/account'); ?>">List</a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action="" method="post" class="form-horizontal">
                        <div class="col-sm-10 col-md-offset-1">
                            <div class="table-header">
                                Supplier Ledger
                            </div>
                            <br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1">
                                            Supplier</label>
                                        <div class="col-sm-8">
                                            <select name="supplierId" class="chosen-select form-control"
                                                    id="form-field-select-3" data-placeholder="Search by Supplier"
                                                    onchange="check_pretty_cash(this.value)">
                                                <option <?php
                                                if (!empty($supplierId) && $supplierId == 'all') {
                                                    echo "selected";
                                                }
                                                ?> value="all">All
                                                </option>
                                                <?php foreach ($supplierList as $eachInfo): ?>
                                                    <option <?php
                                                    if (!empty($supplierId) && $supplierId == $eachInfo->sup_id) {
                                                        echo "selected";
                                                    }
                                                    ?> value="<?php echo $eachInfo->sup_id; ?>"><?php echo $eachInfo->supName; ?>
                                                        [<?php echo $eachInfo->supID; ?>]
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From
                                            Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker" id="start_date" name="start_date"
                                                   value="<?php
                                                   if (!empty($from_date)) {
                                                       echo $from_date;
                                                   } else {
                                                       echo date('d-m-Y');
                                                   }
                                                   ?>" data-date-format='dd-mm-yyyy'
                                                   placeholder="Start Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To
                                            Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker" id="end_date" name="end_date"
                                                   value="<?php
                                                   if (!empty($to_date)):
                                                       echo $to_date;
                                                   else:
                                                       echo date('d-m-Y');
                                                   endif;
                                                   ?>" data-date-format='dd-mm-yyyy'
                                                   placeholder="End Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <div class="col-sm-6">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-6">
                                            <button type="button" class="btn btn-info btn-sm" onclick="window.print();"
                                                    style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date']) && isset($_POST['end_date'])) :
                // dumpVar($_POST);
                $supplierId = $this->input->post('supplierId');
                $from = date('Y-m-d', strtotime($this->input->post('start_date')));
                $to = date('Y-m-d', strtotime($this->input->post('end_date')));
                unset($_SESSION["supplierId"]);
                unset($_SESSION["start_date"]);
                unset($_SESSION["end_date"]);
                $_SESSION["supplierId"] = $supplierId;
                $_SESSION["start_date"] = $from;
                $_SESSION["end_date"] = $to;
                $dist_id = $this->dist_id;
                $dr = 0;
                $cr = 0;
                if ($supplierId != 'all'):
                    ?>
                    <div class="row">
                        <div class="col-sm-10 col-md-offset-1">
                            <div class="table-header">
                                Supplier Ledger <span style="color:greenyellow;">From <?php echo $from_date; ?>
                                    To <?php echo $to_date; ?></span>
                            </div>
                            <!--                            <div class="noPrint">
                                                        <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url($this->project . '/FinaneController/supplierLedger_export_excel/') ?>" class="btn btn-success pull-right">
                                                            <i class="ace-icon fa fa-download"></i>
                                                            Excel
                                                        </a>
                                                        </div>-->


                            <?php if ($companyInfo->invoice_format_type == 1): ?>
                                <table class="table table-responsive">
                                    <tr>
                                        <td style="text-align:center;">
                                            <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                            <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                            <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                            <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                            <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                            <strong><?php
                                                $supplierInfo = $this->Common_model->tableRow('supplier', 'sup_id', $supplierId);
                                                echo $supplierInfo->supName . ' [ ' . $supplierInfo->supID . ' ]';
                                                ?></strong>

                                        </td>
                                    </tr>
                                </table>

                            <?php else: ?>
                                <div class="row text-center">
                                    <?php echo $companyInfo->report_header; ?>
                                    <strong style="font-size: 18px;"><?php
                                        $supplierInfo = $this->Common_model->tableRow('supplier', 'sup_id', $supplierId);
                                        echo $supplierInfo->supName . ' [ ' . $supplierInfo->supID . ' ]';
                                        ?></strong><br><br>
                                </div>
                            <?php endif; ?>


                            <table class="table table-bordered">

                                <tr>
                                    <td rowspan="2" class="text-center" ><strong>SL</strong></td>
                                    <td rowspan="2" class="text-center"><strong>Date</strong></td>
                                    <td rowspan="2" class="text-center"><strong>Voucher No</strong></td>
                                    <td colspan="5" class="text-center" style="width:56%"><strong>Product</strong></td>
                                   <!-- <td align="left"><strong>Type</strong></td>-->
                                    <!--<td align="center"><strong>Charge</strong></td>-->
                                    <td rowspan="2" class="text-center" ><strong>Payable (+)</strong></td>
                                    <td rowspan="2" class="text-center"><strong>Paid (-)</strong></td>
                                    <td rowspan="2" class="text-center"><strong>Due</strong></td>
                                </tr>
                                <tr>

                                        <td class="text-center" style="width:20%" ><strong>Name</strong></td>
                                        <td class="text-center" style="width:8%" ><strong>Qty</strong></td>
                                        <td class="text-center"  style="width:8%"><strong>Unit</strong></td>
                                        <td class="text-center" style="width:10%"><strong>Price</strong></td>
                                        <td class="text-center" style="width:10%"><strong>Toatal Price </strong></td>
                                    </tr>

                                <tbody>
                                <tr>
                                    <td colspan="10" align="right"><strong>Opening Balance (In BDT.)</strong></td>
                                    <td align="right"><?php
                                        $supOpe = $this->Finane_Model->getSupOpe($supplierId, $from, $dist_id);
                                        echo number_format((float)$supOpe, 2, '.', ',');
                                        ?></td>
                                </tr>
                                <?php
                                $dr = '';
                                $cr = '';
                                $tdr = '';
                                $tcr = '';
                                $query = $this->Finane_Model->supplier_ledger($supplierId, $from, $to, $dist_id);
                                foreach ($query as $key => $row):
                                    $generalinfo = $this->Common_model->tableRow('generals', 'generals_id', $row['history_id']);
                                    $formId = $generalinfo->form_id;
                                    ?>
                                    <tr>
                                        <td><?php echo $key + 1; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td>
                                        <td align="left">
                                            <?php
                                            if ($formId == 14) {
                                                ?>
                                                <a target="_blank"
                                                   href="<?php echo site_url($this->project . '/viewMoneryReceiptForPayment/' . $generalinfo->generals_id); ?>"><?php echo $row['trans_type']; ?></a>
                                            <?php } elseif ($formId == 2) {
                                                ?>
                                                <a target="_blank"
                                                   href="<?php echo site_url($this->project . '/paymentVoucherView/' . $row['history_id']); ?>"><?php echo $row['trans_type']; ?></a>
                                            <?php } elseif ($formId == 3) {
                                                ?>
                                                <a target="_blank"
                                                   href="<?php echo site_url($this->project . '/receiveVoucherView/' . $row['history_id']); ?>"><?php echo $row['trans_type']; ?></a>
                                            <?php } elseif ($formId == 7) {
                                                ?>
                                                <a target="_blank" title="View Sales Voucher"
                                                   href="<?php echo site_url($this->project . '/viewMoneryReceiptForPayment/' . $generalinfo->generals_id); ?>"> <?php echo $row['trans_type']; ?></a>
                                            <?php } elseif ($formId == 1) {
                                                ?>
                                                <a target="_blank"
                                                   href="<?php echo site_url($this->project . '/journalVoucherView/' . $row['history_id']); ?>"><?php echo $row['trans_type']; ?></a>
                                            <?php } elseif ($formId == 5) {
                                                ?>
                                                <a target="_blank" title="View Sales Voucher"
                                                   href="<?php echo site_url($this->project . '/salesInvoice_view/' . $row['history_id']); ?>"><?php echo $row['trans_type']; ?></a>
                                                <?php
                                            } elseif ($formId == 11) {
                                                ?>
                                                <a target="_blank" title="View Purchases Voucher"
                                                   href="<?php echo site_url($this->project . '/viewPurchases/' . $row['history_id']); ?>"><?php echo $row['trans_type']; ?></a>
                                                <?php
                                            } else {
                                                echo $row['trans_type'];
                                            }
                                            if ($row['paymentType'] != '') {
                                                echo "(<span>" . $row['paymentType'] . "</span>)";
                                            }
                                            ?>
                                        </td>
                                       <td colspan="5" style="padding: 0px !important;">
                                            <?php
                                            if ($formId == 11) {
                                                $salesProductList = $this->Common_model->get_data_list_by_single_column('stock', 'generals_id', $row['history_id']);
                                                ?>
                                                <table class="table table-bordered" style="margin-bottom: 0px">

                                                    

                                                    <tbody>
                                                    <?php
                                                    foreach ($salesProductList as $key => $each_info):
                                                        if ($each_info->type == 'In') {
                                                            $productCategoryName=$this->Common_model->tableRow('productcategory', 'category_id', $each_info->category_id)->title;
                                                            $productInfo=$this->Common_model->tableRow('product', 'product_id', $each_info->product_id);
                                                            $productName=$productInfo->productName;
                                                            $brandName=$this->Common_model->tableRow('brand', 'brandId', $productInfo->brand_id)->brandName;
                                                            ?>
                                                            <tr>
                                                                <td class="text-left" style="width:20%;text-align: center;"><?php echo $productCategoryName .' '.$productName .' [ '.$brandName.' ]'.'&nbsp' ?></td>
                                                                <td class="text-right" style="width:8%;vertical-align: middle;text-align: right"><?php echo $each_info->quantity.'&nbsp' ?></td>
                                                                <td class="text-right" style="width:8%;vertical-align: middle;"><?php
                                                                    if (!empty($productInfo->unit_id)):
                                                                        echo $this->Common_model->tableRow('unit', 'unit_id', $productInfo->unit_id)->unitTtile.'&nbsp' ;
                                                                    else:
                                                                        echo "KG".'&nbsp' ;
                                                                    endif;
                                                                    ?></td>
                                                                <td class="text-right" style="width:10%;vertical-align: middle;"><?php echo $each_info->rate .' ';

                                                                   /* if (!empty($productInfo->unit_id)):
                                                                        echo $this->Common_model->tableRow('unit', 'unit_id', $productInfo->unit_id)->unitTtile.'&nbsp';
                                                                    else:
                                                                        echo "KG".'&nbsp';
                                                                    endif;*/
                                                                    ?></td>
                                                                <td class="text-right" style="width:10%;vertical-align: middle;"><?php  echo number_format($each_info->rate * $each_info->quantity, 2).'&nbsp'; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    endforeach;
                                                    ?>
                                                    </tbody>
                                                </table>

                                            <?php }
                                            ?>

                                        </td>
                                       <!-- <td align="left"><?php /*echo $row['paymentType']; */?></td>-->
                                        <!--<td align="right"><?php //echo number_format((float) $row['amount'], 2, '.', ',');
                                        ?></td>-->
                                        <td align="right"><?php
                                            $dr += $row['dr'];
                                            $tdr += $row['dr'];
                                            echo number_format((float)$row['dr'], 2, '.', ',');
                                            ?></td>
                                        <td align="right"><?php
                                            $cr += $row['cr'];
                                            $tcr += $row['cr'];
                                            echo number_format((float)$row['cr'], 2, '.', ',');
                                            ?></td>
                                        <td align="right"><?php
                                            echo number_format((float)($dr - $cr) + $supOpe, 2, '.', ',');
                                            ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <td colspan="8" align="right"><strong>Total (In BDT.)</strong></td>
                                    <td align="right">
                                        <strong><?php echo number_format((float)$tdr, 2, '.', ','); ?></strong></td>
                                    <td align="right">
                                        <strong> <?php echo number_format((float)$tcr, 2, '.', ','); ?></strong></td>
                                    <td align="right"><strong> <?php
                                            echo number_format((float)($dr - $cr) + $supOpe, 2, '.', ',');
                                            $finalAmount = $dr - $cr;
                                            ?></strong></td>
                                </tr>
                                </tfoot>
                            </table>
                            <br>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <div class="col-sm-10 col-md-offset-1">
                            <div class="table-header">
                                Supplier Ledger <span style="color:greenyellow;">From <?php echo $from_date; ?>
                                    To <?php echo $to_date; ?></span>
                            </div>
                            <!--                            <div class="noPrint">
                                                        <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url($this->project . '/FinaneController/supplierLedger_export_excel/') ?>" class="btn btn-success pull-right">
                                                            <i class="ace-icon fa fa-download"></i>
                                                            Excel
                                                        </a></div>-->


                            <?php if ($companyInfo->invoice_format_type == 1): ?>
                                <table class="table table-responsive">
                                    <tr>
                                        <td style="text-align:center;">
                                            <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                            <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                            <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                            <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                            <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                            <strong>All Supplier Ledger</strong><br>

                                        </td>
                                    </tr>
                                </table>

                            <?php else: ?>
                                <div class="row text-center">
                                    <?php echo $companyInfo->report_header; ?>
                                    <strong style="font-size: 18px;">All Supplier Ledger</strong><br><br>
                                </div>
                            <?php endif; ?>


                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <td align="left"><strong>SL</strong></td>
                                    <td align="left"><strong>Name</strong></td>
                                    <td align="left"><strong>Address</strong></td>
                                    <td align="left"><strong>Contact Number</strong></td>
                                    <td align="left"><strong>Opening Balance</strong></td>
                                    <td align="right"><strong>Payable (+)</strong></td>
                                    <td align="right"><strong>Paid (-)</strong></td>
                                    <td align="right"><strong>Due</strong></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $ttopen = 0;
                                $ttdrebit = 0;
                                $ttcredit = 0;
                                $sl = 1;
                                foreach ($supplierList as $key => $eachSup):
                                    $supplierBal = $this->Finane_Model->getSupplierSummation($eachSup->sup_id, $from, $to, $dist_id);
                                    if (!empty($supplierBal['opening']) || !empty($supplierBal['debit']) || !empty($supplierBal['credit'])):
                                        ?>
                                        <tr>
                                            <td><?php echo $sl++; ?></td>
                                            <td align="left">
                                                <a target="_blank" title="View Supplier Dashboard"
                                                   href="<?php echo site_url($this->project . '/supplierDashboard/' . $eachSup->sup_id); ?>"><?php echo $eachSup->supID . ' [ ' . $eachSup->supName . ' ] '; ?></a>
                                            </td>
                                            <td align="center"><?php echo $eachSup->address; ?></td>
                                            <td align="center"><?php echo $eachSup->mobile; ?></td>
                                            <td align="right"><?php
                                                echo number_format((float)$supplierBal['opening'], 2, '.', ',');
                                                $ttopen += $supplierBal['opening'];
                                                ?></td>
                                            <td align="right"><?php
                                                echo number_format((float)$supplierBal['debit'], 2, '.', ',');
                                                $ttdrebit += $supplierBal['debit'];
                                                ?></td>
                                            <td align="right"><?php
                                                echo number_format((float)$supplierBal['credit'], 2, '.', ',');
                                                $ttcredit += $supplierBal['credit'];
                                                ?></td>
                                            <td align="right"><?php
                                                echo number_format((float)($supplierBal['opening'] + $supplierBal['debit']) - $supplierBal['credit'], 2, '.', ',');
                                                ?></td>
                                        </tr>
                                        <?php
                                    endif;
                                endforeach;
                                ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <td colspan="4" align="right"><strong>Total (In BDT.)</strong></td>
                                    <td align="right">
                                        <strong><?php echo number_format((float)$ttopen, 2, '.', ','); ?></strong></td>
                                    <td align="right">
                                        <strong><?php echo number_format((float)$ttdrebit, 2, '.', ','); ?></strong>
                                    </td>
                                    <td align="right">
                                        <strong> <?php echo number_format((float)$ttcredit, 2, '.', ','); ?></strong>
                                    </td>
                                    <td align="right">
                                        <strong> <?php echo number_format((float)($ttdrebit - $ttcredit) + $ttopen, 2, '.', ','); ?></strong>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <?php
                endif;
            endif;
            ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
