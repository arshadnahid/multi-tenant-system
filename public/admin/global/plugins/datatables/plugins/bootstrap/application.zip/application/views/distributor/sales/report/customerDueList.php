
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sale</a>
                </li>
                <li>Customer Due List</li>

            </ul>

        </div>
        <br>
        <div class="page-content">



            <div class="row">
                <div class="col-sm-10 col-md-offset-1">
                    <div class="table-header">
                        Customer Due List <span style="color:greenyellow;"></span>
                        <div class="widget-toolbar hidden-280 noPrint"  class="hidden-xs" style="margin-top:-10px;">
                            <a  onclick="window.print();" style="cursor:pointer;color:white;">
                                <i class="ace-icon fa fa-print"></i>
                            </a>
                        </div>
                    </div>
                    <?php if ($companyInfo->invoice_format_type == 1): ?>


                        <table class="table table-responsive">
                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                    <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                    <strong><?php echo $pageTitle; ?></strong>
                                </td>
                            </tr>
                        </table>

                    <?php else: ?>
                        <div>
                            <?php echo $companyInfo->report_header; ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <td align="center"><strong>SL</strong></td>
                                <td align="left"><strong>Customer Name</strong></td>
                                <td align="left"><strong>Invoice No</strong></td>
                                <td align="left"><strong>Invoice Date</strong></td>
                                <td align="right"><strong>Invoice Amount</strong></td>
                                <td align="right"><strong>Paid Amount</strong></td>
                                <td align="right"><strong>Due Amount</strong></td>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            foreach ($allResult as $key => $row):

                                $tinvoieAmount+=$row->invoiceamount;
                                $tpaidAmount+=$row->paidAmount;
                                $tDueAmount+=$row->dueAmount;
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td align="left"><?php echo $row->customerName; ?></td>
                                    <td align="left"><?php echo $row->voucher_no; ?></td>
                                    <td align="left"><?php echo date('M d, Y', strtotime($row->date)); ?></td>
                                    <td align="right"><?php echo $row->invoiceamount; ?></td>
                                    <td align="right"><?php echo $row->paidAmount; ?></td>
                                    <td align="right"><?php echo $row->dueAmount; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" align="right"><strong>Total (In BDT.)</strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tinvoieAmount, 2, '.', ','); ?></strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tpaidAmount, 2, '.', ','); ?></strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tDueAmount, 2, '.', ','); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                    <br>
                </div>
            </div>

        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
