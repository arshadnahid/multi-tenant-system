<?php
if (isset($_POST['start_date'])):
    $start_date = $this->input->post('start_date');
    $end_date = $this->input->post('end_date');
    $brandId = $this->input->post('brandId');
endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li>Cylinder Report</li>
                <li class="active">Full Stock Report</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/inventory'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row noPrint">
                <div class="col-md-10 col-md-offset-1">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-12">
                            <div class="table-header">
                                Full Stock Report
                            </div>
                            <br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Brand</label>
                                        <div class="col-sm-8">
                                            <select  name="brandId" class="chosen-select form-control supplierid" id="form-field-select-3" data-placeholder="Search by Brand">
                                                <option <?php
if (!empty($brandId) && $brandId == 'all') {
    echo "selected";
}
?> value="all">All</option>
                                                    <?php foreach ($brandList as $eachInfo): ?>
                                                    <option <?php
                                                    if (!empty($brandId) && $brandId == $eachInfo->brandId) {
                                                        echo "selected";
                                                    }
                                                        ?> value="<?php echo $eachInfo->brandId; ?>"><?php echo $eachInfo->brandName; ?></option>
                                                    <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From Date</label>
                                        <div class="col-sm-8">
                                            <input type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                                    if (!empty($start_date)) {
                                                        echo $start_date;
                                                    } else {
                                                        echo date('d-m-Y');
                                                    }
                                                    ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                                   if (!empty($end_date)) {
                                                       echo $end_date;
                                                   } else {
                                                       echo date('d-m-Y');
                                                   }
                                                    ?>" data-date-format='dd-mm-yyyy' placeholder="End Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="col-sm-6">
                                        <button type="submit" class="btn btn-success btn-sm">
                                            <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                            Search
                                        </button>
                                    </div>
                                    <div class="col-sm-6">
                                        <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                            <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                            Print
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php if (isset($_POST['start_date'])): ?>
                <div class="row">
                    <div class="col-xs-10 col-md-offset-1">
                        <div class="table-header">
                            Full  Stock Report <span style="color:greenyellow;">From <?php echo $start_date; ?> To <?php echo $end_date; ?></span>
                        </div>
                        <div class="noPrint">
    <!--                        <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url($this->project . '/InventoryController/stockReport_export_excel/') ?>" class="btn btn-success pull-right">
                            <i class="ace-icon fa fa-download"></i>
                            Excel
                        </a>-->
                        </div>
                        <table class="table table-responsive">
                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <span><?php echo $companyInfo->address; ?></span><br>
                                    <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                    <strong><?php echo $pageTitle; ?></strong>
                                </td>
                            </tr>
                        </table>
                        <table class="table table-striped table-bordered table-hover table-responsive">
                            <thead>
                                <tr>
                                    <td  style="text-align:center;"><strong>Brand</strong></td>
                                    <td   style="text-align:center;"><strong>Refill Cylinder</strong></td>
                                    <td   style="text-align:center;"><strong>Empty Cylinder</strong></td>
                                    <td   style="text-align:center;"><strong>Total</strong></td>
                                    <td   style="text-align:center;"><strong>Customer Due</strong></td>
                                    <td   style="text-align:center;"><strong>Customer Exits</strong></td>
                                    <td   style="text-align:center;"><strong>Closing stock</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                            <tbody>
                                <?php
                                $totalCylinder = 0;
                                $totalRefill = 0;
                                $totalRefillCylinder = 0;
                                $totalCusDue = 0;
                                $totalCusExits = 0;
                                $final = 0;
                                foreach ($fullStockReport as $key => $value):
                                    $cylinderStock = $value->cylinderPurIn - $value->cylinderSaleOut;
                                    $totalCylinder+=$cylinderStock;
                                    $refillStock = $value->totalRefillIn - $value->totalRefillOut;
                                    $totalRefill+=$refillStock;
                                    $totalRefillCylinder+=$cylinderStock + $refillStock;
                                    $customerDue = $value->totalCusCylinOut - $value->totalCusIn;
                                    $totalCusDue+=$customerDue;
                                    $customerExits = $value->totalCusIn - $value->totalCusCylinOut;
                                    if ($customerExits >= 1) {

                                        $totalCusExits+=$customerExits;
                                    }

                                    $final+=$refillStock + $cylinderStock + $customerDue;
                                    //$final+=$refillStock + $cylinderStock + $customerDue;

                                    if (!empty($refillStock) || !empty($cylinderStock) || !empty($customerDue) || !empty($customerExits)):
                                        ?>
                                        <tr>
                                            <td ><?php echo $value->brandName; ?></td>
                                            <td align="right"><?php echo $value->totalRefillIn - $value->totalRefillOut; ?></td>
                                            <td align="right"><?php echo $value->cylinderPurIn - $value->cylinderSaleOut; ?></td>
                                            <td align="right"><?php echo $cylinderStock + $refillStock; ?></td>
                                            <td align="right"><?php
                            if ($customerDue >= 1) {
                                echo $customerDue;
                            }
                                        ?></td>
                                            <td align="right"><?php
                                    if ($customerExits >= 1) {
                                        echo abs($customerExits);
                                    }
                                        ?></td>
                                            <td align="right"><?php echo abs($refillStock + $cylinderStock + $customerDue); ?></td>
                                        </tr>
                                        <?php
                                    endif;

                                endforeach;
                                ?>
                            </tbody>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td  align="right"><strong>Total (BDT) </strong></td>
                                    <td align="right" ><strong><?php echo $totalRefill; ?></strong></td>
                                    <td align="right" ><strong><?php echo $totalCylinder; ?></strong></td>
                                    <td align="right"><strong><?php echo $totalRefillCylinder; ?></strong></td>
                                    <td align="right" ><strong> <?php echo $totalCusDue; ?></strong></td>
                                    <td align="right" ><strong> <?php echo $totalCusExits; ?></strong></td>
                                    <td align="right" ><strong> <?php echo $final; ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
