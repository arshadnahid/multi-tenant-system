<?php
if (isset($_POST['start_date'])):
    $type_id = $this->input->post('type_id');
    $customer_id = $this->input->post('customer_id');
    $supplier_id = $this->input->post('supplier_id');
    $searchId = $this->input->post('searchId');
    $groupId = $this->input->post('groupId');
    $from_date = date('Y-m-d', strtotime($this->input->post('start_date')));
    $to_date = date('Y-m-d', strtotime($this->input->post('end_date')));
    $dist_id = $this->dist_id;

endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li>Cylinder Report</li>
                <li class="active">Customer/Supplier Wise Cylinder</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/inventory'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-12">
                            <div class="table-header">
                                Customer/Supplier Group Wise Cylinder
                            </div>
                            <br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Type</label>
                                        <div class="col-sm-8">
                                            <select  onchange="selectPayType(this.value)"  id="type_id"   class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Type">

                                                <option value="">-Select-</option>



                                                <option <?php
                                                    if ($type_id == 2) {
                                                        echo "selected";
                                                    }
?> value="2">Customer</option>
                                                <option <?php
                                                    if ($type_id == 3) {
                                                        echo "selected";
                                                    }
?>  value="3">Supplier </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="searchValue"></div>
                                    <div id="oldValue">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label no-padding-right" for="form-field-1"> ID <span style="color:red;">*</span></label>
                                            <div class="col-sm-10">
                                                <select  id="productID" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Name">
                                                    <option value="all">All</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Group</label>
                                        <div class="col-sm-8">
                                            <select   id="groupId" name="groupId"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Group">
                                                <option <?php
                                                    if ($groupId == 'all') {
                                                        echo "selected";
                                                    }
?> value="all">All</option>
                                                    <?php foreach ($typeList as $key => $value): ?>
                                                    <option <?php
                                                    if ($groupId == $value->product_type_id) {
                                                        echo "selected";
                                                    }
                                                        ?> value="<?php echo $value->product_type_id; ?>"><?php echo $value->product_type_name; ?></option>

                                                <?php endforeach; ?>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> From </label>
                                            <div class="col-sm-9">
                                                <input style="width: 100%" type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                                if (!empty($from_date)) {
                                                    echo $from_date;
                                                } else {
                                                    echo date('d-m-Y');
                                                }
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">To</label>
                                            <div class="col-sm-9">
                                                <input  style="width: 100%"  type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                                       if (!empty($to_date)):
                                                           echo $to_date;
                                                       else:
                                                           echo date('d-m-Y');
                                                       endif;
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="End Date: dd-mm-yyyy"/>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">

                                        <div class="col-sm-3">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-3">
                                            <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):
                ?>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="table-header">
                            Supplier/Customer Group Wise Cylinder Report Period <span style="color:greenyellow;">From <?php echo $from_date; ?> To <?php echo $to_date; ?></span>
                        </div>
                        <table class="table table-responsive">
                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <span><?php echo $companyInfo->address; ?></span><br>
                                    <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                    <strong><?php echo $pageTitle; ?></strong>
                                </td>
                            </tr>
                        </table>

                        <table class="table table-striped table-bordered table-hover table-responsive" id="mergeTable">
                            <thead>
                                <tr>
                                    <td align="center"><strong>SL</strong></td>
                                    <td align="center"><strong>Customer</strong></td>
                                    <td align="center"><strong>Product Type</strong></td>
                                    <td align="right"><strong>Opening Stock</strong></td>
                                    <td align="right"><strong> Stock In</strong></td>
                                    <td align="right"><strong> Stock Out</strong></td>
                                    <td align="right"><strong>Balance</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $opening = '';
                                $stockIn = '';
                                $stockOut = '';
                                $finalStock = '';
                                foreach ($result as $key => $eachInfo):
                                    $opening+=$eachInfo->balance;
                                    $stockIn+=$eachInfo->currentStockIn;
                                    $stockOut+=$eachInfo->currentStockOut;
                                    $finalStock+=$eachInfo->finalStock;
                                    ?>
                                    <tr>
                                        <td><?php echo $key + 1; ?></td>
                                        <td><?php echo $eachInfo->customerName; ?></td>
                                        <td><?php echo $eachInfo->product_type_name; ?></td>
                                        <td align="right"><?php echo $eachInfo->balance; ?></td>
                                        <td align="right"><?php echo $eachInfo->currentStockIn; ?></td>
                                        <td align="right"><?php echo $eachInfo->currentStockOut; ?></td>
                                        <td align="right"><?php echo $eachInfo->finalStock; ?></td>
                                    </tr>
                                    <?php
                                endforeach;
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" align="right"><strong>Total </strong></td>

                                    <td align="right"><?php echo $opening; ?></td>
                                    <td align="right"><?php echo $stockIn; ?></td>
                                    <td align="right"><?php echo $stockOut; ?></td>
                                    <td align="right"><?php echo $finalStock; ?></td>
                                </tr>
                            </tfoot>
                        </table>



                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

<script>

    MergeCommonRowsForSearchResult($('#mergeTable'), 2, 0);
    function MergeCommonRowsForSearchResult(table, startCol, HowManyCol) {
        var firstColumnBrakes = [];
        // iterate through the columns instead of passing each column as function parameter:
        for (var i = startCol; i <= (startCol + HowManyCol); i++) {
            var previous = null, cellToExtend = null, rowspan = 1;
            table.find("td:nth-child(" + i + ")").each(function (index, e) {
                var jthis = $(this), content = jthis.text();

                // check if current row "break" exist in the array. If not, then extend rowspan:
                if (previous == content && content !== "" && $.inArray(index, firstColumnBrakes) === -1) {
                    console.log(content);
                    // hide the row instead of remove(), so the DOM index won't "move" inside loop.
                    jthis.addClass('hidden');
                    cellToExtend.attr("rowspan", (rowspan = rowspan + 1));
                    //sum
                } else {
                    // store row breaks only for the first column:
                    if (i === 1)
                        firstColumnBrakes.push(index);
                    rowspan = 1;
                    previous = content;
                    cellToExtend = jthis;
                }

            });
            //sumColValue(table,startCol);
        }

        // now remove hidden td's (or leave them hidden if you wish):
        $('td.hidden').remove();
    }


    function isconfirm2(){
        var supplierid=$("#supplierid").val();
        var purchasesDate=$("#purchasesDate").val();
        var paymentType=$("#paymentType").val();

        if(supplierid == ''){
            swal("Select Supplier Name!", "Validation Error!", "error");
        }else if(purchasesDate == ''){
            swal("Select Purchases Date!", "Validation Error!", "error");
        }else{
            swal({
                title: "Are you sure ?",
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#73AE28',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true,
                type: 'success'
            },
            function (isConfirm) {
                if (isConfirm) {
                    $("#publicForm").submit();
                }else{
                    return false;
                }
            });
        }
    }



</script>

<script>
<?php if (!empty($type_id)):
    ?>
            var url = '<?php echo site_url("FinaneController/getPayUserList2") ?>';
    <?php if ($type_id != 'all'): ?>
                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {'payid': '<?php echo $type_id; ?>','searchId': '<?php echo $searchId; ?>','supplierId':'<?php echo $supplier_id; ?>'},
                    success: function (data)
                    {
                        $(".chosenRefesh").trigger("chosen:updated");
                        $("#searchValue").show(1000);
                        $("#searchValue").html(data);
                        $("#oldValue").hide(1000);
                        $('.chosenRefesh').chosen();
                        $(".chosenRefesh").trigger("chosen:updated");
                    }
                });
    <?php else: ?>
                $("#searchValue").hide(1000);
                $("#oldValue").show(1000);

    <?php
    endif;
endif;
?>
    function selectPayType(payid) {
        var url = '<?php echo site_url("FinaneController/getPayUserList2") ?>';
        if (payid != 'all') {
            $.ajax({
                type: 'POST',
                url: url,
                data: {'payid': payid},
                success: function (data)
                {
                    $(".chosenRefesh").trigger("chosen:updated");
                    $("#searchValue").show(1000);
                    $("#searchValue").html(data);
                    $("#oldValue").hide(1000);
                    $('.chosenRefesh').chosen();
                    $(".chosenRefesh").trigger("chosen:updated");
                }
            });
        } else {
            $("#searchValue").hide(1000);
            $("#oldValue").show(1000);
        }
    }
</script>