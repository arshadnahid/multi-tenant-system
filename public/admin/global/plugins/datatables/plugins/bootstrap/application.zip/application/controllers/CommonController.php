<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class CommonController extends CI_Controller {

    private $timestamp;
    public $admin_id;
    private $dist_id;
    public $project;

    public function __construct() {
        parent::__construct();

        $this->output->set_header("HTTP/1.0 200 OK");
        $this->output->set_header("HTTP/1.1 200 OK");
        $this->output->set_header('Expires: Sat, 26 Jul 2018 05:00:00 GMT');
        $this->output->set_header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        $this->load->model('Common_model');
        $this->load->model('Finane_Model');
        $this->load->model('Inventory_Model');
        $this->load->model('Sales_Model');
        $this->load->model('CommonModel');
        $this->timestamp = date('Y-m-d H:i:s');
        $this->admin_id = $this->session->userdata('admin_id');
        $this->dist_id = $this->session->userdata('dis_id');
        $this->project = $this->session->userdata('project');
        if (empty($this->admin_id) || empty($this->dist_id)) {
            redirect(site_url($this->project));
        }
        $this->db_hostname = $this->session->userdata('db_hostname');
        $this->db_username = $this->session->userdata('db_username');
        $this->db_password = $this->session->userdata('db_password');
        $this->db_name = $this->session->userdata('db_name');
        $this->db->close();
        $config_app = switch_db_dinamico($this->db_username, $this->db_password, $this->db_name);
        $this->db = $this->load->database($config_app, TRUE);
    }




    function subCatDelete($id) {
        $this->db->where('id', $id);
        $this->db->delete(' subcategory');
        message("Your data successfully deleted from database.");
        redirect(site_url($this->project . '/subCatList'));
    }

    public function subCatList($id = null) {
        if (isPostBack()) {

            //dumpVar($_POST);

            $activeValue = $this->input->post('activeValue');
            if ($activeValue == '1'):
                $data['isActive'] = 'Y';
            else:
                $data['isActive'] = 'N';
            endif;
            $data['sub_cat_code'] = $this->input->post('sub_cat_code');
            $data['cat_id'] = $this->input->post('cat_id');
            $data['sub_cat_name'] = $this->input->post('sub_cat_name');
            $data['isDelete'] = 'N';

            if (!empty($id)) {
                $data['updatedBy'] = $this->admin_id;
            } else {
                $data['createdBy'] = $this->admin_id;
            }


            $data['dist_id'] = $this->dist_id;

            if (empty($id)) {

                $insertId = $this->CommonModel->insert_data('subcategory', $data);
                if (!empty($insertId)) {
                    message("Your data successfully inserted into database.");
                    redirect(site_url($this->project . '/subCatList'));
                }
            } else {



                $insertId = $this->CommonModel->update_data('subcategory', $data, 'id', $id);


                if (!empty($insertId)) {
                    message("Your data successfully updated into database.");
                    redirect(site_url($this->project . '/subCatList'));
                } else {
                    exception("You have made no change to update.");
                    redirect(site_url($this->project . '/subCatList'));
                }
            }
        }



        $condition = array(
            'dist_id' => $this->dist_id,
            'isActive' => 'Y',
            'isDelete' => 'N',
        );

        if (!empty($id)) {
            $data['updateData'] = $this->CommonModel->getSubCatListById($id);
        }
        $data['title'] = 'Sub Category List';

        $totalCatId = $this->db->where('dist_id', $this->dist_id)->or_where('dist_id', 1)->count_all_results('subcategory') + 1;
        $data['subCatId'] = "SCID" . date('y') . date('m') . str_pad($totalCatId, 4, "0", STR_PAD_LEFT);
        $condition1 = array(
            'dist_id' => $this->dist_id,
            'isActive' => 'Y',
            'isDelete' => 'N',
        );

        $data['subCatList'] = $this->CommonModel->getSubCatList($condition1);
        $data['categoryList'] = $this->CommonModel->checkPublicProductCat($this->dist_id);
        $data['mainContent'] = $this->load->view('distributor/inventory/subCategory/subCatList', $data, true);
        $this->load->view('distributor/masterDashboard', $data);
    }

}
