<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-14 01:30:54 --> Config Class Initialized
INFO - 2021-05-14 01:30:54 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:54 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:54 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:54 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:54 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:54 --> Router Class Initialized
INFO - 2021-05-14 01:30:54 --> Output Class Initialized
INFO - 2021-05-14 01:30:54 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:54 --> Input Class Initialized
INFO - 2021-05-14 01:30:54 --> Language Class Initialized
INFO - 2021-05-14 01:30:54 --> Loader Class Initialized
INFO - 2021-05-14 01:30:54 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:54 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:54 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:54 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:54 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:54 --> Controller Class Initialized
INFO - 2021-05-14 01:30:54 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:54 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:54 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:54 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:54 --> Total execution time: 0.0648
INFO - 2021-05-14 01:30:54 --> Config Class Initialized
INFO - 2021-05-14 01:30:54 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:54 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:54 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:54 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:54 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:54 --> Router Class Initialized
INFO - 2021-05-14 01:30:54 --> Output Class Initialized
INFO - 2021-05-14 01:30:54 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:54 --> Input Class Initialized
INFO - 2021-05-14 01:30:54 --> Language Class Initialized
INFO - 2021-05-14 01:30:54 --> Loader Class Initialized
INFO - 2021-05-14 01:30:54 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:54 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:54 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:54 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:54 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:54 --> Controller Class Initialized
INFO - 2021-05-14 01:30:54 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:54 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:54 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:54 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:54 --> Total execution time: 0.0408
INFO - 2021-05-14 01:30:55 --> Config Class Initialized
INFO - 2021-05-14 01:30:55 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:55 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:55 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:55 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:55 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:55 --> Router Class Initialized
INFO - 2021-05-14 01:30:55 --> Output Class Initialized
INFO - 2021-05-14 01:30:55 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:55 --> Input Class Initialized
INFO - 2021-05-14 01:30:55 --> Language Class Initialized
INFO - 2021-05-14 01:30:55 --> Loader Class Initialized
INFO - 2021-05-14 01:30:55 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:55 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:55 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:55 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:55 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:55 --> Controller Class Initialized
INFO - 2021-05-14 01:30:55 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:55 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:55 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:55 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:55 --> Total execution time: 0.0614
INFO - 2021-05-14 01:30:55 --> Config Class Initialized
INFO - 2021-05-14 01:30:55 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:55 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:55 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:55 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:55 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:55 --> Router Class Initialized
INFO - 2021-05-14 01:30:55 --> Output Class Initialized
INFO - 2021-05-14 01:30:55 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:55 --> Input Class Initialized
INFO - 2021-05-14 01:30:55 --> Language Class Initialized
INFO - 2021-05-14 01:30:55 --> Loader Class Initialized
INFO - 2021-05-14 01:30:55 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:55 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:55 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:55 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:55 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:55 --> Controller Class Initialized
INFO - 2021-05-14 01:30:55 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:55 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:55 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:55 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:55 --> Total execution time: 0.0621
INFO - 2021-05-14 01:30:56 --> Config Class Initialized
INFO - 2021-05-14 01:30:56 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:56 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:56 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:56 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:56 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:56 --> Router Class Initialized
INFO - 2021-05-14 01:30:56 --> Output Class Initialized
INFO - 2021-05-14 01:30:56 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:56 --> Input Class Initialized
INFO - 2021-05-14 01:30:56 --> Language Class Initialized
INFO - 2021-05-14 01:30:56 --> Loader Class Initialized
INFO - 2021-05-14 01:30:56 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:56 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:56 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:56 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:56 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:56 --> Controller Class Initialized
INFO - 2021-05-14 01:30:56 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:56 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:56 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:56 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:56 --> Total execution time: 0.0610
INFO - 2021-05-14 01:30:56 --> Config Class Initialized
INFO - 2021-05-14 01:30:56 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:56 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:56 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:56 --> URI Class Initialized
INFO - 2021-05-14 01:30:56 --> Router Class Initialized
INFO - 2021-05-14 01:30:56 --> Output Class Initialized
INFO - 2021-05-14 01:30:56 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:56 --> Input Class Initialized
INFO - 2021-05-14 01:30:56 --> Language Class Initialized
INFO - 2021-05-14 01:30:56 --> Loader Class Initialized
INFO - 2021-05-14 01:30:56 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:56 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:56 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:56 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:56 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:56 --> Controller Class Initialized
INFO - 2021-05-14 01:30:56 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:56 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:56 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:56 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:56 --> Total execution time: 0.0482
INFO - 2021-05-14 01:30:57 --> Config Class Initialized
INFO - 2021-05-14 01:30:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:57 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:57 --> URI Class Initialized
INFO - 2021-05-14 01:30:57 --> Router Class Initialized
INFO - 2021-05-14 01:30:57 --> Output Class Initialized
INFO - 2021-05-14 01:30:57 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:57 --> Input Class Initialized
INFO - 2021-05-14 01:30:57 --> Language Class Initialized
ERROR - 2021-05-14 01:30:57 --> 404 Page Not Found: Api/search
INFO - 2021-05-14 01:30:57 --> Config Class Initialized
INFO - 2021-05-14 01:30:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:57 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:57 --> URI Class Initialized
INFO - 2021-05-14 01:30:57 --> Router Class Initialized
INFO - 2021-05-14 01:30:57 --> Output Class Initialized
INFO - 2021-05-14 01:30:57 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:57 --> Input Class Initialized
INFO - 2021-05-14 01:30:57 --> Language Class Initialized
ERROR - 2021-05-14 01:30:57 --> 404 Page Not Found: Git/config
INFO - 2021-05-14 01:30:57 --> Config Class Initialized
INFO - 2021-05-14 01:30:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:57 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:57 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:57 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:57 --> Router Class Initialized
INFO - 2021-05-14 01:30:57 --> Output Class Initialized
INFO - 2021-05-14 01:30:57 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:57 --> Input Class Initialized
INFO - 2021-05-14 01:30:57 --> Language Class Initialized
INFO - 2021-05-14 01:30:57 --> Loader Class Initialized
INFO - 2021-05-14 01:30:57 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:57 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:57 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:57 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:57 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:57 --> Controller Class Initialized
INFO - 2021-05-14 01:30:57 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:57 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:57 --> Total execution time: 0.0549
INFO - 2021-05-14 01:30:57 --> Config Class Initialized
INFO - 2021-05-14 01:30:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:57 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:57 --> URI Class Initialized
INFO - 2021-05-14 01:30:57 --> Router Class Initialized
INFO - 2021-05-14 01:30:57 --> Output Class Initialized
INFO - 2021-05-14 01:30:57 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:57 --> Input Class Initialized
INFO - 2021-05-14 01:30:57 --> Language Class Initialized
ERROR - 2021-05-14 01:30:57 --> 404 Page Not Found: Api/search
INFO - 2021-05-14 01:30:57 --> Config Class Initialized
INFO - 2021-05-14 01:30:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:57 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:57 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:57 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:57 --> Router Class Initialized
INFO - 2021-05-14 01:30:57 --> Output Class Initialized
INFO - 2021-05-14 01:30:57 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:57 --> Input Class Initialized
INFO - 2021-05-14 01:30:57 --> Language Class Initialized
INFO - 2021-05-14 01:30:57 --> Loader Class Initialized
INFO - 2021-05-14 01:30:57 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:57 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:57 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:57 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:57 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:57 --> Controller Class Initialized
INFO - 2021-05-14 01:30:57 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:57 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:57 --> Total execution time: 0.0525
INFO - 2021-05-14 01:30:57 --> Config Class Initialized
INFO - 2021-05-14 01:30:57 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:57 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:57 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:57 --> URI Class Initialized
DEBUG - 2021-05-14 01:30:57 --> No URI present. Default controller set.
INFO - 2021-05-14 01:30:57 --> Router Class Initialized
INFO - 2021-05-14 01:30:57 --> Output Class Initialized
INFO - 2021-05-14 01:30:57 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:57 --> Input Class Initialized
INFO - 2021-05-14 01:30:57 --> Language Class Initialized
INFO - 2021-05-14 01:30:57 --> Loader Class Initialized
INFO - 2021-05-14 01:30:57 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:57 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:57 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:57 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:57 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:57 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:57 --> Controller Class Initialized
INFO - 2021-05-14 01:30:57 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:57 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:57 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:57 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:57 --> Total execution time: 0.0567
INFO - 2021-05-14 01:30:58 --> Config Class Initialized
INFO - 2021-05-14 01:30:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:58 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:58 --> URI Class Initialized
INFO - 2021-05-14 01:30:58 --> Router Class Initialized
INFO - 2021-05-14 01:30:58 --> Output Class Initialized
INFO - 2021-05-14 01:30:58 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:58 --> Input Class Initialized
INFO - 2021-05-14 01:30:58 --> Language Class Initialized
INFO - 2021-05-14 01:30:58 --> Loader Class Initialized
INFO - 2021-05-14 01:30:58 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:58 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:58 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:58 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:58 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:58 --> Controller Class Initialized
INFO - 2021-05-14 01:30:58 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:58 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:58 --> Total execution time: 0.0548
INFO - 2021-05-14 01:30:58 --> Config Class Initialized
INFO - 2021-05-14 01:30:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:58 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:58 --> URI Class Initialized
INFO - 2021-05-14 01:30:58 --> Router Class Initialized
INFO - 2021-05-14 01:30:58 --> Output Class Initialized
INFO - 2021-05-14 01:30:58 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:58 --> Input Class Initialized
INFO - 2021-05-14 01:30:58 --> Language Class Initialized
INFO - 2021-05-14 01:30:58 --> Loader Class Initialized
INFO - 2021-05-14 01:30:58 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:58 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:58 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:58 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:58 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:58 --> Controller Class Initialized
INFO - 2021-05-14 01:30:58 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:58 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:58 --> Total execution time: 0.0589
INFO - 2021-05-14 01:30:58 --> Config Class Initialized
INFO - 2021-05-14 01:30:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:58 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:58 --> URI Class Initialized
INFO - 2021-05-14 01:30:58 --> Router Class Initialized
INFO - 2021-05-14 01:30:58 --> Output Class Initialized
INFO - 2021-05-14 01:30:58 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:58 --> Input Class Initialized
INFO - 2021-05-14 01:30:58 --> Language Class Initialized
ERROR - 2021-05-14 01:30:58 --> 404 Page Not Found: Telescope/requests
INFO - 2021-05-14 01:30:58 --> Config Class Initialized
INFO - 2021-05-14 01:30:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:58 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:58 --> URI Class Initialized
INFO - 2021-05-14 01:30:58 --> Router Class Initialized
INFO - 2021-05-14 01:30:58 --> Output Class Initialized
INFO - 2021-05-14 01:30:58 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:58 --> Input Class Initialized
INFO - 2021-05-14 01:30:58 --> Language Class Initialized
INFO - 2021-05-14 01:30:58 --> Loader Class Initialized
INFO - 2021-05-14 01:30:58 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:58 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:58 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:58 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:58 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:58 --> Controller Class Initialized
INFO - 2021-05-14 01:30:58 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:58 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:58 --> Total execution time: 0.0618
INFO - 2021-05-14 01:30:58 --> Config Class Initialized
INFO - 2021-05-14 01:30:58 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:58 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:58 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:58 --> URI Class Initialized
INFO - 2021-05-14 01:30:58 --> Router Class Initialized
INFO - 2021-05-14 01:30:58 --> Output Class Initialized
INFO - 2021-05-14 01:30:58 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:58 --> Input Class Initialized
INFO - 2021-05-14 01:30:58 --> Language Class Initialized
INFO - 2021-05-14 01:30:58 --> Loader Class Initialized
INFO - 2021-05-14 01:30:58 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:58 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:58 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:58 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:58 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:58 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:58 --> Controller Class Initialized
INFO - 2021-05-14 01:30:58 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:58 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:58 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:58 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:58 --> Total execution time: 0.0687
INFO - 2021-05-14 01:30:59 --> Config Class Initialized
INFO - 2021-05-14 01:30:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:59 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:59 --> URI Class Initialized
INFO - 2021-05-14 01:30:59 --> Router Class Initialized
INFO - 2021-05-14 01:30:59 --> Output Class Initialized
INFO - 2021-05-14 01:30:59 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:59 --> Input Class Initialized
INFO - 2021-05-14 01:30:59 --> Language Class Initialized
INFO - 2021-05-14 01:30:59 --> Loader Class Initialized
INFO - 2021-05-14 01:30:59 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:59 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:59 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:59 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:59 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:59 --> Controller Class Initialized
INFO - 2021-05-14 01:30:59 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:59 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:59 --> Total execution time: 0.0519
INFO - 2021-05-14 01:30:59 --> Config Class Initialized
INFO - 2021-05-14 01:30:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:59 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:59 --> URI Class Initialized
INFO - 2021-05-14 01:30:59 --> Router Class Initialized
INFO - 2021-05-14 01:30:59 --> Output Class Initialized
INFO - 2021-05-14 01:30:59 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:59 --> Input Class Initialized
INFO - 2021-05-14 01:30:59 --> Language Class Initialized
ERROR - 2021-05-14 01:30:59 --> 404 Page Not Found: V2/_catalog
INFO - 2021-05-14 01:30:59 --> Config Class Initialized
INFO - 2021-05-14 01:30:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:59 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:59 --> URI Class Initialized
INFO - 2021-05-14 01:30:59 --> Router Class Initialized
INFO - 2021-05-14 01:30:59 --> Output Class Initialized
INFO - 2021-05-14 01:30:59 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:59 --> Input Class Initialized
INFO - 2021-05-14 01:30:59 --> Language Class Initialized
INFO - 2021-05-14 01:30:59 --> Loader Class Initialized
INFO - 2021-05-14 01:30:59 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:59 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:59 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:59 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:59 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:59 --> Controller Class Initialized
INFO - 2021-05-14 01:30:59 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:59 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:59 --> Total execution time: 0.0424
INFO - 2021-05-14 01:30:59 --> Config Class Initialized
INFO - 2021-05-14 01:30:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:59 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:59 --> URI Class Initialized
INFO - 2021-05-14 01:30:59 --> Router Class Initialized
INFO - 2021-05-14 01:30:59 --> Output Class Initialized
INFO - 2021-05-14 01:30:59 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:59 --> Input Class Initialized
INFO - 2021-05-14 01:30:59 --> Language Class Initialized
INFO - 2021-05-14 01:30:59 --> Loader Class Initialized
INFO - 2021-05-14 01:30:59 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:59 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:59 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:59 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:59 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:59 --> Controller Class Initialized
INFO - 2021-05-14 01:30:59 --> Model "Common_model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:30:59 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:30:59 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:30:59 --> Final output sent to browser
DEBUG - 2021-05-14 01:30:59 --> Total execution time: 0.0663
INFO - 2021-05-14 01:30:59 --> Config Class Initialized
INFO - 2021-05-14 01:30:59 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:30:59 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:30:59 --> Utf8 Class Initialized
INFO - 2021-05-14 01:30:59 --> URI Class Initialized
INFO - 2021-05-14 01:30:59 --> Router Class Initialized
INFO - 2021-05-14 01:30:59 --> Output Class Initialized
INFO - 2021-05-14 01:30:59 --> Security Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:30:59 --> Input Class Initialized
INFO - 2021-05-14 01:30:59 --> Language Class Initialized
INFO - 2021-05-14 01:30:59 --> Loader Class Initialized
INFO - 2021-05-14 01:30:59 --> Helper loaded: url_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: file_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:30:59 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:30:59 --> Database Driver Class Initialized
INFO - 2021-05-14 01:30:59 --> Email Class Initialized
DEBUG - 2021-05-14 01:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:30:59 --> Helper loaded: form_helper
INFO - 2021-05-14 01:30:59 --> Form Validation Class Initialized
INFO - 2021-05-14 01:30:59 --> Controller Class Initialized
INFO - 2021-05-14 01:31:00 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:00 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:00 --> Total execution time: 0.0547
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
ERROR - 2021-05-14 01:31:00 --> 404 Page Not Found: V2/_catalog
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
INFO - 2021-05-14 01:31:00 --> Loader Class Initialized
INFO - 2021-05-14 01:31:00 --> Helper loaded: url_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: file_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:31:00 --> Database Driver Class Initialized
INFO - 2021-05-14 01:31:00 --> Email Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:31:00 --> Helper loaded: form_helper
INFO - 2021-05-14 01:31:00 --> Form Validation Class Initialized
INFO - 2021-05-14 01:31:00 --> Controller Class Initialized
INFO - 2021-05-14 01:31:00 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:00 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:00 --> Total execution time: 0.0417
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
ERROR - 2021-05-14 01:31:00 --> 404 Page Not Found: Git/config
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
ERROR - 2021-05-14 01:31:00 --> 404 Page Not Found: V2/_catalog
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
INFO - 2021-05-14 01:31:00 --> Loader Class Initialized
INFO - 2021-05-14 01:31:00 --> Helper loaded: url_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: file_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:31:00 --> Database Driver Class Initialized
INFO - 2021-05-14 01:31:00 --> Email Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:31:00 --> Helper loaded: form_helper
INFO - 2021-05-14 01:31:00 --> Form Validation Class Initialized
INFO - 2021-05-14 01:31:00 --> Controller Class Initialized
INFO - 2021-05-14 01:31:00 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:00 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:00 --> Total execution time: 0.0651
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
INFO - 2021-05-14 01:31:00 --> Loader Class Initialized
INFO - 2021-05-14 01:31:00 --> Helper loaded: url_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: file_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:31:00 --> Database Driver Class Initialized
INFO - 2021-05-14 01:31:00 --> Email Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:31:00 --> Helper loaded: form_helper
INFO - 2021-05-14 01:31:00 --> Form Validation Class Initialized
INFO - 2021-05-14 01:31:00 --> Controller Class Initialized
INFO - 2021-05-14 01:31:00 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:00 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:00 --> Total execution time: 0.0419
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
INFO - 2021-05-14 01:31:00 --> Loader Class Initialized
INFO - 2021-05-14 01:31:00 --> Helper loaded: url_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: file_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:31:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:31:00 --> Database Driver Class Initialized
INFO - 2021-05-14 01:31:00 --> Email Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:31:00 --> Helper loaded: form_helper
INFO - 2021-05-14 01:31:00 --> Form Validation Class Initialized
INFO - 2021-05-14 01:31:00 --> Controller Class Initialized
INFO - 2021-05-14 01:31:00 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:00 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:00 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:00 --> Total execution time: 0.0476
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
ERROR - 2021-05-14 01:31:00 --> 404 Page Not Found: Git/config
INFO - 2021-05-14 01:31:00 --> Config Class Initialized
INFO - 2021-05-14 01:31:00 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:00 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:00 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:00 --> URI Class Initialized
INFO - 2021-05-14 01:31:00 --> Router Class Initialized
INFO - 2021-05-14 01:31:00 --> Output Class Initialized
INFO - 2021-05-14 01:31:00 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:00 --> Input Class Initialized
INFO - 2021-05-14 01:31:00 --> Language Class Initialized
ERROR - 2021-05-14 01:31:00 --> 404 Page Not Found: Telescope/requests
INFO - 2021-05-14 01:31:01 --> Config Class Initialized
INFO - 2021-05-14 01:31:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:01 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:01 --> URI Class Initialized
INFO - 2021-05-14 01:31:01 --> Router Class Initialized
INFO - 2021-05-14 01:31:01 --> Output Class Initialized
INFO - 2021-05-14 01:31:01 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:01 --> Input Class Initialized
INFO - 2021-05-14 01:31:01 --> Language Class Initialized
ERROR - 2021-05-14 01:31:01 --> 404 Page Not Found: V2/_catalog
INFO - 2021-05-14 01:31:01 --> Config Class Initialized
INFO - 2021-05-14 01:31:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:01 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:01 --> URI Class Initialized
INFO - 2021-05-14 01:31:01 --> Router Class Initialized
INFO - 2021-05-14 01:31:01 --> Output Class Initialized
INFO - 2021-05-14 01:31:01 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:01 --> Input Class Initialized
INFO - 2021-05-14 01:31:01 --> Language Class Initialized
INFO - 2021-05-14 01:31:01 --> Loader Class Initialized
INFO - 2021-05-14 01:31:01 --> Helper loaded: url_helper
INFO - 2021-05-14 01:31:01 --> Helper loaded: file_helper
INFO - 2021-05-14 01:31:01 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:31:01 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:31:01 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:31:01 --> Database Driver Class Initialized
INFO - 2021-05-14 01:31:01 --> Email Class Initialized
DEBUG - 2021-05-14 01:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:31:01 --> Helper loaded: form_helper
INFO - 2021-05-14 01:31:01 --> Form Validation Class Initialized
INFO - 2021-05-14 01:31:01 --> Controller Class Initialized
INFO - 2021-05-14 01:31:01 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:01 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:01 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:01 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:01 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:01 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:01 --> Total execution time: 0.0643
INFO - 2021-05-14 01:31:01 --> Config Class Initialized
INFO - 2021-05-14 01:31:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:01 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:01 --> URI Class Initialized
INFO - 2021-05-14 01:31:01 --> Router Class Initialized
INFO - 2021-05-14 01:31:01 --> Output Class Initialized
INFO - 2021-05-14 01:31:01 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:01 --> Input Class Initialized
INFO - 2021-05-14 01:31:01 --> Language Class Initialized
ERROR - 2021-05-14 01:31:01 --> 404 Page Not Found: Api/search
INFO - 2021-05-14 01:31:01 --> Config Class Initialized
INFO - 2021-05-14 01:31:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:01 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:01 --> URI Class Initialized
INFO - 2021-05-14 01:31:01 --> Router Class Initialized
INFO - 2021-05-14 01:31:01 --> Output Class Initialized
INFO - 2021-05-14 01:31:01 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:01 --> Input Class Initialized
INFO - 2021-05-14 01:31:01 --> Language Class Initialized
ERROR - 2021-05-14 01:31:01 --> 404 Page Not Found: Git/config
INFO - 2021-05-14 01:31:01 --> Config Class Initialized
INFO - 2021-05-14 01:31:01 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:01 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:01 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:01 --> URI Class Initialized
INFO - 2021-05-14 01:31:01 --> Router Class Initialized
INFO - 2021-05-14 01:31:01 --> Output Class Initialized
INFO - 2021-05-14 01:31:01 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:01 --> Input Class Initialized
INFO - 2021-05-14 01:31:01 --> Language Class Initialized
ERROR - 2021-05-14 01:31:01 --> 404 Page Not Found: Telescope/requests
INFO - 2021-05-14 01:31:02 --> Config Class Initialized
INFO - 2021-05-14 01:31:02 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:02 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:02 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:02 --> URI Class Initialized
INFO - 2021-05-14 01:31:02 --> Router Class Initialized
INFO - 2021-05-14 01:31:02 --> Output Class Initialized
INFO - 2021-05-14 01:31:02 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:02 --> Input Class Initialized
INFO - 2021-05-14 01:31:02 --> Language Class Initialized
INFO - 2021-05-14 01:31:02 --> Loader Class Initialized
INFO - 2021-05-14 01:31:02 --> Helper loaded: url_helper
INFO - 2021-05-14 01:31:02 --> Helper loaded: file_helper
INFO - 2021-05-14 01:31:02 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:31:02 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:31:02 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:31:02 --> Database Driver Class Initialized
INFO - 2021-05-14 01:31:02 --> Email Class Initialized
DEBUG - 2021-05-14 01:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:31:02 --> Helper loaded: form_helper
INFO - 2021-05-14 01:31:02 --> Form Validation Class Initialized
INFO - 2021-05-14 01:31:02 --> Controller Class Initialized
INFO - 2021-05-14 01:31:02 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:02 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:02 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:02 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:02 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:02 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:02 --> Total execution time: 0.0480
INFO - 2021-05-14 01:31:02 --> Config Class Initialized
INFO - 2021-05-14 01:31:02 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:02 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:02 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:02 --> URI Class Initialized
INFO - 2021-05-14 01:31:02 --> Router Class Initialized
INFO - 2021-05-14 01:31:02 --> Output Class Initialized
INFO - 2021-05-14 01:31:02 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:02 --> Input Class Initialized
INFO - 2021-05-14 01:31:02 --> Language Class Initialized
ERROR - 2021-05-14 01:31:02 --> 404 Page Not Found: Api/search
INFO - 2021-05-14 01:31:03 --> Config Class Initialized
INFO - 2021-05-14 01:31:03 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:03 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:03 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:03 --> URI Class Initialized
INFO - 2021-05-14 01:31:03 --> Router Class Initialized
INFO - 2021-05-14 01:31:03 --> Output Class Initialized
INFO - 2021-05-14 01:31:03 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:03 --> Input Class Initialized
INFO - 2021-05-14 01:31:03 --> Language Class Initialized
ERROR - 2021-05-14 01:31:03 --> 404 Page Not Found: Telescope/requests
INFO - 2021-05-14 01:31:03 --> Config Class Initialized
INFO - 2021-05-14 01:31:03 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:31:03 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:31:03 --> Utf8 Class Initialized
INFO - 2021-05-14 01:31:03 --> URI Class Initialized
INFO - 2021-05-14 01:31:03 --> Router Class Initialized
INFO - 2021-05-14 01:31:03 --> Output Class Initialized
INFO - 2021-05-14 01:31:03 --> Security Class Initialized
DEBUG - 2021-05-14 01:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:31:03 --> Input Class Initialized
INFO - 2021-05-14 01:31:03 --> Language Class Initialized
INFO - 2021-05-14 01:31:03 --> Loader Class Initialized
INFO - 2021-05-14 01:31:03 --> Helper loaded: url_helper
INFO - 2021-05-14 01:31:03 --> Helper loaded: file_helper
INFO - 2021-05-14 01:31:03 --> Helper loaded: utility_helper
INFO - 2021-05-14 01:31:03 --> Helper loaded: unit_helper
INFO - 2021-05-14 01:31:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 01:31:03 --> Database Driver Class Initialized
INFO - 2021-05-14 01:31:03 --> Email Class Initialized
DEBUG - 2021-05-14 01:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 01:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 01:31:03 --> Helper loaded: form_helper
INFO - 2021-05-14 01:31:03 --> Form Validation Class Initialized
INFO - 2021-05-14 01:31:03 --> Controller Class Initialized
INFO - 2021-05-14 01:31:03 --> Model "Common_model" initialized
INFO - 2021-05-14 01:31:03 --> Model "Finane_Model" initialized
INFO - 2021-05-14 01:31:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 01:31:03 --> Model "Sales_Model" initialized
INFO - 2021-05-14 01:31:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 01:31:03 --> Final output sent to browser
DEBUG - 2021-05-14 01:31:03 --> Total execution time: 0.0470
INFO - 2021-05-14 01:43:25 --> Config Class Initialized
INFO - 2021-05-14 01:43:25 --> Hooks Class Initialized
DEBUG - 2021-05-14 01:43:25 --> UTF-8 Support Enabled
INFO - 2021-05-14 01:43:25 --> Utf8 Class Initialized
INFO - 2021-05-14 01:43:25 --> URI Class Initialized
INFO - 2021-05-14 01:43:25 --> Router Class Initialized
INFO - 2021-05-14 01:43:25 --> Output Class Initialized
INFO - 2021-05-14 01:43:25 --> Security Class Initialized
DEBUG - 2021-05-14 01:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 01:43:25 --> Input Class Initialized
INFO - 2021-05-14 01:43:25 --> Language Class Initialized
ERROR - 2021-05-14 01:43:25 --> 404 Page Not Found: admin/Fileupload/index.php
INFO - 2021-05-14 02:27:27 --> Config Class Initialized
INFO - 2021-05-14 02:27:27 --> Hooks Class Initialized
DEBUG - 2021-05-14 02:27:27 --> UTF-8 Support Enabled
INFO - 2021-05-14 02:27:27 --> Utf8 Class Initialized
INFO - 2021-05-14 02:27:27 --> URI Class Initialized
DEBUG - 2021-05-14 02:27:27 --> No URI present. Default controller set.
INFO - 2021-05-14 02:27:27 --> Router Class Initialized
INFO - 2021-05-14 02:27:27 --> Output Class Initialized
INFO - 2021-05-14 02:27:27 --> Security Class Initialized
DEBUG - 2021-05-14 02:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 02:27:27 --> Input Class Initialized
INFO - 2021-05-14 02:27:27 --> Language Class Initialized
INFO - 2021-05-14 02:27:27 --> Loader Class Initialized
INFO - 2021-05-14 02:27:27 --> Helper loaded: url_helper
INFO - 2021-05-14 02:27:27 --> Helper loaded: file_helper
INFO - 2021-05-14 02:27:27 --> Helper loaded: utility_helper
INFO - 2021-05-14 02:27:27 --> Helper loaded: unit_helper
INFO - 2021-05-14 02:27:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 02:27:27 --> Database Driver Class Initialized
INFO - 2021-05-14 02:27:27 --> Email Class Initialized
DEBUG - 2021-05-14 02:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 02:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 02:27:27 --> Helper loaded: form_helper
INFO - 2021-05-14 02:27:27 --> Form Validation Class Initialized
INFO - 2021-05-14 02:27:27 --> Controller Class Initialized
INFO - 2021-05-14 02:27:27 --> Model "Common_model" initialized
INFO - 2021-05-14 02:27:27 --> Model "Finane_Model" initialized
INFO - 2021-05-14 02:27:27 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 02:27:27 --> Model "Sales_Model" initialized
INFO - 2021-05-14 02:27:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 02:27:27 --> Final output sent to browser
DEBUG - 2021-05-14 02:27:27 --> Total execution time: 0.0716
INFO - 2021-05-14 03:47:17 --> Config Class Initialized
INFO - 2021-05-14 03:47:17 --> Hooks Class Initialized
DEBUG - 2021-05-14 03:47:17 --> UTF-8 Support Enabled
INFO - 2021-05-14 03:47:17 --> Utf8 Class Initialized
INFO - 2021-05-14 03:47:17 --> URI Class Initialized
DEBUG - 2021-05-14 03:47:17 --> No URI present. Default controller set.
INFO - 2021-05-14 03:47:17 --> Router Class Initialized
INFO - 2021-05-14 03:47:17 --> Output Class Initialized
INFO - 2021-05-14 03:47:17 --> Security Class Initialized
DEBUG - 2021-05-14 03:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 03:47:17 --> Input Class Initialized
INFO - 2021-05-14 03:47:17 --> Language Class Initialized
INFO - 2021-05-14 03:47:17 --> Loader Class Initialized
INFO - 2021-05-14 03:47:17 --> Helper loaded: url_helper
INFO - 2021-05-14 03:47:17 --> Helper loaded: file_helper
INFO - 2021-05-14 03:47:17 --> Helper loaded: utility_helper
INFO - 2021-05-14 03:47:17 --> Helper loaded: unit_helper
INFO - 2021-05-14 03:47:17 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 03:47:17 --> Database Driver Class Initialized
INFO - 2021-05-14 03:47:17 --> Email Class Initialized
DEBUG - 2021-05-14 03:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 03:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 03:47:17 --> Helper loaded: form_helper
INFO - 2021-05-14 03:47:17 --> Form Validation Class Initialized
INFO - 2021-05-14 03:47:17 --> Controller Class Initialized
INFO - 2021-05-14 03:47:17 --> Model "Common_model" initialized
INFO - 2021-05-14 03:47:17 --> Model "Finane_Model" initialized
INFO - 2021-05-14 03:47:17 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 03:47:17 --> Model "Sales_Model" initialized
INFO - 2021-05-14 03:47:17 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 03:47:17 --> Final output sent to browser
DEBUG - 2021-05-14 03:47:17 --> Total execution time: 0.0453
INFO - 2021-05-14 05:57:16 --> Config Class Initialized
INFO - 2021-05-14 05:57:16 --> Hooks Class Initialized
DEBUG - 2021-05-14 05:57:16 --> UTF-8 Support Enabled
INFO - 2021-05-14 05:57:16 --> Utf8 Class Initialized
INFO - 2021-05-14 05:57:16 --> URI Class Initialized
DEBUG - 2021-05-14 05:57:16 --> No URI present. Default controller set.
INFO - 2021-05-14 05:57:16 --> Router Class Initialized
INFO - 2021-05-14 05:57:16 --> Output Class Initialized
INFO - 2021-05-14 05:57:16 --> Security Class Initialized
DEBUG - 2021-05-14 05:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 05:57:16 --> Input Class Initialized
INFO - 2021-05-14 05:57:16 --> Language Class Initialized
INFO - 2021-05-14 05:57:16 --> Loader Class Initialized
INFO - 2021-05-14 05:57:16 --> Helper loaded: url_helper
INFO - 2021-05-14 05:57:16 --> Helper loaded: file_helper
INFO - 2021-05-14 05:57:16 --> Helper loaded: utility_helper
INFO - 2021-05-14 05:57:16 --> Helper loaded: unit_helper
INFO - 2021-05-14 05:57:16 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 05:57:16 --> Database Driver Class Initialized
INFO - 2021-05-14 05:57:16 --> Email Class Initialized
DEBUG - 2021-05-14 05:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 05:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 05:57:16 --> Helper loaded: form_helper
INFO - 2021-05-14 05:57:16 --> Form Validation Class Initialized
INFO - 2021-05-14 05:57:16 --> Controller Class Initialized
INFO - 2021-05-14 05:57:16 --> Model "Common_model" initialized
INFO - 2021-05-14 05:57:16 --> Model "Finane_Model" initialized
INFO - 2021-05-14 05:57:16 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 05:57:16 --> Model "Sales_Model" initialized
INFO - 2021-05-14 05:57:16 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 05:57:16 --> Final output sent to browser
DEBUG - 2021-05-14 05:57:16 --> Total execution time: 0.0514
INFO - 2021-05-14 10:00:32 --> Config Class Initialized
INFO - 2021-05-14 10:00:32 --> Hooks Class Initialized
DEBUG - 2021-05-14 10:00:32 --> UTF-8 Support Enabled
INFO - 2021-05-14 10:00:32 --> Utf8 Class Initialized
INFO - 2021-05-14 10:00:32 --> URI Class Initialized
DEBUG - 2021-05-14 10:00:32 --> No URI present. Default controller set.
INFO - 2021-05-14 10:00:32 --> Router Class Initialized
INFO - 2021-05-14 10:00:32 --> Output Class Initialized
INFO - 2021-05-14 10:00:32 --> Security Class Initialized
DEBUG - 2021-05-14 10:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 10:00:32 --> Input Class Initialized
INFO - 2021-05-14 10:00:32 --> Language Class Initialized
INFO - 2021-05-14 10:00:32 --> Loader Class Initialized
INFO - 2021-05-14 10:00:32 --> Helper loaded: url_helper
INFO - 2021-05-14 10:00:32 --> Helper loaded: file_helper
INFO - 2021-05-14 10:00:32 --> Helper loaded: utility_helper
INFO - 2021-05-14 10:00:32 --> Helper loaded: unit_helper
INFO - 2021-05-14 10:00:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 10:00:32 --> Database Driver Class Initialized
INFO - 2021-05-14 10:00:32 --> Email Class Initialized
DEBUG - 2021-05-14 10:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 10:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 10:00:32 --> Helper loaded: form_helper
INFO - 2021-05-14 10:00:32 --> Form Validation Class Initialized
INFO - 2021-05-14 10:00:32 --> Controller Class Initialized
INFO - 2021-05-14 10:00:32 --> Model "Common_model" initialized
INFO - 2021-05-14 10:00:32 --> Model "Finane_Model" initialized
INFO - 2021-05-14 10:00:32 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 10:00:32 --> Model "Sales_Model" initialized
INFO - 2021-05-14 10:00:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 10:00:32 --> Final output sent to browser
DEBUG - 2021-05-14 10:00:32 --> Total execution time: 0.0500
INFO - 2021-05-14 12:47:29 --> Config Class Initialized
INFO - 2021-05-14 12:47:29 --> Hooks Class Initialized
DEBUG - 2021-05-14 12:47:29 --> UTF-8 Support Enabled
INFO - 2021-05-14 12:47:29 --> Utf8 Class Initialized
INFO - 2021-05-14 12:47:29 --> URI Class Initialized
DEBUG - 2021-05-14 12:47:29 --> No URI present. Default controller set.
INFO - 2021-05-14 12:47:29 --> Router Class Initialized
INFO - 2021-05-14 12:47:29 --> Output Class Initialized
INFO - 2021-05-14 12:47:29 --> Security Class Initialized
DEBUG - 2021-05-14 12:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 12:47:29 --> Input Class Initialized
INFO - 2021-05-14 12:47:29 --> Language Class Initialized
INFO - 2021-05-14 12:47:29 --> Loader Class Initialized
INFO - 2021-05-14 12:47:29 --> Helper loaded: url_helper
INFO - 2021-05-14 12:47:29 --> Helper loaded: file_helper
INFO - 2021-05-14 12:47:29 --> Helper loaded: utility_helper
INFO - 2021-05-14 12:47:29 --> Helper loaded: unit_helper
INFO - 2021-05-14 12:47:29 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 12:47:29 --> Database Driver Class Initialized
INFO - 2021-05-14 12:47:29 --> Email Class Initialized
DEBUG - 2021-05-14 12:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 12:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 12:47:29 --> Helper loaded: form_helper
INFO - 2021-05-14 12:47:29 --> Form Validation Class Initialized
INFO - 2021-05-14 12:47:29 --> Controller Class Initialized
INFO - 2021-05-14 12:47:29 --> Model "Common_model" initialized
INFO - 2021-05-14 12:47:29 --> Model "Finane_Model" initialized
INFO - 2021-05-14 12:47:29 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 12:47:29 --> Model "Sales_Model" initialized
INFO - 2021-05-14 12:47:29 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 12:47:29 --> Final output sent to browser
DEBUG - 2021-05-14 12:47:29 --> Total execution time: 0.1015
INFO - 2021-05-14 19:29:29 --> Config Class Initialized
INFO - 2021-05-14 19:29:29 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:29:29 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:29:29 --> Utf8 Class Initialized
INFO - 2021-05-14 19:29:29 --> URI Class Initialized
DEBUG - 2021-05-14 19:29:29 --> No URI present. Default controller set.
INFO - 2021-05-14 19:29:29 --> Router Class Initialized
INFO - 2021-05-14 19:29:29 --> Output Class Initialized
INFO - 2021-05-14 19:29:29 --> Security Class Initialized
DEBUG - 2021-05-14 19:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:29:29 --> Input Class Initialized
INFO - 2021-05-14 19:29:29 --> Language Class Initialized
INFO - 2021-05-14 19:29:29 --> Loader Class Initialized
INFO - 2021-05-14 19:29:29 --> Helper loaded: url_helper
INFO - 2021-05-14 19:29:29 --> Helper loaded: file_helper
INFO - 2021-05-14 19:29:29 --> Helper loaded: utility_helper
INFO - 2021-05-14 19:29:29 --> Helper loaded: unit_helper
INFO - 2021-05-14 19:29:29 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 19:29:29 --> Database Driver Class Initialized
INFO - 2021-05-14 19:29:29 --> Email Class Initialized
DEBUG - 2021-05-14 19:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:29:29 --> Helper loaded: form_helper
INFO - 2021-05-14 19:29:29 --> Form Validation Class Initialized
INFO - 2021-05-14 19:29:29 --> Controller Class Initialized
INFO - 2021-05-14 19:29:29 --> Model "Common_model" initialized
INFO - 2021-05-14 19:29:29 --> Model "Finane_Model" initialized
INFO - 2021-05-14 19:29:29 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 19:29:29 --> Model "Sales_Model" initialized
INFO - 2021-05-14 19:29:29 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 19:29:29 --> Final output sent to browser
DEBUG - 2021-05-14 19:29:29 --> Total execution time: 0.0873
INFO - 2021-05-14 19:38:55 --> Config Class Initialized
INFO - 2021-05-14 19:38:55 --> Hooks Class Initialized
DEBUG - 2021-05-14 19:38:55 --> UTF-8 Support Enabled
INFO - 2021-05-14 19:38:55 --> Utf8 Class Initialized
INFO - 2021-05-14 19:38:55 --> URI Class Initialized
DEBUG - 2021-05-14 19:38:55 --> No URI present. Default controller set.
INFO - 2021-05-14 19:38:55 --> Router Class Initialized
INFO - 2021-05-14 19:38:55 --> Output Class Initialized
INFO - 2021-05-14 19:38:55 --> Security Class Initialized
DEBUG - 2021-05-14 19:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 19:38:55 --> Input Class Initialized
INFO - 2021-05-14 19:38:55 --> Language Class Initialized
INFO - 2021-05-14 19:38:55 --> Loader Class Initialized
INFO - 2021-05-14 19:38:55 --> Helper loaded: url_helper
INFO - 2021-05-14 19:38:55 --> Helper loaded: file_helper
INFO - 2021-05-14 19:38:55 --> Helper loaded: utility_helper
INFO - 2021-05-14 19:38:55 --> Helper loaded: unit_helper
INFO - 2021-05-14 19:38:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 19:38:55 --> Database Driver Class Initialized
INFO - 2021-05-14 19:38:55 --> Email Class Initialized
DEBUG - 2021-05-14 19:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 19:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 19:38:55 --> Helper loaded: form_helper
INFO - 2021-05-14 19:38:55 --> Form Validation Class Initialized
INFO - 2021-05-14 19:38:55 --> Controller Class Initialized
INFO - 2021-05-14 19:38:55 --> Model "Common_model" initialized
INFO - 2021-05-14 19:38:55 --> Model "Finane_Model" initialized
INFO - 2021-05-14 19:38:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 19:38:55 --> Model "Sales_Model" initialized
INFO - 2021-05-14 19:38:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 19:38:55 --> Final output sent to browser
DEBUG - 2021-05-14 19:38:55 --> Total execution time: 0.0532
INFO - 2021-05-14 22:37:55 --> Config Class Initialized
INFO - 2021-05-14 22:37:55 --> Hooks Class Initialized
DEBUG - 2021-05-14 22:37:55 --> UTF-8 Support Enabled
INFO - 2021-05-14 22:37:55 --> Utf8 Class Initialized
INFO - 2021-05-14 22:37:55 --> URI Class Initialized
INFO - 2021-05-14 22:37:55 --> Router Class Initialized
INFO - 2021-05-14 22:37:55 --> Output Class Initialized
INFO - 2021-05-14 22:37:55 --> Security Class Initialized
DEBUG - 2021-05-14 22:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 22:37:55 --> Input Class Initialized
INFO - 2021-05-14 22:37:55 --> Language Class Initialized
INFO - 2021-05-14 22:37:55 --> Loader Class Initialized
INFO - 2021-05-14 22:37:55 --> Helper loaded: url_helper
INFO - 2021-05-14 22:37:55 --> Helper loaded: file_helper
INFO - 2021-05-14 22:37:55 --> Helper loaded: utility_helper
INFO - 2021-05-14 22:37:55 --> Helper loaded: unit_helper
INFO - 2021-05-14 22:37:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 22:37:55 --> Database Driver Class Initialized
INFO - 2021-05-14 22:37:55 --> Email Class Initialized
DEBUG - 2021-05-14 22:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 22:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 22:37:55 --> Helper loaded: form_helper
INFO - 2021-05-14 22:37:55 --> Form Validation Class Initialized
INFO - 2021-05-14 22:37:55 --> Controller Class Initialized
INFO - 2021-05-14 22:37:55 --> Model "Common_model" initialized
INFO - 2021-05-14 22:37:55 --> Model "Finane_Model" initialized
INFO - 2021-05-14 22:37:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 22:37:55 --> Model "Sales_Model" initialized
INFO - 2021-05-14 22:37:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 22:37:55 --> Final output sent to browser
DEBUG - 2021-05-14 22:37:55 --> Total execution time: 0.0487
INFO - 2021-05-14 23:56:50 --> Config Class Initialized
INFO - 2021-05-14 23:56:50 --> Hooks Class Initialized
DEBUG - 2021-05-14 23:56:50 --> UTF-8 Support Enabled
INFO - 2021-05-14 23:56:50 --> Utf8 Class Initialized
INFO - 2021-05-14 23:56:50 --> URI Class Initialized
INFO - 2021-05-14 23:56:50 --> Router Class Initialized
INFO - 2021-05-14 23:56:50 --> Output Class Initialized
INFO - 2021-05-14 23:56:50 --> Security Class Initialized
DEBUG - 2021-05-14 23:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 23:56:50 --> Input Class Initialized
INFO - 2021-05-14 23:56:50 --> Language Class Initialized
INFO - 2021-05-14 23:56:50 --> Loader Class Initialized
INFO - 2021-05-14 23:56:50 --> Helper loaded: url_helper
INFO - 2021-05-14 23:56:50 --> Helper loaded: file_helper
INFO - 2021-05-14 23:56:50 --> Helper loaded: utility_helper
INFO - 2021-05-14 23:56:50 --> Helper loaded: unit_helper
INFO - 2021-05-14 23:56:50 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 23:56:50 --> Database Driver Class Initialized
INFO - 2021-05-14 23:56:50 --> Email Class Initialized
DEBUG - 2021-05-14 23:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 23:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 23:56:50 --> Helper loaded: form_helper
INFO - 2021-05-14 23:56:50 --> Form Validation Class Initialized
INFO - 2021-05-14 23:56:50 --> Controller Class Initialized
INFO - 2021-05-14 23:56:50 --> Model "Common_model" initialized
INFO - 2021-05-14 23:56:50 --> Model "Finane_Model" initialized
INFO - 2021-05-14 23:56:50 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 23:56:50 --> Model "Sales_Model" initialized
INFO - 2021-05-14 23:56:50 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 23:56:50 --> Final output sent to browser
DEBUG - 2021-05-14 23:56:50 --> Total execution time: 0.0565
INFO - 2021-05-14 23:56:51 --> Config Class Initialized
INFO - 2021-05-14 23:56:51 --> Hooks Class Initialized
DEBUG - 2021-05-14 23:56:51 --> UTF-8 Support Enabled
INFO - 2021-05-14 23:56:51 --> Utf8 Class Initialized
INFO - 2021-05-14 23:56:51 --> URI Class Initialized
DEBUG - 2021-05-14 23:56:51 --> No URI present. Default controller set.
INFO - 2021-05-14 23:56:51 --> Router Class Initialized
INFO - 2021-05-14 23:56:51 --> Output Class Initialized
INFO - 2021-05-14 23:56:51 --> Security Class Initialized
DEBUG - 2021-05-14 23:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-14 23:56:51 --> Input Class Initialized
INFO - 2021-05-14 23:56:51 --> Language Class Initialized
INFO - 2021-05-14 23:56:51 --> Loader Class Initialized
INFO - 2021-05-14 23:56:51 --> Helper loaded: url_helper
INFO - 2021-05-14 23:56:51 --> Helper loaded: file_helper
INFO - 2021-05-14 23:56:51 --> Helper loaded: utility_helper
INFO - 2021-05-14 23:56:51 --> Helper loaded: unit_helper
INFO - 2021-05-14 23:56:51 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-14 23:56:51 --> Database Driver Class Initialized
INFO - 2021-05-14 23:56:51 --> Email Class Initialized
DEBUG - 2021-05-14 23:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-14 23:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-14 23:56:51 --> Helper loaded: form_helper
INFO - 2021-05-14 23:56:51 --> Form Validation Class Initialized
INFO - 2021-05-14 23:56:51 --> Controller Class Initialized
INFO - 2021-05-14 23:56:51 --> Model "Common_model" initialized
INFO - 2021-05-14 23:56:51 --> Model "Finane_Model" initialized
INFO - 2021-05-14 23:56:51 --> Model "Inventory_Model" initialized
INFO - 2021-05-14 23:56:51 --> Model "Sales_Model" initialized
INFO - 2021-05-14 23:56:51 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-14 23:56:51 --> Final output sent to browser
DEBUG - 2021-05-14 23:56:51 --> Total execution time: 0.0401
