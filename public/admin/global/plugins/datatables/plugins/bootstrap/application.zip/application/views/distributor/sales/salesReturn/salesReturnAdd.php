
<script src="<?php echo base_url(); ?>assets/js/jQueryUI/jquery-new-ui.js"></script>
<style>
    table tr td{
        margin: 0px!important;
        padding: 2px!important;
    }

    table tr td  tfoot .form-control {
        width: 100%;
        height: 25px;
    }
</style>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Transaction</li>
                <li class="active">Sales Return Add</li>
                <li class="active"></li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li class="active">
                    <i class="ace-icon fa fa-list"></i>
                    <a href="<?php echo site_url($this->project . '/salesReturn'); ?>">List</a>
                </li>
            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <table class="mytable table-responsive table table-bordered">
                            <tr>
                                <td  style="padding: 10px!important;">
                                    <div class="col-md-12">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer   <span style="color:red;"> *</span></label>
                                                <div class="col-sm-7">
                                                    <select  id="customerList" onchange="getDateAndInvoiceList(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by customer">
                                                        <option value=""></option>
                                                        <?php foreach ($customerList as $key => $value): ?>
                                                            <option value="<?php echo $value->customer_id; ?>"><?php echo $value->cusName; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Sales Date</label>
                                                <div class="col-sm-7">

                                                    <select  id="salesDate" onchange="getInvoiceListbyDateAndCustomer(this.value)" class="chosen-select form-control"  data-placeholder="Search by Name">
                                                        <option value=""></option>
                                                    </select>

                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Invoice No</label>
                                                <div class="col-sm-7">

                                                    <select  id="invoiceList" onchange="getInvoiceProduct(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Name">
                                                        <option value=""></option>
                                                    </select>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </td>
                            </tr>

                            <tr>
                                <td style="padding: 10px!important;">

                                    <div id="invoiceProduct"></div>


                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="clearfix"></div>
                                    <div class="clearfix form-actions" >
                                        <div class="col-md-offset-1 col-md-10">
                                            <button onclick="return isconfirm2()" id="subBtn" class="btn btn-info" type="submit">
                                                <i class="ace-icon fa fa-check bigger-110"></i>
                                                Save
                                            </button>
                                            &nbsp; &nbsp; &nbsp;

                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>












<script>




    function getDateAndInvoiceList(customerId){
        var customerId=$("#customerList").val();
        $("#invoiceProduct").html('');
        $.ajax({
            type:"POST",
            url:"<?php echo site_url($this->project . '/getDateList'); ?>",
            data:{customerId:customerId},
            success: function(result)
            {
                var jobject=   JSON.parse(result);
                var addedDate='';

                var addedDate='';
                $('#salesDate option').remove();
                $('#invoiceList option').remove();
                $("#invoiceList").trigger("chosen:updated");

                addedDate+='<option value="" selected disabled>Select Date</option>';


                for(var i=0;i<jobject.length;i++){
                    $('#salesDate').val('');
                    addedDate+='<option value="'+ jobject[i].date +'">' + jobject[i].date + '</option>';

                }
                $('#salesDate').append($(addedDate));
                $("#salesDate").trigger("chosen:updated");

            }
        });

    }



    function getInvoiceListbyDateAndCustomer(){
        $("#invoiceProduct").html('');
        var customerId=$("#customerList").val();
        var saleDate=$("#salesDate").val();
        $.ajax({
            type:"POST",
            url:"<?php echo site_url($this->project . '/getInvoiceListbyCustomerIdAndDate'); ?>",
            data:{customerId:customerId,saleDate:saleDate},
            success: function(result)
            {
                var jobject=   JSON.parse(result);
                var addedInvoice='';

                $('#invoiceList option').remove();
                addedInvoice+='<option value="" selected disabled>Select Invoice</option>';
                for(var i=0;i<jobject.length;i++){

                    addedInvoice+='<option value="'+ jobject[i].generals_id +'">' + jobject[i].voucher_no + '</option>';
                }
                $('#invoiceList').append($(addedInvoice));
                $("#invoiceList").trigger("chosen:updated");
            }
        });
    }

    function getInvoiceProduct(invoiceId){

        $.ajax({
            type:"POST",
            url:"<?php echo site_url($this->project . '/getInvoiceProductList'); ?>",
            data: 'invoiceId=' + invoiceId,
            success: function(result)
            {
                $("#invoiceProduct").html(result);
            }
        });

    }


    $('.date-picker2').datepicker({
        autoclose: true,
        todayHighlight: true,
        onSelect: function(date)
        {

            $.ajax({
                type:"POST",
                url:"<?php echo site_url($this->project . '/showAllInvoiceListByDate'); ?>",
                data: 'date=' + date,
                success: function(result)
                {
                    $('#invoiceList').chosen();
                    $('#invoiceList option').remove();
                    $('#invoiceList').append($(result));
                    $("#invoiceList").trigger("chosen:updated");
                }
            });
        }
    })
    //show datepicker when clicking on the icon
    .next().on(ace.click_event, function(){
        $(this).prev().focus();
    });


















</script>