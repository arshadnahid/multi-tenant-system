
<?php
if (isset($_POST['start_date'])):
    $from_date = $this->input->post('start_date');
    $to_date = $this->input->post('end_date');
endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Report</li>
                <li class="active">Sales Report</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/sales'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-8 col-sm-offset-2">
                            <div class="table-header">
                                Sales Report
                            </div><br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From Date</label>
                                        <div class="col-sm-8">
                                            <input type="text"class="date-picker" id="start_date" name="start_date" value="<?php
if (!empty($from_date)) {
    echo $from_date;
} else {
    echo date('Y-m-d');
}
?>" data-date-format='yyyy-mm-dd' placeholder="Start Date: yyyy-mm-dd"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                                   if (!empty($to_date)):
                                                       echo $to_date;
                                                   else:
                                                       echo date('Y-m-d');
                                                   endif;
?>" data-date-format='yyyy-mm-dd' placeholder="End Date: yyyy-mm-dd"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-6">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-6">
                                            <button type="button" class="btn btn-info btn-sm" id="btn-print" onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):
                //  dumpVar($_POST);
                $from_date = $this->input->post('start_date');
                $to_date = $this->input->post('end_date');
                unset($_SESSION["start_date"]);
                unset($_SESSION["end_date"]);
                $_SESSION["start_date"] = $from_date;
                $_SESSION["end_date"] = $to_date;
                $dist_id = $this->dist_id;
                $total_pvsdebit = '';
                $total_pvscredit = '';
                $total_debit = '';
                $total_credit = '';
                $total_balance = '';
                ?>
                <div class="row">
                    <div class="col-xs-8 col-xs-offset-2">
                        <div class="table-header">
                            Sales Report Period <span style="color:greenyellow;">From <?php echo $from_date; ?> To <?php echo $to_date; ?></span>
                        </div>
                    </div>

                    <div class="col-xs-8 col-xs-offset-2">
                        <div class="noPrint">
    <!--                            <button style="border-radius:100px 0 100px 0;" href="<?php echo site_url($this->project . '/SalesController/salesReport_export_excel/') ?>" class="btn btn-success pull-right noPrint">
                            <i class="ace-icon fa fa-download"></i>
                            Excel
                        </button>-->
                        </div>
                        <?php if ($companyInfo->invoice_format_type == 1): ?>


                            <table class="table table-responsive">
                                <tr>
                                    <td style="text-align:center;">
                                        <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                        <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                        <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                        <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                        <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                        <strong><?php echo $pageTitle; ?></strong>
                                    </td>
                                </tr>
                            </table>

                        <?php else: ?>
                            <div>
                                <?php echo $companyInfo->report_header; ?>
                             
                            </div>
                        <?php endif; ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <td align="left"><strong>SL</strong></td>
                                    <td align="left"><strong>Date</strong></td>
                                    <td align="left"><strong>Product.</strong></td>
                                    <td align="right"><strong>Bundle Qty</strong></td>
                                    <td align="right"><strong>Sale Qty</strong></td>
                                    <td align="right"><strong>Sale Price</strong></td>
                                    <td align="right"><strong>Total Sale</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($allResult as $key => $row):

                                    $tsaleRte+=$row->rate;
                                    $tqty+=$row->saleQty;
                                    $tprice+=$row->totalPrice;
                                    $tbundle+=$row->bundleQty;
                                    ?>
                                    <tr>
                                        <td align="left"><?php echo $key + 1; ?></td>
                                        <td align="left"><?php echo date('M d, Y', strtotime($row->date)); ?></td>
                                        <td align="left"><?php echo $row->productName; ?></td>
                                        <td align="right"><?php echo $row->bundleQty; ?></td>
                                        <td align="right"><?php echo $row->saleQty; ?></td>
                                        <td align="right"><?php echo $row->rate; ?></td>
                                        <td align="right"><?php echo $row->totalPrice; ?></td>

                                    </tr>
                                <?php endforeach; ?>
                                <!-- /Search Balance -->
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" align="right"><strong>Total Sales Amount</strong></td>
                                    <td align="right"><strong><?php echo $tbundle; ?>&nbsp;</strong></td>
                                    <td align="right"><strong><?php echo $tqty; ?>&nbsp;</strong></td>
                                    <td align="right"><strong><?php echo number_format((float) abs($tsaleRte), 2, '.', ','); ?>&nbsp;</strong></td>
                                    <td align="right"><strong><?php echo number_format((float) abs($tprice), 2, '.', ','); ?>&nbsp;</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
