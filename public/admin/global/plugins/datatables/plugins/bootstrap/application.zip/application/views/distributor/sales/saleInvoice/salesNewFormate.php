<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Transaction</li>
                <li class="active">Sales Invoice</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/salesInvoice'); ?>">
                        <i class="ace-icon 	fa fa-list"></i> List
                    </a>
                </li>
                <!--                <li class="active saleAddPermission"><a href="<?php echo site_url($this->project . '/salesInvoice_add'); ?>" >
                        <i class="ace-icon 	fa fa-plus"></i>  Add
                    </a>
                </li>
                <li>
                    <a class="saleEditPermission"  href="<?php echo site_url($this->project . '/salesInvoice_edit/' . $saleslist->generals_id); ?>">
                        <i class="ace-icon 	fa fa-pencil bigger-130"></i> Edit
                    </a>
                </li>-->

                <li>
                    <a onclick="window.print();" style="cursor:pointer;">
                        <i class="ace-icon fa fa-print"></i> Print
                    </a>
                </li>

            </ul>
        </div>
        <div class="page-content">
              <div class="row">
			  <div style="width:5%!important;" class="noPrint"></div>
                <div style="width: 70%!important;" >
                           
                                <!-- PAGE CONTENT BEGINS -->
                                <div class="space-6"></div>

                                <div class="row">
                                    <div class="col-sm-10 col-sm-offset-1">
                                        <div class="widget-box transparent" style="margin-left: 5px;">
                                            <div class="widget-body">
                                               <div>
                                                    <table class="table" style="border:none">
                                                         <tbody style="border:none">
                                                            <tr style="border:none">
                                                              
  
                                                                <td  style="border:none;text-align:left">
                                                                   <img src="<?php echo base_url('assets/images/estia/logo.jpg'); ?>" style="height:70px ;width:80px"  data-holder-rendered="true"/>
                                                                 
																</td>
                                                                <td style="border:none;line-height: 10px;text-align: center"> <p><strong style="font-size:20px">ইসতিয়া এন্টারপ্রাইজ </strong></p>
                                                                    <p><strong style="font-size:20px">ESTIA ENTERPRISE </strong></p>
                                                                    <p><strong style="font-size:20px">প্রো : মোঃ জলিল </strong></p>
                                                                </td>
                                                               
                                                                <td style="border:none;line-height: 10px; text-align:right;" ></p>
                                                                <p style="left:0px"><strong>Mobile : </strong> 01713013484</p>
                                                                <p style="left:0px"><strong>:</strong>  01712172046</p>
                                                                <p style="left:0px"><strong>Office :</strong> 7277194</p>
                                                                <p style="left:0px">7274717</p>
                                                                </td>
                                                            </tr>

                                                          </tbody>
                                                    </table>
                                                </div> 
												<div>
                                                    <table class="table" style="border:none; margin-top: -20px;">
                                                         <tbody style="border:none">
                                                        <tr style="border:none">
                                                        <td style="border:none;line-height: 10px;"> 
														<p style="left:0px"><strong> Name : </strong><?php echo $customerInfo->customerID . '[' . $customerInfo->customerName . ']' ?></p>
                                                        <p style="left:0px"><strong> Address: </strong><?php echo $customerInfo->customerAddress; ?></p>
                                                                    
                                                        </td>
                                                               
                                                                <td style="border:none;line-height: 10px; text-align:right;">
                                                                <p style="left:0px"><strong>Invoice ID : </strong> <?php echo $saleslist->voucher_no; ?></p>
                                                                <p style="left:0px"><strong>Date : </strong>  <?php echo date('M d, Y', strtotime($saleslist->date)); ?></p>
                                                                
                                                                </td>
                                                            </tr>

                                                          </tbody>
                                                    </table>
                                                </div>

                                                <div class="space"></div>

                                                <div>
                                                    <table class="table table-striped table-bordered" style="margin-top: -30px;">
                                                     
                                                            <tr>
                                                                <td  style="width:5%;white-space:nowrap;" class="center"><strong style="font-size:12px;">#</strong></td>
                                                                <td style="width:30%;white-space:nowrap;" class="text-center"><strong style="font-size: 12px;">Product</strong></td>
                                                                <td width="10%" class="text-right"><strong style="font-size: 12px;">Bundle</strong></td>
                                                                <td width="10%" class="text-right"><strong style="font-size: 12px;">Quantity</strong></td>
                                                                <td width="10%" class="text-right"><strong style="font-size: 12px;">Unit</strong></td>
																<td width="10%" class="text-right"><strong style="font-size: 12px;">Unit Price</strong></td>
																<td width="10%" class="text-right"><strong style="font-size: 12px;">Total Price</strong></td>
                                                            </tr>
                                                       

                                                        <tbody>
                                            <?php
                                            $tqty = 0;
                                            $trate = 0;
                                            $tprice = 0;
                                            $j = 1;
                                            foreach ($stockList as $key => $each_info):
                                                if ($each_info->type == 'Out') {
                                                    $tqty += $each_info->quantity;
                                                    $trate += $each_info->rate;
                                                    $tprice += $each_info->rate * $each_info->quantity;
                                                    ?>
                                                    <tr>
                                                        <td class="center"><?php echo $j++; ?></td>
                                                        <td>
                                                            <?php
                                                            echo $this->Common_model->tableRow('productcategory', 'category_id', $each_info->category_id)->title;
                                                            ?>

                                                            <?php
                                                            $productInfo = $this->Common_model->tableRow('product', 'product_id', $each_info->product_id);
                                                            echo $productInfo->productName;
                                                            echo ' [ ' . $this->Common_model->tableRow('brand', 'brandId', $productInfo->brand_id)->brandName . ' ] ';
                                                            ?>
                                                        </td>

                                                        <td class="text-right"><?php
                                                    if ($each_info->bundle > 0) {
                                                        echo $each_info->bundle;
                                                    }
                                                            ?> </td>
                                                        <td class="text-right"><?php echo $each_info->quantity; ?> </td>
                                                        <td class="text-right">
                                                            <?php
                                                            if (!empty($productInfo->unit_id)):
                                                                echo $this->Common_model->tableRow('unit', 'unit_id', $productInfo->unit_id)->unitTtile;
                                                            else:
                                                                echo "KG";
                                                            endif;
                                                            ?>
                                                        </td>
                                                        <td align="right"><?php echo $each_info->rate; ?> </td>
                                                        <td align="right"><?php echo number_format($each_info->rate * $each_info->quantity, 2); ?> </td>
                                                    </tr>
                                                <?php }endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Sub - Total</strong></td>

                                                <td align="right"><?php echo number_format($tprice, 2); ?></td>
                                            </tr>
                                            <?php
                                            if (!empty($saleslist->discount) && $saleslist->discount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Discount ( - ) </strong></td>
                                                    <td align="right"><?php echo number_format($saleslist->discount, 2); ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                            if (!empty($saleslist->vatAmount) && $saleslist->vatAmount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>VAT <?php echo round($saleslist->vat, 2) . ' '; ?>%( + )</strong></td>
                                                    <td align="right"><?php echo number_format($saleslist->vatAmount, 2); ?></td>

                                                </tr>
                                                <?php
                                            endif;
                                            if (!empty($saleslist->loaderAmount) && $saleslist->loaderAmount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Loader ( + )</strong></td>
                                                    <td align="right"><?php echo number_format($saleslist->loaderAmount, 2); ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                            if (!empty($saleslist->transportationAmount) && $saleslist->transportationAmount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Transportation ( + )</strong></td>
                                                    <td align="right"><?php echo number_format($saleslist->transportationAmount, 2); ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                            ?>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Net Total</strong></td>
                                                <td align="right"><?php echo number_format($saleslist->debit, 2); ?></td>
                                            </tr>
                                            <?php
                                            if (!empty($invoicePayment) && $invoicePayment > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Payment ( - )</strong></td>
                                                    <td align="right"><?php echo number_format($invoicePayment, 2); ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                            $dueAmount1 = $saleslist->debit - $invoicePayment;
                                            if (!empty($dueAmount1) && $dueAmount1 > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Due Amount</strong></td>
                                                    <td align="right"><?php echo number_format($saleslist->debit - $invoicePayment, 2); ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                            ?>
                                            <tr>
                                                <td colspan="7" >
                                                    <strong><span>In Words : &nbsp;</span> <?php echo $this->Common_model->get_bd_amount_in_text($saleslist->debit); ?></strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="7">
                                                    <span>Narration : &nbsp;</span> <?php echo $saleslist->narration; ?>
                                                </td>
                                            </tr>
                                        </tfoot>
                                                    </table>
                                                </div>
												<table class="table" style="border:none; margin-top: -10px;">
                                                         <tbody style="border:none">
                                                        <tr style="border:none">
                                                        <td style="border:none;line-height: 10px;"> 
														<p style="left:0px"><strong>Prepared By:_____________</strong></p>
                                                        <p style="left:0px"><strong> Date:____________________</strong></p>
                                                                    
                                                        </td>
                                                               
                                                                <td style="border:none;line-height: 10px; text-align:right;">
                                                                <p style="left:0px"><strong>Approved By:________________</strong></p>
                                                                <p style="left:0px"><strong>Date:_________________</strong></p>
                                                                
                                                                </td>
                                                            </tr>

                                                          </tbody>
                                                    </table>

                                                <div class="space-6"></div>
                                                <div class="well text-center">
                                                    সর্বপ্রকার  লৌহজাত  ,সিমেন্ট  দ্র্রব্যর  পাইকারী  বিক্রেতা  ও  সরবরাহকারী।<br> ৫৩৮,দক্ষিন  মান্ডা  (মেইন  রোড ) ,ঢাকা -১২১৪
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								</div>
								<div style="width:25%!important;" class="noPrint"></div>
                            </div>

                            <!-- PAGE CONTENT ENDS -->
                      
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>
<script>
    var url = baseUrl + "SalesController/getCustomerCurrentBalance";
    $.ajax({
        type: 'POST',
        url: url,
        data: {
            customerId: '<?php echo $saleslist->customer_id; ?>'
        },
        success: function (data) {
            $('.currentBalance').text(parseFloat(data).toFixed(2));


        }
    });

</script>
