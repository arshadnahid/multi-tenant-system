
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Account</a>
                </li>
                <li>Account Report</li>
                <li class="active">Journal List Ledger</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li class="active">
                    <i class="ace-icon fa fa-list"></i>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/account'); ?>">List</a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">



            <div class="row">
                <div class="col-sm-10 col-md-offset-1">
                    <div class="table-header">
                        Journal List Ledger
                    </div>

                    <table class="table table-responsive">
                        <tr>
                            <td style="text-align:center;">
                                <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                <span><?php echo $companyInfo->address; ?></span><br>
                                <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                <strong><?php echo $pageTitle; ?></strong>
                            </td>
                        </tr>
                    </table>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <td align="center"><strong>SL</strong></td>
                                <td align="center"><strong>Date</strong></td>
                                <td align="center"><strong>Voucher</strong></td>
                                <td align="center"><strong>Journal Type</strong></td>
                                <td align="center"><strong>Debit Balance</strong></td>
                                <td align="center"><strong>Credit Balance</strong></td>
                                <td align="center"><strong>Balance</strong></td>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $tdebit = 0;
                            $tcredit = 0;
                            foreach ($journalList as $key => $eachSup):

                                $tdebit+=$eachSup->totalDebit;
                                $tcredit+=$eachSup->totalCredit;
                                ?>
                                <tr <?php if($eachSup->totalDebit !=$eachSup->totalCredit){ ?>style="color: red;"<?php }?>>
                                    <td><?php echo $sl++; ?></td>
                                    <td align="center"><?php echo $eachSup->date; ?></td>
                                    <td align="center"><?php echo $eachSup->voucher_no; ?></td>
                                    <td align="center"><?php echo $eachSup->name; ?></td>
                                    <td align="right"><?php echo $eachSup->totalDebit; ?></td>
                                    <td align="right"><?php echo $eachSup->totalCredit; ?></td>
                                    <td align="right"><?php echo $eachSup->totalDebit - $eachSup->totalCredit; ?></td>
                                </tr>
                                <?php
                            endforeach;
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" align="right"><strong>Total (In BDT.)</strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tdebit, 2, '.', ','); ?></strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tcredit, 2, '.', ','); ?></strong></td>
                                <td align="right"><strong><?php echo number_format((float) $tdebit-$tcredit, 2, '.', ','); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
