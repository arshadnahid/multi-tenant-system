<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class TrialExpired extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Common_model');
        date_default_timezone_set('Asia/Dhaka');
    }

    function index() {
        // die('test');
        $this->timebomb();
    }

    function timebomb() {
        $today = date("Y-m-d");
        $trialPeriod = 1;
        $startDate = date("Y-m-d");
        $getExpiryDate = strtotime('+' . $trialPeriod . "days", strtotime($startDate));
        $expiryDate = date("Y-m-d", $getExpiryDate);
        $checkStatus = $this->Common_model->row('timebomb');

        // die('test');
        if (!$checkStatus) {
            $this->redirect();
        } else {
            if ($checkStatus['id'] != 1 || empty($checkStatus['StartDate']) || empty($checkStatus['ExpiryDate']) || empty($checkStatus['code']) || empty($checkStatus['status'])) {
                $this->redirect();
            } else {
                $getPeriod = $this->Common_model->row('timebomb');
                if (strlen($getPeriod['ExpiryDate']) != 16) {
                    $this->redirect();
                } else {
                    if (substr($getPeriod['ExpiryDate'], -2) != '==') {
                        $this->redirect();
                    } else {
                        $endOfTrial = $this->textDecode($getPeriod['ExpiryDate']);
                        $explode = explode('-', $endOfTrial);

                        if (strlen($explode[0]) != 4 && strlen($explode[1]) != 2 && strlen($explode[2]) != 2) {
                            $this->redirect();
                        } else {
                            if (!is_numeric($explode[0]) || !is_numeric($explode[1]) || !is_numeric($explode[2])) {
                                $this->redirect();
                            } else {
                                if ($endOfTrial == $today || $endOfTrial < $today) {
                                    $data['title'] = "License expired";
                                    $this->load->view('trialExpired/trialExpired', $data);
                                } else {
                                    $data['title'] = 'Distributor Login';
                                    $this->load->view('login', $data);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    function updateTrial() {
        $input = $this->textDecode($this->input->post('code'));
        $explode = (explode("-", $input));

        if (isset($explode[0]) && isset($explode[1]) && isset($explode[2]) && isset($explode[3])) {
            $code = md5($this->textEncode($explode[0] . "-" . $explode[1] . "-" . $explode[3]));
        } else {
            $msg = "Invalid Code Format";
            $this->session->set_flashdata('failed', $msg);
            redirect($this->project . '/trialExpired/trialExpired');
        }

        $trialPeriod = $explode[2];
        $row = $this->Common_model->get_single_data_by_single_column('timebomb','code',$code);
       // $row = $this->Common_model->Common_model('*', 'timebomb', array('code' => $code));

        if ($row) {
            if ($row['id'] != 1) {
                $msg = "Modified the database table, please contact to ABH World";
                $this->session->set_flashdata('failed', $msg);
                redirect($this->project . '/trialExpired/trialExpired');
            }

            $prev_date = $this->textDecode($row['ExpiryDate']);
            $getExpiryDate = strtotime('+' . $trialPeriod . "days", strtotime($prev_date));
            $expiryDate = $this->textEncode(date("Y-m-d", $getExpiryDate));
            $int = intval(preg_replace('/[^0-9]+/', '', $explode['1'])) + 1;
            $new_code = "a" . $int . "a";
            $update_code = $explode[0] . "-" . $new_code . "-" . $explode[3];
            $encoded = md5($this->textEncode($update_code));

            $data = array('ExpiryDate' => $expiryDate, 'code' => $encoded, 'status' => $int);
            $this->common_model->update('timebomb', array('id' => $row['id']), $data);

            $msg = "Congrats! your trial has been extended for $trialPeriod days";
            $this->session->set_flashdata('success', $msg);
            redirect($this->project . '/dashboardcontroller');
        } else {
            $msg = "Invalid Code";
            $this->session->set_flashdata('failed', $msg);
            redirect($this->project . '/trialExpired/trialExpired');
        }
    }

    function textEncode($string) {
        return base64_encode($string);
    }

    function textDecode($string) {
        return base64_decode($string);
    }

    function redirect() {
        $data['msg'] = "Extension Table has been modified";
        $this->load->view('trialExpired/trialExpired', $data);
    }

}