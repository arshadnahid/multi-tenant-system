
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li >Inventory Report</li>
                <li class="active">Stock Report</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/inventory'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>

                <li>
                    <a  onclick="window.print();" style="cursor:pointer;">
                        <i class="ace-icon fa fa-print"></i> Print
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">

            <?php
            $dr = 0;
            $cr = 0;
            ?>
            <div class="row">
                <div class="col-xs-8 col-xs-offset-2">

                    <div class="table-header">
                        Current Stock Report
                    </div>
                    <div class="noPrint">

                    </div>

                   <?php if ($companyInfo->invoice_format_type == 1): ?>


                            <table class="table table-responsive">
                                <tr>
                                    <td style="text-align:center;">
                                        <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                        <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                        <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                        <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                        <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                        <strong><?php echo $pageTitle; ?></strong>
                                    </td>
                                </tr>
                            </table>

                        <?php else: ?>
                            <div>
                                <?php echo $companyInfo->report_header; ?>
                            </div>
                        <?php endif; ?>
                    <table class="table table-striped table-bordered table-hover table-responsive">
                        <thead>
                            <tr>
                                <td style="text-align:left;"><strong>SL</strong></td>
                                <td style="text-align:left;"><strong>Product Name</strong></td>
                                <td style="text-align:right;"><strong>Bundle Received Qty</strong></td>
                                <td style="text-align:right;"><strong>Received Qty</strong></td>
                                <td style="text-align:right;"><strong>Bundle Sales Qty</strong></td>
                                <td style="text-align:right;"><strong>Sales Qty</strong></td>
                                <td style="text-align:right;"><strong>Bundle Balance</strong></td>
                                <td style="text-align:right;"><strong>Balance</strong></td>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $tReceiveQty = 0;
                            $tSaleQty = 0;
                            $tBalanceQty = 0;
                            foreach ($allStock as $key => $eachStock):
                                $ttotalBundleIn+=$eachStock->totalBundleIn;
                                $ttotalBundleOut+=$eachStock->totalBundleOut;
                                $tbundleBalance+=$eachStock->bundleBalance;
                                $tReceiveQty+=$eachStock->receiveQty;
                                $tSaleQty+=$eachStock->saleQty;
                                $tBalanceQty+=$eachStock->balance;
                                ?>
                                <tr>
                                    <td ><?php echo $key + 1; ?></td>
                                    <td><?php echo $eachStock->productName; ?></td>
                                    <td align="right"><?php echo number_format((float) $eachStock->totalBundleIn, 2, '.', ','); ?></td>
                                    <td align="right"><?php echo number_format((float) $eachStock->receiveQty, 2, '.', ','); ?></td>
                                    <td align="right"><?php echo number_format((float) $eachStock->totalBundleOut, 2, '.', ','); ?></td>
                                    <td align="right"><?php echo number_format((float) $eachStock->saleQty, 2, '.', ','); ?></td>
                                    <td align="right"><?php echo number_format((float) $eachStock->bundleBalance, 2, '.', ','); ?></td>
                                    <td align="right"><?php echo number_format((float) $eachStock->balance, 2, '.', ','); ?></td>
                                </tr>
                                <?php
                                //  endif;
                            endforeach;
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2" style="text-align:right;"><strong>Total</strong></td>
                                <td style="text-align:right;"><strong><?php echo number_format((float) $ttotalBundleIn, 2, '.', ','); ?></strong></td>
                                <td style="text-align:right;"><strong><?php echo number_format((float) $tReceiveQty, 2, '.', ','); ?></strong></td>
                                <td style="text-align:right;"><strong><?php echo number_format((float) $ttotalBundleOut, 2, '.', ','); ?></strong></td>
                                <td style="text-align:right;"><strong><?php echo number_format((float) $tSaleQty, 2, '.', ','); ?></strong></td>
                                <td style="text-align:right;"><strong><?php echo number_format((float) $tbundleBalance, 2, '.', ','); ?></strong></td>
                                <td style="text-align:right;"><strong><?php echo number_format((float) $tBalanceQty, 2, '.', ','); ?></strong></td>

                            </tr>
                        </tfoot>

                    </table>
                </div>
            </div>

        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

