<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Inventory_Model extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
    }

    public function getImportProduct($distId = null) {
        $this->db->select('*');
        $this->db->from('productimport');
        $this->db->where('productimport.dist_id', $distId);
        $this->db->group_start();
        $this->db->where_in('catId', 0);
        $this->db->or_where_in('brandId', 0);
        $this->db->or_where_in('unitId', 0);
        $this->db->group_end();
        $result = $this->db->get()->result();
        return $result;
    }

    function currentStockValue($distId) {
        $sql = "SELECT
	p.productName,
	IFNULL(sin.totalInPurQty, 0)AS receiveQty,
	IFNULL(sout.totalOutSaleQty, 0)AS SaleQty,
IFNULL(sin.totalBundleInQty, 0)AS bundleIn,
IFNULL(sout.totalBundleOutQty, 0)AS bundleOut,
(IFNULL(sin.totalBundleInQty, 0)- IFNULL(sout.totalBundleOutQty, 0)) as currentBundleStock,
	(
		IFNULL(sin.totalInPurQty, 0)- IFNULL(sout.totalOutSaleQty, 0)
	)AS currentStock,
	sin.totalAvgprice,
	(
		(
			IFNULL(sin.totalInPurQty, 0)- IFNULL(sout.totalOutSaleQty, 0)
		)* IFNULL(sin.totalAvgprice, 0)
	)AS totalValue,
	p.product_id
FROM
	product AS p
LEFT JOIN(
	SELECT
		sum(s.quantity)AS totalInPurQty,
    sum(s.bundle)AS totalBundleInQty,
		sum(s.price)AS totalPrice,
		(
			IFNULL(sum(s.price), 0)/ IFNULL(sum(s.quantity), 0)
		)AS totalAvgprice,
		s.product_id
	FROM
		stock AS s
	WHERE
		s.type = 'In'   AND s.dist_id='$distId'
	GROUP BY
		s.product_id
)AS sin ON sin.product_id = p.product_id
LEFT JOIN(
	SELECT
		sum(s.bundle)AS totalBundleOutQty,
   sum(s.quantity)AS totalOutSaleQty,
		sum(s.price)AS totalPrice,
		(IFNULL(sum(s.price), 0)/ IFNULL(sum(s.quantity), 0))AS totalSaleprice,
		s.product_id
	FROM stock AS s
	WHERE
		s.type = 'Out' AND s.dist_id='$distId'
	GROUP BY
		s.product_id
)AS sout ON sout.product_id = p.product_id
GROUP BY
	p.product_id HAVING currentStock > 0";
        $result = $this->db->query($sql)->result();
        return $result;
    }

    public function supplierDueList($distId) {
        $sql = "SELECT g.generals_id,CONCAT(s.supID,' [ ',s.supName,' ] ') AS supName,g.voucher_no,g.date,iam.invoiceamount,pam.paidAmount,(IFNULL(iam.invoiceamount,0) - IFNULL(pam.paidAmount,0)) AS dueAmount FROM supplier as s
left JOIN generals as g ON s.sup_id=g.supplier_id
LEFT JOIN ( select sum(g.debit) as invoiceamount,g.supplier_id,g.voucher_no from generals as g WHERE g.form_id=11 GROUP BY g.voucher_no,g.supplier_id) AS iam on iam.supplier_id=s.sup_id AND g.voucher_no = iam.voucher_no
LEFT JOIN ( select sum(g.credit) as paidAmount,g.supplier_id,g.voucher_no from generals as g WHERE g.form_id=14 GROUP BY g.voucher_no,g.supplier_id) AS pam on pam.supplier_id=s.sup_id AND g.voucher_no = pam.voucher_no
WHERE s.dist_id='$distId'
GROUP BY s.sup_id,g.voucher_no
HAVING dueAmount > 0";
        $result = $this->db->query($sql)->result();
        return $result;
    }

    public function currentStock() {
        $sql = "SELECT
	CONCAT(
		p.productName,
		' [ ',
		b.brandName,
		' ] '
	)AS productName,
	pin.totalPurchasesIn AS receiveQty,
pin.totalBundleIn,
sin.totalBundleOut,
(IFNULL(pin.totalBundleIn, 0)- IFNULL(sin.totalBundleOut, 0)) AS bundleBalance,
	sin.totalSaleOut AS saleQty,
	(
		ifnull(pin.totalPurchasesIn, 0)- ifnull(sin.totalSaleOut, 0)
	)AS balance
FROM
	product AS p
LEFT JOIN brand AS b ON p.brand_id = b.brandId
LEFT JOIN(
	SELECT
		sum(s.bundle)AS totalBundleIn,
	sum(s.quantity)AS totalPurchasesIn,
s.product_id
	FROM
		stock AS s
	WHERE
		s.type = 'In'
	GROUP BY
		s.product_id
)AS pin ON pin.product_id = p.product_id
LEFT JOIN(
	SELECT
		sum(s.bundle)AS totalBundleOut,
   sum(s.quantity)AS totalSaleOut,
		s.product_id
	FROM
		stock AS s
	WHERE
		s.type = 'Out'
	GROUP BY
		s.product_id
)AS sin ON sin.product_id = p.product_id
GROUP BY
	p.product_id
HAVING
	receiveQty > 0
OR saleQty > 0 OR bundleBalance > 0";
        $result = $this->db->query($sql)->result();
        return $result;
    }

    public function checkInvoiceWiseStock($invoiceId) {
        $sql = "SELECT
	stock.product_id,
	stock.quantity,
	tab1.totalQtyIn,
	tab2.totalQtyOut,
	IFNULL(tab1.totalQtyIn, 0)- IFNULL(tab2.totalQtyOut, 0) AS paresentStock
FROM
	stock
LEFT JOIN(
	SELECT
		SUM(s.quantity)AS totalQtyIn,
		s.product_id
	FROM
		stock AS s
	WHERE
		s.type = 'In'
	GROUP BY
		s.product_id
)AS tab1 ON tab1.product_id = stock.product_id
LEFT JOIN(
	SELECT
		SUM(s.quantity) AS totalQtyOut,
		s.product_id
	FROM
		stock AS s
	WHERE
		s.type = 'Out'
	GROUP BY
		s.product_id
) AS tab2 ON tab2.product_id = stock.product_id
WHERE
	stock.type = 'In'
    AND stock.generals_id = '$invoiceId'
GROUP BY
	stock.product_id";


        $query = $this->db->query($sql);
        $result = $query->result();
        $false = true;
        foreach ($result as $eachRow) {
            if ($eachRow->paresentStock >= $eachRow->quantity) {
                // $false = true;
            } else {
                $false = false;
            }
        }
        return $false;
    }

    public function getFullStockReport($brandId, $distId, $fromDate, $todate) {

        // $this->getPublicBrand($distId);

        $sql = '';
        if ($brandId == 'all'):
            $sql = 'GROUP BY oriBrand.brandId ORDER BY brandName';
        else:
            $sql = 'WHERE oriBrand.brandId =' . $brandId . ' ORDER BY brandName';
        endif;
        $query = "SELECT sum(detailsTable.tcpIn) as cylinderPurIn,SUM(detailsTable.tcpOut) AS cylinderSaleOut, SUM(detailsTable.trpIn) AS totalRefillIn,SUM(detailsTable.trpOut) AS totalRefillOut,SUM(detailsTable.tccIn) as totalCusIn,
            SUM(detailsTable.tccOut) AS totalCusCylinOut,detailsTable.brandName
            FROM brand oriBrand
            LEFT JOIN (
            SELECT
                    tab1.totalPurchasesIn as tcpIn,
                    tab2.totalSales AS tcpOut,
                    tab3.totalRefilIn AS trpIn,
                    tab4.totalRefilOut AS trpOut,
                    tab5.totalcustomerCylinderIn AS tccIn,
                    tab6.totalcustomerCylinderOut AS tccOut,
                    p.product_id,
                    p.productName,
                    b.brandName AS brandName,
              b.brandId
            FROM
                    product p
            LEFT JOIN brand b ON b.brandId = p.brand_id
            LEFT JOIN(
                    SELECT
                            SUM(s1.quantity)AS totalPurchasesIn,
                            s1.product_id
                    FROM
                            stock s1
                    WHERE
                            s1.type = 'In'
                    AND s1.category_id = 1
                    AND s1.dist_id = '$distId'
                            AND s1.date >='$fromDate'  AND s1.date <='$todate'
                    GROUP BY
                            s1.product_id
            )AS tab1 ON tab1.product_id = p.product_id
            LEFT JOIN(
                    SELECT
                            SUM(s2.quantity)AS totalSales,
                            s2.product_id
                    FROM
                            stock s2
                    WHERE
                            s2.type = 'Out'
                    AND s2.category_id = 1
                    AND s2.dist_id = '$distId'
                            AND s2.date >='$fromDate'  AND s2.date <='$todate'
                    GROUP BY
                            s2.product_id
            )AS tab2 ON tab2.product_id = p.product_id
            LEFT JOIN(
                    SELECT
                            SUM(s3.quantity)AS totalRefilIn,
                            s3.product_id
                    FROM
                            stock s3
                    WHERE
                            s3.type = 'In'
                    AND s3.category_id = 2
                    AND s3.dist_id = '$distId'
                            AND s3.date >='$fromDate'  AND s3.date <='$todate'
                    GROUP BY
                            s3.product_id
            )AS tab3 ON tab3.product_id = p.product_id
            LEFT JOIN(
                    SELECT
                            SUM(s4.quantity)AS totalRefilOut,
                            s4.product_id
                    FROM
                            stock s4
                    WHERE
                            s4.type = 'Out'
                    AND s4.category_id = 2
                    AND s4.dist_id = '$distId'
                            AND s4.date >='$fromDate'  AND s4.date <='$todate'
                    GROUP BY
                            s4.product_id
            )AS tab4 ON tab4.product_id = p.product_id
            LEFT JOIN(
                    SELECT
                            SUM(s5.quantity)AS totalcustomerCylinderIn,
                            s5.product_id
                    FROM
                            stock s5
                    WHERE
                            s5.type = 'Cin'
                    AND s5.category_id = 2
                    AND s5.customerId IS NOT NULL
                    AND s5.dist_id = '$distId'
                            AND s5.date >='$fromDate'  AND s5.date <='$todate'
                    GROUP BY
                            s5.product_id
            )AS tab5 ON tab5.product_id = p.product_id
            LEFT JOIN(
                    SELECT
                            SUM(s6.quantity)AS totalcustomerCylinderOut,
                            s6.product_id
                    FROM
                            stock s6
                    WHERE
                            s6.type = 'Cout'
                    AND s6.category_id = 2
                    AND s6.customerId IS NOT NULL
                    AND s6.dist_id = '$distId'
                            AND s6.date >='$fromDate'  AND s6.date <='$todate'
                    GROUP BY
                            s6.product_id
            )AS tab6 ON tab6.product_id = p.product_id
            GROUP BY
                    p.product_id
            ORDER BY
                    b.brandName ASC
            ) AS detailsTable
            ON detailsTable.brandId = oriBrand.brandId $sql";
        $query = $this->db->query($query);
        $allResult = $query->result();
        return $allResult;
    }

    public function getCylinderTypeReportUpdate($customerId, $groupId, $dist_id, $from_date, $to_date) {

        if ($customerId == 'all' && $groupId == 'all') {
            $all = 'GROUP BY s.customerId,p.product_type_id';
            $all2 = 'GROUP BY c.customer_id,pt.product_type_id';
        } else if ($customerId == 'all' && $groupId != 'all') {
            $all = 'AND p.product_type_id = ' . $groupId . ' GROUP BY s.customerId';
            $all2 = 'WHERE pt.product_type_id = ' . $groupId . ' GROUP BY c.customer_id';
        } else if ($customerId != 'all' && $groupId == 'all') {
            $all = 'AND  s.customerId=' . $customerId . ' GROUP BY p.product_type_id';
            $all2 = 'WHERE c.customer_id   =' . $customerId . ' GROUP BY pt.product_type_id';
        } else {



            $all = 'AND s.customerId =' . $customerId . ' AND p.product_type_id=' . $groupId;
            $all2 = 'WHERE c.customer_id =' . $customerId . ' AND pt.product_type_id=' . $groupId;
        }


        $sql = "SELECT
  c.customerName,
  pt.product_type_name,

	IFNULL(tab1.totalStockIn, 0)- IFNULL(tab2.totalStockOut, 0)AS balance,
  tab3.currentStockIn,
  tab4.currentStockOut,
  ((IFNULL(tab1.totalStockIn, 0)- IFNULL(tab2.totalStockOut, 0)) + IFNULL(tab3.currentStockIn,0) + IFNULL(tab4.currentStockOut,0)) AS finalStock,
  tab1.totalStockIn AS openingIn,
	tab2.totalStockOut AS openingOut,
	c.customer_id,
	pt.product_type_id
FROM
	stock AS s
LEFT JOIN customer AS c ON c.customer_id = s.customerId
LEFT JOIN product AS p ON p.product_id = s.product_id
LEFT JOIN product_type AS pt ON p.product_type_id = pt.product_type_id
LEFT JOIN(
	SELECT
		sum(s.quantity)AS totalStockIn,
		c.customerName,
		pt.product_type_name,
		c.customer_id,
		p.product_type_id
	FROM
		stock AS s
	LEFT JOIN customer AS c ON c.customer_id = s.customerId
	LEFT JOIN product AS p ON p.product_id = s.product_id
	LEFT JOIN product_type AS pt ON p.product_type_id = pt.product_type_id
	WHERE
		s.type = 'Cin'
	AND s.date < '$from_date'
	AND s.dist_id = '$dist_id'
$all
	ORDER BY
		c.customerName
)AS tab1
ON tab1.product_type_id = pt.product_type_id
AND tab1.customer_id = c.customer_id
LEFT JOIN(
	SELECT
		sum(s.quantity)AS totalStockOut,
		c.customerName,
		pt.product_type_name,
		c.customer_id,
		pt.product_type_id
	FROM
		stock AS s
	LEFT JOIN customer AS c ON c.customer_id = s.customerId
	LEFT JOIN product AS p ON p.product_id = s.product_id
	LEFT JOIN product_type AS pt ON p.product_type_id = pt.product_type_id
	WHERE
		s.type = 'Cout'
	AND s.date < '$from_date'
	AND s.dist_id = '$dist_id'
	$all
	ORDER BY
		c.customerName
)AS tab2
ON tab2.customer_id = c.customer_id
AND tab2.product_type_id = pt.product_type_id

LEFT JOIN(
	SELECT
		sum(s.quantity)AS currentStockIn,
		c.customerName,
		pt.product_type_name,
		c.customer_id,
		pt.product_type_id
	FROM
		stock AS s
	LEFT JOIN customer AS c ON c.customer_id = s.customerId
	LEFT JOIN product AS p ON p.product_id = s.product_id
	LEFT JOIN product_type AS pt ON p.product_type_id = pt.product_type_id
	WHERE
		s.type = 'Cin'
	AND s.date >= '$from_date'
  AND s.date <= '$to_date'
	AND s.dist_id = '$dist_id'
	$all
	ORDER BY
		c.customerName
)AS tab3
ON tab3.customer_id = c.customer_id
AND tab3.product_type_id = pt.product_type_id
LEFT JOIN(
	SELECT
		sum(s.quantity)AS currentStockOut,
		c.customerName,
		pt.product_type_name,
		c.customer_id,
		pt.product_type_id
	FROM
		stock AS s
	LEFT JOIN customer AS c ON c.customer_id = s.customerId
	LEFT JOIN product AS p ON p.product_id = s.product_id
	LEFT JOIN product_type AS pt ON p.product_type_id = pt.product_type_id
	WHERE
		s.type = 'Cout'
	AND s.date >= '$from_date'
  AND s.date <= '$to_date'
	AND s.dist_id = '$dist_id'
	$all
	ORDER BY
		c.customerName
)AS tab4
ON tab4.customer_id = c.customer_id
AND tab4.product_type_id = pt.product_type_id
$all2

ORDER BY
	c.customerName,
	pt.product_type_name ASC";

        return $this->db->query($sql)->result();
    }

    public function getPublicBrand($distId) {
        $this->db->select("*");
        $this->db->from("brand");
        $this->db->group_start();
        $this->db->where('dist_id', $distId);
        $this->db->or_where('dist_id', 1);
        $this->db->group_end();
        $this->db->order_by('brandName', 'ASE');
        $getProductList = $this->db->get()->result();
        return $getProductList;
    }

    public function getCylinderTypeReport() {
        $sql = '';
        if ($catId != 'All' && $brandId == 'All'):
            if ($stockType == 1) :
                $sql = 'WHERE  p.category_id =1 AND   AND p.category_id=' . $catId;
            else:
                $sql = 'WHERE  p.category_id !=1 AND p.category_id=' . $catId;
            endif; //inner if end
        elseif ($catId == 'All' && $brandId != 'All'):
            if ($stockType == 1):
                $sql = 'WHERE p.category_id =1 AND p.brand_id=' . $brandId;
            else:
                $sql = 'WHERE p.category_id !=1 AND p.brand_id=' . $brandId;
            endif; //inner if end
        elseif ($catId != 'All' && $brandId != 'All'):
            if ($stockType == 1):
                $sql = 'WHERE  p.category_id =1 AND p.brand_id= ' . $brandId . ' AND p.category_id=' . $catId;
            else:
                $sql = 'WHERE  p.category_id !=1 AND p.brand_id= ' . $brandId . ' AND p.category_id=' . $catId;
            endif; //inner if end
        else:
            if ($stockType == 1):
                $sql = 'WHERE p.category_id =1';
            else:
                $sql = 'WHERE p.category_id !=1';
            endif; //inner if end
        endif;
        $query = "SELECT c.title as pCateogry,p.product_id,p.productName,p.product_code,b.brandName,tab1.product_id,
tab1.opStockIn,
tab2.opStockOut ,
tab3.opStockIn as currentStockIn,
tab4.opStockOut as currentStockOut ,
tab5.avgPurPrice,
tab6.avgSalePrice
FROM product p
LEFT JOIN
brand b ON b.brandId=p.brand_id
LEFT JOIN
productcategory c ON c.category_id=p.category_id
left JOIN
	(SELECT SUM(s.quantity) as opStockIn,s.product_id ,s.type
	 FROM stock s
	WHERE s.date < '$fromDate'
	AND s.type='In'
        AND s.dist_id='$distId'
	GROUP BY s.product_id ) tab1
ON tab1.product_id=p.product_id
left JOIN
	(SELECT SUM(s1.quantity) as opStockOut,s1.product_id
	 FROM stock s1
	WHERE s1.date < '$fromDate'
	AND s1.type='Out'
        AND s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab2
ON tab2.product_id=p.product_id
LEFT JOIN
(SELECT SUM(s.quantity) as opStockIn,s.product_id ,s.type
	 FROM stock s
	WHERE s.date >='$fromDate'  AND s.date <='$todate'
	AND s.type='In'
        AND s.dist_id='$distId'
	GROUP BY s.product_id ) tab3
ON tab3.product_id=p.product_id
LEFT JOIN
	(SELECT SUM(s1.quantity) as opStockOut,s1.product_id
	 FROM stock s1
	WHERE s1.date >='$fromDate'  AND s1.date <='$todate'
	AND s1.type='Out'
        AND s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab4
ON tab4.product_id=p.product_id
LEFT JOIN
	(SELECT SUM(s1.price)/SUM(s1.quantity) as avgPurPrice,s1.product_id
	 FROM stock s1
	WHERE s1.type='In'
        AND  s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab5
ON tab5.product_id=p.product_id
LEFT JOIN
	(SELECT SUM(s1.price)/SUM(s1.quantity) as avgSalePrice,s1.product_id
	 FROM stock s1
	WHERE s1.type='Out'
        AND  s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab6
ON tab6.product_id=p.product_id
        $sql  GROUP BY p.product_id";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    public function getStock($distId, $fromDate, $todate, $catId, $brandId) {
        $sql = '';
        if ($catId != 'All' && $brandId == 'All'):
            $sql = 'WHERE   p.category_id=' . $catId;
        elseif ($catId == 'All' && $brandId != 'All'):
            $sql = 'WHERE  p.brand_id=' . $brandId;
        elseif ($catId != 'All' && $brandId != 'All'):
            $sql = 'WHERE  p.brand_id= ' . $brandId . ' AND p.category_id=' . $catId;

        else:
//CONDITION WILL COME HERE.
        endif;
        $query = "
            SELECT
	c.title AS pCateogry,
        u.unitTtile as unit,
	p.product_id,
	p.productName,
	p.product_code,
	b.brandName,
	tab1.product_id,
	tab1.opStockIn,
        tab1.opBundleIn,
        tab2.opBundleOut,
        tab3.purchasesBundleIn,
        tab4.salesBundleOut,
	tab2.opStockOut,
         (IFNULL(tab1.opBundleIn,0) - IFNULL(tab2.opBundleOut,0)) AS totalOpeningBundle,
         (((IFNULL(tab1.opBundleIn, 0)- IFNULL(tab2.opBundleOut, 0)) + IFNULL(tab3.purchasesBundleIn,0)) - IFNULL(tab4.salesBundleOut,0)) AS closingBundleStock,
   (IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)) AS totalOpeningQty,
	 IFNULL(tab1.openingStockPrice, 0) / IFNULL(tab1.opStockIn,0) AS openingAvgPrice,
   ((IFNULL(tab1.openingStockPrice, 0) / IFNULL(tab1.opStockIn,0)) * ((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)))) as totalOpeningPrice,
	 IFNULL(tab3.purchasesStockIn,0) AS totalPurchasesQty,
   (IFNULL(tab3.purchasesPrice,0) / IFNULL(tab3.purchasesStockIn,0)) AS purchasesAvgPrice,
	(((IFNULL(tab3.purchasesPrice,0) / IFNULL(tab3.purchasesStockIn,0))) * IFNULL(tab3.purchasesStockIn,0)) AS totalPurchasesPrice,
	IFNULL(tab4.salesStockOut,0) AS totalSalesQty,
  IFNULL(tab4.salesPrice,0)/IFNULL(tab4.salesStockOut,0) AS salesAvgPrice,
(IFNULL(tab4.salesPrice,0)/IFNULL(tab4.salesStockOut,0) * IFNULL(tab4.salesStockOut,0)) AS totalSalePrice,
 (IFNULL(tab3.purchasesStockIn,0) - IFNULL(tab4.salesStockOut,0)) AS currentStock,
IFNULL((IFNULL((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)),0) + IFNULL(tab3.purchasesStockIn,0)),0) AS closingForAvgCal,
 ((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)) + (IFNULL(tab3.purchasesStockIn,0) - IFNULL(tab4.salesStockOut,0))) AS totalClosingQty,
IFNULL((IFNULL(((IFNULL(tab1.openingStockPrice, 0) / IFNULL(tab1.opStockIn,0)) * ((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)))),0)
   + IFNULL((((IFNULL(tab3.purchasesPrice,0) / IFNULL(tab3.purchasesStockIn,0))) * IFNULL(tab3.purchasesStockIn,0)),0)),0) / IFNULL((IFNULL((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)),0) + IFNULL(tab3.purchasesStockIn,0)),0) as closingAvgPrice,

(IFNULL((IFNULL(((IFNULL(tab1.openingStockPrice, 0) / IFNULL(tab1.opStockIn,0)) * ((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)))),0)
   + IFNULL((((IFNULL(tab3.purchasesPrice,0) / IFNULL(tab3.purchasesStockIn,0))) * IFNULL(tab3.purchasesStockIn,0)),0)),0) / IFNULL((IFNULL((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)),0) + IFNULL(tab3.purchasesStockIn,0)),0)) * ((IFNULL(tab1.opStockIn,0) - IFNULL(tab2.opStockOut,0)) + (IFNULL(tab3.purchasesStockIn,0) - IFNULL(tab4.salesStockOut,0))) as totalClosingPrice

FROM product p
LEFT JOIN brand b ON b.brandId=p.brand_id
LEFT JOIN unit u ON u.unit_id=p.unit_id
LEFT JOIN
productcategory c ON c.category_id=p.category_id
left JOIN
	(SELECT SUM(s.quantity) as opStockIn,SUM(s.bundle) as opBundleIn,SUM(s.price) AS openingStockPrice, s.product_id ,s.type
	 FROM stock s
	WHERE s.date < '$fromDate'
	AND (s.type='In'
        AND s.dist_id='$distId')
OR (s.openingStatus ='1' AND s.dist_id = '$distId')
	GROUP BY s.product_id ) tab1
ON tab1.product_id=p.product_id
left JOIN
	(SELECT
		SUM(s1.bundle)AS opBundleOut,
SUM(s1.quantity)AS opStockOut,
s1.product_id
	 FROM stock s1
	WHERE s1.date < '$fromDate'
	AND s1.type='Out'

        AND s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab2
ON tab2.product_id=p.product_id
LEFT JOIN
(SELECT
		SUM(s.bundle)AS purchasesBundleIn,SUM(s.quantity)AS purchasesStockIn,sum(s.price) AS purchasesPrice,
		s.product_id,
		s.type
	 FROM stock s
	WHERE s.date >='$fromDate'  AND s.date <='$todate'
	AND s.type='In'
        AND s.dist_id='$distId'
        AND s.openingStatus !='1'
	GROUP BY s.product_id ) tab3
ON tab3.product_id=p.product_id
LEFT JOIN
	(SELECT
		SUM(s1.bundle)AS salesBundleOut,SUM(s1.quantity)AS salesStockOut,SUM(s1.price)AS salesPrice,
		s1.product_id
	 FROM stock s1
	WHERE s1.date >='$fromDate'  AND s1.date <='$todate'
	AND s1.type='Out'
        AND s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab4
ON tab4.product_id=p.product_id
LEFT JOIN
	(SELECT
		SUM(s1.price)/ SUM(s1.quantity)AS avgPurPrice,
		s1.product_id
	 FROM stock s1
	WHERE s1.type='In'
        AND  s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab5
ON tab5.product_id=p.product_id
LEFT JOIN
	(SELECT SUM(s1.price)/SUM(s1.quantity) as avgSalePrice,s1.product_id
	 FROM stock s1
	WHERE s1.type='Out'
        AND s1.date >='$fromDate'  AND s1.date <='$todate'
        AND  s1.dist_id='$distId'
	GROUP BY s1.product_id )
tab6
ON tab6.product_id=p.product_id
        $sql  GROUP BY p.product_id HAVING totalOpeningQty > 0 || totalPurchasesQty > 0 || totalSalesQty > 0 || totalClosingQty > 0";
        $query = $this->db->query($query);
        $result = $query->result();

        // echo $this->db->last_query();die;

        return $result;
    }

    public function getCusSupProductSummary($type, $cusSumId, $productId, $fromDate, $todate, $distId) {
        if ($productId == 'all') {
            $pSql = 'GROUP BY p.product_id';
        } else {
            $pSql = 'WHERE  p.product_id=' . $productId;
        }
        if ($type == 2) {
            if ($productId == 'all') {
                $sql = 'AND  s.dist_id=' . $distId . ' AND s.customerId=' . $cusSumId . ' GROUP BY s.product_id';
            } else {
                $sql = 'AND  s.dist_id=' . $distId . ' AND s.customerId=' . $cusSumId . ' AND s.product_id=' . $productId;
            }
        } else {
            if ($productId == 'all') {
                $sql = 'AND  s.dist_id=' . $distId . ' AND s.supplierId=' . $cusSumId . ' GROUP BY s.product_id';
            } else {
                $sql = 'AND  s.dist_id=' . $distId . ' AND s.supplierId=' . $cusSumId . ' AND s.product_id=' . $productId;
            }
        }
        $query = "SELECT p.product_id,p.productName,p.product_code,b.brandName,tab1.product_id,
tab1.opStockIn,
tab2.opStockOut,
tab3.currentStockIn,
tab4.currentStockOut
FROM product p
LEFT JOIN
brand b ON b.brandId=p.brand_id
left JOIN
	(SELECT SUM(s.quantity) as opStockIn,s.product_id ,s.type
	 FROM stock s
	 WHERE s.date < '$fromDate'
	AND s.type='Cin'
        $sql) tab1
ON tab1.product_id=p.product_id
left JOIN
	(SELECT SUM(s.quantity) as opStockOut,s.product_id ,s.type
	 FROM stock s
	 WHERE s.date < '$fromDate'
	AND s.type='Cout'
        $sql)
tab2
ON tab2.product_id=p.product_id
LEFT JOIN
(SELECT SUM(s.quantity) as currentStockIn,s.product_id ,s.type
	 FROM stock s
	 WHERE s.date >= '$fromDate'
	 AND s.date <= '$todate'
	AND s.type='Cin'
        $sql)
tab3
ON tab3.product_id=p.product_id
LEFT JOIN
	(SELECT SUM(s.quantity) as currentStockOut,s.product_id ,s.type
	 FROM stock s
	 WHERE s.date >= '$fromDate'
	 AND s.date <= '$todate'
	AND s.type='Cout'
       $sql)
tab4
ON tab4.product_id=p.product_id
         $pSql";
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

    public function checkOpenigValid($distId) {
        $this->db->select("sum(credit) as totalAmount");
        $this->db->from("opening_balance");
        $this->db->where('dist_id', $distId);
        $result = $this->db->get()->row();
        if (!empty($result->totalAmount)):
            return $result->totalAmount;
        else:
            return 0;
        endif;
    }

    public function getProductLedger($fromDate, $toDate, $productId, $distId) {
        $this->db->select("generals.voucher_no,stock.type,stock.bundle,brand.brandName,productcategory.title,product.productName,product.product_code,stock.quantity,stock.date,customer.customerName,supplier.supName");
        $this->db->from("stock");
        $this->db->join('generals', 'generals.generals_id=stock.generals_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id=stock.category_id', 'left');
        $this->db->join('product', 'product.product_id=stock.product_id', 'left');
        $this->db->join('supplier', 'supplier.sup_id=generals.supplier_id', 'left');
        $this->db->join('customer', 'customer.customer_id=generals.customer_id', 'left');
        $this->db->join('brand', 'brand.brandId=product.brand_id', 'left');
        $this->db->where('stock.dist_id', $distId);
        if (!empty($productId) && $productId != 'all') {
            $this->db->where('stock.product_id', $productId);
        }
        $this->db->where('stock.date >=', $fromDate);
        $this->db->where('stock.date <=', $toDate);
        $this->db->where('stock.form_id !=', 10);
        $this->db->order_by('stock.date', 'asc');
        $this->db->where_in('stock.type', array('In', 'Out'));
        $ledgerReport = $this->db->get()->result();
        return $ledgerReport;
    }

    public function getProductLedgerOpening($fromDate, $toDate, $productId, $distId) {
        $this->db->select("sum(stock.quantity) as totalIn,sum(stock.bundle) as totalBundle");
        $this->db->from("stock");
        $this->db->where('stock.dist_id', $distId);
        if (!empty($productId) && $productId != 'all') {
            $this->db->where('stock.product_id', $productId);
        }
        $this->db->where('stock.date <', $fromDate);
        $this->db->where('stock.form_id !=', 10);
        $this->db->where('stock.type', 'In');
        $ledgerIn = $this->db->get()->row();

        $this->db->select("sum(stock.quantity) as totalOut");
        $this->db->from("stock");
        $this->db->where('stock.dist_id', $distId);
        if (!empty($productId) && $productId != 'all') {
            $this->db->where('stock.product_id', $productId);
        }
        $this->db->where('stock.date <', $fromDate);
        $this->db->where('stock.form_id !=', 10);
        $this->db->where('stock.type', 'Out');
        $ledgerOut = $this->db->get()->row();
        return $ledgerIn->totalIn - $ledgerOut->totalOut;
    }

    public function getProductLedgerOpeningBundle($fromDate, $toDate, $productId, $distId) {
        $this->db->select("sum(stock.bundle) as totalBundle");
        $this->db->from("stock");
        $this->db->where('stock.dist_id', $distId);
        if (!empty($productId) && $productId != 'all') {
            $this->db->where('stock.product_id', $productId);
        }
        $this->db->where('stock.date <', $fromDate);
        $this->db->where('stock.form_id !=', 10);
        $this->db->where('stock.type', 'In');
        $ledgerIn = $this->db->get()->row();

        $this->db->select("sum(stock.bundle) as totalOut");
        $this->db->from("stock");
        $this->db->where('stock.dist_id', $distId);
        if (!empty($productId) && $productId != 'all') {
            $this->db->where('stock.product_id', $productId);
        }
        $this->db->where('stock.date <', $fromDate);
        $this->db->where('stock.form_id !=', 10);
        $this->db->where('stock.type', 'Out');
        $ledgerOut = $this->db->get()->row();
        return $ledgerIn->totalBundle - $ledgerOut->totalOut;
    }

    public function checkProductFormate($productFormate, $disttId) {
        $this->db->select("*");
        $this->db->from("product");
        $this->db->where('category_id', $productFormate[1]);
        $this->db->where('product_id', $productFormate[2]);
        $this->db->group_start();
        $this->db->where('dist_id', $disttId);
        $this->db->or_where('dist_id', 1);
        $this->db->group_end();
        $exits = $this->db->get()->row();
        if (!empty($exits)):
            return TRUE;
        else:
            return FALSE;
        endif;
    }

    function getPaymentDueSupplierCustomer($distId, $supCus) {
        if ($supCus == 1) {
            $sql = "SELECT tab.customerName,sum(dueAmount) as dueCustomer,tab.customer_id FROM (SELECT c.customer_id,CONCAT(c.customerID,' [ ',c.customerName,' ] ') AS customerName,g.voucher_no,g.date,iam.invoiceamount,pam.paidAmount,(IFNULL(iam.invoiceamount,0) - IFNULL(pam.paidAmount,0)) AS dueAmount FROM customer as c
left JOIN generals as g ON c.customer_id=g.customer_id
LEFT JOIN (select sum(g.debit) as invoiceamount,g.customer_id,g.voucher_no from generals as g WHERE form_id=5 GROUP BY g.voucher_no,g.customer_id) AS iam on iam.customer_id=c.customer_id AND g.voucher_no = iam.voucher_no
LEFT JOIN (select sum(g.credit) as paidAmount,g.customer_id,g.voucher_no from generals as g WHERE form_id=7 GROUP BY g.voucher_no,g.customer_id) AS pam on pam.customer_id=c.customer_id AND g.voucher_no = pam.voucher_no
WHERE g.dist_id ='$distId'
GROUP BY c.customer_id,g.voucher_no
HAVING dueAmount > 0 ) as tab
GROUP BY tab.customer_id";
            $result = $this->db->query($sql)->result();
            return $result;
        } else {
            $sql = "SELECT tab.supName,sum(dueAmount) as dueCustomer,tab.sup_id FROM (SELECT g.generals_id,s.sup_id,CONCAT(s.supID,' [ ',s.supName,' ] ') AS supName,g.voucher_no,g.date,iam.invoiceamount,pam.paidAmount,(IFNULL(iam.invoiceamount,0) - IFNULL(pam.paidAmount,0)) AS dueAmount FROM supplier as s
left JOIN generals as g ON s.sup_id=g.supplier_id
LEFT JOIN ( select sum(g.debit) as invoiceamount,g.supplier_id,g.voucher_no from generals as g WHERE g.form_id=11 GROUP BY g.voucher_no,g.supplier_id) AS iam on iam.supplier_id=s.sup_id AND g.voucher_no = iam.voucher_no
LEFT JOIN ( select sum(g.credit) as paidAmount,g.supplier_id,g.voucher_no from generals as g WHERE g.form_id=14 GROUP BY g.voucher_no,g.supplier_id) AS pam on pam.supplier_id=s.sup_id AND g.voucher_no = pam.voucher_no
WHERE s.dist_id='$distId'
GROUP BY s.sup_id,g.voucher_no
HAVING dueAmount > 0) as tab
GROUP BY tab.sup_id";
            $result = $this->db->query($sql)->result();
            return $result;
        }
    }

    function getCylinderLedger($distId, $fromDate, $toDate) {
        $this->db->select("generals.voucher_no,stock.type,brand.brandName,productcategory.title,product.productName,product.product_code,stock.quantity,stock.date,customer.customerName,supplier.supName");
        $this->db->from("stock");
        $this->db->join('generals', 'generals.generals_id=stock.generals_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id=stock.category_id', 'left');
        $this->db->join('product', 'product.product_id=stock.product_id', 'left');
        $this->db->join('supplier', 'supplier.sup_id=generals.supplier_id', 'left');
        $this->db->join('customer', 'customer.customer_id=generals.customer_id', 'left');
        $this->db->join('brand', 'brand.brandId=product.brand_id', 'left');
        $this->db->where('stock.dist_id', $distId);
        $this->db->where('stock.date >=', $fromDate);
        $this->db->where('stock.date <=', $toDate);
        $this->db->where('stock.form_id !=', 10);
        $this->db->order_by('stock.date', 'asc');
        $this->db->where_in('stock.type', array('Cin', 'Cout'));
        $ledgerReport = $this->db->get()->result();
        return $ledgerReport;
    }

    function getSupplierClosingBalance($distId, $supplierId) {
        $this->db->select("sum(dr) - sum(cr) as totalCurrentBalance");
        $this->db->from("client_vendor_ledger");
        $this->db->where('dist_id', $distId);
        $this->db->where('ledger_type', 2);
        $this->db->where('client_vendor_id', $supplierId);
        $result = $this->db->get()->row();
        return $result->totalCurrentBalance;
    }

    function getPurchasesList() {
        $this->db->select("form.name,generals.generals_id,generals.voucher_no,generals.narration,generals.date,generals.debit,supplier.supID,supplier.supName,supplier.sup_id,supplier.sup_id");
        $this->db->from("generals");
        $this->db->join('supplier', 'supplier.sup_id=generals.supplier_id');
        $this->db->join('form', 'form.form_id=generals.form_id');
        $this->db->where('generals.dist_id', $this->dist_id);
        $this->db->where('generals.form_id', 11);
        $this->db->order_by('generals.date', 'desc');
        $result = $this->db->get()->result();
        return $result;
    }

    function getCreditAmount($invoiceId) {
        $this->db->select("credit,generals_id,");
        $this->db->from("generals");
        $this->db->where("mainInvoiceId", $invoiceId);
        $this->db->where("form_id", 14);
        $this->db->where('dist_id', $this->dist_id);
        $creditAmount = $this->db->get()->row();
        if (!empty($creditAmount)) {
            return $creditAmount;
        }
    }

    function getPurchasesAccountId($invoiceId) {
        $this->db->select("account");
        $this->db->from("generalledger");
        $this->db->where("generals_id", $invoiceId);
        $this->db->where("form_id", 14);
        $this->db->where("credit >=", '1');
        $this->db->where('dist_id', $this->dist_id);
        $this->db->order_by('generalledger_id', 'ASC');
        $creditAccount = $this->db->get()->row();

        if (!empty($creditAccount->account)) {
            return $creditAccount->account;
        }
    }

    function getReturnAbleCylinder($distId, $invoiceId, $productId) {
        $this->db->select("generals_id");
        $this->db->from("generals");
        $this->db->where("dist_id", $distId);
        //form Id 24 means cylinder receive,form Id 23 means cylinder out
        $this->db->where("form_id", 24);
        $this->db->where("mainInvoiceId", $invoiceId);
        $generalId = $this->db->get()->row();
        if (!empty($generalId)) {
            $this->db->select('stock.quantity');
            $this->db->from('stock');
            $this->db->join('productcategory', 'stock.category_id = productcategory.category_id');
            $this->db->join('product', 'stock.product_id = product.product_id');
            $this->db->join('unit', 'stock.unit = unit.unit_id');
            $this->db->join('brand', 'product.brand_id = brand.brandId');
            $this->db->where('stock.dist_id', $distId);
            $this->db->where('stock.type', 'Cin');
            $this->db->where('stock.product_id', $productId);
            //type 24 means cylinder receive,type 23 means cylinder out
            $this->db->where('stock.form_id', 24);
            $this->db->where('stock.generals_id', $generalId->generals_id);
            $cylinderInOutResult = $this->db->get()->row();
            return $cylinderInOutResult;
        }
    }

    function getReturnAbleCylinder2($distId, $invoiceId, $productId) {
        $this->db->select("quantity");
        $this->db->from("stock");
        $this->db->where("dist_id", $distId);
        //form Id 24 means cylinder receive,form Id 23 means cylinder out
        $this->db->where("form_id", 24);
        $this->db->where("product_id", $productId);
        $this->db->where("generals_id", $invoiceId);
        $generalId = $this->db->get()->row();
        return $generalId;
//        if (!empty($generalId)) {
//            $this->db->select('stock.quantity');
//            $this->db->from('stock');
//            $this->db->join('productcategory', 'stock.category_id = productcategory.category_id');
//            $this->db->join('product', 'stock.product_id = product.product_id');
//            $this->db->join('unit', 'stock.unit = unit.unit_id');
//            $this->db->join('brand', 'product.brand_id = brand.brandId');
//            $this->db->where('stock.dist_id', $distId);
//            $this->db->where('stock.type', 'Cin');
//            $this->db->where('stock.product_id', $productId);
//            //type 24 means cylinder receive,type 23 means cylinder out
//            $this->db->where('stock.form_id', 24);
//            $this->db->where('stock.generals_id', $generalId->generals_id);
//            $cylinderInOutResult = $this->db->get()->row();
//            return $cylinderInOutResult;
//        }
    }

    function getVoucherIdByGeneralId($generalId) {
        $voucehrInfo = $this->db->get_where('generals', array('generals_id' => $generalId))->row();
        if (!empty($voucehrInfo)) {
            return $voucehrInfo->voucher_no;
        } else {
            return 0;
        }
    }

    function getCustomerOrSupplierIdByGeneralId($generalId) {
        $voucherInfo = $this->db->get_where('generals', array('generals_id' => $generalId))->row();
        if (!empty($voucherInfo->customer_id)) {
            $customerInfo = $this->db->get_where('customer', array('customer_id' => $voucherInfo->customer_id))->row();
            if (!empty($customerInfo)) {
                return $customerInfo->customerID . ' [ ' . $customerInfo->customerName . ' ] ';
            } else {
                return 0;
            }
        } elseif (!empty($voucherInfo->supplier_id)) {
            $supplierInfo = $this->db->get_where('supplier', array('sup_id' => $voucherInfo->supplier_id))->row();
            if (!empty($supplierInfo)) {
                return $supplierInfo->supID . ' [ ' . $supplierInfo->supName . ' ] ';
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    function getProductSummationReport($dist_id, $productid, $startDate, $endDate) {
        $this->db->select("sum(stock.bundle) AS totalBundle,sum(stock.quantity) as totalQty,avg(stock.rate) as totalAvgRate,product.productName,brand.brandName");
        $this->db->from("stock");
        $this->db->join('product', 'product.product_id=stock.product_id');
        $this->db->join('brand', 'brand.brandId=product.brand_id');
        //$this->db->join('supplier', 'supplier.sup_id=generals.supplier_id');
        $this->db->where("stock.product_id", $productid);
        $this->db->where("stock.type", "In");
        $this->db->where('stock.date >=', $startDate);
        $this->db->where('stock.date <=', $endDate);
        $this->db->where("stock.dist_id", $dist_id);
        $totalStockIn = $this->db->get()->row();
        return $totalStockIn;
    }

    function getProductWiseSalesReport($dist_id, $productid, $startDate, $endDate) {
        $this->db->select("*");
        $this->db->from("stock");
        //$this->db->join('generals', 'generals.generals_id=stock.generals_id');
        //$this->db->join('supplier', 'supplier.sup_id=generals.supplier_id');
        $this->db->where("stock.product_id", $productid);
        $this->db->where("stock.type", "In");
        $this->db->where('stock.date >=', $startDate);
        $this->db->where('stock.date <=', $endDate);
        $this->db->where("stock.dist_id", $dist_id);
        $totalStockIn = $this->db->get()->result();
        return $totalStockIn;
    }

    function generals_supplier($supplier_id) {
        $query = $this->db->get_where('generals', array('form_id' => 11, 'supplier_id' => $supplier_id));
        return $query->result_array();
    }

    function generals_voucher($voucher_no) {
        $dr = '';
        $cr = '';
        $query = $this->db->get_where('generals', array('voucher_no' => $voucher_no, 'dist_id' => $this->dist_id))->result_array();
        foreach ($query as $row) {
            $dr += $row['debit'];
            $cr += $row['credit'];
        }
        $bal = $dr - $cr;
        return $bal;
    }

    public function getStockReport($startDate, $endDate, $productid, $brandId, $distributor = null) {
        if (!empty($distributor)):
            $distID = $distributor;
        else:
            $distID = $this->dist_id;
        endif;
        //openingStock
        $this->db->select('avg(stock.rate) totalAvgSalesPrice');
        $this->db->from('stock');
        $this->db->join('product', 'stock.product_id = product.product_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id = stock.category_id', 'left');
        $this->db->where('stock.type', 'Out');
        $this->db->where('stock.dist_id', $distID);
        if ($brandId != 'All') {
            $this->db->where('product.brand_id', $brandId);
        }
        $this->db->where('stock.product_id', $productid);
        $this->db->order_by('stock.category_id', 'ASC');
        $openingAvgSalesPrice = $this->db->get()->row_array();
        $data['totalAvgSalesPrice'] = $openingAvgSalesPrice['totalAvgSalesPrice'];
        $this->db->select('avg(stock.rate) totalAvgPusPrice');
        $this->db->from('stock');
        $this->db->join('product', 'stock.product_id = product.product_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id = stock.category_id', 'left');
        $this->db->where('stock.type', 'In');
        if ($brandId != 'All') {
            $this->db->where('product.brand_id', $brandId);
        }
        $this->db->where('stock.dist_id', $distID);
        $this->db->where('stock.product_id', $productid);
        $this->db->order_by('stock.category_id', 'ASC');
        $openingAvgPurcPrice = $this->db->get()->row_array();
        $data['totalAvgPurcPrice'] = $openingAvgPurcPrice['totalAvgPusPrice'];
        $this->db->select('product.product_id,product.category_id,product.productName,product.product_code,productcategory.title as catName,sum(stock.quantity) as totalOpeQty,avg(stock.rate) totalAvgOpePusPrice,');
        $this->db->from('stock');
        $this->db->join('product', 'stock.product_id = product.product_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id = stock.category_id', 'left');
        $this->db->where('stock.type', 'In');
        if ($brandId != 'All') {
            $this->db->where('product.brand_id', $brandId);
        }
        $this->db->where('stock.openingStatus', 1);
        $this->db->where('stock.dist_id', $distID);
        $this->db->where('stock.product_id', $productid);
        $this->db->order_by('stock.category_id', 'ASC');
        $data['mainOpeningStock'] = $this->db->get()->row_array();
        $this->db->select('product.product_id,product.category_id,product.productName,product.product_code,productcategory.title as catName,sum(stock.quantity) as totalOpeQty,avg(stock.rate) totalAvgOpePusPrice,');
        $this->db->from('stock');
        $this->db->join('product', 'stock.product_id = product.product_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id = stock.category_id', 'left');
        $this->db->where('date <', $startDate);
        if ($brandId != 'All') {
            $this->db->where('product.brand_id', $brandId);
        }
        $this->db->where('stock.type', 'In');
        $this->db->where('stock.openingStatus !=', 1);
        $this->db->where('stock.dist_id', $distID);
        $this->db->where('stock.product_id', $productid);
        $this->db->order_by('stock.category_id', 'ASC');
        $data['openingStock'] = $this->db->get()->row_array();
        $this->db->select('avg(stock.rate) as averagePurchasesPrice,product.product_id,product.category_id,product.productName,product.product_code,productcategory.title as catName,sum(stock.quantity) as totalOpeQty,avg(stock.rate) totalAvgOpePusPrice,');
        $this->db->from('stock');
        $this->db->join('product', 'stock.product_id = product.product_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id = stock.category_id', 'left');
        $this->db->where('date <', $startDate);
        if ($brandId != 'All') {
            $this->db->where('product.brand_id', $brandId);
        }
        $this->db->where('stock.type', 'Out');
        $this->db->where('stock.dist_id', $distID);
        $this->db->where('stock.product_id', $productid);
        $this->db->order_by('stock.category_id', 'ASC');
        $data['openingOut'] = $this->db->get()->row_array();
        //purchases stock
        $this->db->select('product.product_id,product.category_id,product.productName,product.product_code,productcategory.title as catName,sum(stock.quantity) as totalPurcQty,avg(stock.rate) totalAvgPusPrice,');
        $this->db->from('stock');
        $this->db->join('product', 'stock.product_id = product.product_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id = stock.category_id', 'left');
        $this->db->where('date >=', $startDate);
        $this->db->where('date <=', $endDate);
        if ($brandId != 'All') {
            $this->db->where('product.brand_id', $brandId);
        }
        $this->db->where('stock.type', 'In');
        $this->db->where('stock.openingStatus !=', 1);
        $this->db->where('stock.dist_id', $distID);
        $this->db->where('stock.product_id', $productid);
        $this->db->order_by('stock.category_id', 'ASC');
        $data['purchasesStock'] = $this->db->get()->row_array();
        //Sale Out
        $this->db->select('product.product_id,product.category_id,product.productName,product.product_code,productcategory.title as catName,sum(stock.quantity) as totalSaleQty,avg(stock.rate) totalAvgSalePusPrice,');
        $this->db->from('stock');
        $this->db->join('product', 'stock.product_id = product.product_id', 'left');
        $this->db->join('productcategory', 'productcategory.category_id = stock.category_id', 'left');
        $this->db->where('date >=', $startDate);
        $this->db->where('date <=', $endDate);
        if ($brandId != 'All') {
            $this->db->where('product.brand_id', $brandId);
        }
        $this->db->where('stock.type', 'Out');
        $this->db->where('stock.dist_id', $distID);
        $this->db->where('stock.product_id', $productid);
        $this->db->order_by('stock.category_id', 'ASC');
        $data['saleStock'] = $this->db->get()->row_array();
        return $data;
    }

    //$type_id, $balance_type, $sub_cus_id, $from_date, $to_date, $this->dist_id
    function getCusSupProductdetails($type_id, $balance_type, $sub_cus_id, $fromDate, $to_date, $distId) {
        $sql = "";
        if ($type_id == 2) {
            //customer
            if ($sub_cus_id != 'all') {
                $sql = "AND subCusTable.customer_id = " . $sub_cus_id;
            }


            $query = "SELECT
                        subCusTable.customer_id,
                        subCusTable.customerID AS subCusId,
                        subCusTable.customerName AS subCusName,
                        s.product_id,
                        s.type,
                        s.quantity,
                        InTable.StockIn,
                        OutTable.StockOut,
                        (
                            InTable.StockIn - OutTable.StockOut
                        ) AS balance,
                        InTable.product_id,
                        productTable.productName,
                        productTable.product_code,
                        productTable.brandName
                    FROM
                        customer subCusTable
                    LEFT JOIN stock s ON
                        s.customerId = subCusTable.customer_id
                                        LEFT JOIN(
                    SELECT p.product_id,
                        p.brand_id,
                        p.category_id,
                        p.productName,
                        p.product_code,
                        b.brandName,
                        pc.title
                    FROM
                        product p
                    LEFT JOIN productcategory pc ON
                        pc.category_id = p.category_id
                    LEFT JOIN brand b ON
                        b.brandId = p.brand_id
                ) AS productTable
                ON
                    productTable.product_id = s.product_id
                    LEFT JOIN(
                        SELECT
                            SUM(s.quantity) AS StockIn,
                            s.product_id,
                            s.type,
                            s.customerId
                        FROM
                            stock s
                        WHERE
                            s.type = 'Cin' AND s.dist_id = " . $distId . "
                        GROUP BY
                            s.product_id,
                            s.customerId
                    ) AS InTable
                    ON
                        InTable.customerId = s.customerId AND InTable.product_id = s.product_id
                    LEFT JOIN(
                        SELECT
                            SUM(s.quantity) AS StockOut,
                            s.product_id,
                            s.type,
                            s.customerId
                        FROM
                            stock s
                        WHERE
                            s.type = 'Cout' AND s.dist_id = " . $distId . "
                        GROUP BY
                            s.product_id,
                            s.customerId
                    ) AS OutTable
                    ON
                        OutTable.customerId = s.customerId AND OutTable.product_id = s.product_id
                    WHERE
                        subCusTable.dist_id = " . $distId . "  " . $sql . " AND  s.date >= '$fromDate' AND s.date <= '$to_date'
                    GROUP BY
                        s.product_id,
                        s.customerId  order  BY subCusTable.customer_id ASC   ";
        } else {

            //customer
            if ($sub_cus_id != 'all') {
                $sql = "AND subCusTable.sup_id = " . $sub_cus_id;
            }


            $query = "SELECT
                        subCusTable.sup_id,
                        subCusTable.supID AS subCusId,
                        subCusTable.supName AS subCusName,
                        s.product_id,
                        s.type,
                        s.quantity,
                        InTable.StockIn,
                        OutTable.StockOut,
                        (
                            InTable.StockIn - OutTable.StockOut
                        ) AS balance,
                        InTable.product_id,
                        productTable.productName,
                        productTable.product_code,
                        productTable.brandName
                    FROM
                        supplier subCusTable
                    LEFT JOIN stock s ON
                        s.supplierId = subCusTable.sup_id
                                        LEFT JOIN(
                    SELECT p.product_id,
                        p.brand_id,
                        p.category_id,
                        p.productName,
                        p.product_code,
                        b.brandName,
                        pc.title
                    FROM
                        product p
                    LEFT JOIN productcategory pc ON
                        pc.category_id = p.category_id
                    LEFT JOIN brand b ON
                        b.brandId = p.brand_id
                ) AS productTable
                ON
                    productTable.product_id = s.product_id
                    LEFT JOIN(
                        SELECT
                            SUM(s.quantity) AS StockIn,
                            s.product_id,
                            s.type,
                            s.supplierId
                        FROM
                            stock s
                        WHERE
                            s.type = 'Cin' AND s.dist_id = " . $distId . "
                        GROUP BY
                            s.product_id,
                            s.supplierId
                    ) AS InTable
                    ON
                        InTable.supplierId = s.supplierId AND InTable.product_id = s.product_id
                    LEFT JOIN(
                        SELECT
                            SUM(s.quantity) AS StockOut,
                            s.product_id,
                            s.type,
                            s.supplierId
                        FROM
                            stock s
                        WHERE
                            s.type = 'Cout' AND s.dist_id = " . $distId . "
                        GROUP BY
                            s.product_id,
                            s.supplierId
                    ) AS OutTable
                    ON
                        OutTable.supplierId = s.supplierId AND OutTable.product_id = s.product_id
                    WHERE
                        subCusTable.dist_id = " . $distId . "  " . $sql . " AND  s.date >= '$fromDate' AND s.date <= '$to_date'
                    GROUP BY
                        s.product_id,
                        s.customerId  order  BY subCusTable.sup_id ASC   ";
        }
        $query = $this->db->query($query);
        $result = $query->result();
        return $result;
    }

}

?>