<?php
if (isset($_POST['start_date'])):
    $type_id = $this->input->post('type_id');
    $customer_id = $this->input->post('customer_id');
    $supplier_id = $this->input->post('supplier_id');
    $searchId = $this->input->post('searchId');
    $groupId = $this->input->post('groupId');
    $from_date = date('Y-m-d', strtotime($this->input->post('start_date')));
    $to_date = date('Y-m-d', strtotime($this->input->post('end_date')));
    $dist_id = $this->dist_id;

endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state  noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li>Cylinder Report</li>
                <li class="active">Customer/Supplier Wise Cylinder</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/3'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row  noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-12">
                            <div class="table-header">
                                Customer/Supplier Group Wise Cylinder
                            </div>
                            <br>
                            <div style="background-color: grey!important;">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Type</label>
                                        <div class="col-sm-8">
                                            <select  onchange="selectPayType(this.value)"  id="type_id" name="type_id"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Type">
                                                <option <?php
if ($type_id == 'all') {
    echo "selected";
}
?> value="all">All</option>
                                                <option <?php
                                                    if ($type_id == 2) {
                                                        echo "selected";
                                                    }
?> value="2">Customer</option>
                                                <option <?php
                                                    if ($type_id == 3) {
                                                        echo "selected";
                                                    }
?>  value="3">Supplier </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="searchValue"></div>
                                    <div id="oldValue">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label no-padding-right" for="form-field-1"> ID <span style="color:red;">*</span></label>
                                            <div class="col-sm-10">
                                                <select name="firstType" id="productID" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Name">
                                                    <option value="all">All</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Group</label>
                                        <div class="col-sm-8">
                                            <select   id="groupId" name="groupId"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Select Group">
                                                <option <?php
                                                    if ($groupId == 'all') {
                                                        echo "selected";
                                                    }
?> value="all">All</option>
                                                    <?php foreach ($typeList as $key => $value): ?>
                                                    <option <?php
                                                    if ($groupId == $value->product_type_id) {
                                                        echo "selected";
                                                    }
                                                        ?> value="<?php echo $value->product_type_id; ?>"><?php echo $value->product_type_name; ?></option>

                                                <?php endforeach; ?>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> From </label>
                                            <div class="col-sm-9">
                                                <input style="width: 100%" type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                                if (!empty($from_date)) {
                                                    echo $from_date;
                                                } else {
                                                    echo date('d-m-Y');
                                                }
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">To</label>
                                            <div class="col-sm-9">
                                                <input  style="width: 100%"  type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                                       if (!empty($to_date)):
                                                           echo $to_date;
                                                       else:
                                                           echo date('d-m-Y');
                                                       endif;
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="End Date: dd-mm-yyyy"/>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">

                                        <div class="col-sm-3">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-3">
                                            <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):
                $type_id = $this->input->post('type_id');
                $firstType = $this->input->post('firstType');
                $searchId = $this->input->post('searchId');
                $groupId = $this->input->post('groupId');
                $from_date = date('Y-m-d', strtotime($this->input->post('start_date')));
                $to_date = date('Y-m-d', strtotime($this->input->post('end_date')));
                $total_pvsdebit = '';
                $total_pvscredit = '';
                $total_debit = '';
                $total_credit = '';
                $total_balance = '';
                ?>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="table-header">
                            Supplier/Customer Group Wise Cylinder Report Period <span style="color:greenyellow;">From <?php echo $from_date; ?> To <?php echo $to_date; ?></span>
                        </div>
                        <table class="table table-responsive">
                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <span><?php echo $companyInfo->address; ?></span><br>
                                    <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                    <strong><?php echo $pageTitle; ?></strong>
                                </td>
                            </tr>
                        </table>
                        <table class="table table-bordered">
                            <?php
                            if ($groupId == 'all'):
                                //all supplier all customer
                                if ($type_id == 'all' && $firstType == 'all'):
                                    $ftotalOp = 0;
                                    $ftotalIn = 0;
                                    $ftotalOut = 0;
                                    ?>
                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="center"><strong>Opening</strong></td>
                                            <td align="center"><strong>Stock In</strong></td>
                                            <td align="center"><strong>Stock Out</strong></td>
                                            <td align="center"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $customerList = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id);
                                        $totalStockIn1 = 0;
                                        $totalStockOut1 = 0;
                                        $totalStockOpel = 0;

                                        foreach ($customerList as $key => $eachCustomer):
                                            ?>
                                            <tr>
                                                <td colspan="4" style="font-weight: bold;" align="left">Customer : <?php echo $eachCustomer->customerID . ' [ ' . $eachCustomer->customerName . ' ] '; ?></td>
                                            </tr>
                                            <?php
                                            $totalStockIn = 0;
                                            $totalStockOut = 0;
                                            $totalStockOpe = 0;

                                            foreach ($typeList as $key => $value):
                                                $this->db->select("sum(stock.quantity) as totalStockInOp,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $openingStockInWithType = $this->db->get()->row();

                                                $this->db->select("sum(stock.quantity) as totalStockOutOp,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $openingStockOutWithType = $this->db->get()->row();

                                                $opening = 0;
                                                $opening = $openingStockInWithType->totalStockInOp - $openingStockOutWithType->totalStockOutOp;


                                                $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockInWithType = $this->db->get()->row();

                                                $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockOutWithType = $this->db->get()->row();

                                                $totalStockIn1+=$stockInWithType->totalStockIn;
                                                $totalStockOut1+=$stockOutWithType->totalStockOut;
                                                $totalStockOpel+=$opening;
                                                $totalStockIn+=$stockInWithType->totalStockIn;
                                                $totalStockOut+=$stockOutWithType->totalStockOut;
                                                $totalStockOpe+=$opening;

                                                $checkStockValid = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;

                                                if (!empty($checkStockValid)):
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $value->product_type_id)->product_type_name; ?></td>
                                                        <td align="right"><?php echo $opening; ?></td>
                                                        <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                        <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                        <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                    </tr>
                                                    <?php
                                                endif;
                                            endforeach;
                                            ?>
                                            <tr>
                                                <td align="right">Total</td>
                                                <td align="right"><?php echo $totalStockOpe; ?></td>
                                                <td align="right"><?php echo $totalStockIn; ?></td>
                                                <td align="right"><?php echo $totalStockOut; ?></td>
                                                <td align="right"><?php echo ($totalStockIn + $totalStockOpe) - $totalStockOut; ?></td>
                                            </tr>
                                            <?php
                                        endforeach;
                                        ?>

                                        <?php
                                        $supplierList = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', $this->dist_id);
                                        $totalStockInValidation = 0;
                                        $totalStockValidation = 0;
                                        $totalStockOpening = 0;
                                        foreach ($supplierList as $key => $eachSupplier):
                                            foreach ($typeList as $key => $value):
                                                $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $openingStockInWithType = $this->db->get()->row();

                                                $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $openingStockOutWithType = $this->db->get()->row();
                                                $opening = 0;
                                                $totalStockOpening+= $openingStockInWithType->totalStockIn - $openingStockOutWithType->totalStockOut;
                                                $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockInWithType = $this->db->get()->row();
                                                $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockOutWithType = $this->db->get()->row();
                                                $totalStockInValidation+=$stockInWithType->totalStockIn;
                                                $totalStockOutValidation+=$stockOutWithType->totalStockOut;
                                            endforeach;
                                        endforeach;
                                        $checkEmptyStock = ($totalStockInValidation + $totalStockOpening) - $totalStockOutValidation;
                                        if (!empty($checkEmptyStock)):
                                            foreach ($supplierList as $key => $eachSupplier):
                                                ?>
                                                <tr>
                                                    <td colspan="4" style="font-weight: bold;" align="left"> Supplier : <?php echo $eachSupplier->supID . ' [ ' . $eachSupplier->supName . ' ] '; ?></td>
                                                </tr>
                                                <?php
                                                $totalStockIn = 0;
                                                $totalStockOut = 0;
                                                $totalStockOpening = 0;

                                                foreach ($typeList as $key => $value):
                                                    //opening transction
                                                    $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                    $this->db->from("stock");
                                                    $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                    $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                    $this->db->group_start();
                                                    $this->db->where('product.dist_id', 1);
                                                    $this->db->or_where('product.dist_id', $dist_id);
                                                    $this->db->group_end();
                                                    $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                    $this->db->where('stock.type', 'Cin');
                                                    $this->db->where('stock.date <', $from_date);
                                                    $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                    $openingStockInWithType = $this->db->get()->row();
                                                    $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                    $this->db->from("stock");
                                                    $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                    $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                    $this->db->group_start();
                                                    $this->db->where('product.dist_id', 1);
                                                    $this->db->or_where('product.dist_id', $dist_id);
                                                    $this->db->group_end();
                                                    $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                    $this->db->where('stock.type', 'Cout');
                                                    $this->db->where('stock.date <', $from_date);
                                                    $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                    $openingStockOutWithType = $this->db->get()->row();
                                                    $opening = 0;
                                                    $opening = $openingStockInWithType->totalStockIn - $openingStockOutWithType->totalStockOut;
                                                    //current transaction
                                                    $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                    $this->db->from("stock");
                                                    $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                    $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                    $this->db->group_start();
                                                    $this->db->where('product.dist_id', 1);
                                                    $this->db->or_where('product.dist_id', $dist_id);
                                                    $this->db->group_end();
                                                    $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                    $this->db->where('stock.type', 'Cin');
                                                    $this->db->where('stock.date >=', $from_date);
                                                    $this->db->where('stock.date <=', $to_date);
                                                    $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                    $stockInWithType = $this->db->get()->row();
                                                    $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                    $this->db->from("stock");
                                                    $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                    $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                    $this->db->group_start();
                                                    $this->db->where('product.dist_id', 1);
                                                    $this->db->or_where('product.dist_id', $dist_id);
                                                    $this->db->group_end();
                                                    $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                    $this->db->where('stock.type', 'Cout');
                                                    $this->db->where('stock.date >=', $from_date);
                                                    $this->db->where('stock.date <=', $to_date);
                                                    $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                    $stockOutWithType = $this->db->get()->row();


                                                    $totalStockIn1+=$stockInWithType->totalStockIn;
                                                    $totalStockOut1+=$stockOutWithType->totalStockOut;
                                                    $totalStockOpel+=$opening;

                                                    $totalStockIn+=$stockInWithType->totalStockIn;
                                                    $totalStockOut+=$stockOutWithType->totalStockOut;
                                                    $totalStockOpening+=$opening;
                                                    $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;
                                                    if (!empty($checkEmptyStock)):
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $value->product_type_id)->product_type_name; ?></td>
                                                            <td align="right"><?php echo $opening; ?></td>
                                                            <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                            <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                            <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                        </tr>
                                                        <?php
                                                    endif;
                                                endforeach;
                                                ?>
                                                <tr>
                                                    <td align="right">Total</td>
                                                    <td align="right"><?php echo $totalStockOpening; ?></td>
                                                    <td align="right"><?php echo $totalStockIn; ?></td>
                                                    <td align="right"><?php echo $totalStockOut; ?></td>
                                                    <td align="right"><?php echo ($totalStockIn + $totalStockOpening) - $totalStockOut; ?></td>
                                                </tr>
                                                <?php
                                            endforeach;
                                        endif;
                                        ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td  align="right"><strong>Grand-Total</strong></td>
                                            <td align="right"><strong><?php echo $totalStockOpel; ?>&nbsp;</strong></td>
                                            <td align="right"><strong><?php echo $totalStockIn1; ?>&nbsp;</strong></td>
                                            <td align="right"><strong><?php echo $totalStockOut1; ?>&nbsp;</strong></td>
                                            <td align="right"><strong><?php echo ($totalStockIn1 + $totalStockOpel) - $totalStockOut1; ?>&nbsp;</strong></td>
                                        </tr>
                                    </tfoot>
                                <?php endif; ?>

                                <?php
                                //only customer all result
                                if ($type_id == '2' && $firstType == 'all' && $searchId == 'all'):
                                    ?>
                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="right"><strong>Opening</strong></td>
                                            <td align="right"><strong>Stock In</strong></td>
                                            <td align="right"><strong>Stock Out</strong></td>
                                            <td align="right"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $customerList = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id);
                                        $totalStockIn1 = 0;
                                        $totalStockOut1 = 0;
                                        $totalStockOpe1 = 0;

                                        foreach ($customerList as $key => $eachCustomer):
                                            ?>

                                            <tr>
                                                <td colspan="5" style="font-weight: bold;" align="left"> Customer : <?php echo $eachCustomer->customerID . ' [ ' . $eachCustomer->customerName . ' ] '; ?></td>
                                            </tr>
                                            <?php
                                            $totalStockIn = 0;
                                            $totalStockOut = 0;
                                            $totalStockOpe = 0;

                                            foreach ($typeList as $key => $value):
                                                $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockInWithTypeOpenig = $this->db->get()->row();
//echo $this->db->last_query();die;
                                                $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockOutWithTypeOpenig = $this->db->get()->row();
                                                $opening = 0;
                                                $opening = $stockInWithTypeOpenig->totalStockIn - $stockOutWithTypeOpenig->totalStockOut;


                                                $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockInWithType = $this->db->get()->row();

                                                // echo $this->db->last_query();die;



                                                $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $value->product_type_id);
                                                $stockOutWithType = $this->db->get()->row();




                                                $totalStockIn1+=$stockInWithType->totalStockIn;
                                                $totalStockOut1+=$stockOutWithType->totalStockOut;
                                                $totalStockOpe1+=$opening;
                                                $totalStockIn+=$stockInWithType->totalStockIn;
                                                $totalStockOut+=$stockOutWithType->totalStockOut;
                                                $totalStockOpe+=$opening;
                                                $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;
                                                if (!empty($checkEmptyStock)):
                                                    ?>

                                                    <tr>
                                                        <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $value->product_type_id)->product_type_name; ?></td>
                                                        <td align="right"><?php echo $opening; ?></td>
                                                        <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                        <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                        <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                    </tr>
                                                    <?php
                                                endif;
                                            endforeach;
                                            $checkTotalEmptyStock = ($totalStockIn + $totalStockOpe) - $totalStockOut;
                                            if (!empty($checkTotalEmptyStock)):
                                                ?>
                                                <tr>
                                                    <td align="right">Total</td>
                                                    <td align="right"><?php echo $totalStockOpe; ?></td>
                                                    <td align="right"><?php echo $totalStockIn; ?></td>
                                                    <td align="right"><?php echo $totalStockOut; ?></td>
                                                    <td align="right"><?php echo ($totalStockIn + $totalStockOpe) - $totalStockOut; ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                        endforeach;
                                        ?>
                                    </tbody>


                                    <?php
                                    $chekFinalStock = ($totalStockOpe1 + $totalStockIn1) - $totalStockOut1;
                                    if (!empty($chekFinalStock)):
                                        ?>

                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Grand-Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpe1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn1 + $totalStockOpe1) - $totalStockOut1; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                        <?php ?>
                                    <?php endif; ?>

                                <?php endif; ?>
                                <?php
                                //all supplier all customer
                                if ($type_id == '3' && $firstType == 'all' && $searchId == 'all'):
                                    ?>

                                    <?php
                                    $supplierList = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', $this->dist_id);
                                    $totalStockIn1 = 0;
                                    $totalStockOut1 = 0;
                                    $totalStockOpen1 = 0;

                                    foreach ($supplierList as $key => $eachSupplier):
                                        ?>
                                        <tr>
                                            <td colspan="5" style="font-weight: bold;" align="left"> Supplier : <?php echo $eachSupplier->supID . ' [ ' . $eachSupplier->supName . ' ] '; ?></td>
                                        </tr>
                                        <?php
                                        $totalStockIn = 0;
                                        $totalStockOut = 0;
                                        $totalStockOpe = 0;

                                        foreach ($typeList as $key => $value):
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockInWithTypeOpening = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockOutWithTypeOpening = $this->db->get()->row();
                                            $opening = 0;
                                            $opening = $stockInWithTypeOpening->totalStockIn - $stockOutWithTypeOpening->totalStockOut;

                                            //current stock
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockInWithType = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockOutWithType = $this->db->get()->row();

                                            $totalStockIn+=$stockInWithType->totalStockIn;
                                            $totalStockOut+=$stockOutWithType->totalStockOut;
                                            $totalStockOpe+=$opening;
                                            $totalStockIn1+=$stockInWithType->totalStockIn;
                                            $totalStockOut1+=$stockOutWithType->totalStockOut;
                                            $totalStockOpen1+=$opening;


                                            $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;


                                            if (!empty($checkEmptyStock)):
                                                ?>

                                                <tr>
                                                    <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $value->product_type_id)->product_type_name; ?></td>
                                                    <td align="right"><?php echo $opening; ?></td>
                                                    <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                    <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                    <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                        endforeach;

                                        $checkSubStockEmpty = ($totalStockIn + $totalStockOpe) - $totalStockOut;

                                        if (!empty($checkSubStockEmpty)):
                                            ?>
                                            <tr>
                                                <td align="right">Total</td>
                                                <td align="right"><?php echo $totalStockOpe; ?></td>
                                                <td align="right"><?php echo $totalStockIn; ?></td>
                                                <td align="right"><?php echo $totalStockOut; ?></td>
                                                <td align="right"><?php echo ($totalStockIn + $totalStockOpe) - $totalStockOut; ?></td>
                                            </tr>
                                            <?php
                                        endif;
                                    endforeach;
                                    ?>
                                    </tbody>

                                    <?php
                                    $finalStock = ($totalStockOpen1 + $totalStockIn1) - $totalStockOut1;

                                    if (!empty($finalStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Grand-Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpen1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn1 + $totalStockOpen1) - $totalStockOut1; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                        <?php
                                    endif;
                                endif;
                                ?>

                                <?php
                                if ($type_id == '2' && $searchId != 'all'):
                                    ?>
                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="center"><strong>Opening</strong></td>
                                            <td align="center"><strong>Stock In</strong></td>
                                            <td align="center"><strong>Stock Out</strong></td>
                                            <td align="center"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $totalStockIn = 0;
                                        $totalStockOut = 0;
                                        $totalStockOpening = 0;

                                        foreach ($typeList as $key => $value):
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $searchId);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockInWithTypeOpening = $this->db->get()->row();

                                            // echo $this->db->last_query();die;
                                            //  echo $stockInWithTypeOpening->totalStockIn;die(" tst");
                                            //  echo $this->db->last_query();die;
                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $searchId);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockOutWithTypeOpening = $this->db->get()->row();


                                            $opening = 0;
                                            $opening = $stockInWithTypeOpening->totalStockIn - $stockOutWithTypeOpening->totalStockOut;

                                            //Current stock
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $searchId);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockInWithType = $this->db->get()->row();
                                            //  echo $this->db->last_query();die;
                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $searchId);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockOutWithType = $this->db->get()->row();
                                            //echo $this->db->last_query();die;
                                            $totalStockIn+=$stockInWithType->totalStockIn;
                                            $totalStockOut+=$stockOutWithType->totalStockOut;
                                            $totalStockOpening+=$opening;
                                            $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;
                                            if (!empty($checkEmptyStock)):
                                                ?>
                                                <tr>
                                                    <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $value->product_type_id)->product_type_name; ?></td>
                                                    <td align="right"><?php echo $opening; ?></td>
                                                    <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                    <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                    <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                        endforeach;
                                        ?>
                                    </tbody>
                                    <?php
                                    $checkFinalStock = ($totalStockOpening + $totalStockIn) - $totalStockOut;
                                    if (!empty($checkFinalStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpening; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn + $totalStockOpening) - $totalStockOut; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                        <?php
                                    endif;
                                endif;
                                ?>
                                <?php
                                if ($type_id == '3' && $searchId != 'all'):
                                    ?>
                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="center"><strong>Opening</strong></td>
                                            <td align="center"><strong>Stock In</strong></td>
                                            <td align="center"><strong>Stock Out</strong></td>
                                            <td align="center"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $totalStockIn = 0;
                                        $totalStockOut = 0;
                                        $totalStockOpe = 0;

                                        foreach ($typeList as $key => $value):
                                            //opening stock
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $searchId);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockInWithTypeOpenig = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $searchId);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockOutWithTypeOpenig = $this->db->get()->row();
                                            $opening = 0;
                                            $opening = $stockInWithTypeOpenig->totalStockIn - $stockOutWithTypeOpenig->totalStockOut;

                                            //current stock
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $searchId);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockInWithType = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $searchId);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $value->product_type_id);
                                            $stockOutWithType = $this->db->get()->row();




                                            $totalStockIn+=$stockInWithType->totalStockIn;
                                            $totalStockOut+=$stockOutWithType->totalStockOut;
                                            $totalStockOpe+=$opening;
                                            $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;

                                            if (!empty($checkEmptyStock)):
                                                ?>
                                                <tr>
                                                    <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $value->product_type_id)->product_type_name; ?></td>
                                                    <td align="right"><?php echo $opening; ?></td>
                                                    <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                    <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                    <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                        endforeach;
                                        ?>
                                    </tbody>
                                    <?php
                                    $checkFinalStock = ($totalStockOpe + $totalStockIn) - $totalStockOut;
                                    if (!empty($checkFinalStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpe; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn + $totalStockOpe) - $totalStockOut; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                        <?php ?>
                                        <?php
                                    endif;
                                endif;
                                ?>

                            <?php else: ?>

                                <?php
                                //all supplier all customer
                                if ($type_id == 'all' && $firstType == 'all' && $groupId != 'all'):
                                    $ftotalOp = 0;
                                    $ftotalIn = 0;
                                    $ftotalOut = 0;
                                    ?>
                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="center"><strong>Stock In</strong></td>
                                            <td align="center"><strong>Stock Out</strong></td>
                                            <td align="center"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $customerList = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id);

                                        $totalStockIn1 = 0;
                                        $totalStockOut1 = 0;
                                        $totalStockOpe1 = 0;

                                        foreach ($customerList as $key => $eachCustomer):
                                            ?>

                                            <?php
                                            $totalStockIn = 0;
                                            $totalStockOut = 0;
                                            $totalStockOpe = 0;

                                            //foreach ($typeList as $key => $value):
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockInWithTypeOpening = $this->db->get()->row();




                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockOutWithTypeOpening = $this->db->get()->row();

                                            $opening = 0;
                                            $opening = $stockInWithTypeOpening->totalStockIn - $stockOutWithTypeOpening->totalStockOut;


                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockInWithType = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockOutWithType = $this->db->get()->row();



                                            $totalStockIn1+=$stockInWithType->totalStockIn;
                                            $totalStockOut1+=$stockOutWithType->totalStockOut;
                                            $totalStockOpe1+=$opening;
                                            $totalStockIn+=$stockInWithType->totalStockIn;
                                            $totalStockOut+=$stockOutWithType->totalStockOut;
                                            $totalStockOpe+=$opening;

                                            $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;

                                            if (!empty($checkEmptyStock)):
                                                ?>
                                                <tr>
                                                    <td colspan="4" style="font-weight: bold;" align="left"> Customer : <?php echo $eachCustomer->customerID . ' [ ' . $eachCustomer->customerName . ' ] '; ?></td>
                                                </tr>

                                                <tr>
                                                    <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $groupId)->product_type_name; ?></td>
                                                    <td align="right"><?php echo $opening; ?></td>
                                                    <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                    <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                    <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                            //endforeach;
                                            ?>

                                            <?php
                                        endforeach;
                                        ?>

                                        <?php
                                        $supplierList = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', $this->dist_id);
                                        $totalStockInValidation = 0;
                                        $totalStockValidation = 0;
                                        $totalStockValidationOpening = 0;

                                        foreach ($supplierList as $key => $eachSupplier):
                                            // foreach ($typeList as $key => $value):
                                            // foreach ($typeList as $key => $value):
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockInWithTypeOpening = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockOutWithTypeOpenig = $this->db->get()->row();
                                            $opening = 0;
                                            $totalStockValidationOpening+= $stockInWithTypeOpening->totalStockIn - $stockOutWithTypeOpenig->totalStockOut;



                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockInWithType = $this->db->get()->row();
                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockOutWithType = $this->db->get()->row();

                                            $totalStockInValidation+=$stockInWithType->totalStockIn;
                                            $totalStockOutValidation+=$stockOutWithType->totalStockOut;

                                        // endforeach;
                                        endforeach;
                                        $checkEmptyStock = ($totalStockInValidation + $totalStockValidationOpening) - $totalStockOutValidation;

                                        if (!empty($checkEmptyStock)):

                                            foreach ($supplierList as $key => $eachSupplier):
                                                ?>

                                                <?php
                                                $totalStockIn = 0;
                                                $totalStockOut = 0;
                                                $totalStockOpe = 0;
                                                // foreach ($typeList as $key => $value):
                                                $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $groupId);
                                                $stockInWithTypeOpening = $this->db->get()->row();

                                                $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date <', $from_date);
                                                $this->db->where('product_type.product_type_id', $groupId);
                                                $stockOutWithTypeOpenig = $this->db->get()->row();
                                                $opening = 0;
                                                $opening = $stockInWithTypeOpening->totalStockIn - $stockOutWithTypeOpenig->totalStockOut;
                                                //query current stock

                                                $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cin');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $groupId);
                                                $stockInWithType = $this->db->get()->row();
                                                $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                                $this->db->from("stock");
                                                $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                                $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                                $this->db->group_start();
                                                $this->db->where('product.dist_id', 1);
                                                $this->db->or_where('product.dist_id', $dist_id);
                                                $this->db->group_end();
                                                $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                                $this->db->where('stock.type', 'Cout');
                                                $this->db->where('stock.date >=', $from_date);
                                                $this->db->where('stock.date <=', $to_date);
                                                $this->db->where('product_type.product_type_id', $groupId);
                                                $stockOutWithType = $this->db->get()->row();


                                                $totalStockIn1+=$stockInWithType->totalStockIn;
                                                $totalStockOut1+=$stockOutWithType->totalStockOut;
                                                $totalStockOpe1 = $opening;
                                                $totalStockIn+=$stockInWithType->totalStockIn;
                                                $totalStockOut+=$stockOutWithType->totalStockOut;
                                                $totalStockOpe+=$opening;

                                                $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;
                                                if (!empty($checkEmptyStock)):
                                                    ?>
                                                    <tr>
                                                        <td colspan="4" style="font-weight: bold;" align="left"> Supplier : <?php echo $eachSupplier->supID . ' [ ' . $eachSupplier->supName . ' ] '; ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $groupId)->product_type_name; ?></td>
                                                        <td align="right"><?php echo $opening; ?></td>
                                                        <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                        <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                        <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                    </tr>
                                                    <?php
                                                endif;
                                            endforeach;

                                        endif;
                                        ?>
                                    </tbody>
                                    <?php
                                    $checkEmptyStock = ($totalStockIn1 + $totalStockOpe1) - $totalStockOut1;
                                    if (!empty($checkEmptyStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Grand-Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpe1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn1 + $totalStockOpe1) - $totalStockOut1; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php
                                //only customer all result
                                if ($type_id == '2' && $firstType == 'all' && $searchId == 'all' && $groupId != 'all'):
                                    ?>


                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="right"><strong>Opening</strong></td>
                                            <td align="right"><strong>Stock In</strong></td>
                                            <td align="right"><strong>Stock Out</strong></td>
                                            <td align="right"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $customerList = $this->Common_model->get_data_list_by_single_column('customer', 'dist_id', $this->dist_id);
                                        $totalStockIn1 = 0;
                                        $totalStockOut1 = 0;
                                        $totalStockOpe1 = 0;

                                        foreach ($customerList as $key => $eachCustomer):
                                            ?>

                                            <?php
                                            $totalStockIn = 0;
                                            $totalStockOut = 0;
                                            $totalStockOpe = 0;

                                            //foreach ($typeList as $key => $value):
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockInWithTypeOpenig = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date <', $from_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockOutWithTypeOpenig = $this->db->get()->row();

                                            $opening = 0;
                                            $opening = $stockInWithTypeOpenig->totalStockIn - $stockOutWithTypeOpenig->totalStockOut;


                                            //current stock
                                            $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cin');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockInWithType = $this->db->get()->row();

                                            $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                            $this->db->from("stock");
                                            $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                            $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                            $this->db->group_start();
                                            $this->db->where('product.dist_id', 1);
                                            $this->db->or_where('product.dist_id', $dist_id);
                                            $this->db->group_end();
                                            $this->db->where('stock.customerId', $eachCustomer->customer_id);
                                            $this->db->where('stock.type', 'Cout');
                                            $this->db->where('stock.date >=', $from_date);
                                            $this->db->where('stock.date <=', $to_date);
                                            $this->db->where('product_type.product_type_id', $groupId);
                                            $stockOutWithType = $this->db->get()->row();

                                            $totalStockIn1+=$stockInWithType->totalStockIn;
                                            $totalStockOut1+=$stockOutWithType->totalStockOut;
                                            $totalStockOpe1+=$opening;
                                            $totalStockIn+=$stockInWithType->totalStockIn;
                                            $totalStockOut+=$stockOutWithType->totalStockOut;
                                            $totalStockOpe+=$opening;
                                            $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;
                                            if (!empty($checkEmptyStock)):
                                                ?>
                                                <tr>
                                                    <td colspan="4" style="font-weight: bold;" align="left"> Customer : <?php echo $eachCustomer->customerID . ' [ ' . $eachCustomer->customerName . ' ] '; ?></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $groupId)->product_type_name; ?></td>
                                                    <td align="right"><?php echo $opening; ?></td>
                                                    <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                    <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                    <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                                </tr>
                                                <?php
                                            endif;
                                            //endforeach;
                                            ?>
                                            <?php
                                        endforeach;
                                        ?>
                                    </tbody>
                                    <?php
                                    $checkFinalStock = ($totalStockOpe1 + $totalStockIn1) - $totalStockOut1;
                                    if (!empty($checkFinalStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Grand-Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpe1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn1 + $totalStockOpe1) - $totalStockOut1; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php
                                //all supplier all customer
                                if ($type_id == '3' && $firstType == 'all' && $searchId == 'all' && $groupId != 'all'):
                                    ?>

                                    <?php
                                    $supplierList = $this->Common_model->get_data_list_by_single_column('supplier', 'dist_id', $this->dist_id);
                                    $totalStockIn1 = 0;
                                    $totalStockOut1 = 0;
                                    $totalStockOpe1 = 0;

                                    foreach ($supplierList as $key => $eachSupplier):
                                        ?>

                                        <?php
                                        $totalStockIn = 0;
                                        $totalStockOut = 0;
                                        $totalStockOpe = 0;

                                        // foreach ($typeList as $key => $value):
                                        $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                        $this->db->where('stock.type', 'Cin');
                                        $this->db->where('stock.date <', $from_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockInWithTypeOpening = $this->db->get()->row();

                                        $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                        $this->db->where('stock.type', 'Cout');
                                        $this->db->where('stock.date <', $from_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockOutWithTypeOpening = $this->db->get()->row();

                                        $opening = 0;
                                        $opening = $stockInWithTypeOpening->totalStockIn - $stockOutWithTypeOpening->totalStockOut;


                                        //current it
                                        // foreach ($typeList as $key => $value):
                                        $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                        $this->db->where('stock.type', 'Cin');
                                        $this->db->where('stock.date >=', $from_date);
                                        $this->db->where('stock.date <=', $to_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockInWithType = $this->db->get()->row();

                                        $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $eachSupplier->sup_id);
                                        $this->db->where('stock.type', 'Cout');
                                        $this->db->where('stock.date >=', $from_date);
                                        $this->db->where('stock.date <=', $to_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockOutWithType = $this->db->get()->row();

                                        $totalStockIn+=$stockInWithType->totalStockIn;
                                        $totalStockOut+=$stockOutWithType->totalStockOut;
                                        $totalStockIn1+=$stockInWithType->totalStockIn;
                                        $totalStockOut1+=$stockOutWithType->totalStockOut;
                                        $totalStockOpe+=$opening;
                                        $totalStockOpe1+=$opening;

                                        $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;

                                        if (!empty($checkEmptyStock)):
                                            ?>
                                            <tr>
                                                <td colspan="4" style="font-weight: bold;" align="left"> Supplier : <?php echo $eachSupplier->supID . ' [ ' . $eachSupplier->supName . ' ] '; ?></td>
                                            </tr>
                                            <tr>
                                                <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $groupId)->product_type_name; ?></td>
                                                <td align="right"><?php echo $opening; ?></td>
                                                <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                            </tr>
                                            <?php
                                        endif;
                                    //endforeach;

                                    endforeach;
                                    ?>
                                    </tbody>
                                    <?php
                                    $checkFinalStock = ($totalStockOpe1 + $totalStockIn1) - $totalStockOut1;
                                    if (!empty($checkFinalStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Grand-Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpe1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut1; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn1 + $totalStockOpe1 - $totalStockOut1; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php
                                if ($type_id == '2' && $searchId != 'all' && $groupId != 'all'):
                                    ?>
                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="center"><strong>Opening</strong></td>
                                            <td align="center"><strong>Stock In</strong></td>
                                            <td align="center"><strong>Stock Out</strong></td>
                                            <td align="center"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $totalStockIn = 0;
                                        $totalStockOut = 0;
                                        $totalStockOpe = 0;

                                        // foreach ($typeList as $key => $value):
                                        $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.customerId', $searchId);
                                        $this->db->where('stock.type', 'Cin');
                                        $this->db->where('stock.date <', $from_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockInWithTypeOpening = $this->db->get()->row();
                                        //  echo $this->db->last_query();die;
                                        $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.customerId', $searchId);
                                        $this->db->where('stock.type', 'Cout');
                                        $this->db->where('stock.date <', $from_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockOutWithTypeOpening = $this->db->get()->row();
                                        $opening = 0;
                                        $opening = $stockInWithTypeOpening->totalStockIn + $stockOutWithTypeOpening->totalStockOut;
                                        // foreach ($typeList as $key => $value):
                                        $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.customerId', $searchId);
                                        $this->db->where('stock.type', 'Cin');
                                        $this->db->where('stock.date >=', $from_date);
                                        $this->db->where('stock.date <=', $to_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockInWithType = $this->db->get()->row();
                                        //  echo $this->db->last_query();die;
                                        $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.customerId', $searchId);
                                        $this->db->where('stock.type', 'Cout');
                                        $this->db->where('stock.date >=', $from_date);
                                        $this->db->where('stock.date <=', $to_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockOutWithType = $this->db->get()->row();



                                        //echo $this->db->last_query();die;
                                        $totalStockIn+=$stockInWithType->totalStockIn;
                                        $totalStockOut+=$stockOutWithType->totalStockOut;
                                        $totalStockOpe+=$opening;

                                        $checkEmptyVali = 0;
                                        $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;

                                        if (!empty($checkEmptyStock)):
                                            ?>
                                            <tr>
                                                <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $groupId)->product_type_name; ?></td>
                                                <td align="right"><?php echo $opening; ?></td>
                                                <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                            </tr>
                                            <?php
                                        endif;
                                        // endforeach;
                                        ?>
                                    </tbody>
                                    <?php
                                    $checkEmptyStock = ($totalStockOpe + $totalStockIn) - $totalStockOut;

                                    if (!empty($checkEmptyStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpe; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn + $totalStockOpe) - $totalStockOut; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                        <?php
                                    endif;
                                endif;
                                ?>
                                <?php
                                if ($type_id == '3' && $searchId != 'all' && $groupId != 'all'):
                                    ?>
                                    <thead>
                                        <tr>
                                            <td align="center"><strong>Product Group</strong></td>
                                            <td align="center"><strong>Stock In</strong></td>
                                            <td align="center"><strong>Stock Out</strong></td>
                                            <td align="center"><strong>Balance ( Pcs )</strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $totalStockIn = 0;
                                        $totalStockOut = 0;
                                        $totalStockOpe = 0;

                                        // foreach ($typeList as $key => $value):
                                        $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $searchId);
                                        $this->db->where('stock.type', 'Cin');
                                        $this->db->where('stock.date <', $from_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockInWithTypeOpenig = $this->db->get()->row();

                                        $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $searchId);
                                        $this->db->where('stock.type', 'Cout');
                                        $this->db->where('stock.date <', $from_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockOutWithTypeOpenig = $this->db->get()->row();
                                        $opening = 0;
                                        $opening = $stockInWithTypeOpenig->totalStockIn - $stockOutWithTypeOpenig->totalStockOut;


                                        $this->db->select("sum(stock.quantity) as totalStockIn,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $searchId);
                                        $this->db->where('stock.type', 'Cin');
                                        $this->db->where('stock.date >=', $from_date);
                                        $this->db->where('stock.date <=', $to_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockInWithType = $this->db->get()->row();

                                        $this->db->select("sum(stock.quantity) as totalStockOut,product_type.product_type_name");
                                        $this->db->from("stock");
                                        $this->db->join('product', 'stock.product_id=product.product_id', 'left');
                                        $this->db->join('product_type', 'product.product_type_id=product_type.product_type_id', 'left');
                                        $this->db->group_start();
                                        $this->db->where('product.dist_id', 1);
                                        $this->db->or_where('product.dist_id', $dist_id);
                                        $this->db->group_end();
                                        $this->db->where('stock.supplierId', $searchId);
                                        $this->db->where('stock.type', 'Cout');
                                        $this->db->where('stock.date >=', $from_date);
                                        $this->db->where('stock.date <=', $to_date);
                                        $this->db->where('product_type.product_type_id', $groupId);
                                        $stockOutWithType = $this->db->get()->row();

                                        $totalStockIn+=$stockInWithType->totalStockIn;
                                        $totalStockOut+=$stockOutWithType->totalStockOut;
                                        $totalStockOpe+=$opening;
                                        $checkEmptyStock = ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut;
                                        if (!empty($checkEmptyStock)):
                                            ?>
                                            <tr>
                                                <td><?php echo $this->Common_model->tableRow('product_type', 'product_type_id', $groupId)->product_type_name; ?></td>
                                                <td align="right"><?php echo $opening; ?></td>
                                                <td align="right"><?php echo $stockInWithType->totalStockIn; ?></td>
                                                <td align="right"><?php echo $stockOutWithType->totalStockOut; ?></td>
                                                <td align="right"><?php echo ($stockInWithType->totalStockIn + $opening) - $stockOutWithType->totalStockOut; ?></td>
                                            </tr>
                                            <?php
                                        endif;
                                        // endforeach;
                                        ?>
                                    </tbody>
                                    <?php
                                    $finalStock = ($totalStockOpe + $totalStockIn) - $totalStockOut;
                                    if (!empty($finalStock)):
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <td  align="right"><strong>Total</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOpe; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockIn; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo $totalStockOut; ?>&nbsp;</strong></td>
                                                <td align="right"><strong><?php echo ($totalStockIn + $totalStockOpe) - $totalStockOut; ?>&nbsp;</strong></td>
                                            </tr>
                                        </tfoot>
                                        <?php
                                    endif;
                                endif;
                                ?>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>
<script>
<?php if (!empty($type_id)):
    ?>
            var url = '<?php echo site_url("FinaneController/getPayUserList2") ?>';
    <?php if ($type_id != 'all'): ?>
                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {'payid': '<?php echo $type_id; ?>','searchId': '<?php echo $searchId; ?>','supplierId':'<?php echo $supplier_id; ?>'},
                    success: function (data)
                    {
                        $(".chosenRefesh").trigger("chosen:updated");
                        $("#searchValue").show(1000);
                        $("#searchValue").html(data);
                        $("#oldValue").hide(1000);
                        $('.chosenRefesh').chosen();
                        $(".chosenRefesh").trigger("chosen:updated");
                    }
                });
    <?php else: ?>
                $("#searchValue").hide(1000);
                $("#oldValue").show(1000);

    <?php
    endif;
endif;
?>
    function selectPayType(payid) {
        var url = '<?php echo site_url("FinaneController/getPayUserList2") ?>';
        if (payid != 'all') {
            $.ajax({
                type: 'POST',
                url: url,
                data: {'payid': payid},
                success: function (data)
                {
                    $(".chosenRefesh").trigger("chosen:updated");
                    $("#searchValue").show(1000);
                    $("#searchValue").html(data);
                    $("#oldValue").hide(1000);
                    $('.chosenRefesh').chosen();
                    $(".chosenRefesh").trigger("chosen:updated");
                }
            });
        } else {
            $("#searchValue").hide(1000);
            $("#oldValue").show(1000);
        }
    }
</script>