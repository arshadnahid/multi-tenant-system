
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Return</li>
                <li class="active">Sales Return List</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a class="saleAddPermission" href="<?php echo site_url($this->project . '/salesReturnAdd'); ?>">
                        <i class="ace-icon fa fa-plus"></i>
                        Add
                    </a>
                </li>
            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="table-header">
                    Sales Return List
                </div>
                <div>
                    <table id="example" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Date</th>
                                <th>Customer</th>
                                <th>Invoice ID</th>
                                <th>Return Amount</th>
                                <th>Action</th>


                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($salesReturnList as $key => $value):
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo $value->date; ?></td>
                                    <td><?php echo $value->customerName; ?></td>
                                    <td><?php echo $value->voucher_no; ?></td>
                                    <td align="right"><?php echo $value->amount; ?></td>
                                    <td>
                                        <a class="green" href="<?php echo site_url($this->project .'/viewSalesReturn/'. $value->sales_return_id); ?>">
                                            <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                        </a>

                                    </td>

                                </tr>
                            <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div><script src="<?php echo base_url('assets/setup.js'); ?>"></script>
