<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/* import setup start */

$route['(:any)/subCatList'] = 'CommonController/subCatList';
$route['(:any)/voucherList'] = 'FinaneController/voucherList';
$route['(:any)/subCatList/(:any)'] = 'CommonController/subCatList/$2';
$route['(:any)/setupImport'] = 'ImportController/setupImport';
$route['(:any)/productImport'] = 'ImportController/productImport';
$route['(:any)/demoImport'] = 'VoucherController/demoImport';
$route['(:any)/demolist'] = 'VoucherController/demolist';
$route['(:any)/PurchaseDemoConfirm/(:any)'] = 'VoucherController/PurchaseDemoConfirm/$2';
$route['(:any)/salesImport'] = 'VoucherController/salesImport';
$route['(:any)/addSalesImport'] = 'VoucherController/addSalesImport';
$route['(:any)/salesImportConfirm/(:any)'] = 'VoucherController/salesImportConfirm/$2';
$route['(:any)/financeImport'] = 'VoucherController/financeImport';
$route['(:any)/financeImportAdd'] = 'VoucherController/financeImportAdd';
$route['(:any)/paymentVoucherPosting/(:any)'] = 'VoucherController/paymentVoucherPosting/$2';
$route['(:any)/receiveVoucherPosting/(:any)'] = 'VoucherController/receiveVoucherPosting/$2';
$route['(:any)/journalVoucherPosting/(:any)'] = 'VoucherController/journalVoucherPosting/$2';
/* import setup end */
/* Admin module start */
$route['(:any)/renewSoftware'] = 'admin/AdminSettings/renewList';
$route['(:any)/adminProductAdd'] = 'admin/AdminSettings/adminProductAdd';
$route['(:any)/adminUpdateProduct/(:any)'] = 'admin/AdminSettings/adminUpdateProduct/$2';
$route['(:any)/adminProuductList'] = 'admin/AdminSettings/adminProuductList';
$route['(:any)/adminProductImport'] = 'admin/AdminSettings/adminProductImport';
//admin product cat
$route['(:any)/adminProductCatAdd'] = 'admin/AdminSettings/adminProductCatAdd';
$route['(:any)/adminUpdateProductCat/(:any)'] = 'admin/AdminSettings/adminUpdateProductCat/$2';
$route['(:any)/adminProuductCatList'] = 'admin/AdminSettings/adminProuductCatList';
//admin brand add
$route['(:any)/adminBrandAdd'] = 'admin/AdminSettings/adminBrandAdd';
$route['(:any)/adminBrandUpdate/(:any)'] = 'admin/AdminSettings/adminBrandUpdate/$2';
$route['(:any)/adminBrandList'] = 'admin/AdminSettings/adminBrandList';
//admin unit add
$route['(:any)/adminUnitAdd'] = 'admin/AdminSettings/adminUnitAdd';
$route['(:any)/adminUnitUpdate/(:any)'] = 'admin/AdminSettings/adminUnitUpdate/$2';
$route['(:any)/adminUnitList'] = 'admin/AdminSettings/adminUnitList';
//admin brand add
$route['(:any)/adminSupAdd'] = 'admin/AdminSettings/adminSupAdd';
$route['(:any)/adminSignout'] = 'admin/AdminAuthController/adminSignout';
$route['(:any)/adminSupEdit/(:any)'] = 'admin/AdminSettings/adminSupEdit/$2';
$route['(:any)/adminSupList'] = 'admin/AdminSettings/adminSupList';


$route['(:any)/adminlogin'] = 'admin/AdminAuthController';
$route['(:any)/adminDashboard'] = 'admin/AdminDashboard/adminDashboard';
//distributor Report
$route['(:any)/distributor_add'] = 'admin/AdminSettings/distributor_add';
$route['(:any)/distributor'] = 'admin/AdminSettings/distributor';
$route['(:any)/distributor_edit/(:any)'] = 'admin/AdminSettings/distributor_edit/$2';
//zone Add
$route['(:any)/zone_add'] = 'admin/AdminSettings/zone_add';
$route['(:any)/zone'] = 'admin/AdminSettings/zone';
$route['(:any)/zone_edit/(:any)'] = 'admin/AdminSettings/zone_edit/$2';
//District Add
$route['(:any)/viewDistributor/(:any)'] = 'admin/AdminSettings/viewDistributor/$2';
$route['(:any)/district_add'] = 'admin/AdminSettings/district_add';
$route['(:any)/district_list'] = 'admin/AdminSettings/district_list';
$route['(:any)/district_edit/(:any)'] = 'admin/AdminSettings/district_edit/$2';
//offer Add
$route['(:any)/offer_add'] = 'admin/AdminSettings/offer_add';
$route['(:any)/offer'] = 'admin/AdminSettings/offer_';
$route['(:any)/offer_edit/(:any)'] = 'admin/AdminSettings/offer_edit/$2';
//message Add
$route['(:any)/inbox_add'] = 'admin/AdminSettings/inbox_add';
$route['(:any)/inbox'] = 'admin/AdminSettings/inbox';
$route['(:any)/inbox_edit/(:any)'] = 'admin/AdminSettings/inbox_edit/$2';

//user info

$route['(:any)/profile'] = 'admin/AdminSettings/profile';
$route['(:any)/updateProfile'] = 'admin/AdminSettings/updateProfile';
$route['(:any)/change_Admin_password'] = 'admin/AdminSettings/change_Admin_password';

//head office Report
$route['(:any)/disPurchasesReport'] = 'admin/AdminReportController/disPurchasesReport';
$route['(:any)/disStockReport'] = 'admin/AdminReportController/disStockReport';
$route['(:any)/disSalesReport'] = 'admin/AdminReportController/disSalesReport';
$route['(:any)/disSalesReportView/(:any)'] = 'admin/AdminReportController/disSalesReportView/$2';
$route['(:any)/adminViewPurchases/(:any)'] = 'admin/AdminReportController/adminViewPurchases/$2';
$route['(:any)/adminViewPurchases/(:any)'] = 'admin/AdminReportController/adminViewPurchases/$2';
$route['(:any)/getDistributorAccess'] = 'admin/AdminReportController/getDistributorAccess';
$route['(:any)/dbBackup'] = 'admin/AdminSettings/dbBackup';

/* Admin module end */
/* Admin Login end */



$route['default_controller'] = 'AuthController';

$route['(:any)/login'] = 'AuthController/login';
$route['(:any)/signout'] = 'AuthController/signout';
$route['(:any)/signoutHeadoffice'] = 'AuthController/signoutHeadoffice';

$route['(:any)'] = 'AuthController/index';
$route['(:any)/login'] = 'AuthController/index';




//home controller
$route['(:any)/DistributorDashboard'] = 'HomeController/dashboard';
$route['(:any)/DistributorDashboard/(:any)'] = 'HomeController/dashboard/$2';
$route['(:any)/userAccess'] = 'HomeController/userAccess';
$route['(:any)/moduleDashboard'] = 'HomeController/moduleDashboard';
$route['(:any)/adminLoginHistory'] = 'HomeController/adminLoginHistory';
$route['(:any)/insert_menu_accessList'] = 'HomeController/insert_menu_accessList';


/* setup controller start */

$route['(:any)/userMessageList'] = 'SetupController/userMessageList';
$route['(:any)/userAllOfferList'] = 'SetupController/userAllOfferList';
$route['(:any)/getAllMessage'] = 'SetupController/getAllMessage';
$route['(:any)/incentiveList'] = 'SetupController/incentiveList';
$route['(:any)/userList'] = 'SetupController/userList';
$route['(:any)/addUser'] = 'SetupController/addUser';
$route['(:any)/editUser/(:any)'] = 'SetupController/editUser/$2)';
$route['(:any)/decision'] = 'SetupController/decision_tools';
$route['(:any)/save_decision'] = 'SetupController/save_decision_tools';
$route['(:any)/compare_decision'] = 'SetupController/compare_decision';
$route['(:any)/distributor_profile'] = 'SetupController/distributor_profile';
$route['(:any)/updatePassword/(:any)'] = 'SetupController/updatePassword/$2';
$route['(:any)/change_password'] = 'SetupController/change_password';
$route['(:any)/newDecision'] = 'SetupController/newDecision';
$route['(:any)/newDecisionList'] = 'SetupController/newDecisionList';
$route['(:any)/SystemConfig'] = 'SetupController/SystemConfig';
$route['(:any)/bankList'] = 'SetupController/bankList';
$route['(:any)/addBank'] = 'SetupController/addBank';
$route['(:any)/editBank/(:any)'] = 'SetupController/editBank/$2';

//vehicle
$route['(:any)/vehicleList'] = 'LoaderTransportationController/vehicleList';
$route['(:any)/vehicleAdd'] = 'LoaderTransportationController/vehicleAdd';
$route['(:any)/vehicleEdit/(:any)'] = 'LoaderTransportationController/vehicleEdit/$2)';
$route['(:any)/vehicleDelete/(:any)'] = 'LoaderTransportationController/vehicleDelete/$2)';
//employee
$route['(:any)/employeeList'] = 'LoaderTransportationController/employeeList';
$route['(:any)/employeeAdd'] = 'LoaderTransportationController/employeeAdd';
$route['(:any)/employeeEdit/(:any)'] = 'LoaderTransportationController/employeeEdit/$2)';
$route['(:any)/employeeDelete/(:any)'] = 'LoaderTransportationController/employeeDelete/$2)';

/* setup controller end */


/* inventory  controller start */

$route['(:any)/productWiseFullStock'] = 'InventoryController/productWiseFullStock';
$route['(:any)/viewMoneryReceiptForPayment/(:any)'] = 'InventoryController/viewMoneryReceiptForPayment/$2';
$route['(:any)/Supplier'] = 'InventoryController/Supplier';
$route['(:any)/supplierList'] = 'InventoryController/supplierList';
$route['(:any)/productList'] = 'InventoryController/productList';
$route['(:any)/addProduct'] = 'InventoryController/addProduct';
$route['(:any)/updateProduct/(:any)'] = 'InventoryController/updateProduct/$2';
$route['(:any)/productCatList'] = 'InventoryController/productCatList';
$route['(:any)/deleteInventorySetup/(:any)'] = 'InventoryController/deleteInventorySetup/$2';
$route['(:any)/deleteProductCategory/(:any)'] = 'InventoryController/deleteProductCategory/$2';
$route['(:any)/deleteProduct/(:any)'] = 'InventoryController/deleteProduct/$2';
$route['(:any)/deleteBrand/(:any)'] = 'InventoryController/deleteBrand/$2';
$route['(:any)/deleteUnit/(:any)'] = 'InventoryController/deleteUnit/$2';
$route['(:any)/addProductCat'] = 'InventoryController/addProductCat';
$route['(:any)/updateProductCat/(:any)'] = 'InventoryController/updateProductCat/$2';
$route['(:any)/currentStockReport'] = 'InventoryController/currentStockReport';

$route['(:any)/cylinderSummaryReport'] = 'InventoryController/cylinderSummaryReport';
$route['(:any)/cylinderDetailsReport'] = 'InventoryController/cylinderDetailsReport';
$route['(:any)/cylinderLedger'] = 'InventoryController/cylinderLedger';
$route['(:any)/cylinderInOutJournal'] = 'InventoryController/cylinderInOutJournal';
$route['(:any)/cylinderInOutJournalAdd'] = 'InventoryController/cylinderInOutJournalAdd';
$route['(:any)/cylinderInOutJournalView/(:any)'] = 'InventoryController/cylinderInOutJournalView/$2';
$route['(:any)/cylinderInOutJournalEdit/(:any)'] = 'InventoryController/cylinderInOutJournalEdit/$2';
$route['(:any)/cylinderOpening'] = 'InventoryController/cylinderOpening';
$route['(:any)/cylinderOpeningAdd'] = 'InventoryController/cylinderOpeningAdd';
$route['(:any)/cylinderOpeningView/(:any)'] = 'InventoryController/cylinderOpeningView/$2';
$route['(:any)/cylinderStockReport'] = 'InventoryController/cylinderStockReport';
$route['(:any)/viewMoneryReceiptSup/(:any)'] = 'InventoryController/viewMoneryReceiptSup/$2';
$route['(:any)/viewMoneryReceiptSup/(:any)/(:any)'] = 'InventoryController/viewMoneryReceiptSup/$2/$3';
$route['(:any)/productWisePurchasesReport'] = 'InventoryController/productWisePurchasesReport';
$route['(:any)/newCylinderStockReport'] = 'InventoryController/newCylinderStockReport';
$route['(:any)/cylinderTypeReport'] = 'InventoryController/cylinderTypeReport';
$route['(:any)/lowInventoryReport'] = 'InventoryController/lowInventoryReport';
$route['(:any)/productWiseCylinderStock'] = 'InventoryController/productWiseCylinderStock';
$route['(:any)/productLedger'] = 'InventoryController/productLedger';
$route['(:any)/brandWiseProfit'] = 'SalesController/brandWiseProfit';
$route['(:any)/fullStockReport'] = 'InventoryController/fullStockReport';
$route['(:any)/currentStockValue'] = 'InventoryController/currentStockValue';
$route['(:any)/dateWiseTotalSale'] = 'SalesController/dateWiseTotalSale';


$route['(:any)/unit'] = 'InventoryController/unit';
$route['(:any)/unitEdit/(:any)'] = 'InventoryController/unitEdit/$2';
$route['(:any)/supplierUpdate/(:any)'] = 'InventoryController/supplierUpdate/$2';
$route['(:any)/unitAdd'] = 'InventoryController/unitAdd';

$route['(:any)/productBarcode'] = 'InventoryController/productBarcode';
$route['(:any)/categoryReport'] = 'InventoryController/categoryReport';
$route['(:any)/supplierDashboard/(:any)'] = 'InventoryController/supplierDashboard/$2';



$route['(:any)/cylinderPurchases'] = 'InventoryController/cylinderPurchases';
$route['(:any)/cylinderPurchases_add'] = 'InventoryController/cylinderPurchases_add';
$route['(:any)/viewCylinder/(:any)'] = 'InventoryController/viewCylinder/$2';

$route['(:any)/cylinderExchange'] = 'InventoryController/cylinderExchange';
$route['(:any)/cylinderExchangeAdd'] = 'InventoryController/cylinderExchangeAdd';
$route['(:any)/viewCylinderExchange/(:any)'] = 'InventoryController/viewCylinderExchange/$2';

$route['(:any)/brand'] = 'InventoryController/brand';
$route['(:any)/brandAdd'] = 'InventoryController/brandAdd';
$route['(:any)/brandEdit/(:any)'] = 'InventoryController/brandEdit/$2';

$route['(:any)/inventoryAdjustment'] = 'InventoryController/inventoryAdjustment';
$route['(:any)/inventoryAdjustmentAdd'] = 'InventoryController/inventoryAdjustmentAdd';
$route['(:any)/deleteInventoryOpening/(:any)'] = 'InventoryController/deleteInventoryOpening/$2';
$route['(:any)/openigInventoryImport'] = 'InventoryController/openigInventoryImport';
$route['(:any)/viewAdjustment/(:any)'] = 'InventoryController/viewAdjustment/$2';
$route['(:any)/supplierPayment'] = 'InventoryController/supplierPayment';

$route['(:any)/supplierPaymentAdd'] = 'InventoryController/supplierPaymentAdd';
$route['(:any)/purchases_list'] = 'InventoryController/purchases_list';
$route['(:any)/purchases_add'] = 'InventoryController/purchases_add';
$route['(:any)/purchases_add/(:any)'] = 'InventoryController/purchases_add/$2';
$route['(:any)/purchases_edit/(:any)'] = 'InventoryController/purchases_edit/$2';
$route['(:any)/purchasesDelete/(:any)'] = 'InventoryController/purchasesDelete/$2';
$route['(:any)/viewPurchases/(:any)'] = 'InventoryController/viewPurchases/$2';
$route['(:any)/viewPurchasesWithCylinder/(:any)'] = 'InventoryController/viewPurchasesWithCylinder/$2';
$route['(:any)/editPurchases/(:any)'] = 'InventoryController/editPurchases/$2';

$route['(:any)/stockReport'] = 'InventoryController/stockReport';
$route['(:any)/purchasesReport'] = 'InventoryController/purchasesReport';
$route['(:any)/supplierPurchasesReport'] = 'InventoryController/supplierPurchasesReport';
$route['(:any)/supPendingCheque'] = 'InventoryController/supPendingCheque';
$route['(:any)/supplierDueList'] = 'InventoryController/supplierDueList';

/* inventory  controller end */


/* Sales Module start */

$route['(:any)/productWiseSalesReport'] = 'SalesController/productWiseSalesReport';
$route['(:any)/salesReport'] = 'SalesController/salesReport';
$route['(:any)/referenceSalesReport'] = 'SalesController/referenceSalesReport';
$route['(:any)/cancelOrder'] = 'SalesController/cancelOrder';
$route['(:any)/salesOrderCancel/(:any)'] = 'SalesController/salesOrderCancel/$2';
$route['(:any)/salesOrder'] = 'SalesController/salesOrder';
$route['(:any)/customerSalesReport'] = 'SalesController/customerSalesReport';
$route['(:any)/salesOrderAdd'] = 'SalesController/salesOrderAdd';
$route['(:any)/cylinderReceive'] = 'SalesController/cylinderReceive';
$route['(:any)/dateWiseSaleReport'] = 'SalesController/dateWiseSaleReport';
$route['(:any)/customerDueList'] = 'SalesController/customerDueList';

$route['(:any)/cylinderReceiveAdd'] = 'SalesController/cylinderReceiveAdd';
$route['(:any)/cylinderReceiveView/(:any)'] = 'SalesController/cylinderReceiveView/$2';
$route['(:any)/salesOrderView/(:any)'] = 'SalesController/salesOrderView/$2';
$route['(:any)/reference'] = 'SalesController/reference';
$route['(:any)/referenceAdd'] = 'SalesController/referenceAdd';
$route['(:any)/deleteReference/(:any)'] = 'SalesController/deleteReference/$2';
$route['(:any)/editReference/(:any)'] = 'SalesController/editReference/$2';
$route['(:any)/customerDashboard/(:any)'] = 'SalesController/customerDashboard/$2';
$route['(:any)/topSaleProduct'] = 'SalesController/topSaleProduct';

$route['(:any)/dishonourCustomerChwque/(:any)'] = 'SalesController/dishonourCustomerChwque/$2';
$route['(:any)/dishonourCustomerChwqueList'] = 'SalesController/dishonourCustomerChwqueList';
$route['(:any)/pendingCheck'] = 'SalesController/pendingCheck';
$route['(:any)/customerPaymentAdd'] = 'SalesController/customerPaymentAdd';
$route['(:any)/viewMoneryReceipt/(:any)'] = 'SalesController/viewMoneryReceipt/$2';
$route['(:any)/viewMoneryReceipt/(:any)/(:any)'] = 'SalesController/viewMoneryReceipt/$2/$3';

$route['(:any)/customerPayment'] = 'SalesController/customerPayment';
$route['(:any)/customerList'] = 'SalesController/customerList';
$route['(:any)/addCustomer'] = 'SalesController/addCustomer';
$route['(:any)/editCustomer/(:any)'] = 'SalesController/editCustomer/$2';

$route['(:any)/salesOrderConfirm/(:any)'] = 'SalesController/salesOrderConfirm/$2';
$route['(:any)/salesInvoice'] = 'SalesController/salesInvoice';
$route['(:any)/salesInvoice_add'] = 'SalesController/salesInvoice_add';
$route['(:any)/salesInvoice_add/(:any)'] = 'SalesController/salesInvoice_add/$2';
$route['(:any)/salesInvoice_edit/(:any)'] = 'SalesController/salesInvoice_edit/$2';
$route['(:any)/salesInvoice_view/(:any)'] = 'SalesController/salesInvoice_view/$2';
$route['(:any)/saleDelete/(:any)'] = 'SalesController/saleDelete/$2';
$route['(:any)/salesInvoicViewWithCylinder/(:any)'] = 'SalesController/salesInvoicViewWithCylinder/$2';



/* Sales Module end */

/* Finance Account start */
$route['(:any)/editChartOfAccount/(:any)'] = 'FinaneController/editChartOfAccount/$2';
$route['(:any)/chartOfAccount'] = 'FinaneController/chartOfAccount';
$route['(:any)/listChartOfAccount'] = 'FinaneController/listChartOfAccount';
$route['(:any)/viewChartOfAccount'] = 'FinaneController/viewChartOfAccount';
$route['(:any)/editChartOfAccount/(:any)'] = 'FinaneController/editChartOfAccount/$2';
$route['(:any)/openingBalance'] = 'FinaneController/openingBalance';
$route['(:any)/openingBalance/(:any)'] = 'FinaneController/openingBalance/$2';
$route['(:any)/deleteOpneningBalance'] = 'FinaneController/deleteOpneningBalance';
$route['(:any)/customerLedger'] = 'FinaneController/customerLedger';
$route['(:any)/supplierLedger'] = 'FinaneController/supplierLedger';
$route['(:any)/journalList'] = 'FinaneController/checkJournalVoucher';
//payment Voucher

$route['(:any)/supplierOpening'] = 'FinaneController/supplierOpening';
$route['(:any)/supplierOpeningAdd'] = 'FinaneController/supplierOpeningAdd';
$route['(:any)/customerOpneing'] = 'FinaneController/customerOpneing';
$route['(:any)/customerOpneingAdd'] = 'FinaneController/customerOpneingAdd';
$route['(:any)/customerOpneingEdit/(:any)'] = 'FinaneController/customerOpneingEdit/$2';
$route['(:any)/supplierOpeningImport'] = 'FinaneController/supplierOpeningImport';
$route['(:any)/customerOpeningImport'] = 'FinaneController/customerOpeningImport';



$route['(:any)/paymentVoucher'] = 'FinaneController/paymentVoucher';
$route['(:any)/paymentVoucherAdd'] = 'FinaneController/paymentVoucherAdd';
$route['(:any)/paymentVoucherAdd/(:any)'] = 'FinaneController/paymentVoucherAdd/$2';
$route['(:any)/paymentVoucherEdit/(:any)'] = 'FinaneController/paymentVoucherEdit/$2';
$route['(:any)/paymentVoucherView/(:any)'] = 'FinaneController/paymentVoucherView/$2';
$route['(:any)/paymentDelete/(:any)'] = 'FinaneController/paymentDelete/$2';

//Report Voucher
$route['(:any)/paymentReceiveVoucherReport'] = 'FinaneController/paymentReceiveVoucherReport';
$route['(:any)/trialBalance'] = 'FinaneController/trialBalance';
$route['(:any)/generalLedger'] = 'FinaneController/generalLedger';
$route['(:any)/generalLedger/(:any)'] = 'FinaneController/generalLedger/$2';

$route['(:any)/incomeStetement'] = 'FinaneController/incomeStetement';
$route['(:any)/balanceSheet'] = 'FinaneController/balanceSheet';
$route['(:any)/cashFlow'] = 'FinaneController/cashFlow';
$route['(:any)/cashBook'] = 'FinaneController/cashBook';
$route['(:any)/bankBook'] = 'FinaneController/bankBook';
$route['(:any)/detailsLedger/(:any)'] = 'FinaneController/detailsLedger/$2';

//bill voucher
$route['(:any)/billInvoice'] = 'FinaneController/billInvoice';
$route['(:any)/billInvoice_add'] = 'FinaneController/billInvoice_add';
$route['(:any)/billInvoicePayment/(:any)'] = 'FinaneController/billInvoicePayment/$2';
$route['(:any)/billInvoice_view/(:any)'] = 'FinaneController/billInvoice_view/$2';
$route['(:any)/billInvoice_edit/(:any)'] = 'FinaneController/billInvoice_edit/$2';

//Receive Voucher
$route['(:any)/receiveVoucher'] = 'FinaneController/receiveVoucher';
$route['(:any)/receiveVoucherAdd'] = 'FinaneController/receiveVoucherAdd';
$route['(:any)/receiveVoucherAdd/(:any)'] = 'FinaneController/receiveVoucherAdd/$2';
$route['(:any)/receiveVoucherEdit/(:any)'] = 'FinaneController/receiveVoucherEdit/$2';
$route['(:any)/receiveVoucherView/(:any)'] = 'FinaneController/receiveVoucherView/$2';
$route['(:any)/receiveVoucherDelete/(:any)'] = 'FinaneController/receiveVoucherDelete/$2';
//Journal Voucher

$route['(:any)/journalVoucher'] = 'FinaneController/journalVoucher';
$route['(:any)/journalVoucherAdd'] = 'FinaneController/journalVoucherAdd';
$route['(:any)/journalVoucherEdit/(:any)'] = 'FinaneController/journalVoucherEdit/$2';
$route['(:any)/journalVoucherView/(:any)'] = 'FinaneController/journalVoucherView/$2';
$route['(:any)/journalVoucherDelete/(:any)'] = 'FinaneController/journalVoucherDelete/$2';
$route['(:any)/getImportCustomerList'] = 'FinaneController/getImportCustomerList/$2';
$route['(:any)/getImportSupplierList'] = 'FinaneController/getImportSupplierList/$2';
$route['(:any)/getImportProductList'] = 'InventoryController/getImportProductList/$2';

/* Pos routign */
$route['(:any)/salesPos'] = 'PosController/salesPosAdd';
$route['(:any)/salesPosList'] = 'PosController/salesPosList';
/* Pos routign */
/* Finance Account End */
$route['(:any)/404_override'] = '';
$route['(:any)/translate_uri_dashes'] = FALSE;
$route['(:any)/testhelper'] = 'InventoryController/abstest';



$route['(:any)/salesReturn'] = 'ReturnDagameController/salesReturn';
$route['(:any)/salesReturnAdd'] = 'ReturnDagameController/salesReturnAdd';
$route['(:any)/showAllInvoiceListByDate'] = 'ReturnDagameController/showAllInvoiceListByDate';
$route['(:any)/getInvoiceProductList'] = 'ReturnDagameController/getInvoiceProductList';
$route['(:any)/getDateList'] = 'ReturnDagameController/getDateList';
$route['(:any)/getInvoiceListbyCustomerIdAndDate'] = 'ReturnDagameController/getInvoiceListbyCustomerIdAndDate';
$route['(:any)/viewSalesReturn/(:any)'] = 'ReturnDagameController/viewSalesReturn/$2';

$route['(:any)/damageProduct'] = 'ReturnDagameController/damageProduct';
$route['(:any)/damageProductAdd'] = 'ReturnDagameController/damageProductAdd';
$route['(:any)/deleteDamageProduct/(:any)'] = 'ReturnDagameController/deleteDamageProduct/$2';


