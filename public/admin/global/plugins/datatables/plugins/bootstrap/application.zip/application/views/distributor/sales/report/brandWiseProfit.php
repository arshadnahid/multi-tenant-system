<?php
if (isset($_POST['start_date'])):
    $start_date = $this->input->post('start_date');
    $end_date = $this->input->post('end_date');
    $productType = $this->input->post('productType');
    $brandId = $this->input->post('brandId');
endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Report</li>
                <li class="active">Brand Wise Profit</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/sales'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12 noPrint">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <div class="col-sm-12">
                            <div class="table-header">
                                Brand Wise Profit Report
                            </div>
                            <br>
                            <div style="background-color: grey!important;">
                                <input type="hidden" name="productType" value="all"/>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="col-md-4 control-label no-padding-right" for="form-field-1"> Product Brand </label>
                                        <div class="col-md-8">
                                            <select name="brandId" id="productID"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search Product Brand " style="width: 100%">
                                                <option <?php
                                                if ($brandId == 'all') {
                                                    echo "selected";
                                                }
                                                ?> value="all">All</option>
                                                    <?php foreach ($brandList as $key => $eachBrand): ?>
                                                    <option <?php
                                                    if (!empty($brandId) && $brandId == $eachBrand->brandId): echo "selected";
                                                    endif;
                                                        ?> value="<?php echo $eachBrand->brandId; ?>"><?php echo $eachBrand->brandName; ?>
                                                    </option>
                                                <?php endforeach;
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-5 control-label no-padding-right" for="form-field-1"> From Date</label>
                                        <div class="col-sm-7">
                                            <input type="text" style="width:100%"  class="date-picker" id="start_date" name="start_date" value="<?php
                                                if (!empty($start_date)) {
                                                    echo $start_date;
                                                } else {
                                                    echo date('d-m-Y');
                                                }
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="col-sm-5 control-label no-padding-right" for="form-field-1"> To Date</label>
                                        <div class="col-sm-7">
                                            <input type="text"  style="width:100%"  class="date-picker" id="end_date" name="end_date" value="<?php
                                                   if (!empty($end_date)) {
                                                       echo $end_date;
                                                   } else {
                                                       echo date('d-m-Y');
                                                   }
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="End Date: dd-mm-yyyy"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1"></label>
                                        <div class="col-sm-5">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                                Search
                                            </button>
                                        </div>
                                        <div class="col-sm-5">
                                            <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                                <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                                Print
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($brandWiseProfit)):
                ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-header">
                            Brand Wise Profit <span style="color:greenyellow;">From <?php echo $start_date; ?> To <?php echo $end_date; ?></span>
                        </div>
                        <table class="table table-responsive">
                            <tr>
                                <td style="text-align:center;">
                                    <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                    <span><?php echo $companyInfo->address; ?></span><br>
                                    <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                    <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                    <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                    <strong>Brand Wise Profit</strong>
                                </td>
                            </tr>
                        </table>
                        <table class="table table-striped table-bordered table-hover table-responsive" id="mergeTable">
                            <thead>
                                <tr>
                                    <!--<td align="center"><strong>Product Type</strong></td>-->
                                    <td align="left"><strong>SL</strong></td>
                                    <td align="left"><strong>Brand</strong></td>
                                    <td align="left"><strong>Product</strong></td>
                                    <td align="left"><strong>Sales Price</strong></td>
                                    <td align="right"><strong>Sales Quantity</strong></td>
                                    <td align="right"><strong>Avg. Purchase price</strong></td>
                                    <td align="right"><strong>Total Purchase price</strong></td>
                                    <td align="right"><strong>Gross Profit</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $totalGp = '';
                                $totalQty = '';
                                $sl=1;
                                foreach ($brandWiseProfit as $key => $eachInfo):
                                    if (!empty($eachInfo->totalSalesQty) && $eachInfo->totalSalesQty > 0):
                                        ?>
                                        <tr>
                                            <td><?php echo $sl++;?></td>
                                            <!--<td><?php echo $eachInfo->product_type_name; ?></td>-->
                                            <td><?php echo $eachInfo->brandName; ?></td>
                                            <td><?php echo $eachInfo->productName; ?></td>
                                            <td  align="right"><?php echo $eachInfo->totalSalesPrice; ?></td>
                                            <td  align="right"><?php echo number_format((float) $eachInfo->totalSalesQty, 2, '.', ','); ?></td>
                                             <td  align="right"><?php echo number_format((float) $eachInfo->avgPurchasesPrice, 2, '.', ','); ?></td>
                                             <td  align="right"><?php echo number_format((float) $eachInfo->avgPurchasesPrice*$eachInfo->totalSalesQty, 2, '.', ','); ?></td>
                                            <td align="right"><?php
                            $gpAmount = $eachInfo->totalSalesPrice - ($eachInfo->totalSalesQty * $eachInfo->avgPurchasesPrice);
                            echo number_format((float) $gpAmount, 2, '.', ',');
                            $totalQty+=$eachInfo->totalSalesQty;
                            $totalGp+=$eachInfo->totalSalesPrice - ($eachInfo->totalSalesQty * $eachInfo->avgPurchasesPrice);
                                        ?></td>
                                        </tr>
                                        <?php
                                    endif;
                                endforeach;
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" align="right"><strong>Total </strong></td>
                                    <td align="right"><?php echo $totalQty; ?></td>
                                    <td align="right"><?php echo number_format((float) $totalGp, 2, '.', ','); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

<script>

    MergeCommonRowsForSearchResult($('#mergeTable'), 1, 0);
    function MergeCommonRowsForSearchResult(table, startCol, HowManyCol) {
        var firstColumnBrakes = [];
        // iterate through the columns instead of passing each column as function parameter:
        for (var i = startCol; i <= (startCol + HowManyCol); i++) {
            var previous = null, cellToExtend = null, rowspan = 1;
            table.find("td:nth-child(" + i + ")").each(function (index, e) {
                var jthis = $(this), content = jthis.text();

                // check if current row "break" exist in the array. If not, then extend rowspan:
                if (previous == content && content !== "" && $.inArray(index, firstColumnBrakes) === -1) {
                    console.log(content);
                    // hide the row instead of remove(), so the DOM index won't "move" inside loop.
                    jthis.addClass('hidden');
                    cellToExtend.attr("rowspan", (rowspan = rowspan + 1));
                    //sum
                } else {
                    // store row breaks only for the first column:
                    if (i === 1)
                        firstColumnBrakes.push(index);
                    rowspan = 1;
                    previous = content;
                    cellToExtend = jthis;
                }

            });
            //sumColValue(table,startCol);
        }

        // now remove hidden td's (or leave them hidden if you wish):
        $('td.hidden').remove();
    }


</script>

