<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Setup</a>
                </li>
                <li class="active">User List</li>
            </ul>

            <ul class="breadcrumb pull-right">

                <li class="active addPermission"><a href="<?php echo site_url($this->project . '/addBank'); ?>" >
                        <i class="ace-icon 	fa fa-plus"></i>  Add
                    </a>
                </li>

            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <!--                <h3 class="header smaller lighter blue"></h3>

                                <div class="clearfix">
                                    <div class="pull-right tableTools-container"></div>
                                </div>-->
                <div class="table-header">
                    Bank List
                </div>
                <!-- div.table-responsive -->
                <!-- div.dataTables_borderWrap -->
                <div>
                    <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Name</th>
                                <th>Branch Name</th>
                                <th>Account No</th>
                                <th>Address</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($bankList as $key => $value):
                                ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo $value->bankName; ?></td>
                                    <td><?php echo $value->branchName; ?></td>
                                    <td><?php echo $value->bankAccount; ?></td>
                                    <td><?php echo $value->bankAddress; ?></td>
                                    <td>
                                        <div class="hidden-sm hidden-xs action-buttons">
                                            <a class="green" href="<?php echo site_url($this->project . '/editBank/' . $value->bankId); ?>">
                                                <i class="ace-icon fa fa-pencil bigger-130"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div><script src="<?php echo base_url('assets/setup.js'); ?>"></script>
