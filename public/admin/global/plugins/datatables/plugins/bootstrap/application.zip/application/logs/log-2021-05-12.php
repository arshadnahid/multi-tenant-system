<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-12 00:25:43 --> Config Class Initialized
INFO - 2021-05-12 00:25:43 --> Hooks Class Initialized
DEBUG - 2021-05-12 00:25:43 --> UTF-8 Support Enabled
INFO - 2021-05-12 00:25:43 --> Utf8 Class Initialized
INFO - 2021-05-12 00:25:43 --> URI Class Initialized
DEBUG - 2021-05-12 00:25:43 --> No URI present. Default controller set.
INFO - 2021-05-12 00:25:43 --> Router Class Initialized
INFO - 2021-05-12 00:25:43 --> Output Class Initialized
INFO - 2021-05-12 00:25:43 --> Security Class Initialized
DEBUG - 2021-05-12 00:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 00:25:43 --> Input Class Initialized
INFO - 2021-05-12 00:25:43 --> Language Class Initialized
INFO - 2021-05-12 00:25:43 --> Loader Class Initialized
INFO - 2021-05-12 00:25:43 --> Helper loaded: url_helper
INFO - 2021-05-12 00:25:43 --> Helper loaded: file_helper
INFO - 2021-05-12 00:25:43 --> Helper loaded: utility_helper
INFO - 2021-05-12 00:25:43 --> Helper loaded: unit_helper
INFO - 2021-05-12 00:25:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 00:25:43 --> Database Driver Class Initialized
INFO - 2021-05-12 00:25:43 --> Email Class Initialized
DEBUG - 2021-05-12 00:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 00:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 00:25:43 --> Helper loaded: form_helper
INFO - 2021-05-12 00:25:43 --> Form Validation Class Initialized
INFO - 2021-05-12 00:25:43 --> Controller Class Initialized
INFO - 2021-05-12 00:25:43 --> Model "Common_model" initialized
INFO - 2021-05-12 00:25:43 --> Model "Finane_Model" initialized
INFO - 2021-05-12 00:25:43 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 00:25:43 --> Model "Sales_Model" initialized
INFO - 2021-05-12 00:25:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 00:25:43 --> Final output sent to browser
DEBUG - 2021-05-12 00:25:43 --> Total execution time: 0.1097
INFO - 2021-05-12 01:07:10 --> Config Class Initialized
INFO - 2021-05-12 01:07:10 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:07:10 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:07:10 --> Utf8 Class Initialized
INFO - 2021-05-12 01:07:10 --> URI Class Initialized
DEBUG - 2021-05-12 01:07:10 --> No URI present. Default controller set.
INFO - 2021-05-12 01:07:10 --> Router Class Initialized
INFO - 2021-05-12 01:07:10 --> Output Class Initialized
INFO - 2021-05-12 01:07:10 --> Security Class Initialized
DEBUG - 2021-05-12 01:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:07:10 --> Input Class Initialized
INFO - 2021-05-12 01:07:10 --> Language Class Initialized
INFO - 2021-05-12 01:07:10 --> Loader Class Initialized
INFO - 2021-05-12 01:07:10 --> Helper loaded: url_helper
INFO - 2021-05-12 01:07:10 --> Helper loaded: file_helper
INFO - 2021-05-12 01:07:10 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:07:10 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:07:10 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:07:10 --> Database Driver Class Initialized
INFO - 2021-05-12 01:07:10 --> Email Class Initialized
DEBUG - 2021-05-12 01:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:07:10 --> Helper loaded: form_helper
INFO - 2021-05-12 01:07:10 --> Form Validation Class Initialized
INFO - 2021-05-12 01:07:10 --> Controller Class Initialized
INFO - 2021-05-12 01:07:10 --> Model "Common_model" initialized
INFO - 2021-05-12 01:07:10 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:07:10 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:07:10 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:07:10 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:07:10 --> Final output sent to browser
DEBUG - 2021-05-12 01:07:10 --> Total execution time: 0.0676
INFO - 2021-05-12 01:17:23 --> Config Class Initialized
INFO - 2021-05-12 01:17:23 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:23 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:23 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:23 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:23 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:23 --> Router Class Initialized
INFO - 2021-05-12 01:17:23 --> Output Class Initialized
INFO - 2021-05-12 01:17:23 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:23 --> Input Class Initialized
INFO - 2021-05-12 01:17:23 --> Language Class Initialized
INFO - 2021-05-12 01:17:23 --> Loader Class Initialized
INFO - 2021-05-12 01:17:23 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:23 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:23 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:23 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:23 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:23 --> Controller Class Initialized
INFO - 2021-05-12 01:17:23 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:23 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:23 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:23 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:23 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:23 --> Total execution time: 0.0561
INFO - 2021-05-12 01:17:23 --> Config Class Initialized
INFO - 2021-05-12 01:17:23 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:23 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:23 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:23 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:23 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:23 --> Router Class Initialized
INFO - 2021-05-12 01:17:23 --> Output Class Initialized
INFO - 2021-05-12 01:17:23 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:23 --> Input Class Initialized
INFO - 2021-05-12 01:17:23 --> Language Class Initialized
INFO - 2021-05-12 01:17:23 --> Loader Class Initialized
INFO - 2021-05-12 01:17:23 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:23 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:23 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:23 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:23 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:23 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:23 --> Controller Class Initialized
INFO - 2021-05-12 01:17:24 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:24 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:24 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:24 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:24 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:24 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:24 --> Total execution time: 0.0625
INFO - 2021-05-12 01:17:25 --> Config Class Initialized
INFO - 2021-05-12 01:17:25 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:25 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:25 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:25 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:25 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:25 --> Router Class Initialized
INFO - 2021-05-12 01:17:25 --> Output Class Initialized
INFO - 2021-05-12 01:17:25 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:25 --> Input Class Initialized
INFO - 2021-05-12 01:17:25 --> Language Class Initialized
INFO - 2021-05-12 01:17:25 --> Loader Class Initialized
INFO - 2021-05-12 01:17:25 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:25 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:25 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:25 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:25 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:25 --> Controller Class Initialized
INFO - 2021-05-12 01:17:25 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:25 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:25 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:25 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:25 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:25 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:25 --> Total execution time: 0.0540
INFO - 2021-05-12 01:17:25 --> Config Class Initialized
INFO - 2021-05-12 01:17:25 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:25 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:25 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:25 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:25 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:25 --> Router Class Initialized
INFO - 2021-05-12 01:17:25 --> Output Class Initialized
INFO - 2021-05-12 01:17:25 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:25 --> Input Class Initialized
INFO - 2021-05-12 01:17:25 --> Language Class Initialized
INFO - 2021-05-12 01:17:25 --> Loader Class Initialized
INFO - 2021-05-12 01:17:25 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:25 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:25 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:25 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:25 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:25 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:25 --> Controller Class Initialized
INFO - 2021-05-12 01:17:25 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:25 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:25 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:25 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:25 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:25 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:25 --> Total execution time: 0.0411
INFO - 2021-05-12 01:17:26 --> Config Class Initialized
INFO - 2021-05-12 01:17:26 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:26 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:26 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:26 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:26 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:26 --> Router Class Initialized
INFO - 2021-05-12 01:17:26 --> Output Class Initialized
INFO - 2021-05-12 01:17:26 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:26 --> Input Class Initialized
INFO - 2021-05-12 01:17:26 --> Language Class Initialized
INFO - 2021-05-12 01:17:26 --> Loader Class Initialized
INFO - 2021-05-12 01:17:26 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:26 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:26 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:26 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:26 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:26 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:26 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:26 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:26 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:26 --> Controller Class Initialized
INFO - 2021-05-12 01:17:26 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:26 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:26 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:26 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:26 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:26 --> Total execution time: 0.0398
INFO - 2021-05-12 01:17:27 --> Config Class Initialized
INFO - 2021-05-12 01:17:27 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:27 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:27 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:27 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:27 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:27 --> Router Class Initialized
INFO - 2021-05-12 01:17:27 --> Output Class Initialized
INFO - 2021-05-12 01:17:27 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:27 --> Input Class Initialized
INFO - 2021-05-12 01:17:27 --> Language Class Initialized
INFO - 2021-05-12 01:17:27 --> Loader Class Initialized
INFO - 2021-05-12 01:17:27 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:27 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:27 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:27 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:27 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:27 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:27 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:27 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:27 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:27 --> Controller Class Initialized
INFO - 2021-05-12 01:17:27 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:27 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:27 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:27 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:27 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:27 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:27 --> Total execution time: 0.0412
INFO - 2021-05-12 01:17:28 --> Config Class Initialized
INFO - 2021-05-12 01:17:28 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:28 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:28 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:28 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:28 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:28 --> Router Class Initialized
INFO - 2021-05-12 01:17:28 --> Output Class Initialized
INFO - 2021-05-12 01:17:28 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:28 --> Input Class Initialized
INFO - 2021-05-12 01:17:28 --> Language Class Initialized
INFO - 2021-05-12 01:17:28 --> Loader Class Initialized
INFO - 2021-05-12 01:17:28 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:28 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:28 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:28 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:28 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:28 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:28 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:28 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:28 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:28 --> Controller Class Initialized
INFO - 2021-05-12 01:17:28 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:28 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:28 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:28 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:28 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:28 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:28 --> Total execution time: 0.0409
INFO - 2021-05-12 01:17:29 --> Config Class Initialized
INFO - 2021-05-12 01:17:29 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:29 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:29 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:29 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:29 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:29 --> Router Class Initialized
INFO - 2021-05-12 01:17:29 --> Output Class Initialized
INFO - 2021-05-12 01:17:29 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:29 --> Input Class Initialized
INFO - 2021-05-12 01:17:29 --> Language Class Initialized
INFO - 2021-05-12 01:17:29 --> Loader Class Initialized
INFO - 2021-05-12 01:17:29 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:29 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:29 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:29 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:29 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:29 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:29 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:29 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:29 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:29 --> Controller Class Initialized
INFO - 2021-05-12 01:17:29 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:29 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:29 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:29 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:29 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:29 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:29 --> Total execution time: 0.0396
INFO - 2021-05-12 01:17:30 --> Config Class Initialized
INFO - 2021-05-12 01:17:30 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:30 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:30 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:30 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:30 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:30 --> Router Class Initialized
INFO - 2021-05-12 01:17:30 --> Output Class Initialized
INFO - 2021-05-12 01:17:30 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:30 --> Input Class Initialized
INFO - 2021-05-12 01:17:30 --> Language Class Initialized
INFO - 2021-05-12 01:17:30 --> Loader Class Initialized
INFO - 2021-05-12 01:17:30 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:30 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:30 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:30 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:30 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:30 --> Controller Class Initialized
INFO - 2021-05-12 01:17:30 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:30 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:30 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:30 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:30 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:30 --> Total execution time: 0.0615
INFO - 2021-05-12 01:17:30 --> Config Class Initialized
INFO - 2021-05-12 01:17:30 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:30 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:30 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:30 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:30 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:30 --> Router Class Initialized
INFO - 2021-05-12 01:17:30 --> Output Class Initialized
INFO - 2021-05-12 01:17:30 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:30 --> Input Class Initialized
INFO - 2021-05-12 01:17:30 --> Language Class Initialized
INFO - 2021-05-12 01:17:30 --> Loader Class Initialized
INFO - 2021-05-12 01:17:30 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:30 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:30 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:30 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:30 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:30 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:30 --> Controller Class Initialized
INFO - 2021-05-12 01:17:30 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:30 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:30 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:30 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:30 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:30 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:30 --> Total execution time: 0.0389
INFO - 2021-05-12 01:17:31 --> Config Class Initialized
INFO - 2021-05-12 01:17:31 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:31 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:31 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:31 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:31 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:31 --> Router Class Initialized
INFO - 2021-05-12 01:17:31 --> Output Class Initialized
INFO - 2021-05-12 01:17:31 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:31 --> Input Class Initialized
INFO - 2021-05-12 01:17:31 --> Language Class Initialized
INFO - 2021-05-12 01:17:31 --> Loader Class Initialized
INFO - 2021-05-12 01:17:31 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:31 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:31 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:31 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:31 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:31 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:31 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:31 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:31 --> Controller Class Initialized
INFO - 2021-05-12 01:17:31 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:31 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:31 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:31 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:31 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:31 --> Total execution time: 0.0552
INFO - 2021-05-12 01:17:32 --> Config Class Initialized
INFO - 2021-05-12 01:17:32 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:32 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:32 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:32 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:32 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:32 --> Router Class Initialized
INFO - 2021-05-12 01:17:32 --> Output Class Initialized
INFO - 2021-05-12 01:17:32 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:32 --> Input Class Initialized
INFO - 2021-05-12 01:17:32 --> Language Class Initialized
INFO - 2021-05-12 01:17:32 --> Loader Class Initialized
INFO - 2021-05-12 01:17:32 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:32 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:32 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:32 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:32 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:32 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:32 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:32 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:32 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:32 --> Controller Class Initialized
INFO - 2021-05-12 01:17:32 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:32 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:32 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:32 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:32 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:32 --> Total execution time: 0.0402
INFO - 2021-05-12 01:17:33 --> Config Class Initialized
INFO - 2021-05-12 01:17:33 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:33 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:33 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:33 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:33 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:33 --> Router Class Initialized
INFO - 2021-05-12 01:17:33 --> Output Class Initialized
INFO - 2021-05-12 01:17:33 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:33 --> Input Class Initialized
INFO - 2021-05-12 01:17:33 --> Language Class Initialized
INFO - 2021-05-12 01:17:33 --> Loader Class Initialized
INFO - 2021-05-12 01:17:33 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:33 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:33 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:33 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:33 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:33 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:33 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:33 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:33 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:33 --> Controller Class Initialized
INFO - 2021-05-12 01:17:33 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:33 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:33 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:33 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:33 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:33 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:33 --> Total execution time: 0.0536
INFO - 2021-05-12 01:17:34 --> Config Class Initialized
INFO - 2021-05-12 01:17:34 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:34 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:34 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:34 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:34 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:34 --> Router Class Initialized
INFO - 2021-05-12 01:17:34 --> Output Class Initialized
INFO - 2021-05-12 01:17:34 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:34 --> Input Class Initialized
INFO - 2021-05-12 01:17:34 --> Language Class Initialized
INFO - 2021-05-12 01:17:34 --> Loader Class Initialized
INFO - 2021-05-12 01:17:34 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:34 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:34 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:34 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:34 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:34 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:34 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:34 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:34 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:34 --> Controller Class Initialized
INFO - 2021-05-12 01:17:34 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:35 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:35 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:35 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:35 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:35 --> Total execution time: 0.0453
INFO - 2021-05-12 01:17:35 --> Config Class Initialized
INFO - 2021-05-12 01:17:35 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:35 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:35 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:35 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:35 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:35 --> Router Class Initialized
INFO - 2021-05-12 01:17:35 --> Output Class Initialized
INFO - 2021-05-12 01:17:35 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:35 --> Input Class Initialized
INFO - 2021-05-12 01:17:35 --> Language Class Initialized
INFO - 2021-05-12 01:17:35 --> Loader Class Initialized
INFO - 2021-05-12 01:17:35 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:35 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:35 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:35 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:35 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:35 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:35 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:35 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:35 --> Controller Class Initialized
INFO - 2021-05-12 01:17:35 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:35 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:35 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:35 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:35 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:35 --> Total execution time: 0.0558
INFO - 2021-05-12 01:17:36 --> Config Class Initialized
INFO - 2021-05-12 01:17:36 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:36 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:36 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:36 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:36 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:36 --> Router Class Initialized
INFO - 2021-05-12 01:17:36 --> Output Class Initialized
INFO - 2021-05-12 01:17:36 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:36 --> Input Class Initialized
INFO - 2021-05-12 01:17:36 --> Language Class Initialized
INFO - 2021-05-12 01:17:36 --> Loader Class Initialized
INFO - 2021-05-12 01:17:36 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:36 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:36 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:36 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:36 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:36 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:36 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:36 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:36 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:36 --> Controller Class Initialized
INFO - 2021-05-12 01:17:36 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:36 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:36 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:36 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:36 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:36 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:36 --> Total execution time: 0.0403
INFO - 2021-05-12 01:17:37 --> Config Class Initialized
INFO - 2021-05-12 01:17:37 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:37 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:37 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:37 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:37 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:37 --> Router Class Initialized
INFO - 2021-05-12 01:17:37 --> Output Class Initialized
INFO - 2021-05-12 01:17:37 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:37 --> Input Class Initialized
INFO - 2021-05-12 01:17:37 --> Language Class Initialized
INFO - 2021-05-12 01:17:37 --> Loader Class Initialized
INFO - 2021-05-12 01:17:37 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:37 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:37 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:37 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:37 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:37 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:37 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:37 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:37 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:37 --> Controller Class Initialized
INFO - 2021-05-12 01:17:37 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:37 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:37 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:37 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:37 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:37 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:37 --> Total execution time: 0.0498
INFO - 2021-05-12 01:17:38 --> Config Class Initialized
INFO - 2021-05-12 01:17:38 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:38 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:38 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:38 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:38 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:38 --> Router Class Initialized
INFO - 2021-05-12 01:17:38 --> Output Class Initialized
INFO - 2021-05-12 01:17:38 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:38 --> Input Class Initialized
INFO - 2021-05-12 01:17:38 --> Language Class Initialized
INFO - 2021-05-12 01:17:38 --> Loader Class Initialized
INFO - 2021-05-12 01:17:38 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:38 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:38 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:38 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:38 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:38 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:38 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:38 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:38 --> Controller Class Initialized
INFO - 2021-05-12 01:17:38 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:38 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:38 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:38 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:38 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:38 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:38 --> Total execution time: 0.0656
INFO - 2021-05-12 01:17:39 --> Config Class Initialized
INFO - 2021-05-12 01:17:39 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:39 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:39 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:39 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:39 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:39 --> Router Class Initialized
INFO - 2021-05-12 01:17:39 --> Output Class Initialized
INFO - 2021-05-12 01:17:39 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:39 --> Input Class Initialized
INFO - 2021-05-12 01:17:39 --> Language Class Initialized
INFO - 2021-05-12 01:17:39 --> Loader Class Initialized
INFO - 2021-05-12 01:17:39 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:39 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:39 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:39 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:39 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:39 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:39 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:39 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:39 --> Controller Class Initialized
INFO - 2021-05-12 01:17:39 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:39 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:39 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:39 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:39 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:39 --> Total execution time: 0.0508
INFO - 2021-05-12 01:17:40 --> Config Class Initialized
INFO - 2021-05-12 01:17:40 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:40 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:40 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:40 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:40 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:40 --> Router Class Initialized
INFO - 2021-05-12 01:17:40 --> Output Class Initialized
INFO - 2021-05-12 01:17:40 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:40 --> Input Class Initialized
INFO - 2021-05-12 01:17:40 --> Language Class Initialized
INFO - 2021-05-12 01:17:40 --> Loader Class Initialized
INFO - 2021-05-12 01:17:40 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:40 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:40 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:40 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:40 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:40 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:40 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:40 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:40 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:40 --> Controller Class Initialized
INFO - 2021-05-12 01:17:40 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:40 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:40 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:40 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:40 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:40 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:40 --> Total execution time: 0.0536
INFO - 2021-05-12 01:17:41 --> Config Class Initialized
INFO - 2021-05-12 01:17:41 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:41 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:41 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:41 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:41 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:41 --> Router Class Initialized
INFO - 2021-05-12 01:17:41 --> Output Class Initialized
INFO - 2021-05-12 01:17:41 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:41 --> Input Class Initialized
INFO - 2021-05-12 01:17:41 --> Language Class Initialized
INFO - 2021-05-12 01:17:41 --> Loader Class Initialized
INFO - 2021-05-12 01:17:41 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:41 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:41 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:41 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:41 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:41 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:41 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:41 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:41 --> Controller Class Initialized
INFO - 2021-05-12 01:17:41 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:41 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:41 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:41 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:41 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:41 --> Total execution time: 0.0602
INFO - 2021-05-12 01:17:43 --> Config Class Initialized
INFO - 2021-05-12 01:17:43 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:43 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:43 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:43 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:43 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:43 --> Router Class Initialized
INFO - 2021-05-12 01:17:43 --> Output Class Initialized
INFO - 2021-05-12 01:17:43 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:43 --> Input Class Initialized
INFO - 2021-05-12 01:17:43 --> Language Class Initialized
INFO - 2021-05-12 01:17:43 --> Loader Class Initialized
INFO - 2021-05-12 01:17:43 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:43 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:43 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:43 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:43 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:43 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:43 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:43 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:43 --> Controller Class Initialized
INFO - 2021-05-12 01:17:43 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:43 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:43 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:43 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:43 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:43 --> Total execution time: 0.0426
INFO - 2021-05-12 01:17:44 --> Config Class Initialized
INFO - 2021-05-12 01:17:44 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:44 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:44 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:44 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:44 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:44 --> Router Class Initialized
INFO - 2021-05-12 01:17:44 --> Output Class Initialized
INFO - 2021-05-12 01:17:44 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:44 --> Input Class Initialized
INFO - 2021-05-12 01:17:44 --> Language Class Initialized
INFO - 2021-05-12 01:17:44 --> Loader Class Initialized
INFO - 2021-05-12 01:17:44 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:44 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:44 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:44 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:44 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:44 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:44 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:44 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:44 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:44 --> Controller Class Initialized
INFO - 2021-05-12 01:17:44 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:44 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:44 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:44 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:44 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:44 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:44 --> Total execution time: 0.0434
INFO - 2021-05-12 01:17:45 --> Config Class Initialized
INFO - 2021-05-12 01:17:45 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:45 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:45 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:45 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:45 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:45 --> Router Class Initialized
INFO - 2021-05-12 01:17:45 --> Output Class Initialized
INFO - 2021-05-12 01:17:45 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:45 --> Input Class Initialized
INFO - 2021-05-12 01:17:45 --> Language Class Initialized
INFO - 2021-05-12 01:17:45 --> Loader Class Initialized
INFO - 2021-05-12 01:17:45 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:45 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:45 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:45 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:45 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:45 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:45 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:45 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:45 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:45 --> Controller Class Initialized
INFO - 2021-05-12 01:17:45 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:45 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:45 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:45 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:45 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:45 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:45 --> Total execution time: 0.0452
INFO - 2021-05-12 01:17:47 --> Config Class Initialized
INFO - 2021-05-12 01:17:47 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:47 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:47 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:47 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:47 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:47 --> Router Class Initialized
INFO - 2021-05-12 01:17:47 --> Output Class Initialized
INFO - 2021-05-12 01:17:47 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:47 --> Input Class Initialized
INFO - 2021-05-12 01:17:47 --> Language Class Initialized
INFO - 2021-05-12 01:17:47 --> Loader Class Initialized
INFO - 2021-05-12 01:17:47 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:47 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:47 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:47 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:47 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:47 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:47 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:47 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:47 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:47 --> Controller Class Initialized
INFO - 2021-05-12 01:17:47 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:47 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:47 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:47 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:47 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:47 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:47 --> Total execution time: 0.0422
INFO - 2021-05-12 01:17:48 --> Config Class Initialized
INFO - 2021-05-12 01:17:48 --> Hooks Class Initialized
DEBUG - 2021-05-12 01:17:48 --> UTF-8 Support Enabled
INFO - 2021-05-12 01:17:48 --> Utf8 Class Initialized
INFO - 2021-05-12 01:17:48 --> URI Class Initialized
DEBUG - 2021-05-12 01:17:48 --> No URI present. Default controller set.
INFO - 2021-05-12 01:17:48 --> Router Class Initialized
INFO - 2021-05-12 01:17:48 --> Output Class Initialized
INFO - 2021-05-12 01:17:48 --> Security Class Initialized
DEBUG - 2021-05-12 01:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 01:17:48 --> Input Class Initialized
INFO - 2021-05-12 01:17:48 --> Language Class Initialized
INFO - 2021-05-12 01:17:48 --> Loader Class Initialized
INFO - 2021-05-12 01:17:48 --> Helper loaded: url_helper
INFO - 2021-05-12 01:17:48 --> Helper loaded: file_helper
INFO - 2021-05-12 01:17:48 --> Helper loaded: utility_helper
INFO - 2021-05-12 01:17:48 --> Helper loaded: unit_helper
INFO - 2021-05-12 01:17:48 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 01:17:48 --> Database Driver Class Initialized
INFO - 2021-05-12 01:17:48 --> Email Class Initialized
DEBUG - 2021-05-12 01:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 01:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 01:17:48 --> Helper loaded: form_helper
INFO - 2021-05-12 01:17:48 --> Form Validation Class Initialized
INFO - 2021-05-12 01:17:48 --> Controller Class Initialized
INFO - 2021-05-12 01:17:48 --> Model "Common_model" initialized
INFO - 2021-05-12 01:17:48 --> Model "Finane_Model" initialized
INFO - 2021-05-12 01:17:48 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 01:17:48 --> Model "Sales_Model" initialized
INFO - 2021-05-12 01:17:48 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 01:17:48 --> Final output sent to browser
DEBUG - 2021-05-12 01:17:48 --> Total execution time: 0.0450
INFO - 2021-05-12 02:47:54 --> Config Class Initialized
INFO - 2021-05-12 02:47:54 --> Hooks Class Initialized
DEBUG - 2021-05-12 02:47:54 --> UTF-8 Support Enabled
INFO - 2021-05-12 02:47:54 --> Utf8 Class Initialized
INFO - 2021-05-12 02:47:54 --> URI Class Initialized
DEBUG - 2021-05-12 02:47:54 --> No URI present. Default controller set.
INFO - 2021-05-12 02:47:54 --> Router Class Initialized
INFO - 2021-05-12 02:47:54 --> Output Class Initialized
INFO - 2021-05-12 02:47:54 --> Security Class Initialized
DEBUG - 2021-05-12 02:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 02:47:54 --> Input Class Initialized
INFO - 2021-05-12 02:47:54 --> Language Class Initialized
INFO - 2021-05-12 02:47:54 --> Loader Class Initialized
INFO - 2021-05-12 02:47:54 --> Helper loaded: url_helper
INFO - 2021-05-12 02:47:54 --> Helper loaded: file_helper
INFO - 2021-05-12 02:47:54 --> Helper loaded: utility_helper
INFO - 2021-05-12 02:47:54 --> Helper loaded: unit_helper
INFO - 2021-05-12 02:47:54 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 02:47:54 --> Database Driver Class Initialized
INFO - 2021-05-12 02:47:54 --> Email Class Initialized
DEBUG - 2021-05-12 02:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 02:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 02:47:54 --> Helper loaded: form_helper
INFO - 2021-05-12 02:47:54 --> Form Validation Class Initialized
INFO - 2021-05-12 02:47:54 --> Controller Class Initialized
INFO - 2021-05-12 02:47:54 --> Model "Common_model" initialized
INFO - 2021-05-12 02:47:54 --> Model "Finane_Model" initialized
INFO - 2021-05-12 02:47:54 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 02:47:54 --> Model "Sales_Model" initialized
INFO - 2021-05-12 02:47:54 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 02:47:54 --> Final output sent to browser
DEBUG - 2021-05-12 02:47:54 --> Total execution time: 0.0462
INFO - 2021-05-12 04:33:31 --> Config Class Initialized
INFO - 2021-05-12 04:33:31 --> Hooks Class Initialized
DEBUG - 2021-05-12 04:33:31 --> UTF-8 Support Enabled
INFO - 2021-05-12 04:33:31 --> Utf8 Class Initialized
INFO - 2021-05-12 04:33:31 --> URI Class Initialized
INFO - 2021-05-12 04:33:31 --> Router Class Initialized
INFO - 2021-05-12 04:33:31 --> Output Class Initialized
INFO - 2021-05-12 04:33:31 --> Security Class Initialized
DEBUG - 2021-05-12 04:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 04:33:31 --> Input Class Initialized
INFO - 2021-05-12 04:33:31 --> Language Class Initialized
INFO - 2021-05-12 04:33:31 --> Loader Class Initialized
INFO - 2021-05-12 04:33:31 --> Helper loaded: url_helper
INFO - 2021-05-12 04:33:31 --> Helper loaded: file_helper
INFO - 2021-05-12 04:33:31 --> Helper loaded: utility_helper
INFO - 2021-05-12 04:33:31 --> Helper loaded: unit_helper
INFO - 2021-05-12 04:33:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 04:33:31 --> Database Driver Class Initialized
INFO - 2021-05-12 04:33:31 --> Email Class Initialized
DEBUG - 2021-05-12 04:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 04:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 04:33:31 --> Helper loaded: form_helper
INFO - 2021-05-12 04:33:31 --> Form Validation Class Initialized
INFO - 2021-05-12 04:33:31 --> Controller Class Initialized
INFO - 2021-05-12 04:33:31 --> Model "Common_model" initialized
INFO - 2021-05-12 04:33:31 --> Model "Finane_Model" initialized
INFO - 2021-05-12 04:33:31 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 04:33:31 --> Model "Sales_Model" initialized
INFO - 2021-05-12 04:33:31 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 04:33:31 --> Final output sent to browser
DEBUG - 2021-05-12 04:33:31 --> Total execution time: 0.0483
INFO - 2021-05-12 04:44:38 --> Config Class Initialized
INFO - 2021-05-12 04:44:38 --> Hooks Class Initialized
DEBUG - 2021-05-12 04:44:38 --> UTF-8 Support Enabled
INFO - 2021-05-12 04:44:38 --> Utf8 Class Initialized
INFO - 2021-05-12 04:44:38 --> URI Class Initialized
DEBUG - 2021-05-12 04:44:38 --> No URI present. Default controller set.
INFO - 2021-05-12 04:44:38 --> Router Class Initialized
INFO - 2021-05-12 04:44:38 --> Output Class Initialized
INFO - 2021-05-12 04:44:38 --> Security Class Initialized
DEBUG - 2021-05-12 04:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 04:44:38 --> Input Class Initialized
INFO - 2021-05-12 04:44:38 --> Language Class Initialized
INFO - 2021-05-12 04:44:38 --> Loader Class Initialized
INFO - 2021-05-12 04:44:38 --> Helper loaded: url_helper
INFO - 2021-05-12 04:44:38 --> Helper loaded: file_helper
INFO - 2021-05-12 04:44:38 --> Helper loaded: utility_helper
INFO - 2021-05-12 04:44:38 --> Helper loaded: unit_helper
INFO - 2021-05-12 04:44:38 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 04:44:38 --> Database Driver Class Initialized
INFO - 2021-05-12 04:44:38 --> Email Class Initialized
DEBUG - 2021-05-12 04:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 04:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 04:44:38 --> Helper loaded: form_helper
INFO - 2021-05-12 04:44:38 --> Form Validation Class Initialized
INFO - 2021-05-12 04:44:38 --> Controller Class Initialized
INFO - 2021-05-12 04:44:38 --> Model "Common_model" initialized
INFO - 2021-05-12 04:44:38 --> Model "Finane_Model" initialized
INFO - 2021-05-12 04:44:38 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 04:44:38 --> Model "Sales_Model" initialized
INFO - 2021-05-12 04:44:38 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 04:44:38 --> Final output sent to browser
DEBUG - 2021-05-12 04:44:38 --> Total execution time: 0.0500
INFO - 2021-05-12 05:30:26 --> Config Class Initialized
INFO - 2021-05-12 05:30:26 --> Hooks Class Initialized
DEBUG - 2021-05-12 05:30:26 --> UTF-8 Support Enabled
INFO - 2021-05-12 05:30:26 --> Utf8 Class Initialized
INFO - 2021-05-12 05:30:26 --> URI Class Initialized
DEBUG - 2021-05-12 05:30:26 --> No URI present. Default controller set.
INFO - 2021-05-12 05:30:26 --> Router Class Initialized
INFO - 2021-05-12 05:30:26 --> Output Class Initialized
INFO - 2021-05-12 05:30:26 --> Security Class Initialized
DEBUG - 2021-05-12 05:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 05:30:26 --> Input Class Initialized
INFO - 2021-05-12 05:30:26 --> Language Class Initialized
INFO - 2021-05-12 05:30:26 --> Loader Class Initialized
INFO - 2021-05-12 05:30:26 --> Helper loaded: url_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: file_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: utility_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: unit_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 05:30:26 --> Database Driver Class Initialized
INFO - 2021-05-12 05:30:26 --> Email Class Initialized
DEBUG - 2021-05-12 05:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 05:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 05:30:26 --> Helper loaded: form_helper
INFO - 2021-05-12 05:30:26 --> Form Validation Class Initialized
INFO - 2021-05-12 05:30:26 --> Controller Class Initialized
INFO - 2021-05-12 05:30:26 --> Model "Common_model" initialized
INFO - 2021-05-12 05:30:26 --> Model "Finane_Model" initialized
INFO - 2021-05-12 05:30:26 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 05:30:26 --> Model "Sales_Model" initialized
INFO - 2021-05-12 05:30:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 05:30:26 --> Final output sent to browser
DEBUG - 2021-05-12 05:30:26 --> Total execution time: 0.0724
INFO - 2021-05-12 05:30:26 --> Config Class Initialized
INFO - 2021-05-12 05:30:26 --> Hooks Class Initialized
DEBUG - 2021-05-12 05:30:26 --> UTF-8 Support Enabled
INFO - 2021-05-12 05:30:26 --> Utf8 Class Initialized
INFO - 2021-05-12 05:30:26 --> URI Class Initialized
INFO - 2021-05-12 05:30:26 --> Router Class Initialized
INFO - 2021-05-12 05:30:26 --> Output Class Initialized
INFO - 2021-05-12 05:30:26 --> Security Class Initialized
DEBUG - 2021-05-12 05:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 05:30:26 --> Input Class Initialized
INFO - 2021-05-12 05:30:26 --> Language Class Initialized
INFO - 2021-05-12 05:30:26 --> Loader Class Initialized
INFO - 2021-05-12 05:30:26 --> Helper loaded: url_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: file_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: utility_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: unit_helper
INFO - 2021-05-12 05:30:26 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 05:30:26 --> Database Driver Class Initialized
INFO - 2021-05-12 05:30:26 --> Email Class Initialized
DEBUG - 2021-05-12 05:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 05:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 05:30:26 --> Helper loaded: form_helper
INFO - 2021-05-12 05:30:26 --> Form Validation Class Initialized
INFO - 2021-05-12 05:30:26 --> Controller Class Initialized
INFO - 2021-05-12 05:30:26 --> Model "Common_model" initialized
INFO - 2021-05-12 05:30:26 --> Model "Finane_Model" initialized
INFO - 2021-05-12 05:30:26 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 05:30:26 --> Model "Sales_Model" initialized
INFO - 2021-05-12 05:30:26 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/forgotpassword.php
INFO - 2021-05-12 05:30:26 --> Final output sent to browser
DEBUG - 2021-05-12 05:30:26 --> Total execution time: 0.0674
INFO - 2021-05-12 05:52:43 --> Config Class Initialized
INFO - 2021-05-12 05:52:43 --> Hooks Class Initialized
DEBUG - 2021-05-12 05:52:43 --> UTF-8 Support Enabled
INFO - 2021-05-12 05:52:43 --> Utf8 Class Initialized
INFO - 2021-05-12 05:52:43 --> URI Class Initialized
INFO - 2021-05-12 05:52:43 --> Router Class Initialized
INFO - 2021-05-12 05:52:43 --> Output Class Initialized
INFO - 2021-05-12 05:52:43 --> Security Class Initialized
DEBUG - 2021-05-12 05:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 05:52:43 --> Input Class Initialized
INFO - 2021-05-12 05:52:43 --> Language Class Initialized
INFO - 2021-05-12 05:52:43 --> Loader Class Initialized
INFO - 2021-05-12 05:52:43 --> Helper loaded: url_helper
INFO - 2021-05-12 05:52:43 --> Helper loaded: file_helper
INFO - 2021-05-12 05:52:43 --> Helper loaded: utility_helper
INFO - 2021-05-12 05:52:43 --> Helper loaded: unit_helper
INFO - 2021-05-12 05:52:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 05:52:43 --> Database Driver Class Initialized
INFO - 2021-05-12 05:52:43 --> Email Class Initialized
DEBUG - 2021-05-12 05:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 05:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 05:52:43 --> Helper loaded: form_helper
INFO - 2021-05-12 05:52:43 --> Form Validation Class Initialized
INFO - 2021-05-12 05:52:43 --> Controller Class Initialized
INFO - 2021-05-12 05:52:43 --> Model "Common_model" initialized
INFO - 2021-05-12 05:52:43 --> Model "Finane_Model" initialized
INFO - 2021-05-12 05:52:43 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 05:52:43 --> Model "Sales_Model" initialized
INFO - 2021-05-12 05:52:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 05:52:43 --> Final output sent to browser
DEBUG - 2021-05-12 05:52:43 --> Total execution time: 0.0593
INFO - 2021-05-12 05:52:53 --> Config Class Initialized
INFO - 2021-05-12 05:52:53 --> Hooks Class Initialized
DEBUG - 2021-05-12 05:52:53 --> UTF-8 Support Enabled
INFO - 2021-05-12 05:52:53 --> Utf8 Class Initialized
INFO - 2021-05-12 05:52:53 --> URI Class Initialized
DEBUG - 2021-05-12 05:52:53 --> No URI present. Default controller set.
INFO - 2021-05-12 05:52:53 --> Router Class Initialized
INFO - 2021-05-12 05:52:53 --> Output Class Initialized
INFO - 2021-05-12 05:52:53 --> Security Class Initialized
DEBUG - 2021-05-12 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 05:52:53 --> Input Class Initialized
INFO - 2021-05-12 05:52:53 --> Language Class Initialized
INFO - 2021-05-12 05:52:53 --> Loader Class Initialized
INFO - 2021-05-12 05:52:53 --> Helper loaded: url_helper
INFO - 2021-05-12 05:52:53 --> Helper loaded: file_helper
INFO - 2021-05-12 05:52:53 --> Helper loaded: utility_helper
INFO - 2021-05-12 05:52:53 --> Helper loaded: unit_helper
INFO - 2021-05-12 05:52:53 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 05:52:53 --> Database Driver Class Initialized
INFO - 2021-05-12 05:52:53 --> Email Class Initialized
DEBUG - 2021-05-12 05:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 05:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 05:52:53 --> Helper loaded: form_helper
INFO - 2021-05-12 05:52:53 --> Form Validation Class Initialized
INFO - 2021-05-12 05:52:53 --> Controller Class Initialized
INFO - 2021-05-12 05:52:53 --> Model "Common_model" initialized
INFO - 2021-05-12 05:52:53 --> Model "Finane_Model" initialized
INFO - 2021-05-12 05:52:53 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 05:52:53 --> Model "Sales_Model" initialized
INFO - 2021-05-12 12:05:07 --> Config Class Initialized
INFO - 2021-05-12 12:05:07 --> Hooks Class Initialized
DEBUG - 2021-05-12 12:05:07 --> UTF-8 Support Enabled
INFO - 2021-05-12 12:05:07 --> Utf8 Class Initialized
INFO - 2021-05-12 12:05:07 --> URI Class Initialized
INFO - 2021-05-12 12:05:07 --> Router Class Initialized
INFO - 2021-05-12 12:05:07 --> Output Class Initialized
INFO - 2021-05-12 12:05:07 --> Security Class Initialized
DEBUG - 2021-05-12 12:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 12:05:07 --> Input Class Initialized
INFO - 2021-05-12 12:05:07 --> Language Class Initialized
ERROR - 2021-05-12 12:05:07 --> 404 Page Not Found: Public/assets
INFO - 2021-05-12 16:39:07 --> Config Class Initialized
INFO - 2021-05-12 16:39:07 --> Hooks Class Initialized
DEBUG - 2021-05-12 16:39:07 --> UTF-8 Support Enabled
INFO - 2021-05-12 16:39:07 --> Utf8 Class Initialized
INFO - 2021-05-12 16:39:07 --> URI Class Initialized
DEBUG - 2021-05-12 16:39:07 --> No URI present. Default controller set.
INFO - 2021-05-12 16:39:07 --> Router Class Initialized
INFO - 2021-05-12 16:39:07 --> Output Class Initialized
INFO - 2021-05-12 16:39:07 --> Security Class Initialized
DEBUG - 2021-05-12 16:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 16:39:07 --> Input Class Initialized
INFO - 2021-05-12 16:39:07 --> Language Class Initialized
INFO - 2021-05-12 16:39:07 --> Loader Class Initialized
INFO - 2021-05-12 16:39:07 --> Helper loaded: url_helper
INFO - 2021-05-12 16:39:07 --> Helper loaded: file_helper
INFO - 2021-05-12 16:39:07 --> Helper loaded: utility_helper
INFO - 2021-05-12 16:39:07 --> Helper loaded: unit_helper
INFO - 2021-05-12 16:39:07 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 16:39:07 --> Database Driver Class Initialized
INFO - 2021-05-12 16:39:07 --> Email Class Initialized
DEBUG - 2021-05-12 16:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 16:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 16:39:07 --> Helper loaded: form_helper
INFO - 2021-05-12 16:39:07 --> Form Validation Class Initialized
INFO - 2021-05-12 16:39:07 --> Controller Class Initialized
INFO - 2021-05-12 16:39:07 --> Model "Common_model" initialized
INFO - 2021-05-12 16:39:07 --> Model "Finane_Model" initialized
INFO - 2021-05-12 16:39:07 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 16:39:07 --> Model "Sales_Model" initialized
INFO - 2021-05-12 16:39:07 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 16:39:07 --> Final output sent to browser
DEBUG - 2021-05-12 16:39:07 --> Total execution time: 0.1037
INFO - 2021-05-12 17:07:31 --> Config Class Initialized
INFO - 2021-05-12 17:07:31 --> Hooks Class Initialized
DEBUG - 2021-05-12 17:07:31 --> UTF-8 Support Enabled
INFO - 2021-05-12 17:07:31 --> Utf8 Class Initialized
INFO - 2021-05-12 17:07:31 --> URI Class Initialized
DEBUG - 2021-05-12 17:07:31 --> No URI present. Default controller set.
INFO - 2021-05-12 17:07:31 --> Router Class Initialized
INFO - 2021-05-12 17:07:31 --> Output Class Initialized
INFO - 2021-05-12 17:07:31 --> Security Class Initialized
DEBUG - 2021-05-12 17:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 17:07:31 --> Input Class Initialized
INFO - 2021-05-12 17:07:31 --> Language Class Initialized
INFO - 2021-05-12 17:07:31 --> Loader Class Initialized
INFO - 2021-05-12 17:07:31 --> Helper loaded: url_helper
INFO - 2021-05-12 17:07:31 --> Helper loaded: file_helper
INFO - 2021-05-12 17:07:31 --> Helper loaded: utility_helper
INFO - 2021-05-12 17:07:31 --> Helper loaded: unit_helper
INFO - 2021-05-12 17:07:31 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 17:07:31 --> Database Driver Class Initialized
INFO - 2021-05-12 17:07:31 --> Email Class Initialized
DEBUG - 2021-05-12 17:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 17:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 17:07:31 --> Helper loaded: form_helper
INFO - 2021-05-12 17:07:31 --> Form Validation Class Initialized
INFO - 2021-05-12 17:07:31 --> Controller Class Initialized
INFO - 2021-05-12 17:07:31 --> Model "Common_model" initialized
INFO - 2021-05-12 17:07:31 --> Model "Finane_Model" initialized
INFO - 2021-05-12 17:07:32 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 17:07:32 --> Model "Sales_Model" initialized
INFO - 2021-05-12 17:07:32 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 17:07:32 --> Final output sent to browser
DEBUG - 2021-05-12 17:07:32 --> Total execution time: 0.0727
INFO - 2021-05-12 18:44:35 --> Config Class Initialized
INFO - 2021-05-12 18:44:35 --> Hooks Class Initialized
DEBUG - 2021-05-12 18:44:35 --> UTF-8 Support Enabled
INFO - 2021-05-12 18:44:35 --> Utf8 Class Initialized
INFO - 2021-05-12 18:44:35 --> URI Class Initialized
DEBUG - 2021-05-12 18:44:35 --> No URI present. Default controller set.
INFO - 2021-05-12 18:44:35 --> Router Class Initialized
INFO - 2021-05-12 18:44:35 --> Output Class Initialized
INFO - 2021-05-12 18:44:35 --> Security Class Initialized
DEBUG - 2021-05-12 18:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 18:44:35 --> Input Class Initialized
INFO - 2021-05-12 18:44:35 --> Language Class Initialized
INFO - 2021-05-12 18:44:35 --> Loader Class Initialized
INFO - 2021-05-12 18:44:35 --> Helper loaded: url_helper
INFO - 2021-05-12 18:44:35 --> Helper loaded: file_helper
INFO - 2021-05-12 18:44:35 --> Helper loaded: utility_helper
INFO - 2021-05-12 18:44:35 --> Helper loaded: unit_helper
INFO - 2021-05-12 18:44:35 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 18:44:35 --> Database Driver Class Initialized
INFO - 2021-05-12 18:44:35 --> Email Class Initialized
DEBUG - 2021-05-12 18:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 18:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 18:44:35 --> Helper loaded: form_helper
INFO - 2021-05-12 18:44:35 --> Form Validation Class Initialized
INFO - 2021-05-12 18:44:35 --> Controller Class Initialized
INFO - 2021-05-12 18:44:35 --> Model "Common_model" initialized
INFO - 2021-05-12 18:44:35 --> Model "Finane_Model" initialized
INFO - 2021-05-12 18:44:35 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 18:44:35 --> Model "Sales_Model" initialized
INFO - 2021-05-12 18:44:35 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 18:44:35 --> Final output sent to browser
DEBUG - 2021-05-12 18:44:35 --> Total execution time: 0.0741
INFO - 2021-05-12 21:32:39 --> Config Class Initialized
INFO - 2021-05-12 21:32:39 --> Hooks Class Initialized
DEBUG - 2021-05-12 21:32:39 --> UTF-8 Support Enabled
INFO - 2021-05-12 21:32:39 --> Utf8 Class Initialized
INFO - 2021-05-12 21:32:39 --> URI Class Initialized
INFO - 2021-05-12 21:32:39 --> Router Class Initialized
INFO - 2021-05-12 21:32:39 --> Output Class Initialized
INFO - 2021-05-12 21:32:39 --> Security Class Initialized
DEBUG - 2021-05-12 21:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 21:32:39 --> Input Class Initialized
INFO - 2021-05-12 21:32:39 --> Language Class Initialized
INFO - 2021-05-12 21:32:39 --> Loader Class Initialized
INFO - 2021-05-12 21:32:39 --> Helper loaded: url_helper
INFO - 2021-05-12 21:32:39 --> Helper loaded: file_helper
INFO - 2021-05-12 21:32:39 --> Helper loaded: utility_helper
INFO - 2021-05-12 21:32:39 --> Helper loaded: unit_helper
INFO - 2021-05-12 21:32:39 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 21:32:39 --> Database Driver Class Initialized
INFO - 2021-05-12 21:32:39 --> Email Class Initialized
DEBUG - 2021-05-12 21:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 21:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 21:32:39 --> Helper loaded: form_helper
INFO - 2021-05-12 21:32:39 --> Form Validation Class Initialized
INFO - 2021-05-12 21:32:39 --> Controller Class Initialized
INFO - 2021-05-12 21:32:39 --> Model "Common_model" initialized
INFO - 2021-05-12 21:32:39 --> Model "Finane_Model" initialized
INFO - 2021-05-12 21:32:39 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 21:32:39 --> Model "Sales_Model" initialized
INFO - 2021-05-12 21:32:39 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 21:32:39 --> Final output sent to browser
DEBUG - 2021-05-12 21:32:39 --> Total execution time: 0.0611
INFO - 2021-05-12 21:32:41 --> Config Class Initialized
INFO - 2021-05-12 21:32:41 --> Hooks Class Initialized
DEBUG - 2021-05-12 21:32:41 --> UTF-8 Support Enabled
INFO - 2021-05-12 21:32:41 --> Utf8 Class Initialized
INFO - 2021-05-12 21:32:41 --> URI Class Initialized
DEBUG - 2021-05-12 21:32:41 --> No URI present. Default controller set.
INFO - 2021-05-12 21:32:41 --> Router Class Initialized
INFO - 2021-05-12 21:32:41 --> Output Class Initialized
INFO - 2021-05-12 21:32:41 --> Security Class Initialized
DEBUG - 2021-05-12 21:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 21:32:41 --> Input Class Initialized
INFO - 2021-05-12 21:32:41 --> Language Class Initialized
INFO - 2021-05-12 21:32:41 --> Loader Class Initialized
INFO - 2021-05-12 21:32:41 --> Helper loaded: url_helper
INFO - 2021-05-12 21:32:41 --> Helper loaded: file_helper
INFO - 2021-05-12 21:32:41 --> Helper loaded: utility_helper
INFO - 2021-05-12 21:32:41 --> Helper loaded: unit_helper
INFO - 2021-05-12 21:32:41 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 21:32:41 --> Database Driver Class Initialized
INFO - 2021-05-12 21:32:41 --> Email Class Initialized
DEBUG - 2021-05-12 21:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 21:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 21:32:41 --> Helper loaded: form_helper
INFO - 2021-05-12 21:32:41 --> Form Validation Class Initialized
INFO - 2021-05-12 21:32:41 --> Controller Class Initialized
INFO - 2021-05-12 21:32:41 --> Model "Common_model" initialized
INFO - 2021-05-12 21:32:41 --> Model "Finane_Model" initialized
INFO - 2021-05-12 21:32:41 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 21:32:41 --> Model "Sales_Model" initialized
INFO - 2021-05-12 21:32:41 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 21:32:41 --> Final output sent to browser
DEBUG - 2021-05-12 21:32:41 --> Total execution time: 0.0536
INFO - 2021-05-12 22:50:22 --> Config Class Initialized
INFO - 2021-05-12 22:50:22 --> Hooks Class Initialized
DEBUG - 2021-05-12 22:50:22 --> UTF-8 Support Enabled
INFO - 2021-05-12 22:50:22 --> Utf8 Class Initialized
INFO - 2021-05-12 22:50:22 --> URI Class Initialized
DEBUG - 2021-05-12 22:50:22 --> No URI present. Default controller set.
INFO - 2021-05-12 22:50:22 --> Router Class Initialized
INFO - 2021-05-12 22:50:22 --> Output Class Initialized
INFO - 2021-05-12 22:50:22 --> Security Class Initialized
DEBUG - 2021-05-12 22:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-12 22:50:22 --> Input Class Initialized
INFO - 2021-05-12 22:50:22 --> Language Class Initialized
INFO - 2021-05-12 22:50:22 --> Loader Class Initialized
INFO - 2021-05-12 22:50:22 --> Helper loaded: url_helper
INFO - 2021-05-12 22:50:22 --> Helper loaded: file_helper
INFO - 2021-05-12 22:50:22 --> Helper loaded: utility_helper
INFO - 2021-05-12 22:50:22 --> Helper loaded: unit_helper
INFO - 2021-05-12 22:50:22 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-12 22:50:22 --> Database Driver Class Initialized
INFO - 2021-05-12 22:50:22 --> Email Class Initialized
DEBUG - 2021-05-12 22:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-12 22:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-12 22:50:22 --> Helper loaded: form_helper
INFO - 2021-05-12 22:50:22 --> Form Validation Class Initialized
INFO - 2021-05-12 22:50:22 --> Controller Class Initialized
INFO - 2021-05-12 22:50:22 --> Model "Common_model" initialized
INFO - 2021-05-12 22:50:22 --> Model "Finane_Model" initialized
INFO - 2021-05-12 22:50:22 --> Model "Inventory_Model" initialized
INFO - 2021-05-12 22:50:22 --> Model "Sales_Model" initialized
INFO - 2021-05-12 22:50:22 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-12 22:50:22 --> Final output sent to browser
DEBUG - 2021-05-12 22:50:22 --> Total execution time: 0.0547
