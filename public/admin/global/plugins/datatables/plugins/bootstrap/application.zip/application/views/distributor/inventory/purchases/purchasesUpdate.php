
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li >Inventory Transaction</li>
                <li class="active">Purchases View</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a class="inventoryAddPermission" href="<?php echo site_url($this->project . '/purchases_add'); ?>">
                        <i class="ace-icon fa fa-plus"></i>
                        Add
                    </a>
                </li>
                <li>
                    <a href="<?php echo site_url($this->project . '/purchases_list'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
                <li>
                    <a class="inventoryEditPermission" href="<?php echo site_url($this->project . '/purchases_edit/' . $purchasesList->generals_id); ?>">
                        <i class="ace-icon fa fa-pencil bigger-130"></i> Edit
                    </a>
                </li>
                <li>
                    <a  onclick="window.print();" style="cursor:pointer;">
                        <i class="ace-icon fa fa-print"></i> Print
                    </a>
                </li>

            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="widget-box transparent">

                        <div class="widget-body">
                            <div class="widget-main padding-24" style="margin-top: -45px;">
                                <div class="row"  style="height:15px;">
                                    <div class="col-xs-3 text-left" >
                                        <img src="<?php echo base_url('assets/images/logo.jpg'); ?>" height="60px"  data-holder-rendered="true"/>
                                    </div>
                                    <div class="col-xs-6 text-center">
                                        <span style="font-size: 20px;letter-spacing:1px;">ইসতিয়া এন্টারপ্রাইজ</span>
                                        <br>
                                        <span  style="font-size: 20px;letter-spacing:1px;">ESTIA ENTERPRISE</span><br>
                                        <span  style="font-size: 16px;text-align: center;;">প্রো : মোঃ জলিল</span>
                                    </div>
                                    <div class="col-xs-3">
                                        <div>
                                            <ul class="list-unstyled  spaced">
                                                <li style="margin: 0px;padding: 0px;"><strong>   &nbsp;&nbsp; Mob : </strong> 01713013484</li>
                                                <li style="margin: 0px;padding: 0px;"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </strong> 01712172046</li>
                                                <li style="margin: 0px;padding: 0px;"><strong>    Office : </strong> 7277194</li>
                                                <li style="margin: 0px;padding: 0px;"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </strong> 7274717</li>
                                            </ul>
                                        </div>
                                    </div><!-- /.col -->
                                </div><!-- /.row -->

                                <div class="row" style="height:10px">
                                    <div class="col-xs-9">
                                        <div>
                                            <ul class="list-unstyled  spaced">
                                                <li style="margin: 0px;padding: 0px;">
                                                    <strong>    Name : </strong> <?php echo $supplierInfo->supID . '[' . $supplierInfo->supName . ']' ?>
                                                </li>

                                                <li style="margin: 0px;padding: 0px;">
                                                    <strong> Address: </strong>  <?php echo $supplierInfo->supAddress; ?>
                                                </li>
                                            </ul>
                                        </div>

                                    </div>


                                    <div class="col-xs-3 text-left">

                                        <div>
                                            <ul class="list-unstyled  spaced">
                                                <li style="white-space: nowrap;margin: 0px;padding: 0px;">
                                                    <strong>Invoice ID : </strong> <?php echo $purchasesList->voucher_no; ?> <?php
if (!empty($purchasesList->mainInvoiceId)) {
    echo ' / ' . $purchasesList->mainInvoiceId;
}
?>
                                                </li>

                                                <li style="white-space: nowrap;margin: 0px;padding: 0px;">
                                                    <strong>    Date : </strong>  <?php echo date('d-m-Y', strtotime($purchasesList->date)); ?>
                                                </li>
                                            </ul>
                                        </div>

                                    </div><!-- /.col -->
                                </div>

                                <div class="space"></div>
                                <div style="min-height:200px;" >
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <td class="center">#</td>
                                                <td><strong>Product</strong></td>
                                                <td class="text-right"><strong>Bundle</strong></td>
                                                <td class="text-right"><strong>Quantity</strong></td>
                                                <td class="text-right"><strong>Unit</strong></td>
                                                <td class="text-right"><strong>Unit Price</strong></td>
                                                <td class="text-right"><strong>Total Price</strong></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $tqty = 0;
                                            $trate = 0;
                                            $tprice = 0;
                                            foreach ($stockList as $key => $each_info):
                                                if ($each_info->type == 'In') {
                                                    $tqty += $each_info->quantity;
                                                    $trate += $each_info->rate;
                                                    $tprice += $each_info->rate * $each_info->quantity;
                                                    ?>
                                                    <tr>
                                                        <td class="center"><?php echo $key + 1; ?></td>
                                                        <td>
                                                            <?php
                                                            echo $this->Common_model->tableRow('productcategory', 'category_id', $each_info->category_id)->title;
                                                            ?>

                                                            <?php
                                                            $productInfo = $this->Common_model->tableRow('product', 'product_id', $each_info->product_id);
                                                            echo $productInfo->productName;
                                                            echo ' [ ' . $this->Common_model->tableRow('brand', 'brandId', $productInfo->brand_id)->brandName . ' ] ';
                                                            ?>
                                                        </td>

                                                        <td align="right"><?php
                                                    if ($each_info->bundle > 0) {
                                                        echo $each_info->bundle;
                                                    }
                                                            ?></td>
                                                        <td align='right'><?php echo $each_info->quantity; ?> </td>
                                                        <td align="right">
                                                            <?php
                                                            if (!empty($each_info->unit)):
                                                                echo $this->Common_model->tableRow('unit', 'unit_id', $each_info->unit)->unitTtile;
                                                            endif;
                                                            ?>
                                                        </td>
                                                        <td align='right'><?php echo $each_info->rate; ?> </td>
                                                        <td align='right'><?php echo number_format($each_info->rate * $each_info->quantity, 2); ?> </td>
                                                    </tr>
                                                <?php }endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Sub-Total</strong></td>
                                                <td align='right'><?php echo number_format((float) $tprice, 2, '.', ','); ?></td>
                                            </tr>
                                            <?php if (!empty($purchasesList->discount) && $purchasesList->discount > 0): ?>

                                                <tr>
                                                    <td colspan="6" align="right"><strong>Discount ( - )</strong></td>
                                                    <td align='right'><?php echo number_format((float) $purchasesList->discount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if (!empty($purchasesList->loaderAmount) && $purchasesList->loaderAmount > 0): ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Loader ( + )</strong></td>
                                                    <td align='right'><?php echo number_format((float) $purchasesList->loaderAmount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if (!empty($purchasesList->transportationAmount) && $purchasesList->transportationAmount > 0): ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Transportation ( + )</strong></td>
                                                    <td align='right'><?php echo number_format((float) $purchasesList->transportationAmount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>

                                            <?php
                                            $netAmount = ($tprice + $purchasesList->transportationAmount + $purchasesList->loaderAmount) - $purchasesList->discount;
                                            ?>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Net Total</strong></td>
                                                <td align='right'><?php echo number_format((float) $netAmount, 2, '.', ','); ?></td>
                                            </tr>

                                            <?php if (!empty($creditAmount->credit) && $creditAmount->credit > 0): ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Payment</strong></td>
                                                    <td align='right'><?php echo number_format((float) $creditAmount->credit, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php
                                            if (!empty($creditAmount->credit)):
                                                $dueAmount = $netAmount - $creditAmount->credit;
                                            else:
                                                $dueAmount = $netAmount;
                                            endif;

                                            if (!empty($dueAmount) && $dueAmount > 0) :
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Due Amount</strong></td>
                                                    <td align='right'><?php echo number_format((float) $dueAmount, 2, '.', ','); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <td colspan="7" >
                                                    <strong>  <span>In Words : &nbsp;</span> <?php echo $this->Common_model->get_bd_amount_in_text($netAmount); ?></strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="7" >
                                                    <span>Narration : &nbsp;</span> <?php echo $purchasesList->narration; ?>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>

                                <div class="row">
                                    <div class="col-xs-4 text-center">
                                        <p>Prepared By:_____________<br />
                                            Date:____________________
                                        </p>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                    </div>
                                    <div class="col-xs-4 text-center">
                                        <p>Approved By:________________<br />
                                            Date:_________________</p>
                                    </div>
                                    <div class="well text-center">

                                        সর্বপ্রকার  লৌহজাত  ,সিমেন্ট  দ্র্রব্যর  পাইকারী  বিক্রেতা  ও  সরবরাহকারী।<br> ৫৩৮,দক্ষিন  মান্ডা  (মেইন  রোড ) ,ঢাকা -১২১৪

                                    </div>

                                </div>




                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>

<script>
    var url = baseUrl + "SalesController/getSupplierClosingBalance";

    $.ajax({
        type: 'POST',
        url:baseUrl + "InventoryController/getSupplierClosingBalance",
        data:{
            supplierid: '<?php echo $purchasesList->supplier_id; ?>'
        },
        success: function (data)
        {
            data=parseFloat(data);
            if(isNaN(data)){
                data=0;
            }
            $('#customerCurrentDue').text(parseFloat(data).toFixed(2));
        }
    });


</script>

