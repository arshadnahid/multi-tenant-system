<style>


    .cashmemo{
        font-size: 25px;
        letter-spacing:1px;
        background-color:blue;
        color:white;
        border-radius: 10px;
        padding: 3px;

    }
    .mainName{
        font-size: 30px;
        letter-spacing:1px;
        color:blue;
    }

    .secondTitle{
        font-size: 18px;
        color:red;
    }
    .thirdTitle{
        font-size: 10px;color:blue;
    }

    .fourthTitle{
        font-size: 12px;
        color:red;

    }
    .fifthTitle{
        font-size: 12px;
        color:blue;
    }

    .sixTitle{
        font-size: 10px;
        color:red;
    }

    @media print {

        .titleColor{
            background-color: red!important;
        }


    }


</style>




<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Transaction</li>
                <li class="active">Sales Invoice</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/salesInvoice'); ?>">
                        <i class="ace-icon 	fa fa-list"></i> List
                    </a>
                </li>
<!--                <li class="active saleAddPermission"><a href="<?php echo site_url($this->project . '/salesInvoice_add'); ?>" >
                        <i class="ace-icon 	fa fa-plus"></i>  Add
                    </a>
                </li>
                <li>
                    <a class="saleEditPermission"  href="<?php echo site_url($this->project . '/salesInvoice_edit/' . $saleslist->generals_id); ?>">
                        <i class="ace-icon 	fa fa-pencil bigger-130"></i> Edit
                    </a>
                </li>-->

                <li>
                    <a  onclick="window.print();" style="cursor:pointer;">
                        <i class="ace-icon fa fa-print"></i> Print
                    </a>
                </li>

            </ul>
        </div>
        <div class="page-content">
            <div class="row"><br>
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="widget-box transparent">
                        <div class="widget-body">
                            <div class="widget-main padding-24" style="margin-top: -45px;">




<!--                                 <div class="row"  style="height:15px;">
                                    <div class="col-xs-12 text-center">
                                        <span style="font-size: 25px;letter-spacing:1px;background-color:blue;color:white;border-radius: 10px;padding: 3px;">ক্যাশ মেমো</span><br>
                                        <span style="font-size: 30px;letter-spacing:1px;color:blue;">মেসার্স নিউ গাজীপুর বিল্ডার্স</span>
                                        <address  style="letter-spacing:1px;">
                                            <span style="font-size: 18px;color:red;">ডিলার : AKS Steel,ফ্রেস সিমেন্ট,হোলসিম  সিমেন্ট</span><br>
                                            <span style="font-size: 10px;color:blue;">এখানে ৫০০ w,৪০ গ্রেড এর এম এস রড ,সিমেন্ট,এঙ্গেল,ফ্লাটবার,জেডবার ইত্যাদি পাইকারি ও খুচরা বিক্রেতা</span><br>
                                            <span style="font-size: 12px;color:red;">মিরের বাজার ,কালীগঞ্জ  রোড ,পূবাইল ,গাজীপুর সিটি</span><br>
                                            <span style="font-size: 12px;color:blue;">মোবাইল:০১৯৪৭-৩৯২৮৬৫,০১৭২৭-৫১২৫৬৮,০১৯৯৩-৭৮৭১০২,০১৯৯৩-৭৮৭১০৫</span><br>
                                            <span style="font-size: 10px;color:red;">E-mail:newgazipurbuilders68@gmail.com</span>
                                        </address>
                                    </div>
                                </div>-->





                                <div>
                                    <?php echo $companyInfo->report_header; ?>
                                </div>
                                <div class="row" style="height:10px">
                                    <div class="col-xs-9">
                                        <div>
                                            <ul class="list-unstyled  spaced">
                                                <li style="margin: 0px;padding: 0px;">
                                                    <strong style="text-align: right !important; "> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;Name&nbsp;:&nbsp;</strong> <?php echo $customerInfo->customerName . ' [ ' . $customerInfo->customerID . ' ] ' ?>
                                                </li>

                                                <li style="margin: 0px;padding: 0px;">
                                                    <strong style="text-align: right !important; "> &nbsp;Address &nbsp;: &nbsp;</strong>  <?php echo $customerInfo->customerAddress; ?>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-xs-3 text-left">
                                        <div>
                                            <ul class="list-unstyled  spaced">
                                                <li style="white-space: nowrap;margin: 0px;padding: 0px;">
                                                    <strong>Invoice ID &nbsp;&nbsp;:&nbsp;</strong>  <?php echo $saleslist->voucher_no; ?>
                                                </li>

                                                <li style="white-space: nowrap;margin: 0px;padding: 0px;">
                                                    <strong style="text-align: right">    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;&nbsp; : &nbsp;</strong> <?php echo date('M d, Y', strtotime($saleslist->date)); ?>
                                                </li>
                                            </ul>
                                        </div>
                                    </div><!-- /.col -->
                                </div>
                                <div class="space"></div>
                                <div style="min-height:200px;" >
                                    <table class="table table-striped table-responsive table-bordered">
                                        <tr>
                                            <td class="center">#</td>
                                            <td style="font-weight: bold !important;">Product</td>
                                            <td class="text-right"><strong>Bundle</strong></td>
                                            <td class="text-right"><strong>Quantity</strong></td>
                                            <td class="text-right"><strong>Unit</strong></td>
                                            <td class="text-right"><strong>Unit Price</strong></td>
                                            <td class="text-right"><strong>Total Price</strong></td>
                                        </tr>
                                        <tbody>
                                            <?php
                                            $tqty = 0;
                                            $trate = 0;
                                            $tprice = 0;
                                            $j = 1;
                                            foreach ($stockList as $key => $each_info):
                                                if ($each_info->type == 'Out') {
                                                    $tqty += $each_info->quantity;
                                                    $trate += $each_info->rate;
                                                    $tprice += $each_info->rate * $each_info->quantity;
                                                    ?>
                                                    <tr>
                                                        <td class="center"><?php echo $j++; ?></td>
                                                        <td>
                                                            <?php
                                                            echo $this->Common_model->tableRow('productcategory', 'category_id', $each_info->category_id)->title;
                                                            ?>

                                                            <?php
                                                            $productInfo = $this->Common_model->tableRow('product', 'product_id', $each_info->product_id);
                                                            echo $productInfo->productName;
                                                            echo ' [ ' . $this->Common_model->tableRow('brand', 'brandId', $productInfo->brand_id)->brandName . ' ] ';
                                                            ?>
                                                        </td>

                                                        <td class="text-right"><?php
                                                    if ($each_info->bundle > 0) {
                                                        echo $each_info->bundle;
                                                    }
                                                            ?> </td>
                                                        <td class="text-right"><?php echo $each_info->quantity; ?> </td>
                                                        <td class="text-right">
                                                            <?php
                                                            if (!empty($productInfo->unit_id)):
                                                                echo $this->Common_model->tableRow('unit', 'unit_id', $productInfo->unit_id)->unitTtile;
                                                            else:
                                                                echo "KG";
                                                            endif;
                                                            ?>
                                                        </td>
                                                        <td align="right"><?php echo $each_info->rate; ?> </td>
                                                        <td align="right"><?php echo number_format($each_info->rate * $each_info->quantity, 2); ?></td>
                                                    </tr>
                                                <?php }endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Sub - Total</strong></td>
                                                <td align="right"><strong><?php echo number_format($tprice, 2); ?></strong></td>
                                            </tr>
                                            <?php
                                            if (!empty($saleslist->discount) && $saleslist->discount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Discount ( - ) </strong></td>
                                                    <td align="right"><strong><?php echo number_format($saleslist->discount, 2); ?></strong></td>
                                                </tr>
                                                <?php
                                            endif;

                                            if (!empty($saleslist->loaderAmount) && $saleslist->loaderAmount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Loader ( + )</strong></td>
                                                    <td align="right"><strong><?php echo number_format($saleslist->loaderAmount, 2); ?></strong></td>
                                                </tr>
                                                <?php
                                            endif;
                                            if (!empty($saleslist->transportationAmount) && $saleslist->transportationAmount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Transportation ( + )</strong></td>
                                                    <td align="right"><strong><?php echo number_format($saleslist->transportationAmount, 2); ?></strong></td>
                                                </tr>
                                                <?php
                                            endif;
                                            ?>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Net Total</strong></td>
                                                <td align="right"><strong><?php echo number_format($saleslist->debit, 2); ?></strong></td>
                                            </tr>
                                            <?php
                                            $cusPreviousAmount = $this->Sales_Model->getCustomerBalance($this->dist_id, $customerInfo->customer_id);
                                            if (!empty($cusPreviousAmount) && $cusPreviousAmount > 0):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Previous Due</strong></td>
                                                    <td align="right"><strong><?php echo number_format(($cusPreviousAmount + $invoicePayment) - $saleslist->debit, 2); ?></strong></td>
                                                </tr>
                                                <?php
                                            endif;



                                            //if (!empty($invoicePayment) && $invoicePayment > 0):
                                            ?>
                                            <tr>
                                                <td colspan="6" align="right"><strong>Payment ( - )</strong></td>
                                                <td align="right"><strong><?php echo number_format($invoicePayment, 2); ?></strong></td>
                                            </tr>
                                            <?php
                                            //  endif;
                                            $dueAmount1 = $saleslist->debit - $invoicePayment;
                                            if (!empty($dueAmount1)):
                                                ?>
                                                <tr>
                                                    <td colspan="6" align="right"><strong>Current Due</strong></td>
                                                    <td align="right"><strong><?php echo number_format($cusPreviousAmount, 2); ?></strong></td>
                                                </tr>
                                                <?php
                                            endif;
                                            ?>
                                            <tr>
                                                <td colspan="7" >
                                                    <strong><span>In Words : &nbsp;</span> <?php echo $this->Common_model->get_bd_amount_in_text($invoicePayment); ?></strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="7">
                                                    <strong><span>Narration : &nbsp;</span> <?php echo $saleslist->narration; ?></strong>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <div><?php echo $companyInfo->report_footer; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.min.js"></script>
<script>
    var url = baseUrl + "SalesController/getCustomerCurrentBalance";
    $.ajax({
        type: 'POST',
        url: url,
        data: {
            customerId: '<?php echo $saleslist->customer_id; ?>'
        },
        success: function (data)
        {
            $('.currentBalance').text(parseFloat(data).toFixed(2));


        }
    });

</script>
