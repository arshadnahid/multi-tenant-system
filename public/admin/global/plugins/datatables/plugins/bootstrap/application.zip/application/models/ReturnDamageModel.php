<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ReturnDamageModel extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
    }

    function getInvoiceListByDate($date, $distId) {
        $this->db->distinct('voucher_no');
        $this->db->select('voucher_no,generals_id');
        $this->db->from('generals');
        $this->db->where('form_id', 5);
        $this->db->where('date', $date);
        $this->db->where('dist_id', $distId);
        $result = $this->db->get()->result();
        return $result;
    }

    function getDateListByCustomerId($customerId, $distId) {
        $sql = "SELECT DISTINCT date FROM generals as g
WHERE customer_id = '$customerId' AND dist_id='$distId'  AND form_id=5";
        $result = $this->db->query($sql)->result_array();
        return $result;
    }

    function getVoucherListByCustomerIdAndDate($customerId, $date, $distId) {
        $sql = "SELECT DISTINCT voucher_no,generals_id  FROM generals as g
WHERE customer_id = '$customerId' AND dist_id='$distId' AND date='$date' AND form_id=5";
        $result = $this->db->query($sql)->result_array();
        return $result;
    }

    function getCustomerList() {
        $sql = "SELECT c.customer_id,CONCAT(c.customerName,' [ ',c.customerID,' ] ') AS cusName FROM customer as c";
        $result = $this->db->query($sql)->result();
        return $result;
    }

    function getReturnProduct($distId) {

        $sql = "SELECT
	sr.date,
	sr.amount,
        g.voucher_no,
        sr.sales_return_id,
CONCAT(c.customerName,' [ ', c.customerID,' ] ') as customerName

FROM
	sales_return AS sr
LEFT JOIN sales_return_details as srd ON srd.return_id=sr.sales_return_id
LEFT JOIN customer as c ON c.customer_id=sr.customer_id
LEFT JOIN generals AS g ON g.generals_id = sr.generals_id
WHERE sr.is_active = 'Y' AND sr.is_delete = 'N' AND sr.dist_id = '$distId' ORDER BY sr.date asc";
        $reslt = $this->db->query($sql)->result();
        return $reslt;
    }


    function productCost($productId, $dist_id) {
        $this->db->select('SUM(stock.price)/SUM(stock.quantity) as totalAvgPurchasesPrice');
        $this->db->from('stock');
        $this->db->where('stock.product_id', $productId);
        $this->db->where('stock.dist_id', $dist_id);
        $this->db->where('stock.type', 'In');
        $results = $this->db->get()->row_array();
        return $results['totalAvgPurchasesPrice'];
    }

    function salesDetailsInfo($id, $distId) {
        $sql = "SELECT srd.return_quantity,
	srd.unit_price,
	CONCAT(
		p.productName,
		' [ ',
		b.brandName,
		' ] '
	)AS productName,
	u.unitTtile as unit
FROM
	sales_return AS sr
LEFT JOIN sales_return_details AS srd ON srd.return_id = sr.sales_return_id
LEFT JOIN product AS p ON p.product_id = srd.product_id
LEFT JOIN brand AS b ON b.brandId = p.brand_id
LEFT JOIN unit as u ON u.unit_id=p.unit_id
LEFT JOIN customer AS c ON c.customer_id = sr.customer_id
LEFT JOIN generals AS g ON g.generals_id = sr.generals_id
WHERE sr.is_active = 'Y' AND sr.is_delete = 'N' AND sr.dist_id = '$distId' AND sr.sales_return_id='$id' ORDER BY sr.date asc";
        $reslt = $this->db->query($sql)->result();
        return $reslt;
    }

    function salesReturnInfo($id, $distId) {
        $sql = "SELECT
	sr.date,
	sr.amount,
        g.voucher_no,
        sr.sales_return_id,
CONCAT(c.customerName,' [ ', c.customerID,' ] ') as customerName,
c.customerAddress as address

FROM
	sales_return AS sr
LEFT JOIN sales_return_details as srd ON srd.return_id=sr.sales_return_id
LEFT JOIN customer as c ON c.customer_id=sr.customer_id
LEFT JOIN generals AS g ON g.generals_id = sr.generals_id
WHERE sr.is_active = 'Y' AND sr.is_delete = 'N' AND sr.dist_id = '$distId' AND sr.sales_return_id='$id' ORDER BY sr.date asc";

        $reslt = $this->db->query($sql)->row();
        return $reslt;
    }

    function getDamageProduct($distId) {
        $sql = "SELECT CONCAT(p.productName,' [ ',b.brandName,' ] ') as productName,dp.date,dp.quantity,dp.unit_price,dp.damage_id FROM damageProduct AS dp
LEFT JOIN product as p ON p.product_id = dp.product_id
LEFT JOIN brand as b ON b.brandId = p.brand_id where dp.is_active = 'Y' AND dp.is_delete = 'N' AND dp.dist_id='$distId'";
        $result = $this->db->query($sql)->result();
        return $result;
    }

    function getInvoiceDetails($invoiceId) {
        $sql = "SELECT g.generals_id,g.customer_id FROM generals AS g
LEFT JOIN customer as c ON c.customer_id=g.customer_id
WHERE g.form_id =5 AND g.generals_id ='$invoiceId'";
        $result = $this->db->query($sql)->row();
        return $result;
    }

    function getInvoiceReturnProduct($invoiceId) {

        $sql = "SELECT
	sr.date,
        c.customer_id,
        g.generals_id,
	g.voucher_no,
	concat(
		p.productName,
		' [ ',
		b.brandName,
		' ] '
	)AS productName,sr.unit_price,sr.return_quantity
FROM
	sales_return_details AS sr
LEFT JOIN generals AS g ON g.generals_id = sr.sales_invoice_id
LEFT JOIN customer AS c ON c.customer_id = g.customer_id
LEFT JOIN product AS p ON p.product_id = sr.product_id
LEFT JOIN brand AS b ON b.brandId = p.brand_id
WHERE
	sr.is_active = 'Y'
AND sr.is_delete = 'N' AND sr.sales_invoice_id = '$invoiceId'";
        $reslt = $this->db->query($sql)->result();
        return $reslt;
    }

}
