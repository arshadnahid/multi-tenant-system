<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-15 02:27:43 --> Config Class Initialized
INFO - 2021-05-15 02:27:43 --> Hooks Class Initialized
DEBUG - 2021-05-15 02:27:43 --> UTF-8 Support Enabled
INFO - 2021-05-15 02:27:43 --> Utf8 Class Initialized
INFO - 2021-05-15 02:27:43 --> URI Class Initialized
DEBUG - 2021-05-15 02:27:43 --> No URI present. Default controller set.
INFO - 2021-05-15 02:27:43 --> Router Class Initialized
INFO - 2021-05-15 02:27:43 --> Output Class Initialized
INFO - 2021-05-15 02:27:43 --> Security Class Initialized
DEBUG - 2021-05-15 02:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 02:27:43 --> Input Class Initialized
INFO - 2021-05-15 02:27:43 --> Language Class Initialized
INFO - 2021-05-15 02:27:43 --> Loader Class Initialized
INFO - 2021-05-15 02:27:43 --> Helper loaded: url_helper
INFO - 2021-05-15 02:27:43 --> Helper loaded: file_helper
INFO - 2021-05-15 02:27:43 --> Helper loaded: utility_helper
INFO - 2021-05-15 02:27:43 --> Helper loaded: unit_helper
INFO - 2021-05-15 02:27:43 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 02:27:43 --> Database Driver Class Initialized
INFO - 2021-05-15 02:27:43 --> Email Class Initialized
DEBUG - 2021-05-15 02:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 02:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 02:27:43 --> Helper loaded: form_helper
INFO - 2021-05-15 02:27:43 --> Form Validation Class Initialized
INFO - 2021-05-15 02:27:43 --> Controller Class Initialized
INFO - 2021-05-15 02:27:43 --> Model "Common_model" initialized
INFO - 2021-05-15 02:27:43 --> Model "Finane_Model" initialized
INFO - 2021-05-15 02:27:43 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 02:27:43 --> Model "Sales_Model" initialized
INFO - 2021-05-15 02:27:43 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 02:27:43 --> Final output sent to browser
DEBUG - 2021-05-15 02:27:43 --> Total execution time: 0.0641
INFO - 2021-05-15 06:07:52 --> Config Class Initialized
INFO - 2021-05-15 06:07:52 --> Hooks Class Initialized
DEBUG - 2021-05-15 06:07:52 --> UTF-8 Support Enabled
INFO - 2021-05-15 06:07:52 --> Utf8 Class Initialized
INFO - 2021-05-15 06:07:52 --> URI Class Initialized
DEBUG - 2021-05-15 06:07:52 --> No URI present. Default controller set.
INFO - 2021-05-15 06:07:52 --> Router Class Initialized
INFO - 2021-05-15 06:07:52 --> Output Class Initialized
INFO - 2021-05-15 06:07:52 --> Security Class Initialized
DEBUG - 2021-05-15 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 06:07:52 --> Input Class Initialized
INFO - 2021-05-15 06:07:52 --> Language Class Initialized
INFO - 2021-05-15 06:07:52 --> Loader Class Initialized
INFO - 2021-05-15 06:07:52 --> Helper loaded: url_helper
INFO - 2021-05-15 06:07:52 --> Helper loaded: file_helper
INFO - 2021-05-15 06:07:52 --> Helper loaded: utility_helper
INFO - 2021-05-15 06:07:52 --> Helper loaded: unit_helper
INFO - 2021-05-15 06:07:52 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 06:07:52 --> Database Driver Class Initialized
INFO - 2021-05-15 06:07:52 --> Email Class Initialized
DEBUG - 2021-05-15 06:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 06:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 06:07:52 --> Helper loaded: form_helper
INFO - 2021-05-15 06:07:52 --> Form Validation Class Initialized
INFO - 2021-05-15 06:07:52 --> Controller Class Initialized
INFO - 2021-05-15 06:07:52 --> Model "Common_model" initialized
INFO - 2021-05-15 06:07:52 --> Model "Finane_Model" initialized
INFO - 2021-05-15 06:07:52 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 06:07:52 --> Model "Sales_Model" initialized
INFO - 2021-05-15 06:07:52 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 06:07:52 --> Final output sent to browser
DEBUG - 2021-05-15 06:07:52 --> Total execution time: 0.0543
INFO - 2021-05-15 08:13:17 --> Config Class Initialized
INFO - 2021-05-15 08:13:17 --> Hooks Class Initialized
DEBUG - 2021-05-15 08:13:17 --> UTF-8 Support Enabled
INFO - 2021-05-15 08:13:17 --> Utf8 Class Initialized
INFO - 2021-05-15 08:13:17 --> URI Class Initialized
INFO - 2021-05-15 08:13:17 --> Router Class Initialized
INFO - 2021-05-15 08:13:17 --> Output Class Initialized
INFO - 2021-05-15 08:13:17 --> Security Class Initialized
DEBUG - 2021-05-15 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 08:13:17 --> Input Class Initialized
INFO - 2021-05-15 08:13:17 --> Language Class Initialized
ERROR - 2021-05-15 08:13:17 --> 404 Page Not Found: Vendor/phpunit
INFO - 2021-05-15 08:30:00 --> Config Class Initialized
INFO - 2021-05-15 08:30:00 --> Hooks Class Initialized
DEBUG - 2021-05-15 08:30:00 --> UTF-8 Support Enabled
INFO - 2021-05-15 08:30:00 --> Utf8 Class Initialized
INFO - 2021-05-15 08:30:00 --> URI Class Initialized
DEBUG - 2021-05-15 08:30:00 --> No URI present. Default controller set.
INFO - 2021-05-15 08:30:00 --> Router Class Initialized
INFO - 2021-05-15 08:30:00 --> Output Class Initialized
INFO - 2021-05-15 08:30:00 --> Security Class Initialized
DEBUG - 2021-05-15 08:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 08:30:00 --> Input Class Initialized
INFO - 2021-05-15 08:30:00 --> Language Class Initialized
INFO - 2021-05-15 08:30:00 --> Loader Class Initialized
INFO - 2021-05-15 08:30:00 --> Helper loaded: url_helper
INFO - 2021-05-15 08:30:00 --> Helper loaded: file_helper
INFO - 2021-05-15 08:30:00 --> Helper loaded: utility_helper
INFO - 2021-05-15 08:30:00 --> Helper loaded: unit_helper
INFO - 2021-05-15 08:30:00 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 08:30:00 --> Database Driver Class Initialized
INFO - 2021-05-15 08:30:00 --> Email Class Initialized
DEBUG - 2021-05-15 08:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 08:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 08:30:00 --> Helper loaded: form_helper
INFO - 2021-05-15 08:30:00 --> Form Validation Class Initialized
INFO - 2021-05-15 08:30:00 --> Controller Class Initialized
INFO - 2021-05-15 08:30:00 --> Model "Common_model" initialized
INFO - 2021-05-15 08:30:00 --> Model "Finane_Model" initialized
INFO - 2021-05-15 08:30:00 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 08:30:00 --> Model "Sales_Model" initialized
INFO - 2021-05-15 08:30:00 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 08:30:00 --> Final output sent to browser
DEBUG - 2021-05-15 08:30:00 --> Total execution time: 0.0492
INFO - 2021-05-15 09:54:35 --> Config Class Initialized
INFO - 2021-05-15 09:54:35 --> Hooks Class Initialized
DEBUG - 2021-05-15 09:54:35 --> UTF-8 Support Enabled
INFO - 2021-05-15 09:54:35 --> Utf8 Class Initialized
INFO - 2021-05-15 09:54:35 --> URI Class Initialized
INFO - 2021-05-15 09:54:35 --> Router Class Initialized
INFO - 2021-05-15 09:54:35 --> Output Class Initialized
INFO - 2021-05-15 09:54:35 --> Security Class Initialized
DEBUG - 2021-05-15 09:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 09:54:35 --> Input Class Initialized
INFO - 2021-05-15 09:54:35 --> Language Class Initialized
ERROR - 2021-05-15 09:54:35 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 09:54:35 --> Config Class Initialized
INFO - 2021-05-15 09:54:35 --> Hooks Class Initialized
DEBUG - 2021-05-15 09:54:35 --> UTF-8 Support Enabled
INFO - 2021-05-15 09:54:35 --> Utf8 Class Initialized
INFO - 2021-05-15 09:54:35 --> URI Class Initialized
INFO - 2021-05-15 09:54:35 --> Router Class Initialized
INFO - 2021-05-15 09:54:35 --> Output Class Initialized
INFO - 2021-05-15 09:54:35 --> Security Class Initialized
DEBUG - 2021-05-15 09:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 09:54:35 --> Input Class Initialized
INFO - 2021-05-15 09:54:35 --> Language Class Initialized
ERROR - 2021-05-15 09:54:35 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 09:54:35 --> Config Class Initialized
INFO - 2021-05-15 09:54:35 --> Hooks Class Initialized
DEBUG - 2021-05-15 09:54:35 --> UTF-8 Support Enabled
INFO - 2021-05-15 09:54:35 --> Utf8 Class Initialized
INFO - 2021-05-15 09:54:35 --> URI Class Initialized
INFO - 2021-05-15 09:54:35 --> Router Class Initialized
INFO - 2021-05-15 09:54:35 --> Output Class Initialized
INFO - 2021-05-15 09:54:35 --> Security Class Initialized
DEBUG - 2021-05-15 09:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 09:54:35 --> Input Class Initialized
INFO - 2021-05-15 09:54:35 --> Language Class Initialized
ERROR - 2021-05-15 09:54:35 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 10:39:54 --> Config Class Initialized
INFO - 2021-05-15 10:39:54 --> Hooks Class Initialized
DEBUG - 2021-05-15 10:39:54 --> UTF-8 Support Enabled
INFO - 2021-05-15 10:39:54 --> Utf8 Class Initialized
INFO - 2021-05-15 10:39:54 --> URI Class Initialized
INFO - 2021-05-15 10:39:54 --> Router Class Initialized
INFO - 2021-05-15 10:39:54 --> Output Class Initialized
INFO - 2021-05-15 10:39:54 --> Security Class Initialized
DEBUG - 2021-05-15 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 10:39:54 --> Input Class Initialized
INFO - 2021-05-15 10:39:54 --> Language Class Initialized
ERROR - 2021-05-15 10:39:54 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 10:39:54 --> Config Class Initialized
INFO - 2021-05-15 10:39:54 --> Hooks Class Initialized
DEBUG - 2021-05-15 10:39:54 --> UTF-8 Support Enabled
INFO - 2021-05-15 10:39:54 --> Utf8 Class Initialized
INFO - 2021-05-15 10:39:54 --> URI Class Initialized
INFO - 2021-05-15 10:39:54 --> Router Class Initialized
INFO - 2021-05-15 10:39:54 --> Output Class Initialized
INFO - 2021-05-15 10:39:54 --> Security Class Initialized
DEBUG - 2021-05-15 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 10:39:54 --> Input Class Initialized
INFO - 2021-05-15 10:39:54 --> Language Class Initialized
ERROR - 2021-05-15 10:39:54 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 10:39:54 --> Config Class Initialized
INFO - 2021-05-15 10:39:54 --> Hooks Class Initialized
DEBUG - 2021-05-15 10:39:54 --> UTF-8 Support Enabled
INFO - 2021-05-15 10:39:54 --> Utf8 Class Initialized
INFO - 2021-05-15 10:39:54 --> URI Class Initialized
INFO - 2021-05-15 10:39:54 --> Router Class Initialized
INFO - 2021-05-15 10:39:54 --> Output Class Initialized
INFO - 2021-05-15 10:39:54 --> Security Class Initialized
DEBUG - 2021-05-15 10:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 10:39:54 --> Input Class Initialized
INFO - 2021-05-15 10:39:54 --> Language Class Initialized
ERROR - 2021-05-15 10:39:54 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 11:22:46 --> Config Class Initialized
INFO - 2021-05-15 11:22:46 --> Hooks Class Initialized
DEBUG - 2021-05-15 11:22:46 --> UTF-8 Support Enabled
INFO - 2021-05-15 11:22:46 --> Utf8 Class Initialized
INFO - 2021-05-15 11:22:46 --> URI Class Initialized
INFO - 2021-05-15 11:22:46 --> Router Class Initialized
INFO - 2021-05-15 11:22:46 --> Output Class Initialized
INFO - 2021-05-15 11:22:46 --> Security Class Initialized
DEBUG - 2021-05-15 11:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 11:22:46 --> Input Class Initialized
INFO - 2021-05-15 11:22:46 --> Language Class Initialized
ERROR - 2021-05-15 11:22:46 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 11:22:46 --> Config Class Initialized
INFO - 2021-05-15 11:22:46 --> Hooks Class Initialized
DEBUG - 2021-05-15 11:22:46 --> UTF-8 Support Enabled
INFO - 2021-05-15 11:22:46 --> Utf8 Class Initialized
INFO - 2021-05-15 11:22:46 --> URI Class Initialized
INFO - 2021-05-15 11:22:46 --> Router Class Initialized
INFO - 2021-05-15 11:22:46 --> Output Class Initialized
INFO - 2021-05-15 11:22:46 --> Security Class Initialized
DEBUG - 2021-05-15 11:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 11:22:46 --> Input Class Initialized
INFO - 2021-05-15 11:22:46 --> Language Class Initialized
ERROR - 2021-05-15 11:22:46 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 11:22:46 --> Config Class Initialized
INFO - 2021-05-15 11:22:46 --> Hooks Class Initialized
DEBUG - 2021-05-15 11:22:46 --> UTF-8 Support Enabled
INFO - 2021-05-15 11:22:46 --> Utf8 Class Initialized
INFO - 2021-05-15 11:22:46 --> URI Class Initialized
INFO - 2021-05-15 11:22:46 --> Router Class Initialized
INFO - 2021-05-15 11:22:46 --> Output Class Initialized
INFO - 2021-05-15 11:22:46 --> Security Class Initialized
DEBUG - 2021-05-15 11:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 11:22:46 --> Input Class Initialized
INFO - 2021-05-15 11:22:46 --> Language Class Initialized
ERROR - 2021-05-15 11:22:46 --> 404 Page Not Found: Well-known/acme-challenge
INFO - 2021-05-15 18:41:23 --> Config Class Initialized
INFO - 2021-05-15 18:41:23 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:41:23 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:41:23 --> Utf8 Class Initialized
INFO - 2021-05-15 18:41:23 --> URI Class Initialized
DEBUG - 2021-05-15 18:41:23 --> No URI present. Default controller set.
INFO - 2021-05-15 18:41:23 --> Router Class Initialized
INFO - 2021-05-15 18:41:23 --> Output Class Initialized
INFO - 2021-05-15 18:41:23 --> Security Class Initialized
DEBUG - 2021-05-15 18:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:41:23 --> Input Class Initialized
INFO - 2021-05-15 18:41:23 --> Language Class Initialized
INFO - 2021-05-15 18:41:23 --> Loader Class Initialized
INFO - 2021-05-15 18:41:23 --> Helper loaded: url_helper
INFO - 2021-05-15 18:41:23 --> Helper loaded: file_helper
INFO - 2021-05-15 18:41:23 --> Helper loaded: utility_helper
INFO - 2021-05-15 18:41:23 --> Helper loaded: unit_helper
INFO - 2021-05-15 18:41:23 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 18:41:23 --> Database Driver Class Initialized
INFO - 2021-05-15 18:41:23 --> Email Class Initialized
DEBUG - 2021-05-15 18:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:41:23 --> Helper loaded: form_helper
INFO - 2021-05-15 18:41:23 --> Form Validation Class Initialized
INFO - 2021-05-15 18:41:23 --> Controller Class Initialized
INFO - 2021-05-15 18:41:23 --> Model "Common_model" initialized
INFO - 2021-05-15 18:41:23 --> Model "Finane_Model" initialized
INFO - 2021-05-15 18:41:23 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 18:41:23 --> Model "Sales_Model" initialized
INFO - 2021-05-15 18:41:23 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 18:41:23 --> Final output sent to browser
DEBUG - 2021-05-15 18:41:23 --> Total execution time: 0.1405
INFO - 2021-05-15 20:15:55 --> Config Class Initialized
INFO - 2021-05-15 20:15:55 --> Hooks Class Initialized
DEBUG - 2021-05-15 20:15:55 --> UTF-8 Support Enabled
INFO - 2021-05-15 20:15:55 --> Utf8 Class Initialized
INFO - 2021-05-15 20:15:55 --> URI Class Initialized
INFO - 2021-05-15 20:15:55 --> Router Class Initialized
INFO - 2021-05-15 20:15:55 --> Output Class Initialized
INFO - 2021-05-15 20:15:55 --> Security Class Initialized
DEBUG - 2021-05-15 20:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 20:15:55 --> Input Class Initialized
INFO - 2021-05-15 20:15:55 --> Language Class Initialized
INFO - 2021-05-15 20:15:55 --> Loader Class Initialized
INFO - 2021-05-15 20:15:55 --> Helper loaded: url_helper
INFO - 2021-05-15 20:15:55 --> Helper loaded: file_helper
INFO - 2021-05-15 20:15:55 --> Helper loaded: utility_helper
INFO - 2021-05-15 20:15:55 --> Helper loaded: unit_helper
INFO - 2021-05-15 20:15:55 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 20:15:55 --> Database Driver Class Initialized
INFO - 2021-05-15 20:15:55 --> Email Class Initialized
DEBUG - 2021-05-15 20:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 20:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 20:15:55 --> Helper loaded: form_helper
INFO - 2021-05-15 20:15:55 --> Form Validation Class Initialized
INFO - 2021-05-15 20:15:55 --> Controller Class Initialized
INFO - 2021-05-15 20:15:55 --> Model "Common_model" initialized
INFO - 2021-05-15 20:15:55 --> Model "Finane_Model" initialized
INFO - 2021-05-15 20:15:55 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 20:15:55 --> Model "Sales_Model" initialized
INFO - 2021-05-15 20:15:55 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 20:15:55 --> Final output sent to browser
DEBUG - 2021-05-15 20:15:55 --> Total execution time: 0.0520
INFO - 2021-05-15 20:15:56 --> Config Class Initialized
INFO - 2021-05-15 20:15:56 --> Hooks Class Initialized
DEBUG - 2021-05-15 20:15:56 --> UTF-8 Support Enabled
INFO - 2021-05-15 20:15:56 --> Utf8 Class Initialized
INFO - 2021-05-15 20:15:56 --> URI Class Initialized
DEBUG - 2021-05-15 20:15:56 --> No URI present. Default controller set.
INFO - 2021-05-15 20:15:56 --> Router Class Initialized
INFO - 2021-05-15 20:15:56 --> Output Class Initialized
INFO - 2021-05-15 20:15:56 --> Security Class Initialized
DEBUG - 2021-05-15 20:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 20:15:56 --> Input Class Initialized
INFO - 2021-05-15 20:15:56 --> Language Class Initialized
INFO - 2021-05-15 20:15:56 --> Loader Class Initialized
INFO - 2021-05-15 20:15:56 --> Helper loaded: url_helper
INFO - 2021-05-15 20:15:56 --> Helper loaded: file_helper
INFO - 2021-05-15 20:15:56 --> Helper loaded: utility_helper
INFO - 2021-05-15 20:15:56 --> Helper loaded: unit_helper
INFO - 2021-05-15 20:15:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 20:15:56 --> Database Driver Class Initialized
INFO - 2021-05-15 20:15:56 --> Email Class Initialized
DEBUG - 2021-05-15 20:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 20:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 20:15:56 --> Helper loaded: form_helper
INFO - 2021-05-15 20:15:56 --> Form Validation Class Initialized
INFO - 2021-05-15 20:15:56 --> Controller Class Initialized
INFO - 2021-05-15 20:15:56 --> Model "Common_model" initialized
INFO - 2021-05-15 20:15:56 --> Model "Finane_Model" initialized
INFO - 2021-05-15 20:15:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 20:15:56 --> Model "Sales_Model" initialized
INFO - 2021-05-15 21:32:03 --> Config Class Initialized
INFO - 2021-05-15 21:32:03 --> Hooks Class Initialized
DEBUG - 2021-05-15 21:32:03 --> UTF-8 Support Enabled
INFO - 2021-05-15 21:32:03 --> Utf8 Class Initialized
INFO - 2021-05-15 21:32:03 --> URI Class Initialized
DEBUG - 2021-05-15 21:32:03 --> No URI present. Default controller set.
INFO - 2021-05-15 21:32:03 --> Router Class Initialized
INFO - 2021-05-15 21:32:03 --> Output Class Initialized
INFO - 2021-05-15 21:32:03 --> Security Class Initialized
DEBUG - 2021-05-15 21:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 21:32:03 --> Input Class Initialized
INFO - 2021-05-15 21:32:03 --> Language Class Initialized
INFO - 2021-05-15 21:32:03 --> Loader Class Initialized
INFO - 2021-05-15 21:32:03 --> Helper loaded: url_helper
INFO - 2021-05-15 21:32:03 --> Helper loaded: file_helper
INFO - 2021-05-15 21:32:03 --> Helper loaded: utility_helper
INFO - 2021-05-15 21:32:03 --> Helper loaded: unit_helper
INFO - 2021-05-15 21:32:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 21:32:03 --> Database Driver Class Initialized
INFO - 2021-05-15 21:32:03 --> Email Class Initialized
DEBUG - 2021-05-15 21:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 21:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 21:32:03 --> Helper loaded: form_helper
INFO - 2021-05-15 21:32:03 --> Form Validation Class Initialized
INFO - 2021-05-15 21:32:03 --> Controller Class Initialized
INFO - 2021-05-15 21:32:03 --> Model "Common_model" initialized
INFO - 2021-05-15 21:32:03 --> Model "Finane_Model" initialized
INFO - 2021-05-15 21:32:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 21:32:03 --> Model "Sales_Model" initialized
INFO - 2021-05-15 21:32:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 21:32:03 --> Final output sent to browser
DEBUG - 2021-05-15 21:32:03 --> Total execution time: 0.0458
INFO - 2021-05-15 22:38:56 --> Config Class Initialized
INFO - 2021-05-15 22:38:56 --> Hooks Class Initialized
DEBUG - 2021-05-15 22:38:56 --> UTF-8 Support Enabled
INFO - 2021-05-15 22:38:56 --> Utf8 Class Initialized
INFO - 2021-05-15 22:38:56 --> URI Class Initialized
DEBUG - 2021-05-15 22:38:56 --> No URI present. Default controller set.
INFO - 2021-05-15 22:38:56 --> Router Class Initialized
INFO - 2021-05-15 22:38:56 --> Output Class Initialized
INFO - 2021-05-15 22:38:56 --> Security Class Initialized
DEBUG - 2021-05-15 22:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 22:38:56 --> Input Class Initialized
INFO - 2021-05-15 22:38:56 --> Language Class Initialized
INFO - 2021-05-15 22:38:56 --> Loader Class Initialized
INFO - 2021-05-15 22:38:56 --> Helper loaded: url_helper
INFO - 2021-05-15 22:38:56 --> Helper loaded: file_helper
INFO - 2021-05-15 22:38:56 --> Helper loaded: utility_helper
INFO - 2021-05-15 22:38:56 --> Helper loaded: unit_helper
INFO - 2021-05-15 22:38:56 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 22:38:56 --> Database Driver Class Initialized
INFO - 2021-05-15 22:38:56 --> Email Class Initialized
DEBUG - 2021-05-15 22:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 22:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 22:38:56 --> Helper loaded: form_helper
INFO - 2021-05-15 22:38:56 --> Form Validation Class Initialized
INFO - 2021-05-15 22:38:56 --> Controller Class Initialized
INFO - 2021-05-15 22:38:56 --> Model "Common_model" initialized
INFO - 2021-05-15 22:38:56 --> Model "Finane_Model" initialized
INFO - 2021-05-15 22:38:56 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 22:38:56 --> Model "Sales_Model" initialized
INFO - 2021-05-15 22:38:56 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 22:38:56 --> Final output sent to browser
DEBUG - 2021-05-15 22:38:56 --> Total execution time: 0.0530
INFO - 2021-05-15 23:07:02 --> Config Class Initialized
INFO - 2021-05-15 23:07:02 --> Hooks Class Initialized
DEBUG - 2021-05-15 23:07:02 --> UTF-8 Support Enabled
INFO - 2021-05-15 23:07:02 --> Utf8 Class Initialized
INFO - 2021-05-15 23:07:02 --> URI Class Initialized
INFO - 2021-05-15 23:07:02 --> Router Class Initialized
INFO - 2021-05-15 23:07:02 --> Output Class Initialized
INFO - 2021-05-15 23:07:02 --> Security Class Initialized
DEBUG - 2021-05-15 23:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 23:07:02 --> Input Class Initialized
INFO - 2021-05-15 23:07:02 --> Language Class Initialized
ERROR - 2021-05-15 23:07:02 --> 404 Page Not Found: Estiaenterprise_rc/assets
INFO - 2021-05-15 23:07:03 --> Config Class Initialized
INFO - 2021-05-15 23:07:03 --> Hooks Class Initialized
DEBUG - 2021-05-15 23:07:03 --> UTF-8 Support Enabled
INFO - 2021-05-15 23:07:03 --> Utf8 Class Initialized
INFO - 2021-05-15 23:07:03 --> URI Class Initialized
INFO - 2021-05-15 23:07:03 --> Router Class Initialized
INFO - 2021-05-15 23:07:03 --> Output Class Initialized
INFO - 2021-05-15 23:07:03 --> Security Class Initialized
DEBUG - 2021-05-15 23:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 23:07:03 --> Input Class Initialized
INFO - 2021-05-15 23:07:03 --> Language Class Initialized
INFO - 2021-05-15 23:07:03 --> Loader Class Initialized
INFO - 2021-05-15 23:07:03 --> Helper loaded: url_helper
INFO - 2021-05-15 23:07:03 --> Helper loaded: file_helper
INFO - 2021-05-15 23:07:03 --> Helper loaded: utility_helper
INFO - 2021-05-15 23:07:03 --> Helper loaded: unit_helper
INFO - 2021-05-15 23:07:03 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 23:07:03 --> Database Driver Class Initialized
INFO - 2021-05-15 23:07:03 --> Email Class Initialized
DEBUG - 2021-05-15 23:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 23:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 23:07:03 --> Helper loaded: form_helper
INFO - 2021-05-15 23:07:03 --> Form Validation Class Initialized
INFO - 2021-05-15 23:07:03 --> Controller Class Initialized
INFO - 2021-05-15 23:07:03 --> Model "Common_model" initialized
INFO - 2021-05-15 23:07:03 --> Model "Finane_Model" initialized
INFO - 2021-05-15 23:07:03 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 23:07:03 --> Model "Sales_Model" initialized
INFO - 2021-05-15 23:07:03 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 23:07:03 --> Final output sent to browser
DEBUG - 2021-05-15 23:07:03 --> Total execution time: 0.0539
INFO - 2021-05-15 23:35:11 --> Config Class Initialized
INFO - 2021-05-15 23:35:11 --> Hooks Class Initialized
DEBUG - 2021-05-15 23:35:11 --> UTF-8 Support Enabled
INFO - 2021-05-15 23:35:11 --> Utf8 Class Initialized
INFO - 2021-05-15 23:35:11 --> URI Class Initialized
DEBUG - 2021-05-15 23:35:11 --> No URI present. Default controller set.
INFO - 2021-05-15 23:35:11 --> Router Class Initialized
INFO - 2021-05-15 23:35:11 --> Output Class Initialized
INFO - 2021-05-15 23:35:11 --> Security Class Initialized
DEBUG - 2021-05-15 23:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 23:35:11 --> Input Class Initialized
INFO - 2021-05-15 23:35:11 --> Language Class Initialized
INFO - 2021-05-15 23:35:11 --> Loader Class Initialized
INFO - 2021-05-15 23:35:11 --> Helper loaded: url_helper
INFO - 2021-05-15 23:35:11 --> Helper loaded: file_helper
INFO - 2021-05-15 23:35:11 --> Helper loaded: utility_helper
INFO - 2021-05-15 23:35:11 --> Helper loaded: unit_helper
INFO - 2021-05-15 23:35:11 --> Helper loaded: db_dinamic_helper
INFO - 2021-05-15 23:35:11 --> Database Driver Class Initialized
INFO - 2021-05-15 23:35:11 --> Email Class Initialized
DEBUG - 2021-05-15 23:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 23:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 23:35:11 --> Helper loaded: form_helper
INFO - 2021-05-15 23:35:11 --> Form Validation Class Initialized
INFO - 2021-05-15 23:35:11 --> Controller Class Initialized
INFO - 2021-05-15 23:35:11 --> Model "Common_model" initialized
INFO - 2021-05-15 23:35:11 --> Model "Finane_Model" initialized
INFO - 2021-05-15 23:35:11 --> Model "Inventory_Model" initialized
INFO - 2021-05-15 23:35:11 --> Model "Sales_Model" initialized
INFO - 2021-05-15 23:35:11 --> File loaded: /home/aelbfopi/amarcement.com/application/views/auth/login.php
INFO - 2021-05-15 23:35:11 --> Final output sent to browser
DEBUG - 2021-05-15 23:35:11 --> Total execution time: 0.0690
