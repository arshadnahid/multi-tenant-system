<style>
    table tr td{
        margin: 0px!important;
        padding: 2px!important;
    }

    table tr td  tfoot .form-control {
        width: 100%;
        height: 25px;
    }
</style>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Sales</a>
                </li>
                <li>Sales Transaction</li>
                <li class="active">Sales Invoice Edit  | <span style="color:red;"> *</span> <span style="color: red">Mark field must be fill up</span></li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/salesInvoice'); ?>">
                        <i class="ace-icon 	fa fa-list"></i> List
                    </a>
                </li>
                <li class="active saleAddPermission"><a href="<?php echo site_url($this->project . '/salesInvoice_add'); ?>" >
                        <i class="ace-icon 	fa fa-plus"></i>  Add
                    </a>
                </li>
                <li>
                    <a class=""  href="<?php echo site_url($this->project . '/salesInvoice_view/' . $editInvoice->generals_id); ?>">
                        <i class="ace-icon fa fa-search-plus bigger-130"></i> View
                    </a>
                </li>

            </ul>
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">
                        <table class="mytable table-responsive table table-bordered">
                            <tr>
                                <td style="padding: 10px!important;">
                                    <div class="col-md-6">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Customer ID <span style="color:red;"> *</span></label>
                                                <div class="col-sm-6">
                                                    <select title="Select product category" onchange="getCustomerCurrentBalace(this.value)"  id="customerid" name="customer_id"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Customer ID OR Name">
                                                        <option></option>
                                                        <?php foreach ($customerList as $key => $each_info): ?>
                                                            <option <?php
                                                        if ($editInvoice->customer_id == $each_info->customer_id) {
                                                            echo "selected";
                                                        }
                                                            ?> value="<?php echo $each_info->customer_id; ?>"><?php echo $each_info->typeTitle . ' - ' . $each_info->customerPhone . ' [ ' . $each_info->customerName . ' ] '; ?></option>
                                                            <?php endforeach; ?>
                                                    </select>
                                                    <div class="clearfix"></div>
                                                    <span id="loadCusSup"></span>


                                                </div>
                                                <!--                                            <div class="col-sm-2" id="newCustomerHide">
                                                                                                <a  data-toggle="modal" data-target="#myModal" class="btn btn-xs btn-success"><i class="fa fa-plus"></i>&nbsp;New</a>
                                                                                            </div>-->
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Reference</label>
                                                <div class="col-sm-6">
                                                    <select  name="reference"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Reference ID OR Name">
                                                        <option></option>
                                                        <?php foreach ($referenceList as $key => $each_ref): ?>
                                                            <option <?php
                                                        if ($editInvoice->reference == $each_ref->reference_id) {
                                                            echo "selected";
                                                        }
                                                            ?>  value="<?php echo $each_ref->reference_id; ?>"><?php echo $each_ref->referenceName; ?></option>
                                                            <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>




                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-4 control-label no-padding-right" for="form-field-1">Payment Type  <span style="color:red;"> *</span></label>
                                                <div class="col-sm-6">
                                                    <?php
                                                    $pType = array('1' => 'Full Cash', '2' => 'Credit', '3' => 'Cheque', '4' => 'Partial');
                                                    ?>
                                                    <select onchange="showBankinfo(this.value)"  name="paymentType"  class="chosen-select form-control" id="paymentType" data-placeholder="Select Payment Type">
                                                        <option></option>
                                                        <!--                                                    <option <?php
                                                    if ($editInvoice->payType == 1) {
                                                        echo "selected";
                                                    }
                                                    ?> value="1"  >Full Cash</option>-->
                                                        <option <?php
                                                        if ($editInvoice->payType == 4) {
                                                            echo "selected";
                                                        }
                                                    ?>  value="4">Cash</option>
                                                        <option <?php
                                                            if ($editInvoice->payType == 2) {
                                                                echo "selected";
                                                            }
                                                    ?>  value="2">Credit</option>
                                                        <option <?php
                                                            if ($editInvoice->payType == 3) {
                                                                echo "selected";
                                                            }
                                                    ?>  value="3">Cheque / DD/ PO</option>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="showBankInfo" style="display:none;">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <div class="col-sm-3"></div>
                                                    <div class="col-sm-2">
                                                        <input type="text" value="<?php echo isset($bank_check_details->bankName) ? $bank_check_details->bankName : '' ?>" name="bankName" id="bankName" class="form-control" placeholder="Bank Name"/>
                                                    </div>
                                                    <div class="col-sm-2">
                                                        <input type="text" value="<?php echo isset($bank_check_details->branchName) ? $bank_check_details->branchName : '' ?>" name="branchName" id="branchName" class="form-control" placeholder="Branch Name"/>
                                                    </div>
                                                    <div class="col-sm-2">
                                                        <input type="text" value="<?php echo isset($bank_check_details->checkNo) ? $bank_check_details->checkNo : '' ?>" class="form-control" id="checkNo" name="checkNo" placeholder="Check NO"/>
                                                    </div>
                                                    <div class="col-sm-2">
                                                        <input class="form-control date-picker"  name="checkDate"  id="checkDate" type="text" value="<?php echo isset($bank_check_details->checkDate) ? $bank_check_details->checkDate : '' ?>" data-date-format="dd-mm-yyyy" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>


                                    <div class="col-md-6">

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Invoice No</label>
                                                <div class="col-sm-4">
                                                    <input type="text" id="form-field-1" name="userInvoiceId" value="<?php echo str_replace("SUID#-","",$editInvoice->mainInvoiceId); ?>" class="form-control" placeholder="Invoice No"/>
                                                </div>
                                                <div class="col-sm-3">
                                                    <input type="text" id="form-field-1" name="voucherid" readonly value="<?php echo $editInvoice->voucher_no; ?>" class="form-control" placeholder="Voucher ID" />
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Sales Date  <span style="color:red;"> *</span></label>
                                                <div class="col-sm-7">
                                                    <div class="input-group">
                                                        <input class="form-control date-picker" name="saleDate" id="id-date-picker-1" type="text" value="<?php echo date('d-m-Y', strtotime($editInvoice->date)); ?>" data-date-format="dd-mm-yyyy" />
                                                        <span class="input-group-addon">
                                                            <i class="fa fa-calendar bigger-110"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Loader</label>
                                                <div class="col-sm-7">
                                                    <select  name="loader"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Loader">
                                                        <option></option>
                                                        <?php foreach ($employeeList as $key => $eachEmp): ?>
                                                            <option <?php
                                                        if ($editInvoice->loader == $eachEmp->id) {
                                                            echo "selected";
                                                        }
                                                            ?> value="<?php echo $eachEmp->id; ?>"><?php echo $eachEmp->personalMobile . ' [ ' . $eachEmp->name . ']'; ?></option>
                                                            <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Transportation</label>
                                                <div class="col-sm-7">
                                                    <select  name="transportation"  class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Transportation">
                                                        <option></option>
                                                        <?php foreach ($vehicleList as $key => $eachVehicle): ?>
                                                            <option <?php
                                                        if ($editInvoice->transportation == $eachVehicle->id) {
                                                            echo "selected";
                                                        }
                                                            ?> value="<?php echo $eachVehicle->id; ?>"><?php echo $eachVehicle->vehicleName . ' [ ' . $eachVehicle->vehicleModel . ' ]'; ?></option>
                                                            <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1">Shipping Address</label>
                                                <div class="col-sm-7">
                                                    <input type="text" placeholder="Shipping Address" name="shippingAddress" class="form-control" value="<?php echo $editInvoice->shipAddress; ?>" >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <input type="hidden" id="invoiceAmount" value="<?php echo $creditAmount->credit; ?>">
                            <input type="hidden" id="editCustomer" value="<?php echo $editInvoice->customer_id; ?>">
                            <input type="hidden" id="paymentType" value="<?php echo $editInvoice->payType; ?>">
                            <tr>
                                <td style="padding: 10px!important;">
                                    <div class="col-md-12">
                                        <div class="col-md-9">
                                            <div class="panel panel-default">
                                                <div class="panel-body">
                                                    <div class="table-header">
                                                        Sales Item
                                                    </div>
                                                    <table class="table table-bordered table-hover" id="show_item">
                                                        <thead>
                                                            <tr>
                                                                <th nowrap style="width:27%" align="center"><strong>Product Category <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width:27%" align="center"><strong>Product <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width:10%" align="center"><strong>Bundle <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width:10%" align="center"><strong>Quantity <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width:10%" align="center"><strong>Unit Price(BDT)  <span style="color:red;"> *</span></strong></th>
                                                                <th nowrap style="width:13%" align="center"><strong>Total Price(BDT) <span style="color:red;"> *</span></strong></th>
                                                                <th style="width:8%" align="center"><strong>Action</strong></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <select id="categoryId" onchange="getProductList2(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Product">
                                                                        <option value=""></option>
                                                                        <?php foreach ($productCat as $key => $eachCat):
                                                                            ?>
                                                                            <option categoryName="<?php echo $eachCat->title; ?>"  value="<?php echo $eachCat->category_id; ?>"><?php echo $eachCat->title; ?></option>
                                                                            <?php
                                                                        endforeach;
                                                                        ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select id="productID2" onchange="getProductPrice(this.value)" class="chosen-select form-control" id="form-field-select-3" data-placeholder="Search by Product">
                                                                        <option value=""></option>
                                                                    </select>
                                                                </td>
                                                                <td><input type="text" id="bundleValue" class="form-control text-right bundle decimal" placeholder="0"></td>
                                                                <td><input type="hidden" value="" id="stockQty"/><input type="text"  onkeyup="checkStockOverQty(this.value)" class="form-control text-right quantity decimal" placeholder="0"></td>
                                                                <td><input type="text" class="form-control text-right rate decimal" placeholder="0.00"  ></td>
                                                                <td><input type="text" class="form-control text-right price decimal" placeholder="0.00" readonly="readonly"></td>
                                                                <td><a id="add_item" class="btn btn-info form-control" href="javascript:;" title="Add Item"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Item</a></td>
                                                            </tr>
                                                        </tbody>
                                                        <tfoot>
                                                            <?php
                                                            $totalEditPrice = 0;
                                                            $totalQty = 0;
                                                            $totalReceive = 0;
                                                            $totalUnitPrice = 0;
                                                            $totalTotalPrice = 0;
                                                            foreach ($editStock as $key => $eachStock):
                                                                if ($eachStock->type == 'Out') {
                                                                    $returnQtyedit = $this->Sales_Model->getReturnAbleCylinder2($this->dist_id, $eachStock->generals_id, $eachStock->product_id, $eachStock->quantity);
                                                                    $totalQty+=$eachStock->quantity;
                                                                    $totalReceive+=$returnQtyedit->quantity;
                                                                    $totalUnitPrice+=$eachStock->rate;
                                                                    $totalTotalPrice+=$eachStock->price;
                                                                    ?>
                                                                    <tr class="new_item<?php echo $key + 100; ?>">
                                                                        <td style="padding-left:15px;">
                                                                            <input type="hidden" name="category_id[]" value="<?php echo $eachStock->category_id; ?>">
                                                                            <?php
                                                                            $catName = $this->Common_model->tableRow('productcategory', 'category_id', $eachStock->category_id)->title;
                                                                            $productInfo = $this->Common_model->tableRow('product', 'product_id', $eachStock->product_id);
                                                                            $brandInfo = $this->Common_model->tableRow('brand', 'brandId', $productInfo->brand_id);
                                                                            echo $catName;
                                                                            ?><input type="hidden" name="product_id[]" value="<?php echo $eachStock->product_id; ?>">
                                                                        </td>
                                                                        <td align="left"><?php echo $productInfo->productName . ' [ ' . $brandInfo->brandName . ' ] '; ?></td>
                                                                        <td align="right"><input type="text" id="bundle_<?php echo $key + 100; ?>" <?php
                                                                    if ($eachStock->category_id != 1) {
                                                                        echo "readonly";
                                                                    }
                                                                            ?> class="add_bundle text-right form-control decimal" name="bundle[]" value="<?php
                                                                                         if ($eachStock->bundle > 0) {
                                                                                             echo $eachStock->bundle;
                                                                                         }
                                                                            ?>"></td>
                                                                        <td align="right"><input type="text" id="qty_<?php echo $key + 100; ?>" class="add_quantity text-right form-control decimal" name="quantity[]" value="<?php echo $eachStock->quantity; ?>"></td>
                                                                        <td align="right"><input type="text" id="rate_<?php echo $key + 100; ?>" class="add_rate  text-right form-control decimal" name="rate[]" value="<?php echo $eachStock->rate; ?>"></td>
                                                                        <td align="right"><?php $totalEditPrice += $eachStock->price; ?><input type="text" class="add_price form-control text-right" id="tprice_<?php echo $key + 100; ?>" readonly name="price[]" value="<?php echo $eachStock->price; ?>"></td>
                                                                        <td><a del_id="<?php echo $key + 100; ?>" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td>
                                                                    </tr>
                                                                    <?php
                                                                }
                                                            endforeach;
                                                            ?>
                                                            <tr>
                                                                <td colspan="3" align="right"> Total </td>
                                                                <td align="right"><span class="total_quantity"><?php echo $totalQty; ?></span></td>
                                                                <td align="right"><span class="total_rate"><?php echo number_format($totalUnitPrice, 2); ?></span></td>
                                                                <td align="right"><span class="total_totalPrice"><?php echo number_format($totalTotalPrice, 2); ?></span></td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>



                                                    <table class="table table-bordered table-hover table-success">
                                                        <tr>
                                                            <td>
                                                                <textarea style="border:none;" cols="120"  class="form-control" name="narration" placeholder="Narration......" type="text"><?php echo $editInvoice->narration; ?></textarea>
                                                            </td>
                                                        </tr>
                                                    </table>



                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="panel panel-default">
                                                <div class="panel-body">
                                                    <div class="table-header">
                                                        Payment Calculation
                                                    </div>
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <td nowrap align="right"><strong>Total(BDT)</strong></td>

                                                            <td align="right"><strong class="total_price"><?php echo $totalEditPrice . '.00'; ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td  nowrap align="right"><strong>Discount ( - ) </strong></td>
                                                            <td><input type="text"  onkeyup="calDiscount()" id="disCount" style="text-align: right" name="discount" value="<?php
                                                            if (!empty($editInvoice->discount) && $editInvoice->discount >= 1): echo $editInvoice->discount;
                                                            endif;
                                                            ?>" class="form-control decimal" placeholder="0.00"    />
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td nowrap  align="right"><strong>Grand Total</strong></td>
                                                            <td><input readonly id="grandTotal" type="text" style="text-align: right" name="grandtotal" value="<?php echo $totalEditPrice - $editInvoice->discount; ?>" class="form-control"  placeholder="0.00"/></td>
                                                        </tr>
                                                        <tr>
                                                            <td nowrap align="right"><strong>VAT(%) ( + )</strong></td>
                                                            <td><input type="text" id="vatAmount"  style="text-align: right" name="vat" readonly value="<?php
                                                                       if (!empty($configInfo->VAT)): echo $configInfo->VAT;
                                                                       endif;
                                                            ?>" class="form-control totalVatAmount"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                        </tr>
                                                        <tr>
                                                            <td nowrap  align="right"><strong>Loader ( + )</strong></td>
                                                            <td><input type="text" id="loader" onkeyup="calcutateFinal()"   style="text-align: right" name="loaderAmount" value="<?php echo $editInvoice->loaderAmount; ?>"  class="form-control"  placeholder="0.00"/></td>
                                                        </tr>
                                                        <tr>
                                                            <td nowrap  align="right"><strong>Transportation ( + )</strong></td>
                                                            <td><input type="text" id="transportation" onkeyup="calcutateFinal()" value="<?php echo $editInvoice->transportationAmount; ?>"   style="text-align: right" name="transportationAmount" value=""  class="form-control"  placeholder="0.00"/></td>
                                                        </tr>
                                                        <?php
                                                        //vat deduction
                                                        $totalAmount = $totalEditPrice - $editInvoice->discount;
                                                        if (!empty($configInfo->VAT)):
                                                            $newAmount = ($configInfo->VAT / 100) * $totalAmount;
                                                        else:
                                                            $newAmount = $totalEditPrice - $editInvoice->discount;
                                                        endif;
                                                        ?>
                                                        <tr>
                                                            <td  nowrap  align="right"><strong>Net Total</strong></td>
                                                            <td><input type="text" id="netAmount"  style="text-align: right" name="netTotal" value="<?php echo $newAmount; ?>" readonly class="form-control"  placeholder="0.00"/></td>

                                                        </tr>
                                                        <tr class="chaque_amount_class" style="display:none">
                                                            <td nowrap  align="right"><strong>Chaque Amount</strong></td>
                                                            <td><input type="text" id="chaque_amount"  style="text-align: right" name="chaque_amount" value="<?php echo isset($bank_check_details->totalPayment) ? $bank_check_details->totalPayment : '' ?>"  class="form-control"  placeholder="0.00"/></td>
                                                        </tr>
                                                        <tr class="creditDate" style="display:none;">
                                                            <td  nowrap align="right"><strong>Due Date</strong></td>
                                                            <td>
                                                                <div class="input-group">
                                                                    <input class="form-control date-picker" name="creditDueDate" id="id-date-picker-1" type="text" value="<?php echo date('d-m-Y'); ?>" data-date-format="dd-mm-yyyy" />
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr class="partisals">
                                                            <td  nowrap  align="right"><strong>Add Account <span style="color:red;"> * </span></strong></td>
                                                            <td width="100%" colspan="2">
                                                                <select   name="accountCrPartial" class="chosen-select   checkAccountBalance" id="partialHead" data-placeholder="Search by Account Head"  onchange="check_pretty_cash(this.value)">
                                                                    <option value=""></option>
                                                                    <?php
                                                                    foreach ($accountHeadList as $key => $head) {
                                                                        if ($key == 42 || $key == 45 || $key == 55) {
                                                                            ?>
                                                                            <optgroup label="<?php echo $head['parentName']; ?>">
                                                                                <?php
                                                                                foreach ($head['Accountledger'] as $eachLedger) :
                                                                                    ?>
                                                                                    <option <?php
                                                                        if ($accountId == $eachLedger->chartId) {
                                                                            echo "selected";
                                                                        } elseif ($eachLedger->chartId == '54') {
                                                                            echo "selected";
                                                                        }
                                                                                    ?> value="<?php echo $eachLedger->chartId; ?>"><?php echo $eachLedger->title . " ( " . $eachLedger->code . " ) "; ?></option>
                                                                                    <?php endforeach; ?>
                                                                            </optgroup>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        <tr  class="partisals">
                                                            <td  nowrap align="right"><strong> Payment ( - )<span style="color:red;"> * </span></strong></td>
                                                            <td><input type="text" id="payment" onkeyup="calculatePartialPayment()" style="text-align: right" name="partialPayment" value="<?php echo $creditAmount->credit; ?>"  class="form-control"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                        <input type="hidden" id="duePayment"  style="text-align: right" name="duePayment" value="<?php echo number_format($newAmount - $creditAmount->credit, 2); ?>" readonly  class="form-control"  placeholder="0.00"/>
                                                        </tr>

                                                        <tr>
                                                            <td nowrap align="right"><strong>Due Amount</strong></td>
                                                            <td><input type="text" id="currentDue"  readonly style="text-align: right" name="" value=""  class="form-control" autocomplete="off"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>

                                                        </tr>
                                                        <tr>
                                                            <td  nowrap align="right"><strong>Previous Due</strong></td>
                                                            <td><input type="text" id="previousDue"  readonly style="text-align: right" name="" value=""  class="form-control" autocomplete="off"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>

                                                        </tr>
                                                        <tr>
                                                            <td  nowrap align="right"><strong>Total Due</strong></td>
                                                            <td><input type="text" id="totalDue"  readonly style="text-align: right" name="" value=""  class="form-control" autocomplete="off"  placeholder="0.00"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" /></td>
                                                        </tr>

                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="clearfix"></div>
                                    <div class="clearfix form-actions" >
                                        <div class="col-md-offset-1 col-md-10">
                                            <button onclick="return isconfirm2()" id="subBtn" class="btn btn-info" type="button">
                                                <i class="ace-icon fa fa-check bigger-110"></i>
                                                Update
                                            </button>

                                        </div>
                                    </div>
                                </td></tr></table>
                    </form>
                </div>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script>
    function isconfirm2() {
        var customerid = $("#customerid").val();
        var saleDate = $("#saleDate").val();
        var paymentType = $("#paymentType").val();
        var paymentType = $("#paymentType").val();
        var dueDate = $("#dueDate").val();
        var partialHead = $("#partialHead").val();
        var thisAllotment = $("#payment").val();
        var bankName = $("#bankName").val();
        var branchName = $("#branchName").val();
        var checkNo = $("#checkNo").val();
        var checkDate = $("#checkDate").val();
        var cylinder = 0;
        if ($("#culinderReceive").css('display') == 'none') {
            cylinder = 0;
        } else {
            //var cylinderItem = parseFloat($(".total_quantity2").text());
            var rowCount = $('#show_item2 tfoot tr').length;

            cylinder = 1;
        }
        var totalPrice = parseFloat($(".total_price").text());
        if (isNaN(totalPrice)) {
            totalPrice = 0;
        }
        if (customerid == '') {
            swal("Select Customer Name!", "Validation Error!", "error");
        } else if (saleDate == '') {
            swal("Select Sale Date!", "Validation Error!", "error");
        } else if (paymentType == '') {
            swal("Select Payment Type", "Validation Error!", "error");
        } else if (paymentType == 2 && dueDate == '') {
            swal("Select Due Date!", "Validation Error!", "error");
        } else if (paymentType == 3 && bankName == '') {
            swal("Type Bank Name!", "Validation Error!", "error");
        } else if (paymentType == 3 && branchName == '') {
            swal("Type Branch Name!", "Validation Error!", "error");
        } else if (paymentType == 3 && checkNo == '') {
            swal("Type Check No!", "Validation Error!", "error");
        } else if (paymentType == 3 && checkDate == '') {
            swal("Select Check Date!", "Validation Error!", "error");
        } else if (totalPrice == '' || totalPrice < 0) {
            swal("Add Purcahses Item!", "Validation Error!", "error");
        } else if (paymentType == 4 && partialHead == '') {
            swal("Select Account Head!", "Validation Error!", "error");
        } else if (paymentType == 4 && thisAllotment == '') {
            swal("Given Cash Amount!", "Validation Error!", "error");
        } else{
            swal({
                title: "Are you sure ?",
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#73AE28',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true,
                type: 'success'
            },
            function (isConfirm) {
                if (isConfirm) {
                    $("#publicForm").submit();
                } else {
                    return false;
                }
            });
        }
    }
</script>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add New Customer</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <form id="publicForm2" action=""  method="post" class="form-horizontal">
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer ID </label>
                                <div class="col-sm-8">
                                    <input type="text" id="customerId" name="customerID" readonly value="<?php echo isset($customerID) ? $customerID : ''; ?>" class="form-control" placeholder="Customer ID" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Customer Name </label>
                                <div class="col-sm-8">
                                    <input type="text" id="customerName" name="customerName" class="form-control" placeholder="Customer Name" required/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Phone</label>
                                <div class="col-sm-8">
                                    <input type="text"  maxlength="11" id="form-field-1 cstPhone" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" onblur="checkDuplicatePhone(this.value)" name="customerPhone" placeholder="Customer Phone" class="form-control" />
                                    <span id="errorMsg"  style="color:red;display: none;"><i class="ace-icon fa fa-spinner fa-spin orange bigger-120"></i> &nbsp;&nbsp;Phone Number already Exits!!</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email</label>
                                <div class="col-sm-8">
                                    <input type="email" id="form-field-1" name="customerEmail" placeholder="Email" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address</label>
                                <div class="col-sm-8">
                                    <!--<textarea id="editor1" cols="10" rows="5" name="comp_add"></textarea>-->
                                    <textarea  cols="6" rows="3" placeholder="Type Address.." class="form-control" name="customerAddress"></textarea>
                                </div>
                            </div>
                            <div class="clearfix form-actions" >
                                <div class="col-md-offset-3 col-md-9">
                                    <button onclick="saveNewCustomer()" id="subBtn2" class="btn btn-info" type="button">
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        Save
                                    </button>
                                    &nbsp; &nbsp; &nbsp;
                                    <button class="btn" type="reset" data-dismiss="modal">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>

<script>


    $.ajax({
        type: "POST",
        url: baseUrl + "InventoryController/loadCusSupDetails",
        data: {
            supCusId:'<?php echo $editInvoice->customer_id; ?>',
            type:1
        },
        success: function (data) {
            $("#loadCusSup").html(data);
        }
    });



    $(document).ready(function () {
        console.log("ready!");

        var payType = $('#paymentType').val();
        showBankinfo(payType);
    });




<?php if (!empty($cylinderReceive)):
    ?>

            setTimeout(function () {
                $('#culinderReceive').show();
            }, 10);
<?php else: ?>
        setTimeout(function () {
            $('#culinderReceive').hide();
        }, 2000);
<?php endif; ?>
    var url = baseUrl + "SalesController/getCustomerCurrentBalance";
    $.ajax({
        type: 'POST',
        url: url,
        data: {
            customerId: '<?php echo $editInvoice->customer_id; ?>'
        },
        success: function (data)
        {
            $('.currentBalance').val(data);
            getCustomerCurrentBala();

        }
    });
<?php if ($editInvoice->payType == 4) { ?>
        setTimeout(function () {
            $(".partisals").show(10);
        }, 2000);
        $(".partisals").show(10);
<?php } elseif ($editInvoice->payType == 3) { ?>
        $("#showBankInfo").show(10);
<?php } elseif ($editInvoice->payType == 2) { ?>
        setTimeout(function () {
            $(".partisals").hide(10);
        }, 2000);
        $(".creditDate").show(10);
<?php } ?>
</script>
<!--<script type="text/javascript" src="<?php echo base_url('assets/sales/salesEdit.js'); ?>"></script>-->


<script>


    $(document).on("keyup", ".add_quantity", function () {
        var id_arr = $(this).attr('id');
        var id = id_arr.split("_");
        var element_id = id[id.length - 1];
        var quantity = parseFloat($("#qty_" + element_id).val());
        if(isNaN(quantity)){
            quantity=0;
        }
        var rate= parseFloat($("#rate_" + element_id).val());
        if(isNaN(rate)){
            rate=0;
        }
        var totalAmount = quantity * rate;
        $("#tprice_"+ element_id).val(parseFloat(totalAmount).toFixed(2));
        var row_total = 0;
        $.each($('.add_price'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            row_total += quantity;
        });
        $('.total_price').html(parseFloat(row_total).toFixed(2));
        calculateCustomerDue();
        findTotalCal();
    });

    $(document).on("keyup", ".add_rate", function () {
        var id_arr = $(this).attr('id');
        var id = id_arr.split("_");
        var element_id = id[id.length - 1];
        var quantity = parseFloat($("#qty_" + element_id).val());
        if(isNaN(quantity)){
            quantity=0;
        }
        var rate= parseFloat($("#rate_" + element_id).val());
        if(isNaN(rate)){
            rate=0;
        }
        var totalAmount = quantity * rate;
        $("#tprice_"+ element_id).val(parseFloat(totalAmount).toFixed(2));
        var row_total = 0;
        $.each($('.add_price'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            row_total += quantity;
        });
        $('.total_price').html(parseFloat(row_total).toFixed(2));
        calculateCustomerDue();
        findTotalCal();
    });


    $(document).on("keyup", ".add_ReturnQuantity", function () {

        calculateCustomerDue();
        findTotalCal();

    });


    function checkDuplicateCategory(catName){
        var url = baseUrl+ "SetupController/checkDuplicateCategory";
        $.ajax({
            type: 'POST',
            url: url,
            data:{
                'catName': catName
            },
            success: function (data)
            {
                if(data == 1){
                    $("#subBtn").attr('disabled',true);
                    $("#errorMsg").show(10);
                }else{
                    $("#subBtn").attr('disabled',false);
                    $("#errorMsg").hide(10);
                }
            }
        });
    }

    function getCustomerCurrentBalace(customerId){
        calculateCustomerDue();
        setTimeout(function() {
            calcutateFinal();
        }, 100);
        $.ajax({
            type: "POST",
            url: baseUrl + "InventoryController/loadCusSupDetails",
            data: {
                supCusId:customerId,
                type:1
            },
            success: function (data) {
                $("#loadCusSup").html(data);
            }
        });
    }


    function getCustomerCurrentBala(){

        calculateCustomerDue();
        setTimeout(function() {
            calcutateFinalEdit();
        }, 100);

    }




    function calcutateFinalEdit(){
        var total_price = parseFloat($(".total_price").text());
        if(isNaN(total_price)){
            total_price=0;
        }
        var payment = parseFloat($("#payment").val());
        if(isNaN(payment)){
            payment=0;
        }
        var previousDue = parseFloat($("#previousDue").val());
        if(isNaN(previousDue)){
            previousDue=0;
        }


        var discount = parseFloat($("#disCount").val());
        if(isNaN(discount)){
            discount=0;
        }
        //var total_price = (total_price + transportation +  loader) - discount;




        if(payment > total_price ){
            $("#currentDue").val(parseFloat(0.00).toFixed(2));
        }else{
            $("#currentDue").val(parseFloat(total_price - payment).toFixed(2));
        }
        $("#previousDue").val(parseFloat(previousDue- (total_price - payment)).toFixed(2));
        $("#totalDue").val(parseFloat(((previousDue - (total_price - payment))+(total_price - payment))).toFixed(2));
    }


    function calculatePartialPayment(){
        setTimeout(function() {
            calcutateFinal();
        }, 100);

    }
    function showDuePayment(paymentValue){
        var netAmount = parseFloat($("#netAmount").val());
        var allocateAmount=parseFloat(paymentValue);
        var dueAmount =netAmount - allocateAmount;
    }
    function showBankinfo(id){
        $(".chaque_amount_class").hide(10);

        calcutateFinal();

        if(id == 3){
            $("#showBankInfo").show(10);
            $(".chaque_amount_class").show(10);
        }else{
            $("#showBankInfo").hide(10);
        }
        if(id == 4){
            $(".partisals").show(10);
        }else{
            $(".partisals").hide(10);
        }
        if(id == 2){
            $(".creditDate").show(10);
        }else{
            $(".creditDate").hide(10);
        }
    }
    function saveNewCustomer(){
        var customerName=$("#customerName").val();
        var customerId=$("#customerId").val();
        if(customerName == ''){
            alert("Customer Name Can't be empty!!");
            return false;
        }else if(customerId == ''){
            alert("Customer Id Can't be empty!!");
            return false;
        }else{
            var url = baseUrl + "SalesController/saveNewCustomer";
            $.ajax({
                type: 'POST',
                url: url,
                data:$("#publicForm2").serializeArray(),
                success: function (data)
                {
                    $('#myModal').modal('toggle');
                    $('#newCustomerHide').hide();
                    $('#customerid').chosen();
                    //$('#customerid option').remove();
                    $('#customerid').append($(data));
                    $("#customerid").trigger("chosen:updated");
                }
            });
        }
    }
    function checkDuplicatePhone(phone){
        var url = baseUrl+ "SalesController/checkDuplicatePhone";
        $.ajax({
            type: 'POST',
            url: url,
            data:{
                'phone': phone
            },
            success: function (data)
            {
                if(data == 1){
                    $("#subBtn2").attr('disabled',true);
                    $("#errorMsg").show(10);
                }else{
                    $("#subBtn2").attr('disabled',false);
                    $("#errorMsg").hide(10);
                }
            }
        });
    }

    $(document).ready(function () {

        $('.rate').blur(function () {
            var rate = parseFloat($(this).val());
            if(isNaN(rate)){
                rate=0;
            }
            $(this).val(parseFloat(rate).toFixed(2));
        });

        $('.quantity').keyup(function () {
            priceCal();
        });
        $('.rate').keyup(function () {
            priceCal();
        });
    });

    function priceCal() {
        var quantity = parseFloat($('.quantity').val());
        var rate = parseFloat($('.rate').val());
        $('.price').val(parseFloat(rate * quantity).toFixed(2));
    }

    function calDiscount() {
        findDiscount();
        findVatAmount();
        calculatePartialPayment();
    }

    var findDiscount = function () {
        var totalPrice = parseFloat($(".total_price").text());
        if(isNaN(totalPrice)){
            totalPrice=0;
        }
        if(totalPrice == ''){
            $("#disCount").val('');
        }
        var disCount = parseFloat($("#disCount").val());
        if(isNaN(disCount)){
            disCount=0;
        }
        //var deductDiscount = (disCount / 100) * totalPrice;
        $("#grandTotal").val(parseFloat(Math.round(totalPrice - disCount)).toFixed(2));
        calcutateFinal();
    };


    var findVatAmount = function () {

        var loader = parseFloat($("#loader").val());
        if(isNaN(loader)){
            loader=0;
        }
        var transportation = parseFloat($("#transportation").val());
        if(isNaN(transportation)){
            transportation=0;
        }

        var vatValue = $("#vatAmount").val();
        if(isNaN(vatValue)){
            vatValue=0;
        }
        var grandTotal = parseFloat($("#grandTotal").val());
        if(isNaN(grandTotal)){
            grandTotal=0;
        }
        var vatForwardAmount = parseFloat((vatValue / 100) * grandTotal);
        if(isNaN(vatForwardAmount)){
            vatForwardAmount=0;
        }
        $(".totalVatAmount").html(parseFloat(Math.round(vatForwardAmount)).toFixed(2));
        $("#netAmount").val(parseFloat(Math.round(vatForwardAmount) + grandTotal + loader + transportation).toFixed(2));
    };


    var findTotalQty = function () {
        var total_quantity = 0;
        $.each($('.add_quantity'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            total_quantity += quantity;
        });
        $('.total_quantity').html(parseFloat(total_quantity));
    };
    var findTotalQty2 = function () {
        var total_quantity2 = 0;
        $.each($('.add_quantity2'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            total_quantity2 += quantity;
        });
        $('.total_quantity2').html(parseFloat(total_quantity2));
    };
    var findTotalReturnQty = function () {
        var total_return_quantity = 0;
        $.each($('.add_ReturnQuantity'), function () {
            quantity = $(this).val();
            quantity = Number(quantity);
            total_return_quantity += quantity;
        });
        $('.total_return_quantity').html(parseFloat(total_return_quantity));
    };
    var findTotalRate = function () {
        var total_rate = 0;
        $.each($('.add_rate'), function () {
            rate = $(this).val();
            rate = Number(rate);
            total_rate += rate;
        });
        $('.total_rate').html(parseFloat(total_rate).toFixed(2));
    };
    var findTotalPrice = function () {
        var total_price = 0;
        $.each($('.add_price'), function () {
            price = $(this).val();
            price = Number(price);
            total_price += price;
        });
        $('.total_price').html(parseFloat(total_price).toFixed(2));
        $('.total_totalPrice').html(parseFloat(total_price).toFixed(2));
        // discount(total_price);
        // findVatAmount(total_price);
    };
    var calculateCustomerDue = function () {
        var customerid=parseFloat($('#customerid').val());
        var url = baseUrl + "SalesController/getCustomerCurrentBalance";
        $.ajax({
            type: 'POST',
            url: url,
            data:{
                customerId: customerid
            },
            success: function (data)
            {
                data=parseFloat(data);
                if(isNaN(data)){
                    data=0;
                }
                $('#previousDue').val(parseFloat(data).toFixed(2));
            }
        });
    };

    var findTotalCal = function () {
        findTotalQty();
        findTotalReturnQty();
        findTotalRate();
        findTotalPrice();
        calDiscount();
        calculatePartialPayment();
    };
    function checkStockOverQty(givenStock){
        var orgiStock=parseFloat($("#stockQty").val());
        var givenStock= parseFloat(givenStock);
        if(isNaN(givenStock)){
            givenStock=0;
        }
        if(isNaN(orgiStock)){
            orgiStock=0;
        }
        //  alert(orgiStock);
        if(orgiStock < givenStock){
            $(".quantity").val('');
            $(".quantity").val(parseFloat(orgiStock));
            productItemValidation("Stock Quantity Not Available.");
        }
    }
    $(document).ready(function () {
        var j = 0;
        $("#add_item").click(function () {
            var productCatID = $('#categoryId').val();
            var productCatName = $('#categoryId').find('option:selected').attr('categoryName');

            var productID = $('#productID2').val();
            var productName = $('#productID2').find('option:selected').attr('productName');
            var quantity = $('.quantity').val();
            var bundle = $('.bundle').val();
            var bundleValue = $('#bundleValue').val();
            var rate = $('.rate').val();
            var price = $('.price').val();
            if(productCatID  == ''){
                swal("Product Category can't be empty!", "Validation Error!", "error");
                return false;
            }else if(productID == ''){
                swal("Product Name can't be empty!", "Validation Error!", "error");
                return false;
            }else if(productCatID == 1 && (bundleValue == '' || bundleValue <= 0)){
                swal("Bundle Qty Can't be empty!", "Validation Error!", "error");
                return false;
            }else if(quantity == ''){
                swal("Quantity Can't be empty!", "Validation Error!", "error");
                return false;
            }else if(rate == ''){
                swal("Unit Price Can't be empty!", "Validation Error!", "error");
                return false;
            }else{
                if(productCatID == 2){
                    $("#show_item tfoot").prepend('<tr class="new_item' + productCatID + productID + j + '"><input type="hidden" name="category_id[]" value="' + productCatID + '"><td style="padding-left:15px;">' + productCatName + '</td><td style="padding-left:15px;">' + productName + '<input type="hidden"  name="product_id[]" value="' + productID + '"></td><td align="right"><input type="text" class="add_bundle decimal text-right form-control" name="bundle[]" value="' + bundle + '"  id="bundle_'+ j +'"><td align="right"><input type="text" class="add_quantity decimal text-right form-control" name="quantity[]" value="' + quantity + '"  id="qty_'+ j +'"></td><td align="right"><input type="text" class="add_rate  text-right form-control decimal" name="rate[]" value="' + rate + '"  id="rate_'+ j +'"></td><td align="right"><input type="text" class="add_price  text-right form-control" readonly name="price[]" value="' + price + '"  id="tprice_'+ j +'"></td><td><a del_id="' + productCatID + productID  + j + '" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');
                }else{
                    $("#show_item tfoot").prepend('<tr class="new_item' + productCatID + productID + j + '"><input type="hidden" name="category_id[]" value="' + productCatID + '"><td style="padding-left:15px;">' + productCatName + '</td><td style="padding-left:15px;">' + productName + '<input type="hidden"  name="product_id[]" value="' + productID + '"></td><td align="right"><input type="text" class="add_bundle decimal text-right form-control" name="bundle[]" value="' + bundle + '"  id="bundle_'+ j +'"><td align="right"><input type="text" class="add_quantity decimal text-right form-control" name="quantity[]" value="' + quantity + '"  id="qty_'+ j +'"></td><td align="right"><input type="text" class="add_rate  text-right form-control decimal" name="rate[]" value="' + rate + '"  id="rate_'+ j +'"></td><td align="right"><input type="text" class="add_price  text-right form-control" readonly name="price[]" value="' + price + '"  id="tprice_'+ j +'"></td><td><a del_id="' + productCatID + productID  + j + '" class="delete_item btn form-control btn-danger" href="javascript:;" title=""><i class="fa fa-times"></i>&nbsp;Remove</a></td></tr>');
                }
                j++;
            }
            $("#subBtn").attr('disabled',false);
            $('.quantity').val('');
            $('.rate').val('');
            $('.bundle').val('');
            $('.price').val('');
            $(".quantity").attr("placeholder", "0");
            $('#categoryId').val('').trigger('chosen:updated');
            $('#productID2').val('').trigger('chosen:updated');
            $('#category_product').val('').trigger('chosen:updated');
            findTotalCal();
            setTimeout(function() {
                calcutateFinal();
            }, 100);
            j++;
        });
        $(document).on('click','.delete_item', function () {
            var id = $(this).attr("del_id");
            swal({
                title: "Are you sure ?",
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#73AE28',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true,
                type: 'success'
            },
            function (isConfirm) {
                if (isConfirm) {
                    $('.new_item' + id).remove();
                    findTotalCal();
                    setTimeout(function() {
                        calcutateFinal();
                    }, 100);
                }else{
                    return false;
                }
            });
        });
    });

    function calcutateFinal(){

        findVatAmount();
        var loader = parseFloat($("#loader").val());
        if(isNaN(loader)){
            loader=0;
        }
        var transportation = parseFloat($("#transportation").val());
        if(isNaN(transportation)){
            transportation=0;
        }


        var total_price = parseFloat($(".total_price").text());
        if(isNaN(total_price)){
            total_price=0;
        }

        var discount = parseFloat($("#disCount").val());
        if(isNaN(discount)){
            discount=0;
        }
        var total_price = (total_price + transportation +  loader) - discount;

        var payment = parseFloat($("#payment").val());
        if(isNaN(payment)){
            payment=0;
        }
        var previousDue = parseFloat($("#previousDue").val());
        if(isNaN(previousDue)){
            previousDue=0;
        }
        if(payment > total_price ){
            $("#currentDue").val(parseFloat(0.00).toFixed(2));
        }else{
            $("#currentDue").val(parseFloat(total_price - payment).toFixed(2));
        }
        $("#totalDue").val(parseFloat((total_price+previousDue) - payment).toFixed(2));
    }

    function getProductPrice(product_id) {

        var productCatID = $('#categoryId').val();
        if(productCatID == 1){
            $("#bundleValue").attr('readonly',false);
        }else{
            $("#bundleValue").val('');
            $("#bundleValue").attr('readonly',true);
        }

        $.ajax({
            type: "POST",
            url: baseUrl + "FinaneController/getProductPriceForSale",
            data: 'product_id=' + product_id,
            success: function (data) {
                $('.rate').val('');
            }
        });
        $.ajax({
            type: "POST",
            url: baseUrl+ "FinaneController/getProductStock",
            data: 'product_id=' + product_id,
            success: function (data) {
                var mainStock = parseFloat(data);
                if(isNaN(mainStock)){
                    mainStock=0;
                }

                if(data !=''){
                    $("#stockQty").val(data);
                    $(".quantity").attr("disabled",false);
                    if(mainStock <= 0){
                        $(".quantity").attr("disabled",true);
                        $(".quantity").attr("placeholder", "0 ");
                    }else{
                        $(".quantity").attr("disabled",false);
                        $(".quantity").attr("placeholder", " "+mainStock);
                    }
                }else{
                    $("#stockQty").val('');
                    $(".quantity").attr("disabled",true);
                    $(".quantity").attr("placeholder", "0");
                }
            }
        });
        if(productCatID == 1){
            $.ajax({
                type: "POST",
                url: baseUrl+ "FinaneController/getProductStockBundle",
                data: 'product_id=' + product_id,
                success: function (data) {
                    var mainStock = parseFloat(data);
                    if(isNaN(mainStock)){
                        mainStock=0;
                    }
                    if(data !=''){
                        $("#stockQtyBundle").val(parseFloat(data).toFixed(2));
                        $(".bundle").attr("disabled",false);
                        if(mainStock <= 0){
                            $(".bundle").attr("disabled",true);
                            $(".bundle").attr("placeholder", "  ");
                        }else{
                            $(".bundle").attr("disabled",false);
                            $(".bundle").attr("placeholder", "" + parseFloat(mainStock).toFixed(2));
                        }
                    }else{
                        $("#stockQtyBundle").val('');
                        $(".bundle").attr("disabled",true);
                        $(".bundle").attr("placeholder", " ");
                    }
                }
            });


        }
    }


    function getProductList(cat_id) {
        if(cat_id == 2){
            $(".returnQuantity").attr("readonly",false);
        }else{
            $(".returnQuantity").attr("readonly",true);
        }
        $.ajax({
            type: "POST",
            url: baseUrl+ "InventoryController/getProductList",
            data: 'cat_id=' + cat_id,
            success: function (data) {
                $('#productID').chosen();
                $('#productID option').remove();
                $('#productID').append($(data));
                $("#productID").trigger("chosen:updated");
            }
        });
    }
    function getProductList2(cat_id) {
        $.ajax({
            type: "POST",
            url: baseUrl+ "InventoryController/getProductList",
            data: 'cat_id=' + cat_id,
            success: function (data) {
                $('#productID2').chosen();
                $('#productID2 option').remove();
                $('#productID2').append($(data));
                $("#productID2").trigger("chosen:updated");
            }
        });


        if(cat_id == 1){
            $("#bundleValue").attr('readonly',false);
        }else{
            $("#bundleValue").attr("placeholder", " ");
            $("#bundleValue").val('');
            $("#bundleValue").attr('readonly',true);
        }



    }



</script>

