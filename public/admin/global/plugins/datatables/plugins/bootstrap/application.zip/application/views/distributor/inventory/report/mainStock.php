<?php
if (isset($_POST['start_date'])):
    $start_date = $this->input->post('start_date');
    $end_date = $this->input->post('end_date');
    $categoryId = $this->input->post('categoryId');
    $brandId = $this->input->post('brandId');

endif;
?>
<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state noPrint" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Inventory</a>
                </li>
                <li >Inventory Report</li>
                <li class="active">Stock Report</li>
            </ul>
            <ul class="breadcrumb pull-right">
                <li>
                    <a href="<?php echo site_url($this->project . '/DistributorDashboard/inventory'); ?>">
                        <i class="ace-icon fa fa-list"></i>
                        List
                    </a>
                </li>
            </ul>
        </div>
        <br>
        <div class="page-content">
            <div class="row noPrint">
                <div class="col-md-12">
                    <form id="publicForm" action=""  method="post" class="form-horizontal">

                        <div class="table-header">
                            Stock Report
                        </div>
                        <br>
                        <div style="background-color: grey!important;">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Category</label>
                                    <div class="col-sm-8">
                                        <select  name="categoryId" class="chosen-select form-control supplierid" id="form-field-select-3" data-placeholder="Search by Category">
                                            <option <?php
if (!empty($categoryId) && $categoryId == 'All') {
    echo "selected";
}
?> value="All">All</option>
                                                <?php foreach ($categoryList as $eachInfo): ?>
                                                <option <?php
                                                if (!empty($categoryId) && $categoryId == $eachInfo->category_id) {
                                                    echo "selected";
                                                }
                                                    ?> value="<?php echo $eachInfo->category_id; ?>"><?php echo $eachInfo->title; ?></option>
                                                <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Brand</label>
                                    <div class="col-sm-8">
                                        <select  name="brandId" class="chosen-select form-control supplierid" id="form-field-select-3" data-placeholder="Search by Category">
                                            <option <?php
                                                if (!empty($brandId) && $brandId == 'All') {
                                                    echo "selected";
                                                }
                                                ?> value="All">All</option>
                                                <?php foreach ($brandList as $eachInfo): ?>
                                                <option <?php
                                                if (!empty($brandId) && $brandId == $eachInfo->brandId) {
                                                    echo "selected";
                                                }
                                                    ?> value="<?php echo $eachInfo->brandId; ?>"><?php echo $eachInfo->brandName; ?></option>
                                                <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> From Date</label>
                                    <div class="col-sm-8">
                                        <input type="text"class="date-picker" id="start_date" name="start_date" value="<?php
                                                if (!empty($start_date)) {
                                                    echo $start_date;
                                                } else {
                                                    echo date('d-m-Y');
                                                }
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="Start Date: dd-mm-yyyy"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> To Date</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="date-picker" id="end_date" name="end_date" value="<?php
                                               if (!empty($end_date)) {
                                                   echo $end_date;
                                               } else {
                                                   echo date('d-m-Y');
                                               }
                                                ?>" data-date-format='dd-mm-yyyy' placeholder="End Date: dd-mm-yyyy"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">



                                <div class="col-sm-6">
                                    <button type="submit" class="btn btn-success btn-sm">
                                        <span class="ace-icon fa fa-search icon-on-right bigger-110"></span>
                                        Search
                                    </button>
                                </div>
                                <div class="col-sm-6">
                                    <button type="button" class="btn btn-info btn-sm"  onclick="window.print();" style="cursor:pointer;">
                                        <i class="ace-icon fa fa-print  align-top bigger-125 icon-on-right"></i>
                                        Print
                                    </button>
                                </div>

                            </div>
                        </div>

                        <div class="clearfix"></div>
                    </form>
                </div>
            </div><!-- /.col -->
            <?php
            if (isset($_POST['start_date'])):
                $dr = 0;
                $cr = 0;
                ?>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="table-header">
                            Stock Report <span style="color:greenyellow;">From <?php echo $start_date; ?> To <?php echo $end_date; ?></span>
                        </div>
                        <div class="noPrint">
    <!--                        <a style="border-radius:100px 0 100px 0;" href="<?php echo site_url($this->project . '/InventoryController/stockReport_export_excel/') ?>" class="btn btn-success pull-right noPrint">
                            <i class="ace-icon fa fa-download"></i>
                            Excel
                        </a>-->
                        </div>



                        <?php if ($companyInfo->invoice_format_type == 1): ?>


                            <table class="table table-responsive">
                                <tr>
                                    <td style="text-align:center;">
                                        <h3><?php echo $companyInfo->companyName; ?>.</h3>
                                        <span><?php echo rtrim($companyInfo->address); ?></span><br>
                                        <strong>Phone : </strong><?php echo $companyInfo->phone; ?><br>
                                        <strong>Email : </strong><?php echo $companyInfo->email; ?><br>
                                        <strong>Website : </strong><?php echo $companyInfo->website; ?><br>
                                        <strong><?php echo $pageTitle; ?></strong>
                                    </td>
                                </tr>
                            </table>

                        <?php else: ?>
                            <div>
                                <?php echo $companyInfo->report_header; ?>
                            </div>
                        <?php endif; ?>

                        <table class="table table-striped table-bordered table-hover table-responsive">
                            <thead>
                                <tr>
                                    <td rowspan="2"  style="text-align:left;"><strong>SL</strong></td>
                                    <td rowspan="2"  style="text-align:left;"><strong>Products</strong></td>
                                    <td colspan="5"  style="text-align:center;"><strong>Opening Stock as on </strong></td>
                                    <td colspan="5"  style="text-align:center;"><strong>Purchase</strong></td>
                                    <td colspan="5"  style="text-align:center;"><strong>Sales</strong></td>
                                    <td colspan="5"  style="text-align:center;"><strong>Closing stock as on </strong></td>
                                </tr>
                                <tr>
                                    <td align="right">Bundle Qty</td>
                                    <td align="right">Qty</td>
                                    <td align="left">Unit</td>
                                    <td align="right">Rate</td>
                                    <td align="right">TK</td>
                                    <td align="right">Bundle Qty</td>
                                    <td align="right">Qty</td>
                                    <td align="left">Unit</td>
                                    <td align="right"> Rate</td>
                                    <td align="right">TK</td>
                                    <td align="right">Bundle Qty</td>
                                    <td align="right">Qty</td>
                                    <td align="left">Unit</td>
                                    <td align="right">Rate</td>
                                    <td align="right">TK</td>
                                    <td align="right">Bundle Qty</td>
                                    <td align="right">Qty</td>
                                    <td align="left">Unit</td>
                                    <td align="right">Rate</td>
                                    <td align="right">TK</td>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                $tOpenQty = 0; //opening quantity
                                $tOpenPrice = 0; //opening total price
                                $tPurQty = 0; //purchases quantity
                                $tPurPrice = 0; //purchases total price
                                $tSalQty = 0; //sale quantity
                                $tSalPrice = 0; //total sale price
                                $tClosStock = 0; //closing quantity
                                $tClosPrice = 0; //closign total price

                                foreach ($allStock as $key => $eachStock):


                                    // dumpVar($eachStock);

                                    $opInQty = 0;
                                    $closingStockQty = 0;

                                    // if ($eachStock->opStockIn > 0 || $eachInfo->openingAvgPrice > 0 || $eachStock->opStockOut > 0 || $eachStock->currentStockIn > 0 || $eachStock->currentStockOut > 0):
                                    $tOpenQty+=$eachStock->totalOpeningQty;
                                    $tOpenPrice+=$eachStock->totalOpeningPrice; //opening Price
                                    $tPurQty+=$eachStock->totalPurchasesQty;
                                    $tPurPrice+=$eachStock->totalPurchasesPrice; //purchases total price
                                    $tSalQty+=$eachStock->totalSalesQty;
                                    $tSalPrice+=$eachStock->totalSalePrice; //sale price
                                    $closingStockQty = $eachStock->totalClosingQty;
                                    $tClosPrice+=$eachStock->totalClosingPrice;
                                    $tClosStock+=$eachStock->totalClosingQty;
                                    ?>
                                    <tr>
                                        <td><?php echo $key + 1; ?></td>
                                        <td><?php echo $eachStock->pCateogry . ' -  ' . $eachStock->productName . ' [ ' . $eachStock->brandName . ' ]'; ?></td>
                                        <td align="right"><?php
                            if (!empty($eachStock->totalOpeningBundle)) {
                                echo number_format((float) $eachStock->totalOpeningBundle, 2, '.', ',');
                            }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->totalOpeningQty)) {
                                        echo number_format((float) abs($eachStock->totalOpeningQty), 2, '.', ',');
                                    }
                                    ?></td>
                                        <td><?php echo $eachStock->unit; ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->openingAvgPrice)) {
                                        echo number_format((float) abs($eachStock->openingAvgPrice), 2, '.', ',');
                                    }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->totalOpeningPrice)) {
                                        echo number_format((float) abs($eachStock->totalOpeningPrice), 2, '.', ',');
                                    }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->purchasesBundleIn)) {
                                        // echo $eachStock->purchasesBundleIn;
                                        echo number_format((float) $eachStock->purchasesBundleIn, 2, '.', ',');
                                    }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->totalPurchasesQty)) {
                                        echo number_format((float) $eachStock->totalPurchasesQty, 2, '.', ',');
                                    }
                                    ?></td>
                                        <td><?php echo $eachStock->unit; ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->purchasesAvgPrice)) {
                                        echo number_format((float) abs($eachStock->purchasesAvgPrice), 2, '.', ',');
                                    }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->totalPurchasesPrice)) {
                                        echo number_format((float) abs($eachStock->totalPurchasesPrice), 2, '.', ',');
                                    }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->salesBundleOut)) {

                                        echo number_format((float) $eachStock->salesBundleOut, 2, '.', ',');
                                    }
                                    ?></td>

                                        <td align="right"><?php
                                    if (!empty($eachStock->totalSalesQty)) {
                                        echo number_format((float) abs($eachStock->totalSalesQty), 2, '.', ',');
                                    }
                                    ?></td>

                                        <td><?php echo $eachStock->unit; ?></td>

                                        <td align="right"><?php
                                    if (!empty($eachStock->salesAvgPrice)) {
                                        echo number_format((float) abs($eachStock->salesAvgPrice), 2, '.', ',');
                                    }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->totalSalePrice)) {
                                        echo number_format((float) abs($eachStock->totalSalePrice), 2, '.', ',');
                                    }
                                    ?></td>





                                        <td align="right"><?php
                                    if (!empty($eachStock->closingBundleStock)) {

                                        echo number_format((float) $eachStock->closingBundleStock, 2, '.', ',');
                                    }
                                    ?></td>

                                        <td align="right"><?php
                                    if (!empty($eachStock->totalClosingQty)) {

                                        echo number_format((float) abs($eachStock->totalClosingQty), 2, '.', ',');
                                    }
                                    ?></td>

                                        <td><?php echo $eachStock->unit; ?></td>

                                        <td align="right"><?php
                                    if (!empty($eachStock->closingAvgPrice)) {
                                        echo number_format((float) abs($eachStock->closingAvgPrice), 2, '.', ',');
                                    }
                                    ?></td>
                                        <td align="right"><?php
                                    if (!empty($eachStock->totalClosingPrice)) {
                                        echo number_format((float) abs($eachStock->totalClosingPrice), 2, '.', ',');
                                    }
                                    ?></td>
                                    </tr>
                                    <?php
                                    //  endif;
                                endforeach;
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td  align="right" colspan="2"><strong>Total (BDT) </strong></td>
                                    <td align="right" colspan="5"><strong><?php
                            if (!empty($tOpenQty)):
                                echo number_format((float) $tOpenPrice, 2, '.', ',');
                            endif;
                                ?></strong>
                                    </td>
                                    <td align="right" colspan="5"><strong><?php
                                        if (!empty($tPurQty)):
                                            echo number_format((float) $tPurPrice, 2, '.', ',');
                                        endif;
                                ?></strong>
                                    </td>
                                    <td align="right" colspan="5"><strong> <?php
                                        if (!empty($tSalQty)):
                                            echo number_format((float) $tSalPrice, 2, '.', ',');
                                        endif;
                                ?></strong>
                                    </td>
                                    <td align="right" colspan="5"><strong> <?php
                                        if (!empty($tClosStock)):
                                            echo number_format((float) $tClosPrice, 2, '.', ',');
                                        endif;
                                ?></strong>
                                    </td>
                                </tr>
                            </tfoot>

                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

